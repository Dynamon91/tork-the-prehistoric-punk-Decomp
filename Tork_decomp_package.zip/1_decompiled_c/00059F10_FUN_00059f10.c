// func FUN_00059f10 @ 0x00059F10 (size 0x4E)

undefined4 FUN_00059f10(void)

{
  undefined4 uVar1;
  int iVar2;
  int in_ECX;
  
  FUN_0012ebe2(*(undefined4 *)(in_ECX + 0x18),0xffffffff);
  uVar1 = *(undefined4 *)(*(int *)(in_ECX + 4) + *(int *)(in_ECX + 8) * 4);
  iVar2 = *(int *)(in_ECX + 8) + 1;
  *(int *)(in_ECX + 8) = iVar2;
  if (*(int *)(in_ECX + 0x14) <= iVar2) {
    *(int *)(in_ECX + 8) = iVar2 - *(int *)(in_ECX + 0x14);
  }
  iVar2 = *(int *)(in_ECX + 0x10) + -1;
  *(int *)(in_ECX + 0x10) = iVar2;
  if (iVar2 == 0) {
    FUN_0012e776(*(undefined4 *)(in_ECX + 0x1c));
  }
  FUN_0012e945(*(undefined4 *)(in_ECX + 0x18));
  return uVar1;
}


