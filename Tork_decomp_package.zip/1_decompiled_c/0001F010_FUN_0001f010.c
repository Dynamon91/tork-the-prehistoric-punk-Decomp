// func FUN_0001f010 @ 0x0001F010 (size 0x351)

void FUN_0001f010(void)

{
  byte bVar1;
  byte *pbVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  code *pcVar7;
  undefined4 **ppuVar8;
  int in_ECX;
  undefined4 *puVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  float10 fVar14;
  undefined1 local_3d;
  int local_3c;
  undefined4 local_34;
  int local_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 *apuStack_20 [4];
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  pbVar2 = *(byte **)(in_ECX + 0x3c);
  iVar3 = *(int *)(in_ECX + 0x20);
  *(byte **)(in_ECX + 0x3c) = pbVar2 + 4;
  bVar1 = *pbVar2;
  iVar4 = *(int *)(in_ECX + 0x30);
  iVar5 = *(int *)(in_ECX + 0xc);
  iVar6 = *(int *)(in_ECX + 0x34);
  if (iVar4 != iVar5) {
    local_34 = *(undefined4 *)(in_ECX + 0x14);
    *(undefined4 *)(in_ECX + 0x14) = *(undefined4 *)(in_ECX + 0x10);
    *(int *)(in_ECX + 0x30) = iVar5;
    local_3c = iVar4;
  }
  if (iVar6 != iVar3) {
    local_3d = *(undefined1 *)(in_ECX + 0x38);
    *(int *)(in_ECX + 0x34) = iVar3;
    *(undefined1 *)(in_ECX + 0x38) = *(undefined1 *)(in_ECX + 0x19);
    local_30 = iVar6;
  }
  uVar10 = (uint)(byte)(&DAT_00225fe8)
                       [(int)((*(ushort *)(pbVar2 + 2) >> 9 & 0x70) + (bVar1 & 0xe)) >> 1];
  if (uVar10 != 0) {
    uVar13 = uVar10;
    do {
      (**(code **)(&DAT_00241540 + (*(byte *)(*(int *)(in_ECX + 0x3c) + 1) & 0x3f) * 0x10))();
      uVar13 = uVar13 - 1;
    } while (uVar13 != 0);
  }
  if (iVar4 != iVar5) {
    *(int *)(in_ECX + 0x30) = local_3c;
    *(undefined4 *)(in_ECX + 0x14) = local_34;
  }
  if (iVar6 != iVar3) {
    *(int *)(in_ECX + 0x34) = local_30;
    *(undefined1 *)(in_ECX + 0x38) = local_3d;
  }
  uVar13 = bVar1 & 0x70;
  if (uVar13 == 0x70) {
    apuStack_20[0] = &uStack_2c;
  }
  uVar12 = (uint)(uVar13 == 0x70);
  if (-1 < (int)(uVar10 - 1)) {
    ppuVar8 = apuStack_20 + (uVar10 - 1) + uVar12;
    uVar11 = uVar10;
    do {
      puVar9 = (undefined4 *)(*(int *)(in_ECX + 8) + -4);
      *(undefined4 **)(in_ECX + 8) = puVar9;
      *ppuVar8 = (undefined4 *)*puVar9;
      ppuVar8 = ppuVar8 + -1;
      uVar11 = uVar11 - 1;
    } while (uVar11 != 0);
  }
  pcVar7 = *(code **)(in_ECX + 0x44 + (*(ushort *)(pbVar2 + 2) & 0x1fff) * 4);
  if (uVar13 == 0x60) {
    switch(uVar10) {
    case 0:
      fVar14 = (float10)(*pcVar7)();
      break;
    case 1:
      fVar14 = (float10)(*pcVar7)(apuStack_20[0]);
      break;
    case 2:
      fVar14 = (float10)(*pcVar7)(apuStack_20[0],apuStack_20[1]);
      break;
    case 3:
      fVar14 = (float10)(*pcVar7)(apuStack_20[0],apuStack_20[1],apuStack_20[2]);
      break;
    case 4:
      fVar14 = (float10)(*pcVar7)(apuStack_20[0],apuStack_20[1],apuStack_20[2],apuStack_20[3]);
      break;
    case 5:
      fVar14 = (float10)(*pcVar7)(apuStack_20[0],apuStack_20[1],apuStack_20[2],apuStack_20[3],
                                  uStack_10);
      break;
    case 6:
      fVar14 = (float10)(*pcVar7)(apuStack_20[0],apuStack_20[1],apuStack_20[2],apuStack_20[3],
                                  uStack_10,uStack_c);
      break;
    default:
      fVar14 = (float10)1.34525e-43;
    }
    if ((char)bVar1 < '\0') {
      **(float **)(in_ECX + 8) = (float)fVar14;
      *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
      *(undefined4 *)(in_ECX + 0x30) = *(undefined4 *)(in_ECX + 0xc);
      return;
    }
  }
  else {
    switch(uVar10 + uVar12) {
    case 0:
      uVar10 = (*pcVar7)();
      break;
    case 1:
      uVar10 = (*pcVar7)(apuStack_20[0]);
      break;
    case 2:
      uVar10 = (*pcVar7)(apuStack_20[0],apuStack_20[1]);
      break;
    case 3:
      uVar10 = (*pcVar7)(apuStack_20[0],apuStack_20[1],apuStack_20[2]);
      break;
    case 4:
      uVar10 = (*pcVar7)(apuStack_20[0],apuStack_20[1],apuStack_20[2],apuStack_20[3]);
      break;
    case 5:
      uVar10 = (*pcVar7)(apuStack_20[0],apuStack_20[1],apuStack_20[2],apuStack_20[3],uStack_10);
      break;
    case 6:
      uVar10 = (*pcVar7)(apuStack_20[0],apuStack_20[1],apuStack_20[2],apuStack_20[3],uStack_10,
                         uStack_c);
      break;
    default:
      uVar10 = uVar13;
    }
    if (uVar13 == 0x30) {
      uVar10 = uVar10 & 0xff;
    }
    else if (uVar13 == 0x40) {
      uVar10 = uVar10 & 0xffff;
    }
    else if (uVar13 == 0x20) {
      uVar10 = uVar10 & 1;
    }
    if ((char)bVar1 < '\0') {
      if (uVar13 == 0x70) {
        **(undefined4 **)(in_ECX + 8) = uStack_2c;
        *(undefined4 *)(*(int *)(in_ECX + 8) + 4) = uStack_28;
        *(undefined4 *)(*(int *)(in_ECX + 8) + 8) = uStack_24;
        *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 0xc;
        *(undefined4 *)(in_ECX + 0x30) = *(undefined4 *)(in_ECX + 0xc);
        return;
      }
      **(uint **)(in_ECX + 8) = uVar10;
      *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
      *(undefined4 *)(in_ECX + 0x30) = *(undefined4 *)(in_ECX + 0xc);
      return;
    }
  }
  *(undefined4 *)(in_ECX + 0x30) = *(undefined4 *)(in_ECX + 0xc);
  return;
}


