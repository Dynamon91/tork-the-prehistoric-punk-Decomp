// func FUN_00058bb0 @ 0x00058BB0 (size 0x49)

void FUN_00058bb0(void)

{
  int in_ECX;
  
  FUN_0012ebe2(*(undefined4 *)(in_ECX + 0x18),0xffffffff);
  *(int *)(in_ECX + 0x34) = *(int *)(in_ECX + 0x34) - *(int *)(in_ECX + 0x10);
  if (*(int *)(in_ECX + 0x34) == 0) {
    FUN_0012e776(*(undefined4 *)(in_ECX + 0x1c));
  }
  *(undefined4 *)(in_ECX + 0x10) = 0;
  *(undefined4 *)(in_ECX + 0xc) = 0;
  *(undefined4 *)(in_ECX + 8) = 0;
  FUN_0012e945(*(undefined4 *)(in_ECX + 0x18));
  return;
}


