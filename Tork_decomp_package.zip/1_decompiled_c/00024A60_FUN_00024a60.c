// func FUN_00024a60 @ 0x00024A60 (size 0x30)

void FUN_00024a60(float *param_1,float param_2)

{
  *param_1 = param_2 * *param_1;
  *(ulonglong *)(param_1 + 1) =
       CONCAT44(param_2 * (float)((ulonglong)*(undefined8 *)(param_1 + 1) >> 0x20),
                param_2 * (float)*(undefined8 *)(param_1 + 1));
  return;
}


