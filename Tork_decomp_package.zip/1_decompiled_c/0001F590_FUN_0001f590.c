// func FUN_0001f590 @ 0x0001F590 (size 0x10B)

void FUN_0001f590(void)

{
  byte bVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int in_ECX;
  uint uVar5;
  byte bVar6;
  byte bVar7;
  int iVar8;
  int iVar9;
  undefined4 uStack_8;
  int local_4;
  
  iVar9 = *(int *)(in_ECX + 0x3c);
  *(int **)(in_ECX + 0x3c) = (int *)(iVar9 + 4);
  bVar6 = *(byte *)(iVar9 + 2) & 1;
  if (bVar6 == 0) {
    iVar8 = local_4;
  }
  else {
    iVar8 = *(int *)(iVar9 + 4);
    *(int *)(in_ECX + 0x3c) = iVar9 + 8;
  }
  bVar1 = *(byte *)(iVar9 + 2) >> 1 & 1;
  if (bVar1 != 0) {
    (**(code **)(&DAT_00241540 + (*(byte *)(*(int *)(in_ECX + 0x3c) + 1) & 0x3f) * 0x10))();
    uStack_8 = *(undefined4 *)(in_ECX + 0x14);
    local_4 = *(int *)(in_ECX + 0x30);
    piVar2 = (int *)(*(int *)(in_ECX + 8) + -4);
    *(int **)(in_ECX + 8) = piVar2;
    iVar9 = *piVar2;
    *(int *)(in_ECX + 0x14) = iVar9;
    if ((*(uint *)(iVar9 + 4) >> 0xc & 1) == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = *(undefined4 *)(*(int *)(iVar9 + 0x24) + 4);
    }
    *(undefined4 *)(in_ECX + 0x30) = uVar3;
  }
  if (bVar6 == 0) {
    iVar9 = local_4;
    bVar7 = bVar1;
  }
  else {
    uVar5 = (uint)*(byte *)(*(int *)(in_ECX + 0x30) + 1);
    iVar4 = 0;
    if (uVar5 != 0) {
      piVar2 = (int *)(*(int *)(in_ECX + 0x30) + 8);
      do {
        if (*piVar2 == iVar8) goto LAB_0001f63e;
        iVar4 = iVar4 + 1;
        piVar2 = piVar2 + 1;
      } while (iVar4 < (int)uVar5);
    }
    iVar4 = 0xff;
LAB_0001f63e:
    iVar9 = *(int *)(in_ECX + 0x34);
    bVar7 = *(byte *)(in_ECX + 0x38);
    *(int *)(in_ECX + 0x34) = iVar8;
    *(char *)(in_ECX + 0x38) = (char)iVar4;
  }
  (**(code **)(&DAT_00241540 + (*(byte *)(*(int *)(in_ECX + 0x3c) + 1) & 0x3f) * 0x10))();
  if (bVar6 != 0) {
    *(int *)(in_ECX + 0x34) = iVar9;
    *(byte *)(in_ECX + 0x38) = bVar7;
  }
  if (bVar1 != 0) {
    *(undefined4 *)(in_ECX + 0x14) = uStack_8;
    *(int *)(in_ECX + 0x30) = local_4;
  }
  return;
}


