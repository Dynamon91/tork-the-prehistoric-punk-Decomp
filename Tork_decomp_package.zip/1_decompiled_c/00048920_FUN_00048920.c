// func FUN_00048920 @ 0x00048920 (size 0x41)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00048920(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined *puVar3;
  
  puVar3 = &DAT_00238808;
  uVar2 = 0;
  _DAT_00222f2c = param_1;
  uVar1 = FUN_0005aba0(0,&DAT_00238808);
  FUN_000112c0(uVar1,uVar2,puVar3);
  (&DAT_000059f4)[DAT_0022d4c0] = 1;
  return;
}


