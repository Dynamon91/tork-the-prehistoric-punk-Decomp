// func FUN_00054b00 @ 0x00054B00 (size 0x24)

undefined4 FUN_00054b00(undefined4 *param_1)

{
  ushort *in_EAX;
  
  if ((int)(uint)*in_EAX < (int)(in_EAX[1] - 1)) {
    *(undefined4 *)(in_EAX + (uint)*in_EAX * 2 + 3) = *param_1;
    *in_EAX = *in_EAX + 1;
    return 0;
  }
  return 0xffffffff;
}


