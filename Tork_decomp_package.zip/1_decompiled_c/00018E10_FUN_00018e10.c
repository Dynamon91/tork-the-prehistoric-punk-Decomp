// func FUN_00018e10 @ 0x00018E10 (size 0x157)

void FUN_00018e10(undefined4 *param_1,undefined *param_2,undefined4 param_3)

{
  int in_EAX;
  undefined *puVar1;
  uint uVar2;
  int iVar3;
  bool bVar4;
  bool bVar5;
  
  puVar1 = (undefined *)*param_1;
  if ((puVar1 < (undefined *)(in_EAX + 0x44)) || (&DAT_00002044 + in_EAX <= puVar1)) {
LAB_00018e60:
    iVar3 = -1;
LAB_00018e63:
    bVar4 = iVar3 == -1;
  }
  else {
    puVar1 = puVar1 + (-0x44 - in_EAX);
    uVar2 = (uint)puVar1 & 0x8000001f;
    bVar4 = uVar2 == 0;
    if ((int)uVar2 < 0) {
      bVar4 = (uVar2 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (!bVar4) goto LAB_00018e60;
    iVar3 = (int)(puVar1 + ((int)puVar1 >> 0x1f & 0x1f)) >> 5;
    bVar4 = iVar3 == -1;
    if (!bVar4) {
      if (*(undefined4 **)(&DAT_00002064 + iVar3 * 4 + in_EAX) != param_1) goto LAB_00018e60;
      goto LAB_00018e63;
    }
  }
  if (((undefined *)(in_EAX + 0x44) <= param_2) && (param_2 < &DAT_00002044 + in_EAX)) {
    puVar1 = param_2 + (-0x44 - in_EAX);
    uVar2 = (uint)puVar1 & 0x8000001f;
    bVar5 = uVar2 == 0;
    if ((int)uVar2 < 0) {
      bVar5 = (uVar2 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (bVar5) {
      iVar3 = (int)(puVar1 + ((int)puVar1 >> 0x1f & 0x1f)) >> 5;
      goto LAB_00018e9f;
    }
  }
  iVar3 = -1;
LAB_00018e9f:
  if ((iVar3 == -1) || (*(int *)(&DAT_00002064 + iVar3 * 4 + in_EAX) != 0)) {
    bVar5 = false;
  }
  else {
    bVar5 = true;
  }
  if (bVar4) {
    if (bVar5) {
      FUN_000197b0(param_3);
      return;
    }
    if (iVar3 == -1) {
      *param_1 = param_2;
      return;
    }
    FUN_00134fe8(param_2,param_3);
    iVar3 = FUN_000196d0(param_3);
  }
  else {
    if (bVar5) {
      FUN_00019750();
      FUN_000197b0(param_3);
      return;
    }
    iVar3 = FUN_00134fe8(param_2,param_3);
    iVar3 = FUN_00019830(param_1,iVar3 * 2 + 2,param_3);
  }
  FUN_00134fcc(iVar3 * 0x20 + 0x44 + in_EAX,param_2);
  return;
}


