// func FUN_00043950 @ 0x00043950 (size 0x2F)

uint FUN_00043950(void)

{
  uint uVar1;
  int in_ECX;
  
  if ((((*(uint *)(in_ECX + 4) >> 8 & 1) == 0) || ((*(uint *)(in_ECX + 4) >> 0x16 & 1) == 0)) ||
     (uVar1 = *(uint *)(*(int *)(in_ECX + 0x24) + 8), uVar1 == 0)) {
    return 0;
  }
  return uVar1 & (*(short *)(uVar1 + 2) != 2) - 1;
}


