// func FUN_00055220 @ 0x00055220 (size 0x8C)

void FUN_00055220(void)

{
  int iVar1;
  uint uVar2;
  uint *puVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int *unaff_EBX;
  
  iVar1 = *unaff_EBX;
  uVar2 = 1 << ((byte)iVar1 & 0x1f);
  puVar3 = (uint *)(unaff_EBX + (iVar1 >> 5) + 1);
  uVar6 = *puVar3;
  iVar5 = iVar1;
  while (iVar5 < 0x100) {
    if ((uVar2 & uVar6) == 0) {
      *unaff_EBX = iVar5;
      return;
    }
    iVar5 = iVar5 + 1;
    if (uVar2 == 0x80000000) {
      uVar6 = puVar3[1];
      puVar3 = puVar3 + 1;
      uVar2 = 1;
    }
    else {
      uVar2 = uVar2 << 1;
    }
  }
  uVar6 = unaff_EBX[1];
  iVar5 = 0;
  piVar4 = unaff_EBX + 1;
  uVar2 = 1;
  if (0 < iVar1) {
    while ((uVar2 & uVar6) != 0) {
      iVar5 = iVar5 + 1;
      if (uVar2 == 0x80000000) {
        uVar6 = piVar4[1];
        piVar4 = piVar4 + 1;
        uVar2 = 1;
      }
      else {
        uVar2 = uVar2 << 1;
      }
      if (*unaff_EBX <= iVar5) {
        return;
      }
    }
    *unaff_EBX = iVar5;
  }
  return;
}


