// func FUN_0004a2d0 @ 0x0004A2D0 (size 0x54)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0004a2d0(void)

{
  undefined4 *in_EAX;
  int unaff_ESI;
  float10 fVar1;
  
  *(undefined4 *)(unaff_ESI + 0x3c) = *in_EAX;
  *(undefined4 *)(unaff_ESI + 0x40) = in_EAX[1];
  *(undefined4 *)(unaff_ESI + 0x44) = in_EAX[2];
  fVar1 = (float10)FUN_00021640();
  if ((float10)_DAT_0020e0c0 < fVar1) {
    *(ushort *)(unaff_ESI + 10) = *(ushort *)(unaff_ESI + 10) ^ (*(byte *)(unaff_ESI + 10) ^ 4) & 4;
    return;
  }
  *(ushort *)(unaff_ESI + 10) = *(ushort *)(unaff_ESI + 10) ^ *(byte *)(unaff_ESI + 10) & 4;
  return;
}


