// func FUN_00018650 @ 0x00018650 (size 0x116)

void FUN_00018650(int param_1,int param_2)

{
  byte bVar1;
  int in_EAX;
  byte bVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  
  iVar4 = param_1 >> 5;
  iVar6 = param_2 >> 5;
  bVar2 = (byte)param_1 & 0x1f;
  bVar1 = (byte)param_2 & 0x1f;
  if (iVar4 == iVar6) {
    *(uint *)(&DAT_00004010 + iVar4 * 4 + in_EAX) =
         *(uint *)(&DAT_00004010 + iVar4 * 4 + in_EAX) &
         (~((1 << (bVar1 + 1 & 0x1f)) - 1U) - 1) + (1 << bVar2);
  }
  else {
    *(uint *)(&DAT_00004010 + iVar4 * 4 + in_EAX) =
         *(uint *)(&DAT_00004010 + iVar4 * 4 + in_EAX) & (1 << bVar2) - 1U;
    while ((iVar4 = iVar4 + 1, iVar4 != iVar6 && ((iVar4 != 0x40 || (iVar4 = 0, iVar6 != 0))))) {
      *(undefined4 *)(&DAT_00004010 + iVar4 * 4 + in_EAX) = 0;
    }
    *(uint *)(&DAT_00004010 + iVar6 * 4 + in_EAX) =
         *(uint *)(&DAT_00004010 + iVar6 * 4 + in_EAX) & ~((1 << (bVar1 + 1 & 0x1f)) - 1U);
  }
  if ((*(int *)(&DAT_00002008 + in_EAX) == param_1) &&
     (uVar5 = param_2 + 1U & 0x7ff, *(uint *)(&DAT_00002008 + in_EAX) = uVar5,
     (*(uint *)(&DAT_00004010 + ((int)uVar5 >> 5) * 4 + in_EAX) & 1 << ((byte)(param_2 + 1U) & 0x1f)
     ) == 0)) {
    do {
      if (*(int *)(&DAT_00002008 + in_EAX) == *(int *)(&DAT_0000200c + in_EAX)) {
        return;
      }
      uVar5 = *(int *)(&DAT_00002008 + in_EAX) + 1;
      uVar3 = uVar5 & 0x7ff;
      *(uint *)(&DAT_00002008 + in_EAX) = uVar3;
    } while ((*(uint *)(&DAT_00004010 + ((int)uVar3 >> 5) * 4 + in_EAX) & 1 << ((byte)uVar5 & 0x1f))
             == 0);
  }
  return;
}


