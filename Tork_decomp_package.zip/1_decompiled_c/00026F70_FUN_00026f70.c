// func FUN_00026f70 @ 0x00026F70 (size 0x55)

void FUN_00026f70(float *param_1)

{
  float local_18;
  undefined8 local_14;
  float local_c;
  undefined8 local_8;
  
  FUN_00094610(*(undefined4 *)(*(int *)(DAT_0022a6c4 + 0x14) + 0x14));
  *param_1 = local_c - local_18;
  *(ulonglong *)(param_1 + 1) =
       CONCAT44((float)((ulonglong)local_8 >> 0x20) - (float)((ulonglong)local_14 >> 0x20),
                (float)local_8 - (float)local_14);
  return;
}


