// func FUN_00043870 @ 0x00043870 (size 0xA3)

undefined4 FUN_00043870(undefined2 param_1,char param_2)

{
  ushort *puVar1;
  byte bVar2;
  undefined2 uVar3;
  short *psVar4;
  int iVar5;
  int in_EAX;
  undefined4 uVar6;
  undefined2 extraout_var;
  
  puVar1 = (ushort *)(in_EAX + 4);
  if (*(int *)(in_EAX + 0x10 + (uint)*(ushort *)(in_EAX + 4) * 8) == 0) {
    uVar6 = FUN_000ffd80();
    *(undefined4 *)(in_EAX + 0x10 + (uint)*puVar1 * 8) = uVar6;
    if (param_2 == '\0') {
      psVar4 = *(short **)(in_EAX + 0x10 + (uint)*puVar1 * 8);
      *psVar4 = *psVar4 + 1;
    }
  }
  FUN_000ffe10();
  iVar5 = *(int *)(in_EAX + 0x10 + (uint)*puVar1 * 8);
  bVar2 = *(byte *)(iVar5 + 4);
  *(byte *)(iVar5 + 4) = bVar2 ^ (param_2 << 3 ^ bVar2) & 8;
  *(undefined2 *)(*(int *)(in_EAX + 0x10 + (uint)*puVar1 * 8) + 0x14) = param_1;
  *(ushort *)(*(int *)(in_EAX + 0x10 + (uint)*puVar1 * 8) + 0x16) = *puVar1;
  FUN_00043810(puVar1);
  *(short *)(in_EAX + 8) = *(short *)(in_EAX + 8) + -1;
  *(short *)(in_EAX + 10) = *(short *)(in_EAX + 10) + 1;
  uVar3 = *(undefined2 *)(in_EAX + 6);
  if (param_2 != '\0') {
    *(short *)(&DAT_0000200c + in_EAX) = *(short *)(&DAT_0000200c + in_EAX) + 1;
  }
  return CONCAT22(extraout_var,uVar3);
}


