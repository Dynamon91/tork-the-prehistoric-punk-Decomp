// func FUN_0004d1d0 @ 0x0004D1D0 (size 0xD2)

void FUN_0004d1d0(void)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float *in_EAX;
  
  fVar1 = in_EAX[0xc];
  fVar2 = in_EAX[0xe];
  fVar3 = in_EAX[0xc];
  in_EAX[0xc] = -(in_EAX[0xc] * *in_EAX + in_EAX[0xe] * in_EAX[2] + in_EAX[0xd] * in_EAX[1]);
  in_EAX[0xe] = -(in_EAX[8] * fVar1 + in_EAX[9] * in_EAX[0xd] + in_EAX[10] * in_EAX[0xe]);
  in_EAX[0xd] = -(in_EAX[4] * fVar3 + in_EAX[5] * in_EAX[0xd] + in_EAX[6] * fVar2);
  fVar1 = in_EAX[1];
  in_EAX[1] = in_EAX[4];
  in_EAX[4] = fVar1;
  fVar1 = in_EAX[2];
  in_EAX[2] = in_EAX[8];
  in_EAX[8] = fVar1;
  fVar1 = in_EAX[6];
  in_EAX[6] = in_EAX[9];
  in_EAX[9] = fVar1;
  in_EAX[0xf] = 1.0;
  in_EAX[0xb] = 0.0;
  in_EAX[7] = 0.0;
  in_EAX[3] = 0.0;
  return;
}


