// func FUN_00053b70 @ 0x00053B70 (size 0x7B)

void FUN_00053b70(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  if ((*(uint *)(param_2 + 4) >> 1 & 1) == 0) {
    param_1[10] = 0x3f800000;
    param_1[5] = 0x3f800000;
    *param_1 = 0x3f800000;
    param_1[0xe] = 0;
    param_1[0xd] = 0;
    param_1[0xc] = 0;
    param_1[9] = 0;
    param_1[8] = 0;
    param_1[6] = 0;
    param_1[4] = 0;
    param_1[2] = 0;
    param_1[1] = 0;
    param_1[0xb] = 0;
    param_1[7] = 0;
    param_1[3] = 0;
    param_1[0xf] = 0x3f800000;
    puVar1 = *(undefined4 **)(param_2 + 0x10);
    if ((*(byte *)(param_2 + 4) & 2) != 0) {
      puVar1 = puVar1 + 0xc;
    }
    param_1[0xc] = *puVar1;
    param_1[0xd] = puVar1[1];
    param_1[0xe] = puVar1[2];
    return;
  }
  puVar1 = *(undefined4 **)(param_2 + 0x10);
  for (iVar2 = 0x10; iVar2 != 0; iVar2 = iVar2 + -1) {
    *param_1 = *puVar1;
    puVar1 = puVar1 + 1;
    param_1 = param_1 + 1;
  }
  return;
}


