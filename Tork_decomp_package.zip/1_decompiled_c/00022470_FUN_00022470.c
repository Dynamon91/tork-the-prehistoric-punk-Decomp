// func FUN_00022470 @ 0x00022470 (size 0x12)

void FUN_00022470(void)

{
  FUN_000241a0();
  return;
}


