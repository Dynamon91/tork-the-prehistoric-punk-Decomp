// func FUN_0001a9c0 @ 0x0001A9C0 (size 0x38)

undefined4 FUN_0001a9c0(void)

{
  int iVar1;
  uint in_EAX;
  int in_ECX;
  
  iVar1 = in_ECX + (in_EAX >> 0x17) * 0x18;
  if ((*(int *)(iVar1 + 0xc) == 0) || (*(uint *)(iVar1 + 0x10) < 2)) {
    FUN_0005fe30(in_ECX,in_EAX);
  }
  iVar1 = *(int *)(*(int *)(iVar1 + 0xc) + 0x18);
  return CONCAT22((short)((uint)iVar1 >> 0x10),
                  *(undefined2 *)(iVar1 + 4 + (in_EAX & 0x7fffff) * 0xc));
}


