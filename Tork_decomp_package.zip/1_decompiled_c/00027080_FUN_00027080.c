// func FUN_00027080 @ 0x00027080 (size 0x61)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00027080(float *param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float *pfVar5;
  
  pfVar5 = *(float **)(*(int *)(DAT_0022a6c4 + 0x14) + 0x28);
  fVar1 = pfVar5[4];
  fVar2 = pfVar5[1];
  fVar3 = pfVar5[5];
  fVar4 = pfVar5[2];
  *param_1 = (pfVar5[3] + *pfVar5) * _DAT_0020df84;
  param_1[1] = (fVar1 + fVar2) * _DAT_0020df84;
  param_1[2] = (fVar3 + fVar4) * _DAT_0020df84;
  return;
}


