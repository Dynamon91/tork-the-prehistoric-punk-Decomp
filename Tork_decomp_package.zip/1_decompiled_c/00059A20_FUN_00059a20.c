// func FUN_00059a20 @ 0x00059A20 (size 0x8D)

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_00059a20(void)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  char *pcVar4;
  char local_210 [516];
  undefined4 local_c;
  
  local_c = DAT_002264b0;
  iVar2 = 0x80;
  pcVar4 = local_210;
  while (puVar3 = DAT_0022aabc, iVar2 != 0) {
    iVar2 = iVar2 + -1;
    builtin_strncpy(pcVar4,"\x01\x01\x01\x01",4);
    pcVar4 = pcVar4 + 4;
  }
  while (puVar3 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*puVar3;
    local_210[(int)(puVar3 + -0x8aab0) / 0x14] = '\0';
    puVar3 = puVar1;
  }
  iVar2 = 0;
  puVar3 = &DAT_0022aac0;
  do {
    if (local_210[iVar2] != '\0') {
      FUN_00059b00();
    }
    puVar3 = puVar3 + 5;
    iVar2 = iVar2 + 1;
  } while ((int)puVar3 < 0x22d2c0);
  return;
}


