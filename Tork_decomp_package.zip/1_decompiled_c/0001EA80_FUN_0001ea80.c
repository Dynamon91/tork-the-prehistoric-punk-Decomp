// func FUN_0001ea80 @ 0x0001EA80 (size 0x550)

void FUN_0001ea80(void)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  ushort uVar4;
  short sVar5;
  byte *pbVar6;
  undefined1 *puVar7;
  undefined2 *puVar8;
  byte bVar9;
  byte bVar10;
  char cVar11;
  uint uVar12;
  undefined4 uVar13;
  byte bVar14;
  int *in_ECX;
  int iVar15;
  int iVar16;
  int *piVar17;
  uint uVar18;
  undefined4 *puVar19;
  undefined4 *puVar20;
  undefined1 local_2a;
  byte local_28;
  int local_24;
  int local_20;
  undefined4 uStack_1c;
  undefined4 local_18;
  int local_14;
  int aiStack_10 [4];
  
  pbVar6 = (byte *)in_ECX[0xf];
  bVar1 = pbVar6[3];
  bVar2 = *pbVar6;
  bVar3 = pbVar6[2];
  iVar15 = in_ECX[2] - *in_ECX >> 2;
  bVar14 = bVar2 & 0x40;
  in_ECX[0xf] = (int)(pbVar6 + 4);
  if (bVar14 != 0) {
    local_18 = *(undefined4 *)(pbVar6 + 4);
    in_ECX[0xf] = (int)(pbVar6 + 8);
  }
  bVar9 = bVar2 >> 4 & 1;
  bVar10 = bVar2 >> 3 & 1;
  local_14 = iVar15;
  if (bVar10 != 0) {
    local_20 = in_ECX[4];
    (**(code **)(&DAT_00241540 + (*(byte *)(in_ECX[0xf] + 1) & 0x3f) * 0x10))();
    iVar15 = in_ECX[2];
    in_ECX[2] = iVar15 + -4;
    uStack_1c = *(uint *)(iVar15 + -4);
    local_24 = *(int *)in_ECX[0xf];
    in_ECX[0xf] = (int)((int *)in_ECX[0xf] + 1);
    iVar15 = *(int *)(*(int *)(uStack_1c + 0x24) + 4);
    uVar12 = (uint)*(byte *)(iVar15 + 1);
    if (uVar12 != 0) {
      piVar17 = (int *)(iVar15 + 8);
      iVar16 = 0;
      do {
        if (*piVar17 == local_24) {
          local_28 = *(byte *)((int)in_ECX + 0x19);
          iVar15 = in_ECX[8];
          local_2a = (undefined1)iVar16;
          goto LAB_0001eb71;
        }
        iVar16 = iVar16 + 1;
        piVar17 = piVar17 + 1;
      } while (iVar16 < (int)uVar12);
    }
    local_28 = *(byte *)((int)in_ECX + 0x19);
    iVar15 = in_ECX[8];
    local_2a = 0xff;
  }
LAB_0001eb71:
  if (bVar9 != 0) {
    local_24 = *(int *)in_ECX[0xf];
    local_28 = *(byte *)((int)in_ECX + 0x19);
    iVar15 = in_ECX[8];
    in_ECX[0xf] = (int)((int *)in_ECX[0xf] + 1);
    local_2a = 0xff;
  }
  if (bVar14 != 0) {
    uVar12 = (uint)bVar1;
    if (uVar12 != 0) {
      uVar18 = uVar12;
      do {
        (**(code **)(&DAT_00241540 + (*(byte *)(in_ECX[0xf] + 1) & 0x3f) * 0x10))();
        uVar18 = uVar18 - 1;
      } while (uVar18 != 0);
    }
    while (uVar12 = uVar12 - 1, -1 < (int)uVar12) {
      iVar16 = in_ECX[2];
      in_ECX[2] = iVar16 + -4;
      aiStack_10[uVar12] = *(int *)(iVar16 + -4);
    }
  }
  if ((bVar9 != 0) || (bVar10 != 0)) {
    *(int *)in_ECX[2] = iVar15;
    iVar15 = in_ECX[2];
    in_ECX[2] = iVar15 + 4;
    *(uint *)(iVar15 + 4) = (uint)local_28;
    iVar15 = in_ECX[2];
    in_ECX[2] = iVar15 + 4;
    if (bVar10 != 0) {
      *(int *)(iVar15 + 4) = local_20;
      in_ECX[2] = in_ECX[2] + 4;
    }
  }
  uVar12 = bVar2 & 7;
  if ((bVar2 & 7) != 0) {
    do {
      (**(code **)(&DAT_00241540 + (*(byte *)(in_ECX[0xf] + 1) & 0x3f) * 0x10))();
      uVar12 = uVar12 - 1;
    } while (uVar12 != 0);
  }
  *(int *)in_ECX[2] = in_ECX[0xf];
  iVar15 = in_ECX[2];
  in_ECX[2] = iVar15 + 4;
  *(int *)(iVar15 + 4) = in_ECX[0xb];
  iVar15 = in_ECX[2];
  in_ECX[2] = iVar15 + 4;
  if (in_ECX[10] == 0) {
    uVar12 = (uint)*(byte *)((int)in_ECX + 0x1a);
  }
  else {
    uVar12 = *(byte *)((int)in_ECX + 0x1b) + 0x1000000;
  }
  if (bVar9 != 0) {
    uVar12 = uVar12 | 0x2000000;
  }
  if (bVar10 != 0) {
    uVar12 = uVar12 | 0x4000000;
  }
  *(uint *)(iVar15 + 4) = uVar12 + 0xf0000000;
  in_ECX[2] = in_ECX[2] + 4;
  if ((bVar9 != 0) || (bVar10 != 0)) {
    in_ECX[0xd] = local_24;
    in_ECX[8] = local_24;
    *(undefined1 *)(in_ECX + 0xe) = local_2a;
    *(undefined1 *)((int)in_ECX + 0x19) = local_2a;
    if (bVar10 != 0) {
      in_ECX[5] = uStack_1c;
      in_ECX[4] = uStack_1c;
      iVar15 = *(int *)(*(int *)(uStack_1c + 0x24) + 4);
      in_ECX[0xc] = iVar15;
      in_ECX[3] = iVar15;
    }
    local_2a = *(undefined1 *)((int)in_ECX + 0x229e);
    *(undefined1 *)((int)in_ECX + 0x229e) = 0;
    if (bVar10 != 0) {
      local_28 = *(byte *)(in_ECX + 6);
      iVar15 = in_ECX[3];
      if (((uint)*(ushort *)(iVar15 + 2) & 1 << (local_28 & 0x1f)) == 0) {
        *(undefined1 *)(in_ECX + 6) = 0;
      }
      uVar4 = *(ushort *)(iVar15 + 0x6e + (uint)*(byte *)(in_ECX + 6) * 8);
      uStack_1c = (uint)uVar4;
      iVar15 = iVar15 + (uint)*(byte *)(in_ECX + 6) * 8;
      if (uVar4 != 0xffff) {
        local_20 = iVar15 + 0x6a;
        *(undefined2 *)(iVar15 + 0x6e) = 0xffff;
      }
    }
  }
  iVar15 = in_ECX[3];
  *(byte *)((int)in_ECX + 0x1b) = bVar3;
  iVar16 = *(int *)(*(int *)(in_ECX[8] + 0x10) + (uint)bVar3 * 4);
  in_ECX[0xf] = iVar16;
  in_ECX[10] = iVar16;
  in_ECX[0xb] = in_ECX[2];
  in_ECX[2] = in_ECX[2] + (uint)*(ushort *)in_ECX[0xf] * 4;
  bVar3 = *(byte *)(in_ECX + 6);
  in_ECX[0xf] = (int)((ushort *)in_ECX[0xf] + 2);
  if ((bVar2 & 0x20) == 0) {
    iVar16 = iVar15 + (uint)bVar3 * 8;
    if ((*(short *)(iVar15 + 0x6e + (uint)bVar3 * 8) == -1) ||
       (sVar5 = *(short *)(iVar16 + 0x6e), sVar5 == -1)) {
LAB_0001ef61:
      *(undefined1 *)(in_ECX + 0x8a7) = 0;
      do {
        (**(code **)(&DAT_00241540 + (*(byte *)(in_ECX[0xf] + 1) & 0x3f) * 0x10))();
      } while ((char)in_ECX[0x8a7] == '\0');
    }
    else {
      uVar13 = FUN_0001c170();
      cVar11 = (*(code *)in_ECX[sVar5 + 0x826])(0,uVar13);
      if (cVar11 != '\0') {
        *(undefined2 *)(iVar16 + 0x6e) = 0xffff;
        in_ECX[0xf] = in_ECX[9] + (uint)*(ushort *)(iVar16 + 0x70) * 4;
        *(undefined1 *)(in_ECX[3] + 0x6d + (uint)*(byte *)(in_ECX + 6) * 8) = 0xff;
        goto LAB_0001ef61;
      }
    }
    *(undefined1 *)(in_ECX + 0x8a7) = 0;
    goto LAB_0001ef95;
  }
  iVar16 = iVar15 + (uint)bVar3 * 8;
  if ((*(short *)(iVar15 + 0x6e + (uint)bVar3 * 8) == -1) ||
     (sVar5 = *(short *)(iVar16 + 0x6e), sVar5 == -1)) {
LAB_0001edee:
    *(undefined1 *)(in_ECX + 0x8a7) = 0;
    do {
      (**(code **)(&DAT_00241540 + (*(byte *)(in_ECX[0xf] + 1) & 0x3f) * 0x10))();
    } while ((char)in_ECX[0x8a7] == '\0');
  }
  else {
    uVar13 = FUN_0001c170();
    cVar11 = (*(code *)in_ECX[sVar5 + 0x826])(0,uVar13);
    if (cVar11 != '\0') {
      *(undefined2 *)(iVar16 + 0x6e) = 0xffff;
      in_ECX[0xf] = in_ECX[9] + (uint)*(ushort *)(iVar16 + 0x70) * 4;
      *(undefined1 *)(in_ECX[3] + 0x6d + (uint)*(byte *)(in_ECX + 6) * 8) = 0xff;
      goto LAB_0001edee;
    }
  }
  *(undefined1 *)(in_ECX + 0x8a7) = 0;
  if (bVar14 == 0) {
    if (-1 < (char)bVar2) {
      in_ECX[2] = *in_ECX + local_14 * 4;
    }
  }
  else {
    uVar12 = (uint)bVar1;
    while (uVar18 = uVar12 - 1, -1 < (int)uVar18) {
      switch(*(undefined1 *)((int)aiStack_10 + (uVar12 - 9))) {
      case 1:
        iVar15 = in_ECX[2];
        in_ECX[2] = iVar15 + -4;
        *(bool *)aiStack_10[uVar18] = *(int *)(iVar15 + -4) != 0;
        uVar12 = uVar18;
        break;
      case 2:
      case 3:
        iVar15 = in_ECX[2];
        puVar7 = (undefined1 *)aiStack_10[uVar18];
        in_ECX[2] = iVar15 + -4;
        *puVar7 = *(undefined1 *)(iVar15 + -4);
        uVar12 = uVar18;
        break;
      case 4:
      case 5:
      case 0x20:
        iVar15 = in_ECX[2];
        puVar8 = (undefined2 *)aiStack_10[uVar18];
        in_ECX[2] = iVar15 + -4;
        *puVar8 = *(undefined2 *)(iVar15 + -4);
        uVar12 = uVar18;
        break;
      default:
        iVar15 = in_ECX[2];
        puVar20 = (undefined4 *)aiStack_10[uVar18];
        in_ECX[2] = iVar15 + -4;
        *puVar20 = *(undefined4 *)(iVar15 + -4);
        uVar12 = uVar18;
        break;
      case 9:
        iVar15 = in_ECX[2];
        puVar20 = (undefined4 *)aiStack_10[uVar18];
        in_ECX[2] = iVar15 + -0xc;
        *puVar20 = *(undefined4 *)(iVar15 + -0xc);
        puVar20[1] = *(undefined4 *)(iVar15 + -8);
        puVar20[2] = *(undefined4 *)(iVar15 + -4);
        uVar12 = uVar18;
        break;
      case 10:
        iVar15 = in_ECX[2];
        puVar20 = (undefined4 *)aiStack_10[uVar18];
        in_ECX[2] = iVar15 + -0x40;
        puVar19 = (undefined4 *)(iVar15 + -0x40);
        for (iVar16 = 0x10; uVar12 = uVar18, iVar16 != 0; iVar16 = iVar16 + -1) {
          *puVar20 = *puVar19;
          puVar19 = puVar19 + 1;
          puVar20 = puVar20 + 1;
        }
      }
    }
  }
LAB_0001ef95:
  if (bVar10 != 0) {
    *(byte *)(in_ECX + 6) = local_28;
    if ((short)uStack_1c != -1) {
      *(short *)(local_20 + 4) = (short)uStack_1c;
    }
  }
  if (bVar9 != 0) {
    *(undefined1 *)((int)in_ECX + 0x229e) = local_2a;
  }
  return;
}


