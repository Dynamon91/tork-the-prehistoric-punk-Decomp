// func FUN_00021b70 @ 0x00021B70 (size 0x3B)

void FUN_00021b70(void)

{
  undefined4 *in_EAX;
  
  *(undefined2 *)((int)in_EAX + 0xe) = 0;
  *(undefined2 *)(in_EAX + 3) = 0;
  in_EAX[2] = 0;
  *(undefined2 *)((int)in_EAX + 6) = 0;
  *(undefined2 *)(in_EAX + 1) = 0;
  *in_EAX = 0;
  if (*(char *)((int)in_EAX + 0x2a) != '\0') {
    in_EAX[4] = 0;
    *(undefined2 *)(in_EAX + 5) = 0;
    *(undefined2 *)((int)in_EAX + 0x16) = 0;
  }
  *(undefined2 *)((int)in_EAX + 0x1e) = 0;
  *(undefined2 *)(in_EAX + 7) = 0;
  in_EAX[6] = 0;
  *(undefined2 *)(in_EAX + 8) = 0x8000;
  return;
}


