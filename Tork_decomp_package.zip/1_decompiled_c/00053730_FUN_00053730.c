// func FUN_00053730 @ 0x00053730 (size 0xC8)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00053730(float *param_1,undefined4 param_2,undefined4 param_3,float *param_4,float param_5)

{
  float fVar1;
  float fVar2;
  
  FUN_0001fce0(param_2,param_3);
  fVar2 = _DAT_0020df98;
  fVar1 = SQRT(param_1[1] * param_1[1] + *param_1 * *param_1);
  if ((uint)param_5 <= (uint)ABS(fVar1)) {
    param_1[2] = 0.0;
    fVar2 = fVar2 / fVar1;
    *param_1 = fVar2 * *param_1;
    *(ulonglong *)(param_1 + 1) =
         CONCAT44(fVar2 * (float)((ulonglong)*(undefined8 *)(param_1 + 1) >> 0x20),
                  fVar2 * (float)*(undefined8 *)(param_1 + 1));
    return;
  }
  if (param_4 == (float *)0x0) {
    *param_1 = 1.0;
    param_1[1] = 0.0;
    param_1[2] = 0.0;
    return;
  }
  *param_1 = *param_4;
  param_1[1] = param_4[1];
  param_1[2] = param_4[2];
  return;
}


