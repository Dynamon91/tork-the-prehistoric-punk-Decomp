// func FUN_0004aef0 @ 0x0004AEF0 (size 0x99)

char * FUN_0004aef0(char *param_1,size_t param_2)

{
  char *__dest;
  int iVar1;
  int iVar2;
  uint uVar3;
  bool bVar4;
  
  iVar1 = DAT_002411d8;
  iVar2 = FUN_000550f0((int)(param_2 + 0x20 + ((int)(param_2 + 0x20) >> 0x1f & 0x1fU)) >> 5);
  *(undefined4 *)(&DAT_00002064 + iVar2 * 4 + iVar1) = 0;
  __dest = (char *)(iVar2 * 0x20 + 0x44 + iVar1);
  _strncpy(__dest,param_1,param_2);
  __dest[param_2] = '\0';
  if (((char *)(DAT_002411d8 + 0x44U) <= param_1) && (param_1 < &DAT_00002044 + DAT_002411d8)) {
    param_1 = param_1 + (-0x44 - DAT_002411d8);
    uVar3 = (uint)param_1 & 0x8000001f;
    bVar4 = uVar3 == 0;
    if ((int)uVar3 < 0) {
      bVar4 = (uVar3 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar4) && ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5 != -1)) &&
       (*(int *)(&DAT_00002064 +
                ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5) * 4 + DAT_002411d8) == 0)) {
      FUN_00019750();
    }
  }
  return __dest;
}


