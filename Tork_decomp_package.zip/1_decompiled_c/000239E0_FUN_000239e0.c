// func FUN_000239e0 @ 0x000239E0 (size 0x8A)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_000239e0(void)

{
  float fVar1;
  char cVar2;
  float *unaff_ESI;
  float *unaff_EDI;
  float10 fVar3;
  float local_18;
  float local_14;
  float local_10;
  
  cVar2 = FUN_00023ad0();
  if (cVar2 == '\0') {
    fVar3 = (float10)FUN_00021640();
    fVar3 = SQRT((float10)_DAT_0020df98 / fVar3);
    local_18 = (float)(fVar3 * (float10)*unaff_EDI);
    local_14 = (float)(fVar3 * (float10)unaff_EDI[1]);
    local_10 = (float)(fVar3 * (float10)unaff_EDI[2]);
  }
  fVar1 = local_18 * *unaff_ESI + local_10 * unaff_ESI[2] + local_14 * unaff_ESI[1];
  *unaff_ESI = *unaff_ESI - local_18 * fVar1;
  unaff_ESI[1] = unaff_ESI[1] - local_14 * fVar1;
  unaff_ESI[2] = unaff_ESI[2] - local_10 * fVar1;
  return;
}


