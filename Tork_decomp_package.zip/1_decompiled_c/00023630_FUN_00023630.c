// func FUN_00023630 @ 0x00023630 (size 0x45)

void FUN_00023630(undefined4 param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  undefined4 local_4;
  
  local_c = param_3[1];
  local_10 = *param_3;
  local_8 = param_3[2];
  local_4 = param_4;
  FUN_00069f90(param_1,&local_10);
  return;
}


