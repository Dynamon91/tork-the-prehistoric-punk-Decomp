// func FUN_0002a5a0 @ 0x0002A5A0 (size 0xBA)

void FUN_0002a5a0(void)

{
  undefined1 *puVar1;
  undefined1 *in_EDX;
  int iVar2;
  
  in_EDX[2] = 0;
  *in_EDX = 0;
  in_EDX[1] = 0;
  in_EDX[3] = 0;
  in_EDX[5] = 0;
  in_EDX[4] = 0;
  *(undefined4 *)(in_EDX + 0x24) = 0;
  *(undefined4 *)(in_EDX + 0x28) = 0;
  *(undefined4 *)(in_EDX + 0x2c) = 0;
  in_EDX[0x4834] = 0;
  puVar1 = in_EDX + 0x3d;
  iVar2 = 0x80;
  do {
    puVar1[1] = 0;
    *puVar1 = 0;
    puVar1[-1] = 0;
    puVar1 = puVar1 + 0x30;
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  puVar1 = in_EDX + 0x183e;
  iVar2 = 8;
  do {
    puVar1[1] = 0;
    *puVar1 = 0;
    puVar1[-1] = 0;
    puVar1[-2] = 0;
    puVar1 = puVar1 + 0x40;
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  puVar1 = in_EDX + 0x1a3c;
  iVar2 = 0x40;
  do {
    *puVar1 = 0;
    puVar1 = puVar1 + 0x4c;
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  puVar1 = in_EDX + 0x2d3e;
  iVar2 = 0x40;
  do {
    puVar1[1] = 0;
    *puVar1 = 0;
    puVar1[-1] = 0;
    puVar1[-2] = 0;
    puVar1 = puVar1 + 0x2c;
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  puVar1 = in_EDX + 0x3841;
  iVar2 = 0x20;
  do {
    *(undefined4 *)(puVar1 + -5) = 0x3f800000;
    puVar1[-1] = 0;
    *puVar1 = 0;
    puVar1[2] = 0;
    puVar1[1] = 0;
    puVar1 = puVar1 + 0x30;
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  return;
}


