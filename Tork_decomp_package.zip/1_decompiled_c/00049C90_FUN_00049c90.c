// func FUN_00049c90 @ 0x00049C90 (size 0x87)

/* WARNING: Removing unreachable block (ram,0x00049cc9) */
/* WARNING: Removing unreachable block (ram,0x00049ca6) */
/* WARNING: Removing unreachable block (ram,0x00049cea) */
/* WARNING: Removing unreachable block (ram,0x00049d06) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00049c90(void)

{
  uint in_EAX;
  float *in_ECX;
  
  *in_ECX = (float)(in_EAX >> 0x10 & 0xff) * _DAT_0020dfb0;
  in_ECX[1] = (float)(in_EAX >> 8 & 0xff) * _DAT_0020dfb0;
  in_ECX[2] = (float)(in_EAX & 0xff) * _DAT_0020dfb0;
  in_ECX[3] = (float)(in_EAX >> 0x18) * _DAT_0020dfb0;
  return;
}


