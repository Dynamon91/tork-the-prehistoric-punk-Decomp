// func FUN_00023c60 @ 0x00023C60 (size 0x42)

void FUN_00023c60(float *param_1,float *param_2,float *param_3,float param_4)

{
  undefined8 uVar1;
  float fVar2;
  float fVar3;
  
  uVar1 = *(undefined8 *)(param_3 + 1);
  fVar2 = (float)*(undefined8 *)(param_2 + 1);
  fVar3 = (float)((ulonglong)*(undefined8 *)(param_2 + 1) >> 0x20);
  *param_1 = param_4 * (*param_3 - *param_2) + *param_2;
  *(ulonglong *)(param_1 + 1) =
       CONCAT44(param_4 * ((float)((ulonglong)uVar1 >> 0x20) - fVar3) + fVar3,
                param_4 * ((float)uVar1 - fVar2) + fVar2);
  return;
}


