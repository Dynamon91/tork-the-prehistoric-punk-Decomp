// func FUN_00018970 @ 0x00018970 (size 0x80)

undefined4 * FUN_00018970(void)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  
  puVar1 = (undefined4 *)FUN_00057f60(&DAT_00002468);
  *puVar1 = 0;
  puVar1[1] = 0;
  puVar1[2] = 0;
  puVar1[3] = 0;
  puVar1[4] = 0;
  puVar1[5] = 0;
  puVar1[6] = 0;
  puVar1[7] = 0;
  puVar1[8] = 0;
  puVar1[9] = 0;
  puVar1[10] = 0;
  puVar1[0xb] = 0;
  puVar1[0xc] = 0;
  puVar1[0xd] = 0;
  puVar1[0xe] = 0;
  puVar1[0xf] = 0;
  puVar1[0x10] = 0;
  puVar1[0x811] = 0;
  puVar1[0x812] = 0;
  puVar1[0x813] = 0;
  puVar1[0x814] = 0;
  puVar1[0x815] = 0;
  puVar1[0x816] = 0;
  puVar1[0x817] = 0;
  puVar1[0x818] = 0;
  puVar3 = puVar1 + 0x819;
  for (iVar2 = 0x100; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar3 = 0;
    puVar3 = puVar3 + 1;
  }
  *(undefined1 *)(puVar1 + 0x919) = 0;
  return puVar1;
}


