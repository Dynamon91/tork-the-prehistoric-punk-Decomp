// func FUN_0004d2f0 @ 0x0004D2F0 (size 0x9C)

void FUN_0004d2f0(float *param_1)

{
  float fVar1;
  float *in_ECX;
  
  fVar1 = *in_ECX;
  *param_1 = fVar1 * *param_1;
  *(ulonglong *)(param_1 + 1) =
       CONCAT44(fVar1 * (float)((ulonglong)*(undefined8 *)(param_1 + 1) >> 0x20),
                fVar1 * (float)*(undefined8 *)(param_1 + 1));
  fVar1 = in_ECX[1];
  param_1[4] = fVar1 * param_1[4];
  *(ulonglong *)(param_1 + 5) =
       CONCAT44(fVar1 * (float)((ulonglong)*(undefined8 *)(param_1 + 5) >> 0x20),
                fVar1 * (float)*(undefined8 *)(param_1 + 5));
  fVar1 = in_ECX[2];
  param_1[8] = fVar1 * param_1[8];
  *(ulonglong *)(param_1 + 9) =
       CONCAT44(fVar1 * (float)((ulonglong)*(undefined8 *)(param_1 + 9) >> 0x20),
                fVar1 * (float)*(undefined8 *)(param_1 + 9));
  return;
}


