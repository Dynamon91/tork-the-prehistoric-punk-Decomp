// func FUN_00049c10 @ 0x00049C10 (size 0x75)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_00049c10(void)

{
  float *in_EAX;
  
  return (((int)(in_EAX[3] * _DAT_0020dfe4 + _DAT_0020e014) << 8 |
          (uint)(*in_EAX * _DAT_0020dfe4 + _DAT_0020e014)) << 8 |
         (uint)(in_EAX[1] * _DAT_0020dfe4 + _DAT_0020e014)) << 8 |
         (uint)(in_EAX[2] * _DAT_0020dfe4 + _DAT_0020e014) & 0xb4ffffff;
}


