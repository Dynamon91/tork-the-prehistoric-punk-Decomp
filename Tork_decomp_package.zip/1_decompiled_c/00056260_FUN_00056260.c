// func FUN_00056260 @ 0x00056260 (size 0x64)

int FUN_00056260(void)

{
  uint in_EAX;
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  
  uVar1 = in_EAX >> 8;
  if (uVar1 < 0x10000) {
    uVar5 = uVar1 - 0x100 >> 0x10 & 8;
    iVar2 = uVar1 << (sbyte)uVar5;
    uVar3 = iVar2 - 0x1000U >> 0x10 & 4;
    iVar2 = iVar2 << (sbyte)uVar3;
    uVar4 = iVar2 - 0x4000U >> 0x10 & 2;
    uVar1 = iVar2 << (sbyte)uVar4;
    iVar2 = ((~(uVar1 >> 0xf) & uVar1 >> 0xe) - uVar4) - (uVar5 + uVar3);
    return (in_EAX >> ((char)iVar2 + 0x13U & 0x1f) & 3) + 0x20 + (iVar2 + 0xd) * 4;
  }
  return 0x5f;
}


