// func FUN_0001b1c0 @ 0x0001B1C0 (size 0x70)

void FUN_0001b1c0(int param_1)

{
  int iVar1;
  ushort uVar2;
  int iVar3;
  int iVar4;
  ushort *puVar5;
  
  puVar5 = (ushort *)(param_1 + (uint)*(ushort *)(param_1 + 2) * 4);
  uVar2 = *puVar5;
  if (uVar2 != 0xffff) {
    do {
      iVar4 = *(int *)(param_1 + (uint)uVar2 * 4);
      if ((((iVar4 != 0) && (iVar3 = FUN_00058910(), iVar3 != -1)) &&
          (iVar1 = *(int *)(DAT_00241208 + iVar3 * 4), iVar4 + -8 == iVar1)) &&
         (iVar4 = (*(int *)(DAT_0024120c + iVar3 * 4) - iVar1) + iVar4, iVar4 != 0)) {
        *(int *)(param_1 + (uint)uVar2 * 4) = iVar4;
      }
      uVar2 = puVar5[1];
      puVar5 = puVar5 + 1;
    } while (uVar2 != 0xffff);
  }
  return;
}


