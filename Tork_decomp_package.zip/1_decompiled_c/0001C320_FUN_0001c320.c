// func FUN_0001c320 @ 0x0001C320 (size 0xDD)

void FUN_0001c320(byte *param_1,undefined4 param_2,char param_3)

{
  byte *pbVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar2 = 0;
  if (*param_1 != 0) {
    pbVar1 = param_1 + 0x6b;
    do {
      *pbVar1 = pbVar1[1];
      pbVar1[3] = 0xff;
      pbVar1[4] = 0xff;
      pbVar1[2] = 0xff;
      iVar2 = iVar2 + 1;
      pbVar1 = pbVar1 + 8;
    } while (iVar2 < (int)(uint)*param_1);
  }
  uVar5 = 0;
  if (param_1[1] != 0) {
    pbVar1 = param_1 + 0x20;
    do {
      if (param_3 == '\0') {
        iVar2 = *(int *)(*(int *)(pbVar1 + -0x18) + 0x18);
        if (iVar2 != 0) {
          FUN_0001cd30(iVar2,*(undefined4 *)(*(int *)(pbVar1 + -0x18) + 0x14),param_2);
        }
      }
      if (*(int *)pbVar1 != 0) {
        if ((char)param_2 == '\0') {
          uVar4 = *(uint *)(*(int *)(param_1 + (uVar5 & 0xff) * 4 + 8) + 8);
          puVar6 = *(undefined4 **)(param_1 + (uVar5 & 0xff) * 4 + 0x20);
          for (uVar3 = uVar4 >> 2; uVar3 != 0; uVar3 = uVar3 - 1) {
            *puVar6 = 0;
            puVar6 = puVar6 + 1;
          }
          for (uVar4 = uVar4 & 3; uVar4 != 0; uVar4 = uVar4 - 1) {
            *(undefined1 *)puVar6 = 0;
            puVar6 = (undefined4 *)((int)puVar6 + 1);
          }
        }
        if (*(int *)(*(int *)(pbVar1 + -0x18) + 0x1c) != 0) {
          FUN_0001cd30(*(int *)(*(int *)(pbVar1 + -0x18) + 0x1c),*(undefined4 *)pbVar1,param_2);
        }
        if (*(int *)(pbVar1 + 0x18) != 0) {
          FUN_0001d380(*(int *)(pbVar1 + 0x18),*(undefined4 *)pbVar1,param_2,
                       *(undefined4 *)(*(int *)(pbVar1 + -0x18) + 0x1c));
        }
      }
      uVar5 = uVar5 + 1;
      pbVar1 = pbVar1 + 4;
    } while ((int)uVar5 < (int)(uint)param_1[1]);
  }
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}


