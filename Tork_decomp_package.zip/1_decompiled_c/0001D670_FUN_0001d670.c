// func FUN_0001d670 @ 0x0001D670 (size 0x101)

void FUN_0001d670(void)

{
  ushort uVar1;
  byte *pbVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int in_EAX;
  int iVar6;
  byte *pbVar7;
  byte *local_4;
  
  DAT_002411e8 = '\0';
  DAT_002411e4 = in_EAX;
  FUN_0001a5a0();
  iVar6 = 0xc0;
  do {
    pbVar2 = *(byte **)(in_EAX + 0x4f4 + iVar6);
    local_4 = pbVar2 + *(int *)(in_EAX + 0x500 + iVar6) * 4;
    pbVar7 = pbVar2;
    if (pbVar2 < local_4) {
      do {
        iVar5 = DAT_0022a6c4;
        if ((*pbVar7 & 1) == 0) {
          iVar3 = *(int *)pbVar7;
          uVar1 = *(ushort *)(iVar3 + 2);
          if ((((byte)uVar1 >> 5 & 1) == 0) &&
             (((uVar1 & 1) != 0 ||
              (((-1 < *(char *)(iVar3 + 0xb) || ((*(byte *)(iVar3 + 8) & 2) != 0)) &&
               ((uVar1 & 0x2000) == 0)))))) {
            uVar4 = *(undefined4 *)(*(int *)(iVar3 + 0x24) + 4);
            *(int *)(DAT_0022a6c4 + 0x14) = iVar3;
            *(int *)(iVar5 + 0x10) = iVar3;
            *(undefined4 *)(iVar5 + 0x30) = uVar4;
            *(undefined4 *)(iVar5 + 0xc) = uVar4;
            FUN_00018070();
            if (DAT_002411e8 != '\0') {
              iVar5 = *(int *)(DAT_002411e4 + 0x4f4 + iVar6);
              local_4 = (byte *)(iVar5 + *(int *)(DAT_002411e4 + 0x500 + iVar6) * 4);
              pbVar7 = pbVar7 + (iVar5 - (int)pbVar2);
              DAT_002411e8 = '\0';
              in_EAX = DAT_002411e4;
            }
          }
        }
        pbVar7 = pbVar7 + 4;
      } while (pbVar7 < local_4);
    }
    iVar5 = DAT_002411e0;
    iVar6 = iVar6 + -0x20;
  } while (-1 < iVar6);
  FUN_00018770();
  DAT_002411e0 = iVar5 + 1;
  return;
}


