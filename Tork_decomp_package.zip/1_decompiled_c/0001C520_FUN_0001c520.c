// func FUN_0001c520 @ 0x0001C520 (size 0x261)

void FUN_0001c520(char param_1)

{
  int *piVar1;
  byte bVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint *puVar5;
  uint uVar6;
  byte *pbVar7;
  int iVar8;
  int iVar9;
  byte *unaff_ESI;
  int *piVar10;
  int iVar11;
  int local_20;
  undefined4 auStack_18 [6];
  
  *(undefined2 *)(unaff_ESI + 4) = *(undefined2 *)(unaff_ESI + 2);
  pbVar7 = unaff_ESI + 0x6a;
  local_20 = 0;
  if (*unaff_ESI != 0) {
    do {
      iVar11 = DAT_0022d4c0;
      if (((uint)*(ushort *)(unaff_ESI + 2) & 1 << ((byte)local_20 & 0x1f)) != 0) {
        piVar1 = (int *)(&DAT_0000281c + DAT_0022d4c0);
        iVar8 = *(int *)(DAT_0022d4c0 + 0xc + *(int *)(&DAT_0000281c + DAT_0022d4c0) * 0x18);
        *pbVar7 = **(byte **)(iVar8 + 0x28);
        piVar10 = (int *)(iVar8 + 0x28);
        *piVar10 = *piVar10 + 1;
        iVar11 = *(int *)(iVar11 + 0xc + *piVar1 * 0x18);
        pbVar7[2] = **(byte **)(iVar11 + 0x28);
        piVar10 = (int *)(iVar11 + 0x28);
        *piVar10 = *piVar10 + 1;
        pbVar7[1] = pbVar7[2];
      }
      local_20 = local_20 + 1;
      pbVar7 = pbVar7 + 8;
    } while (local_20 < (int)(uint)*unaff_ESI);
  }
  iVar11 = DAT_0022d4c8;
  bVar2 = unaff_ESI[1];
  piVar10 = (int *)(&DAT_00004004 + DAT_0022d4c8);
  if (*(int *)(&DAT_00004004 + DAT_0022d4c8) == 0) {
    iVar8 = FUN_00057f60(0x18);
    *piVar10 = iVar8;
  }
  puVar3 = (undefined4 *)*piVar10;
  *(uint *)(iVar11 + 0x4000) = (uint)bVar2;
  *puVar3 = &LAB_0001c790;
  *(uint *)(*piVar10 + 4) = (uint)bVar2;
  *(byte **)(*piVar10 + 8) = unaff_ESI;
  *(undefined4 *)(*piVar10 + 0xc) = 0;
  *(undefined4 *)(*piVar10 + 0x10) = 0;
  *(undefined4 *)(*piVar10 + 0x14) = 0;
  iVar11 = 0;
  if (unaff_ESI[1] != 0) {
    pbVar7 = unaff_ESI + 8;
    do {
      iVar8 = *(int *)(DAT_0022d4c0 + 0xc + *(int *)(&DAT_0000281c + DAT_0022d4c0) * 0x18);
      puVar3 = *(undefined4 **)(iVar8 + 0x2c);
      uVar4 = *puVar3;
      *(undefined4 **)(iVar8 + 0x2c) = puVar3 + 1;
      pbVar7[0] = 0;
      pbVar7[1] = 0;
      pbVar7[2] = 0;
      pbVar7[3] = 0;
      auStack_18[iVar11] = uVar4;
      FUN_000112c0(uVar4,0,pbVar7);
      iVar11 = iVar11 + 1;
      pbVar7 = pbVar7 + 4;
    } while (iVar11 < (int)(uint)unaff_ESI[1]);
  }
  if (param_1 != '\0') {
    iVar11 = *(int *)(DAT_0022d4c0 + 0xc + *(int *)(&DAT_0000281c + DAT_0022d4c0) * 0x18);
    puVar3 = *(undefined4 **)(iVar11 + 0x2c);
    uVar4 = *puVar3;
    *(undefined4 **)(iVar11 + 0x2c) = puVar3 + 1;
    iVar11 = *(int *)(DAT_0022d4c0 + 0xc + *(int *)(&DAT_0000281c + DAT_0022d4c0) * 0x18);
    puVar5 = *(uint **)(iVar11 + 0x28);
    uVar6 = *puVar5;
    *(uint **)(iVar11 + 0x28) = puVar5 + 1;
    iVar11 = DAT_0022d4c8;
    iVar9 = 0;
    iVar8 = 0;
    if (unaff_ESI[1] != 0) {
      do {
        if ((uVar6 & 1 << ((byte)iVar8 & 0x1f)) != 0) {
          iVar9 = iVar9 + 1;
        }
        iVar8 = iVar8 + 1;
      } while (iVar8 < (int)(uint)unaff_ESI[1]);
    }
    piVar10 = (int *)(&DAT_00004004 + DAT_0022d4c8);
    if (*(int *)(&DAT_00004004 + DAT_0022d4c8) == 0) {
      iVar8 = FUN_00057f60(0x18);
      *piVar10 = iVar8;
    }
    puVar3 = (undefined4 *)*piVar10;
    *(int *)(iVar11 + 0x4000) = iVar9;
    *puVar3 = &LAB_0001c820;
    *(int *)(*piVar10 + 4) = iVar9;
    *(byte **)(*piVar10 + 8) = unaff_ESI;
    *(undefined4 *)(*piVar10 + 0xc) = uVar4;
    *(undefined4 *)(*piVar10 + 0x10) = 0;
    *(undefined4 *)(*piVar10 + 0x14) = 0;
    iVar11 = 0;
    if (unaff_ESI[1] != 0) {
      pbVar7 = unaff_ESI + 0x38;
      do {
        if ((uVar6 & 1 << ((byte)iVar11 & 0x1f)) != 0) {
          iVar8 = *(int *)(DAT_0022d4c0 + 0xc + *(int *)(&DAT_0000281c + DAT_0022d4c0) * 0x18);
          puVar3 = *(undefined4 **)(iVar8 + 0x2c);
          uVar4 = *puVar3;
          *(undefined4 **)(iVar8 + 0x2c) = puVar3 + 1;
          FUN_000112c0(uVar4,auStack_18[iVar11],pbVar7);
        }
        iVar11 = iVar11 + 1;
        pbVar7 = pbVar7 + 4;
      } while (iVar11 < (int)(uint)unaff_ESI[1]);
    }
  }
  return;
}


