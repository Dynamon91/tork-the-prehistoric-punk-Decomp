// func FUN_00028970 @ 0x00028970 (size 0x4E)

void FUN_00028970(void)

{
  float fVar1;
  int in_ECX;
  
  fVar1 = *(float *)(in_ECX + 0x9c);
  if (*(float *)(in_ECX + 0x9c) < *(float *)(in_ECX + 0x88)) {
    fVar1 = *(float *)(in_ECX + 0x88);
  }
  if (*(float *)(in_ECX + 0xb0) < fVar1) {
    *(float *)(in_ECX + 0x164) = fVar1;
    return;
  }
  *(float *)(in_ECX + 0x164) = *(float *)(in_ECX + 0xb0);
  return;
}


