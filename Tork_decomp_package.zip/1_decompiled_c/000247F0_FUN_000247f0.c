// func FUN_000247f0 @ 0x000247F0 (size 0x82)

undefined4 FUN_000247f0(float param_1)

{
  float *in_EAX;
  float *in_ECX;
  float fVar1;
  
  fVar1 = ABS(in_ECX[1] - in_EAX[1]);
  if (fVar1 < ABS(*in_ECX - *in_EAX)) {
    fVar1 = ABS(*in_ECX - *in_EAX);
  }
  if (fVar1 <= ABS(in_ECX[2] - in_EAX[2])) {
    fVar1 = ABS(in_ECX[2] - in_EAX[2]);
  }
  if (!((NAN(fVar1) || NAN(param_1)) || fVar1 < param_1 == (fVar1 == param_1))) {
    return 1;
  }
  return 0;
}


