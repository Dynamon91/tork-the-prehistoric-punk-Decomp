// func FUN_0004c620 @ 0x0004C620 (size 0x71)

void FUN_0004c620(undefined4 param_1)

{
  int iVar1;
  byte unaff_BL;
  int unaff_EDI;
  undefined1 local_40 [64];
  
  if ((*(int *)(unaff_EDI + 0xc) != 0) && (unaff_BL < *(byte *)(*(int *)(unaff_EDI + 0xc) + 2))) {
    FUN_00047960();
    iVar1 = *(int *)(unaff_EDI + 0x14);
    FUN_000479c0();
    FUN_000286c0((uint)unaff_BL * 0xc4 + 0x44 + iVar1,local_40);
    FUN_0004c6a0(param_1);
  }
  return;
}


