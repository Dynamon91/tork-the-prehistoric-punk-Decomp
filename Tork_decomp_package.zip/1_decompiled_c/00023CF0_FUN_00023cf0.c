// func FUN_00023cf0 @ 0x00023CF0 (size 0x41)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00023cf0(float *param_1,float *param_2,float param_3)

{
  undefined8 uVar1;
  float fVar2;
  float10 fVar3;
  
  fVar3 = (float10)FUN_00021640();
  fVar2 = (float)(SQRT((float10)_DAT_0020df98 / fVar3) * (float10)param_3);
  uVar1 = *(undefined8 *)(param_2 + 1);
  *param_1 = fVar2 * *param_2;
  *(ulonglong *)(param_1 + 1) =
       CONCAT44(fVar2 * (float)((ulonglong)uVar1 >> 0x20),fVar2 * (float)uVar1);
  return;
}


