// func FUN_000544b0 @ 0x000544B0 (size 0x24)

undefined4 FUN_000544b0(undefined1 *param_1)

{
  ushort *in_EAX;
  
  if ((int)(uint)*in_EAX < (int)(in_EAX[1] - 1)) {
    *(undefined1 *)(*in_EAX + 6 + (int)in_EAX) = *param_1;
    *in_EAX = *in_EAX + 1;
    return 0;
  }
  return 0xffffffff;
}


