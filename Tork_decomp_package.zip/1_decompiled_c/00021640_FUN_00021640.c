// func FUN_00021640 @ 0x00021640 (size 0x36)

float10 FUN_00021640(void)

{
  float *in_ECX;
  float fVar1;
  float fVar2;
  
  fVar1 = (float)*(undefined8 *)(in_ECX + 1);
  fVar2 = (float)((ulonglong)*(undefined8 *)(in_ECX + 1) >> 0x20);
  return (float10)(*in_ECX * *in_ECX + fVar1 * fVar1 + fVar2 * fVar2);
}


