// func FUN_00057e50 @ 0x00057E50 (size 0x40)

int FUN_00057e50(undefined4 param_1)

{
  int iVar1;
  undefined4 in_ECX;
  
  if (DAT_00241a0c == 0) {
    DAT_00241a0c = 0x1000;
  }
  if (DAT_00241a08 == 0) {
    DAT_00241a08 = 0x10000;
  }
  iVar1 = FUN_0013f898(in_ECX,param_1,0x103000,4);
  if (iVar1 == 0) {
    iVar1 = -1;
  }
  return iVar1;
}


