// func FUN_0001cfd0 @ 0x0001CFD0 (size 0x14D)

void FUN_0001cfd0(uint *param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  uint *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint *puVar8;
  uint local_8;
  
  if ((param_1[-1] >> 0x1e & 1) == 0) {
    param_1[-1] = param_1[-1] | 0x40000000;
    local_8 = 0;
    if (*param_1 != 0) {
      puVar3 = param_1;
      do {
        puVar8 = puVar3 + 2;
        uVar5 = *(uint *)(param_2 + 0xc + (uint)(ushort)puVar3[1] * 0x14);
        if (uVar5 < 5) {
          if (((*(char *)((int)puVar3 + 6) < '\0') && (uVar5 = *puVar8, uVar5 != 0)) &&
             ((iVar4 = FUN_00058910(), iVar4 != -1 &&
              ((iVar7 = *(int *)(DAT_00241208 + iVar4 * 4), uVar5 - 8 == iVar7 &&
               (uVar5 = (*(int *)(DAT_0024120c + iVar4 * 4) - iVar7) + uVar5, uVar5 != 0)))))) {
            *puVar8 = uVar5;
          }
        }
        else {
          uVar6 = *puVar8;
          if ((((uVar6 != 0) && (iVar4 = FUN_00058910(), iVar4 != -1)) &&
              (iVar7 = *(int *)(DAT_00241208 + iVar4 * 4), uVar6 - 8 == iVar7)) &&
             (uVar6 = (*(int *)(DAT_0024120c + iVar4 * 4) - iVar7) + uVar6, uVar6 != 0)) {
            *puVar8 = uVar6;
          }
          if (*(char *)((int)puVar3 + 6) < '\0') {
            uVar5 = uVar5 >> 2;
            uVar6 = 0;
            if (uVar5 != 0) {
              do {
                uVar1 = *puVar8;
                iVar4 = *(int *)(uVar1 + uVar6 * 4);
                if (((iVar4 != 0) && (iVar7 = FUN_00058910(), iVar7 != -1)) &&
                   ((iVar2 = *(int *)(DAT_00241208 + iVar7 * 4), iVar4 + -8 == iVar2 &&
                    (iVar4 = (*(int *)(DAT_0024120c + iVar7 * 4) - iVar2) + iVar4, iVar4 != 0)))) {
                  *(int *)(uVar1 + uVar6 * 4) = iVar4;
                }
                uVar6 = uVar6 + 1;
              } while (uVar6 < uVar5);
            }
          }
        }
        local_8 = local_8 + 1;
        puVar3 = puVar8;
      } while (local_8 < *param_1);
    }
  }
  return;
}


