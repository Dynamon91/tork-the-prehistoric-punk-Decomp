// func FUN_0001b740 @ 0x0001B740 (size 0x2B)

void FUN_0001b740(int param_1)

{
  short *psVar1;
  undefined4 *puVar2;
  int iVar3;
  
  iVar3 = 0;
  if (0 < *(short *)(param_1 + 0x26)) {
    puVar2 = (undefined4 *)(param_1 + 0x28);
    do {
      psVar1 = (short *)*puVar2;
      if (psVar1 != (short *)0x0) {
        psVar1[0x12] = psVar1[0x12] + 1;
        *psVar1 = *psVar1 + 1;
      }
      iVar3 = iVar3 + 1;
      puVar2 = puVar2 + 1;
    } while (iVar3 < *(short *)(param_1 + 0x26));
  }
  return;
}


