// func FUN_0002a3a0 @ 0x0002A3A0 (size 0x37)

void FUN_0002a3a0(void)

{
  undefined4 *in_EAX;
  
  in_EAX[10] = 0x3f800000;
  in_EAX[5] = 0x3f800000;
  *in_EAX = 0x3f800000;
  in_EAX[0xe] = 0;
  in_EAX[0xd] = 0;
  in_EAX[0xc] = 0;
  in_EAX[9] = 0;
  in_EAX[8] = 0;
  in_EAX[6] = 0;
  in_EAX[4] = 0;
  in_EAX[2] = 0;
  in_EAX[1] = 0;
  in_EAX[0xb] = 0;
  in_EAX[7] = 0;
  in_EAX[3] = 0;
  in_EAX[0xf] = 0x3f800000;
  return;
}


