// func FUN_0004d100 @ 0x0004D100 (size 0xC2)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0004d100(void)

{
  float *unaff_EDI;
  float10 fVar1;
  
  fVar1 = (float10)FUN_00021640();
  fVar1 = SQRT((float10)_DAT_0020df98 / fVar1);
  *unaff_EDI = (float)(fVar1 * (float10)*unaff_EDI);
  unaff_EDI[1] = (float)(fVar1 * (float10)unaff_EDI[1]);
  unaff_EDI[2] = (float)(fVar1 * (float10)unaff_EDI[2]);
  fVar1 = (float10)FUN_00021640();
  fVar1 = SQRT((float10)_DAT_0020df98 / fVar1);
  unaff_EDI[4] = (float)(fVar1 * (float10)unaff_EDI[4]);
  unaff_EDI[5] = (float)(fVar1 * (float10)unaff_EDI[5]);
  unaff_EDI[6] = (float)(fVar1 * (float10)unaff_EDI[6]);
  fVar1 = (float10)FUN_00021640();
  fVar1 = SQRT((float10)_DAT_0020df98 / fVar1);
  unaff_EDI[8] = (float)(fVar1 * (float10)unaff_EDI[8]);
  unaff_EDI[9] = (float)(fVar1 * (float10)unaff_EDI[9]);
  unaff_EDI[10] = (float)(fVar1 * (float10)unaff_EDI[10]);
  return;
}


