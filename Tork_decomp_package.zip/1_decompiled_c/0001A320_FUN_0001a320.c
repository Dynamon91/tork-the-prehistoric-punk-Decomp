// func FUN_0001a320 @ 0x0001A320 (size 0x43)

void FUN_0001a320(int param_1)

{
  int unaff_EBX;
  int *piVar1;
  int iVar2;
  
  iVar2 = 0;
  if (0 < *(int *)(unaff_EBX + 0x700)) {
    piVar1 = (int *)(unaff_EBX + 0x708);
    do {
      if (*piVar1 == param_1) {
        FUN_0001a370();
        iVar2 = iVar2 + -1;
        piVar1 = piVar1 + -8;
      }
      iVar2 = iVar2 + 1;
      piVar1 = piVar1 + 8;
    } while (iVar2 < *(int *)(unaff_EBX + 0x700));
  }
  return;
}


