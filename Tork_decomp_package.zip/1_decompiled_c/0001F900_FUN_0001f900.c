// func FUN_0001f900 @ 0x0001F900 (size 0x9F)

void FUN_0001f900(void)

{
  int iVar1;
  int iVar2;
  int *in_ECX;
  
  iVar1 = in_ECX[0xf];
  in_ECX[0xf] = iVar1 + 4;
  in_ECX[2] = in_ECX[2] + (uint)*(ushort *)in_ECX[9] * -4;
  if ((*(byte *)(iVar1 + 3) & 2) == 0) {
    *(undefined1 *)((int)in_ECX + 0x1a) = *(undefined1 *)(iVar1 + 2);
  }
  else {
    (**(code **)(&DAT_00241540 + (*(byte *)(iVar1 + 5) & 0x3f) * 0x10))();
    iVar2 = in_ECX[2];
    in_ECX[2] = iVar2 + -4;
    *(undefined1 *)((int)in_ECX + 0x1a) = *(undefined1 *)(iVar2 + -4);
  }
  *(undefined1 *)(in_ECX[7] + 1) = *(undefined1 *)((int)in_ECX + 0x1a);
  iVar2 = *(int *)(*(int *)(in_ECX[8] + 0xc) + (uint)*(byte *)((int)in_ECX + 0x1a) * 4);
  in_ECX[9] = iVar2;
  in_ECX[0xf] = iVar2;
  if ((*(byte *)(iVar1 + 3) & 1) == 0) {
    iVar1 = *in_ECX;
    in_ECX[2] = iVar1;
    in_ECX[0xb] = iVar1;
    in_ECX[2] = iVar1 + (uint)*(ushort *)in_ECX[0xf] * 4;
    in_ECX[0xf] = (int)((ushort *)in_ECX[0xf] + 2);
    return;
  }
  *(undefined1 *)(in_ECX + 0x8a7) = 1;
  return;
}


