// func FUN_00054b40 @ 0x00054B40 (size 0x24)

int FUN_00054b40(void)

{
  char *pcVar1;
  int in_ECX;
  char *pcVar2;
  char *in_EDX;
  char *unaff_ESI;
  
  if ((unaff_ESI != (char *)0x0) && (pcVar2 = unaff_ESI + in_ECX, unaff_ESI < pcVar2)) {
    pcVar1 = unaff_ESI;
    do {
      if (*pcVar1 == *in_EDX) {
        if (pcVar1 < pcVar2) {
          return (int)pcVar1 - (int)unaff_ESI;
        }
        return -1;
      }
      pcVar1 = pcVar1 + 1;
    } while (pcVar1 < pcVar2);
  }
  return -1;
}


