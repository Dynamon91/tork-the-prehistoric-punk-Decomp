// func FUN_000551e0 @ 0x000551E0 (size 0x3F)

void FUN_000551e0(void)

{
  int in_EAX;
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined8 uVar4;
  
  uVar4 = FUN_000550b0();
  piVar1 = (int *)((ulonglong)uVar4 >> 0x20);
  for (iVar2 = in_EAX; iVar2 < (int)uVar4 + in_EAX; iVar2 = iVar2 + 1) {
    uVar3 = ~(1 << ((byte)iVar2 & 0x1f));
    piVar1[(iVar2 >> 5) + 1] = piVar1[(iVar2 >> 5) + 1] & uVar3;
    piVar1[(iVar2 >> 5) + 9] = piVar1[(iVar2 >> 5) + 9] & uVar3;
  }
  if (in_EAX < *piVar1) {
    *piVar1 = in_EAX;
  }
  return;
}


