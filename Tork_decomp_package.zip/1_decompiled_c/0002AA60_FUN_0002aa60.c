// func FUN_0002aa60 @ 0x0002AA60 (size 0x48)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_0002aa60(void)

{
  ushort uVar1;
  int iVar2;
  int *in_EDX;
  float10 fVar3;
  
  iVar2 = *in_EDX;
  if ((((iVar2 == 0) || (*(char *)((int)in_EDX + 0x36) == '\0')) ||
      (*(byte *)(iVar2 + 2) <= *(byte *)((int)in_EDX + 0x49))) ||
     ((iVar2 = *(int *)(iVar2 + 0xc + (uint)*(byte *)((int)in_EDX + 0x49) * 4), iVar2 == 0 ||
      (uVar1 = *(ushort *)(iVar2 + 2), uVar1 == 0)))) {
    return (float10)_DAT_0020df5c;
  }
  fVar3 = (float10)FUN_000ec480();
  return fVar3 / (float10)uVar1;
}


