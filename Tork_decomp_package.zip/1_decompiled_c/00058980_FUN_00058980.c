// func FUN_00058980 @ 0x00058980 (size 0x45)

int FUN_00058980(int param_1,char param_2)

{
  int iVar1;
  
  iVar1 = FUN_00058910();
  if (iVar1 == -1) {
    return 0;
  }
  if ((param_2 == '\0') && (param_1 + -8 != *(int *)(DAT_00241208 + iVar1 * 4))) {
    return 0;
  }
  return (*(int *)(DAT_0024120c + iVar1 * 4) - *(int *)(DAT_00241208 + iVar1 * 4)) + param_1;
}


