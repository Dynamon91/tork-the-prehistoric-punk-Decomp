// func FUN_0001bcc0 @ 0x0001BCC0 (size 0x70)

void FUN_0001bcc0(void)

{
  bool bVar1;
  int unaff_EBX;
  int iVar2;
  int *piVar3;
  
  iVar2 = 0;
  bVar1 = false;
  if (*(char *)(unaff_EBX + 1) != '\0') {
    piVar3 = (int *)(unaff_EBX + 0x38);
    do {
      if (piVar3[-6] != 0) {
        FUN_00058010();
      }
      if (*piVar3 != 0) {
        bVar1 = true;
        FUN_0001cf80(*piVar3,*(undefined4 *)(piVar3[-0xc] + 0x1c));
      }
      FUN_0001ac70();
      iVar2 = iVar2 + 1;
      piVar3 = piVar3 + 1;
    } while (iVar2 < (int)(uint)*(byte *)(unaff_EBX + 1));
    if (bVar1) {
      FUN_0001aab0(DAT_0022d4c0);
    }
  }
  FUN_00058010();
  return;
}


