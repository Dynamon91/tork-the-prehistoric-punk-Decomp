// func FUN_0001e3b0 @ 0x0001E3B0 (size 0x5D8)

void FUN_0001e3b0(void)

{
  float fVar1;
  char cVar2;
  char cVar3;
  char *pcVar4;
  uint uVar5;
  float fVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 uVar10;
  uint *puVar11;
  int in_ECX;
  uint uVar12;
  float *pfVar13;
  byte bVar14;
  uint uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  pcVar4 = *(char **)(in_ECX + 0x3c);
  cVar2 = pcVar4[2];
  bVar14 = pcVar4[3];
  cVar3 = *pcVar4;
  *(char **)(in_ECX + 0x3c) = pcVar4 + 4;
  (**(code **)(&DAT_00241540 + ((byte)pcVar4[5] & 0x3f) * 0x10))();
  (**(code **)(&DAT_00241540 + (*(byte *)(*(int *)(in_ECX + 0x3c) + 1) & 0x3f) * 0x10))();
  switch(cVar2) {
  case '\x06':
  case ' ':
    break;
  default:
    iVar7 = *(int *)(in_ECX + 8);
    puVar11 = (uint *)(iVar7 + -4);
    *(uint **)(in_ECX + 8) = puVar11;
    uVar8 = *puVar11;
    puVar11 = (uint *)(iVar7 + -8);
    *(uint **)(in_ECX + 8) = puVar11;
    if (cVar3 == '\x0e') {
      bVar14 = uVar8 == *puVar11;
    }
    else if (cVar3 == '\x13') {
      bVar14 = uVar8 != *puVar11;
    }
    *puVar11 = (uint)bVar14;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\b':
    iVar7 = *(int *)(in_ECX + 8);
    pfVar13 = (float *)(iVar7 + -4);
    *(float **)(in_ECX + 8) = pfVar13;
    fVar6 = *pfVar13;
    pfVar13 = (float *)(iVar7 + -8);
    *(float **)(in_ECX + 8) = pfVar13;
    fVar1 = *pfVar13;
    switch(cVar3) {
    case '\x01':
      *pfVar13 = fVar1 + fVar6;
      *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
      return;
    case '\x02':
      *pfVar13 = fVar1 - fVar6;
      *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
      return;
    case '\x03':
      *pfVar13 = fVar1 * fVar6;
      *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
      return;
    case '\x04':
      *pfVar13 = fVar1 / fVar6;
      *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
      return;
    default:
      *pfVar13 = fVar6;
      *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
      return;
    case '\x0e':
      if (fVar1 == fVar6) {
LAB_0001e776:
        *pfVar13 = 1.4013e-45;
        *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
        return;
      }
      break;
    case '\x0f':
      if (fVar1 < fVar6) {
        *pfVar13 = 1.4013e-45;
        *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
        return;
      }
      break;
    case '\x10':
      if (fVar6 < fVar1) {
        *pfVar13 = 1.4013e-45;
        *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
        return;
      }
      break;
    case '\x11':
      if ((!NAN(fVar1) && !NAN(fVar6)) && fVar1 < fVar6 != (fVar1 == fVar6)) {
        *pfVar13 = 1.4013e-45;
        *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
        return;
      }
      break;
    case '\x12':
      if (fVar6 <= fVar1) {
        *pfVar13 = 1.4013e-45;
        *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
        return;
      }
      break;
    case '\x13':
      if (fVar1 != fVar6) goto LAB_0001e776;
    }
    *pfVar13 = 0.0;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\t':
    iVar7 = *(int *)(in_ECX + 8);
    if (bVar14 == 9) {
      *(undefined4 **)(in_ECX + 8) = (undefined4 *)(iVar7 + -0xc);
      uStack_18 = *(undefined4 *)(iVar7 + -0xc);
      uStack_14 = *(undefined4 *)(iVar7 + -8);
      uStack_10 = *(undefined4 *)(iVar7 + -4);
    }
    else {
      *(uint **)(in_ECX + 8) = (uint *)(iVar7 + -4);
      uStack_28 = *(uint *)(iVar7 + -4);
    }
    iVar7 = *(int *)(in_ECX + 8);
    puVar11 = (uint *)(iVar7 + -0xc);
    *(uint **)(in_ECX + 8) = puVar11;
    uStack_24 = *puVar11;
    uStack_20 = *(undefined4 *)(iVar7 + -8);
    uStack_1c = *(undefined4 *)(iVar7 + -4);
    switch(cVar3) {
    case '\x01':
      FUN_0001fc70(&uStack_24,&uStack_18);
      break;
    case '\x02':
      FUN_0001fce0(&uStack_24,&uStack_18);
      break;
    case '\x03':
      FUN_0001fc20(&uStack_c,&uStack_24,uStack_28);
      break;
    case '\x04':
      FUN_0001fb40(&uStack_c,&uStack_24,uStack_28);
      break;
    case '\x0e':
      uVar8 = FUN_0001fb20();
      *puVar11 = uVar8 & 0xff;
      *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
      return;
    case '\x13':
      uVar8 = FUN_0001fb00();
      *puVar11 = uVar8 & 0xff;
      *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
      return;
    }
    **(undefined4 **)(in_ECX + 8) = uStack_c;
    *(undefined4 *)(*(int *)(in_ECX + 8) + 4) = uStack_8;
    *(undefined4 *)(*(int *)(in_ECX + 8) + 8) = uStack_4;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 0xc;
    return;
  case '\v':
    iVar7 = *(int *)(in_ECX + 8);
    puVar9 = (undefined4 *)(iVar7 + -4);
    *(undefined4 **)(in_ECX + 8) = puVar9;
    uVar10 = *puVar9;
    puVar9 = (undefined4 *)(iVar7 + -8);
    *(undefined4 **)(in_ECX + 8) = puVar9;
    uVar10 = FUN_00019310(*puVar9,uVar10);
    **(undefined4 **)(in_ECX + 8) = uVar10;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\"':
    iVar7 = *(int *)(in_ECX + 8);
    *(int *)(in_ECX + 8) = iVar7 + -4;
    puVar9 = (undefined4 *)(iVar7 + -8);
    *(undefined4 **)(in_ECX + 8) = puVar9;
    uVar10 = FUN_000194f0(*puVar9);
    **(undefined4 **)(in_ECX + 8) = uVar10;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  }
  iVar7 = *(int *)(in_ECX + 8);
  puVar11 = (uint *)(iVar7 + -4);
  *(uint **)(in_ECX + 8) = puVar11;
  uVar8 = *puVar11;
  puVar11 = (uint *)(iVar7 + -8);
  *(uint **)(in_ECX + 8) = puVar11;
  uVar5 = *puVar11;
  switch(cVar3) {
  case '\x01':
    *puVar11 = uVar5 + uVar8;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\x02':
    *puVar11 = uVar5 - uVar8;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\x03':
    *puVar11 = uVar5 * uVar8;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\x04':
    *puVar11 = (int)uVar5 / (int)uVar8;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\x05':
    *puVar11 = (int)uVar5 % (int)uVar8;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\x06':
    *puVar11 = uVar5 & uVar8;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\a':
    *puVar11 = uVar5 | uVar8;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\b':
    *puVar11 = uVar5 ^ uVar8;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\t':
    *puVar11 = uVar5 << ((byte)uVar8 & 0x1f);
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\n':
    *puVar11 = (int)uVar5 >> ((byte)uVar8 & 0x1f);
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\v':
    if (uVar5 == 0) goto LAB_0001e53e;
    break;
  case '\f':
    if (uVar5 != 0) goto LAB_0001e51f;
    break;
  case '\r':
    uVar12 = uVar5;
    while (uVar8 = uVar8 - 1, uVar8 != 0) {
      uVar12 = uVar12 * uVar5;
    }
    *puVar11 = uVar12;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\x0e':
    *puVar11 = (uint)(uVar5 == uVar8);
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\x0f':
    *puVar11 = (uint)((int)uVar5 < (int)uVar8);
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\x10':
    *puVar11 = (uint)((int)uVar8 < (int)uVar5);
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\x11':
    *puVar11 = (uint)((int)uVar5 <= (int)uVar8);
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\x12':
    *puVar11 = (uint)((int)uVar8 <= (int)uVar5);
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  case '\x13':
    *puVar11 = (uint)(uVar5 != uVar8);
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  default:
    *puVar11 = uStack_28;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  }
  if (uVar8 == 0) {
LAB_0001e53e:
    *puVar11 = 0;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  }
LAB_0001e51f:
  *puVar11 = 1;
  *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
  return;
}


