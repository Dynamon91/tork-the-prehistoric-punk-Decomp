// func FUN_00043740 @ 0x00043740 (size 0x26)

void FUN_00043740(float param_1)

{
  int iVar1;
  uint in_EAX;
  int in_ECX;
  
  iVar1 = *(int *)(in_ECX + 0x10 + (in_EAX & 0xffff) * 8);
  *(float *)(iVar1 + 0x24) = param_1;
  *(float *)(iVar1 + 0x2c) = param_1 * param_1;
  *(float *)(iVar1 + 0x34) = *(float *)(iVar1 + 0x28) - param_1;
  return;
}


