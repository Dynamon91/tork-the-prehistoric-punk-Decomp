// func FUN_00044130 @ 0x00044130 (size 0x2C)

void FUN_00044130(undefined4 param_1)

{
  ushort in_AX;
  int iVar1;
  int in_ECX;
  
  if (in_AX < 0xff) {
    iVar1 = (uint)in_AX * 0x68 + in_ECX;
    if ((char)*(byte *)(iVar1 + 0x58) < '\0') {
      *(undefined4 *)(iVar1 + 0x24) = 0;
      *(undefined4 *)(iVar1 + 0x28) = param_1;
      *(byte *)(iVar1 + 0x58) = *(byte *)(iVar1 + 0x58) | 0x20;
    }
  }
  return;
}


