// func FUN_00019310 @ 0x00019310 (size 0x1D9)

int FUN_00019310(char *param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int unaff_EBX;
  char *pcVar7;
  bool bVar8;
  bool bVar9;
  int local_8;
  
  if ((param_1 < (char *)(unaff_EBX + 0x44)) || (&DAT_00002044 + unaff_EBX <= param_1)) {
LAB_00019345:
    local_8 = -1;
LAB_00019371:
    bVar8 = false;
  }
  else {
    pcVar2 = param_1 + (-0x44 - unaff_EBX);
    uVar6 = (uint)pcVar2 & 0x8000001f;
    bVar8 = uVar6 == 0;
    if ((int)uVar6 < 0) {
      bVar8 = (uVar6 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (!bVar8) goto LAB_00019345;
    local_8 = (int)(pcVar2 + ((int)pcVar2 >> 0x1f & 0x1f)) >> 5;
    if ((local_8 == -1) || (bVar8 = true, *(int *)(&DAT_00002064 + local_8 * 4 + unaff_EBX) != 0))
    goto LAB_00019371;
  }
  if (((char *)(unaff_EBX + 0x44) <= param_2) && (param_2 < &DAT_00002044 + unaff_EBX)) {
    pcVar2 = param_2 + (-0x44 - unaff_EBX);
    uVar6 = (uint)pcVar2 & 0x8000001f;
    bVar9 = uVar6 == 0;
    if ((int)uVar6 < 0) {
      bVar9 = (uVar6 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar9) && ((int)(pcVar2 + ((int)pcVar2 >> 0x1f & 0x1f)) >> 5 != -1)) &&
       (bVar9 = true,
       *(int *)(&DAT_00002064 + ((int)(pcVar2 + ((int)pcVar2 >> 0x1f & 0x1f)) >> 5) * 4 + unaff_EBX)
       == 0)) goto LAB_000193c9;
  }
  bVar9 = false;
LAB_000193c9:
  pcVar2 = param_1;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  pcVar3 = param_2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  if ((bVar8) &&
     (iVar4 = FUN_000550b0(),
     (int)(pcVar2 + (int)(pcVar3 + ((0x20 - (int)(param_2 + 1)) - (int)(param_1 + 1))) +
          ((int)(pcVar2 + (int)(pcVar3 + ((0x20 - (int)(param_2 + 1)) - (int)(param_1 + 1)))) >>
           0x1f & 0x1f)) >> 5 <= iVar4)) {
    iVar4 = local_8 * 0x20 + 0x44 + unaff_EBX;
    pcVar2 = param_2;
    do {
      cVar1 = *pcVar2;
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
    pcVar3 = (char *)(iVar4 + -1);
    do {
      pcVar7 = pcVar3 + 1;
      pcVar3 = pcVar3 + 1;
    } while (*pcVar7 != '\0');
    pcVar7 = param_2;
    for (uVar6 = (uint)((int)pcVar2 - (int)param_2) >> 2; uVar6 != 0; uVar6 = uVar6 - 1) {
      *(undefined4 *)pcVar3 = *(undefined4 *)pcVar7;
      pcVar7 = pcVar7 + 4;
      pcVar3 = pcVar3 + 4;
    }
    for (uVar6 = (int)pcVar2 - (int)param_2 & 3; uVar6 != 0; uVar6 = uVar6 - 1) {
      *pcVar3 = *pcVar7;
      pcVar7 = pcVar7 + 1;
      pcVar3 = pcVar3 + 1;
    }
  }
  else {
    iVar4 = FUN_000550f0((int)(pcVar2 + (int)(pcVar3 + ((0x20 - (int)(param_2 + 1)) -
                                                       (int)(param_1 + 1))) +
                              ((int)(pcVar2 + (int)(pcVar3 + ((0x20 - (int)(param_2 + 1)) -
                                                             (int)(param_1 + 1)))) >> 0x1f & 0x1f))
                         >> 5);
    *(undefined4 *)(&DAT_00002064 + iVar4 * 4 + unaff_EBX) = 0;
    iVar4 = iVar4 * 0x20 + 0x44 + unaff_EBX;
    iVar5 = iVar4 - (int)param_1;
    do {
      cVar1 = *param_1;
      param_1[iVar5] = cVar1;
      param_1 = param_1 + 1;
    } while (cVar1 != '\0');
    pcVar2 = param_2;
    do {
      cVar1 = *pcVar2;
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
    pcVar3 = (char *)(iVar4 + -1);
    do {
      pcVar7 = pcVar3 + 1;
      pcVar3 = pcVar3 + 1;
    } while (*pcVar7 != '\0');
    pcVar7 = param_2;
    for (uVar6 = (uint)((int)pcVar2 - (int)param_2) >> 2; uVar6 != 0; uVar6 = uVar6 - 1) {
      *(undefined4 *)pcVar3 = *(undefined4 *)pcVar7;
      pcVar7 = pcVar7 + 4;
      pcVar3 = pcVar3 + 4;
    }
    for (uVar6 = (int)pcVar2 - (int)param_2 & 3; uVar6 != 0; uVar6 = uVar6 - 1) {
      *pcVar3 = *pcVar7;
      pcVar7 = pcVar7 + 1;
      pcVar3 = pcVar3 + 1;
    }
    if (bVar8) {
      FUN_00019750();
    }
  }
  if (bVar9) {
    FUN_00019750();
  }
  return iVar4;
}


