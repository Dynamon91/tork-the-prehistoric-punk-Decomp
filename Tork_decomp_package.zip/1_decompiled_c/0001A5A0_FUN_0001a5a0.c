// func FUN_0001a5a0 @ 0x0001A5A0 (size 0x257)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0001a5a0(void)

{
  undefined4 *puVar1;
  float fVar2;
  byte bVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  char cVar11;
  int iVar12;
  int unaff_ESI;
  float local_14;
  
  local_14 = *(float *)(DAT_0022d4e4 + 0xc);
  if (_DAT_0020e018 <= local_14) {
    local_14 = 0.05;
  }
  iVar12 = *(int *)(unaff_ESI + 0x700) + -1;
  *(int *)(&DAT_0000470c + unaff_ESI) = iVar12;
  *(int *)(&DAT_00004708 + unaff_ESI) = iVar12 * 0x20 + 0x704 + unaff_ESI;
  if (iVar12 < 0) {
    *(undefined **)(&DAT_00004708 + unaff_ESI) = &DAT_00004710 + unaff_ESI;
    return;
  }
  do {
    piVar4 = *(int **)(&DAT_00004708 + unaff_ESI);
    if (((*(byte *)((int)piVar4 + 0x1b) & 2) == 0) && ((*(byte *)(piVar4[1] + 8) & 8) != 0)) {
      FUN_0001a370();
      goto LAB_0001a7ad;
    }
    if ((short)piVar4[4] == 0) {
      if (((*(byte *)((int)piVar4 + 0x1b) & 1) == 0) && ((*(byte *)(piVar4[1] + 8) & 1) == 0))
      goto LAB_0001a625;
      *(undefined1 *)(unaff_ESI + 0x27f) = 0;
      *(undefined1 *)(unaff_ESI + 0x27e) = 0;
      *(undefined1 *)(unaff_ESI + 0x27d) = 0;
      *(undefined1 *)(unaff_ESI + 0x27c) = 0;
      cVar11 = (**(code **)(unaff_ESI + *piVar4 * 4))();
      if (cVar11 == '\0') goto LAB_0001a625;
      iVar12 = *(int *)(&DAT_00004708 + unaff_ESI);
      iVar5 = *(int *)(iVar12 + 0x1c);
      iVar6 = *(int *)(iVar12 + 4);
      bVar3 = *(byte *)(iVar12 + 8);
      iVar7 = *(int *)(*(int *)(iVar6 + 0x24) + 4);
      (&DAT_00004731)[unaff_ESI] = 0xff;
      (&DAT_00004730)[unaff_ESI] = *(undefined1 *)(iVar7 + 0x6b + (uint)bVar3 * 8);
      iVar10 = DAT_0022a6c4;
      iVar12 = iVar7 + 0x6a + (uint)bVar3 * 8;
      *(int *)(DAT_0022a6c4 + 0x14) = iVar6;
      *(int *)(iVar10 + 0x10) = iVar6;
      *(int *)(iVar10 + 0x30) = iVar7;
      *(int *)(iVar10 + 0xc) = iVar7;
      iVar6 = DAT_0022a6c4;
      bVar3 = *(byte *)(*(int *)(&DAT_00004708 + unaff_ESI) + 8);
      puVar1 = (undefined4 *)(*(int *)(DAT_0022a6c4 + 0xc) + 0x6a + (uint)bVar3 * 8);
      uVar8 = *puVar1;
      *(undefined1 *)((int)puVar1 + 1) = *(undefined1 *)(*(int *)(&DAT_00004708 + unaff_ESI) + 9);
      uVar9 = puVar1[1];
      *(undefined1 *)((int)puVar1 + 3) = 0xff;
      *(undefined2 *)(puVar1 + 1) = 0xffff;
      *(byte *)(iVar6 + 0x18) = bVar3;
      FUN_00017fd0();
      *puVar1 = uVar8;
      puVar1[1] = uVar9;
      if ((&DAT_00004731)[unaff_ESI] != -1) {
        if (*(short *)(iVar12 + 4) != -1) {
          *(undefined2 *)(iVar12 + 4) = 0xffff;
          *(undefined1 *)
           (iVar7 + 0x6d + (uint)*(byte *)(*(int *)(&DAT_00004708 + unaff_ESI) + 8) * 8) = 0xff;
        }
        *(undefined *)(iVar12 + 1) = (&DAT_00004731)[unaff_ESI];
      }
      if ((*(int *)(&DAT_0000470c + unaff_ESI) < *(int *)(unaff_ESI + 0x700)) &&
         (iVar12 = *(int *)(&DAT_00004708 + unaff_ESI), *(int *)(iVar12 + 0x1c) == iVar5)) {
        if ((*(short *)(iVar12 + 10) < 1) ||
           (*(short *)(iVar12 + 10) = *(short *)(iVar12 + 10) + -1,
           *(short *)(*(int *)(&DAT_00004708 + unaff_ESI) + 10) != 0)) goto LAB_0001a625;
        FUN_0001a370();
      }
    }
    else {
      *(short *)(piVar4 + 4) = (short)piVar4[4] + -1;
LAB_0001a625:
      iVar12 = *(int *)(&DAT_00004708 + unaff_ESI);
      if (_DAT_0020df5c < *(float *)(iVar12 + 0xc)) {
        *(float *)(iVar12 + 0xc) = *(float *)(iVar12 + 0xc) - local_14;
        fVar2 = *(float *)(*(int *)(&DAT_00004708 + unaff_ESI) + 0xc);
        if ((!NAN(fVar2) && !NAN(_DAT_0020df5c)) &&
            fVar2 < _DAT_0020df5c != (fVar2 == _DAT_0020df5c)) {
          FUN_0001a370();
        }
      }
    }
LAB_0001a7ad:
    iVar12 = *(int *)(&DAT_0000470c + unaff_ESI);
    *(int *)(&DAT_0000470c + unaff_ESI) = iVar12 + -1;
    *(int *)(&DAT_00004708 + unaff_ESI) = *(int *)(&DAT_00004708 + unaff_ESI) + -0x20;
    if (iVar12 + -1 < 0) {
      *(undefined **)(&DAT_00004708 + unaff_ESI) = &DAT_00004710 + unaff_ESI;
      return;
    }
  } while( true );
}


