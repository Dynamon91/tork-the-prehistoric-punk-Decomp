// func FUN_0005b110 @ 0x0005B110 (size 0x9C)

void FUN_0005b110(void)

{
  char cVar1;
  ushort uVar2;
  char *pcVar3;
  int unaff_EBX;
  int unaff_ESI;
  int iVar4;
  
  if (unaff_ESI != -1) {
    pcVar3 = (char *)(unaff_EBX + 0xc);
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    __write();
    __write();
    __write();
    __write();
    uVar2 = *(ushort *)(unaff_EBX + 10);
    __write();
    iVar4 = 0;
    if (uVar2 != 0) {
      do {
        __write();
        iVar4 = iVar4 + 1;
      } while (iVar4 < (int)(uint)uVar2);
    }
  }
  return;
}


