// func FUN_000531e0 @ 0x000531E0 (size 0x15A)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ushort FUN_000531e0(int param_1,float *param_2,ushort param_3,float *param_4,float *param_5)

{
  bool bVar1;
  bool bVar2;
  ushort uVar3;
  ushort uVar4;
  
  if (param_3 == 0) {
    return 0;
  }
  bVar1 = _DAT_0020df5c <=
          ((param_2 + (uint)(ushort)(param_3 - 1) * 3)[1] - param_4[1]) * *param_5 -
          (param_2[(uint)(ushort)(param_3 - 1) * 3] - *param_4) * param_5[1];
  uVar4 = 0;
  uVar3 = 0;
  if (param_3 != 0) {
    do {
      bVar2 = _DAT_0020df5c <=
              (param_2[1] - param_4[1]) * *param_5 - (*param_2 - *param_4) * param_5[1];
      if (bVar2 != bVar1) {
        FUN_000530c0(param_1 + (uint)uVar4 * 4);
        uVar4 = uVar4 + 1;
        bVar1 = bVar2;
      }
      uVar3 = uVar3 + 1;
      param_2 = param_2 + 3;
    } while (uVar3 < param_3);
  }
  return uVar4;
}


