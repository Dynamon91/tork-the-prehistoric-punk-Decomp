// func FUN_000115b0 @ 0x000115B0 (size 0xDB)

void FUN_000115b0(void)

{
  bool bVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *unaff_EBX;
  
  FUN_00060b10(*unaff_EBX,*(undefined1 *)((int)unaff_EBX + 0x96));
  FUN_00011b20();
  FUN_000d8f50();
  FUN_000823e0(0);
  uVar3 = FUN_00082620();
  unaff_EBX[2] = uVar3;
  FUN_00082740((undefined2)DAT_0022dc90);
  FUN_0008edb0(DAT_0022ddcc,*(undefined4 *)(unaff_EBX[2] + 8));
  FUN_00061010();
  DAT_002387ec = FUN_000bf600();
  if (*(char *)(unaff_EBX + 3) == '\0') {
    bVar1 = false;
  }
  else {
    cVar2 = FUN_0005bfd0(DAT_0022d4c0,unaff_EBX + 3);
    bVar1 = false;
    if (cVar2 != '\0') {
      if (*(char *)(unaff_EBX + 0x26) != '\0') {
        cVar2 = FUN_0005c8b0();
        bVar1 = false;
        if (cVar2 == '\0') goto LAB_00011650;
      }
      bVar1 = true;
    }
  }
LAB_00011650:
  *(bool *)((int)unaff_EBX + 0x99) = !bVar1;
  DAT_002414b0 = FUN_000d7750();
  FUN_00118a60();
  if (*(int *)(DAT_00241220 + 0x104) == 0) {
    *(undefined1 *)((int)unaff_EBX + 0x99) = 1;
  }
  FUN_000117a0();
  return;
}


