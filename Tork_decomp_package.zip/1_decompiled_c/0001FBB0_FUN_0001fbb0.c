// func FUN_0001fbb0 @ 0x0001FBB0 (size 0x36)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0001fbb0(float *param_1,float param_2)

{
  param_2 = _DAT_0020df98 / param_2;
  *param_1 = param_2 * *param_1;
  *(ulonglong *)(param_1 + 1) =
       CONCAT44(param_2 * (float)((ulonglong)*(undefined8 *)(param_1 + 1) >> 0x20),
                param_2 * (float)*(undefined8 *)(param_1 + 1));
  return;
}


