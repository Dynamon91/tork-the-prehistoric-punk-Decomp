// func FUN_0001a500 @ 0x0001A500 (size 0x7E)

void FUN_0001a500(void)

{
  uint in_EAX;
  uint uVar1;
  int iVar2;
  int in_EDX;
  int unaff_EBX;
  
  uVar1 = in_EAX & 0xffff;
  iVar2 = uVar1 + unaff_EBX;
  for (; (int)uVar1 < iVar2; uVar1 = uVar1 + 1) {
    *(uint *)(&DAT_00004738 + ((int)uVar1 >> 5) * 4 + in_EDX) =
         *(uint *)(&DAT_00004738 + ((int)uVar1 >> 5) * 4 + in_EDX) & ~(1 << ((byte)uVar1 & 0x1f));
  }
  if (*(int *)(&DAT_00004734 + in_EDX) == iVar2) {
    iVar2 = *(int *)(&DAT_00004734 + in_EDX) - unaff_EBX;
    *(int *)(&DAT_00004734 + in_EDX) = iVar2;
    while ((0 < iVar2 &&
           (iVar2 = *(int *)(&DAT_00004734 + in_EDX) + -1,
           (*(uint *)(&DAT_00004738 + (iVar2 >> 5) * 4 + in_EDX) & 1 << ((byte)iVar2 & 0x1f)) == 0))
          ) {
      *(int *)(&DAT_00004734 + in_EDX) = iVar2;
    }
  }
  return;
}


