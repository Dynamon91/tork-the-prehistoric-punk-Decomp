// func FUN_00018580 @ 0x00018580 (size 0x7A)

undefined2 FUN_00018580(short param_1)

{
  uint *in_EAX;
  uint in_ECX;
  short unaff_BX;
  uint uVar1;
  
  uVar1 = *in_EAX;
  if (uVar1 != in_EAX[1]) {
    do {
      if (((in_EAX[uVar1 * 4 + 2] == in_ECX) && (unaff_BX <= (short)in_EAX[uVar1 * 4 + 4])) &&
         ((short)in_EAX[uVar1 * 4 + 4] <= param_1)) break;
      uVar1 = uVar1 + 1 & 0x1ff;
    } while (uVar1 != in_EAX[1]);
    if (uVar1 != in_EAX[1]) {
      *(undefined1 *)(in_EAX + 0x1047) = 1;
      in_EAX[0x1048] = uVar1;
      in_EAX[0x1049] = (uint)(ushort)in_EAX[uVar1 * 4 + 5];
      uVar1 = in_EAX[uVar1 * 4 + 4];
      FUN_00018850();
      return (short)uVar1;
    }
  }
  return 0xffff;
}


