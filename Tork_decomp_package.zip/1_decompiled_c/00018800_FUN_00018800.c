// func FUN_00018800 @ 0x00018800 (size 0x46)

void FUN_00018800(void)

{
  int iVar1;
  undefined4 *in_EDX;
  undefined4 *puVar2;
  
  *in_EDX = 0;
  in_EDX[1] = 0;
  iVar1 = 0x200;
  puVar2 = in_EDX;
  do {
    puVar2 = puVar2 + 4;
    *(undefined2 *)puVar2 = 0xffff;
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  in_EDX[0x802] = 0;
  in_EDX[0x803] = 0;
  puVar2 = in_EDX + 0x1004;
  for (iVar1 = 0x40; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar2 = 0;
    puVar2 = puVar2 + 1;
  }
  *(undefined1 *)(in_EDX + 0x1044) = 0;
  *(undefined1 *)(in_EDX + 0x1047) = 0;
  return;
}


