// func FUN_0002be20 @ 0x0002BE20 (size 0xA2)

undefined1 FUN_0002be20(void)

{
  char cVar1;
  int in_EAX;
  
  if ((*(uint *)(in_EAX + 4) >> 0x1e & 1) != 0) {
    FUN_000479c0();
    cVar1 = FUN_00070600();
    if (cVar1 == '\0') {
      return 0;
    }
  }
  return 1;
}


