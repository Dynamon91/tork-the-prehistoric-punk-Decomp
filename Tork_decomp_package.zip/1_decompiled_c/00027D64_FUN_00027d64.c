// func FUN_00027d64 @ 0x00027D64 (size 0x183)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00027d64(void)

{
  float *pfVar1;
  float *pfVar2;
  float *pfVar3;
  uint in_EAX;
  int unaff_EDI;
  float *in_stack_00000010;
  
  FUN_000dea30(in_EAX | 2);
  pfVar3 = *(float **)(unaff_EDI + 0x10);
  pfVar1 = pfVar3 + 4;
  *pfVar1 = -*in_stack_00000010;
  pfVar3[5] = -in_stack_00000010[1];
  pfVar3[6] = -in_stack_00000010[2];
  FUN_00021780();
  pfVar2 = pfVar3 + 8;
  if (_DAT_0020e1e4 < ABS(*pfVar1 * *pfVar2 + pfVar3[9] * pfVar3[5] + pfVar3[10] * pfVar3[6])) {
    *pfVar2 = pfVar3[6] * pfVar3[1] - pfVar3[5] * pfVar3[2];
    pfVar3[9] = pfVar3[2] * *pfVar1 - pfVar3[6] * *pfVar3;
    pfVar3[10] = pfVar3[5] * *pfVar3 - pfVar3[1] * *pfVar1;
    FUN_00021780();
    *pfVar3 = pfVar3[10] * pfVar3[5] - pfVar3[6] * pfVar3[9];
    pfVar3[1] = pfVar3[6] * *pfVar2 - *pfVar1 * pfVar3[10];
    pfVar3[2] = *pfVar1 * pfVar3[9] - *pfVar2 * pfVar3[5];
    FUN_000254c0();
    return;
  }
  *pfVar3 = pfVar3[10] * pfVar3[5] - pfVar3[9] * pfVar3[6];
  pfVar3[1] = *pfVar2 * pfVar3[6] - pfVar3[10] * *pfVar1;
  pfVar3[2] = *pfVar1 * pfVar3[9] - *pfVar2 * pfVar3[5];
  FUN_00021780();
  *pfVar2 = pfVar3[1] * pfVar3[6] - pfVar3[5] * pfVar3[2];
  pfVar3[9] = pfVar3[2] * *pfVar1 - *pfVar3 * pfVar3[6];
  pfVar3[10] = *pfVar3 * pfVar3[5] - pfVar3[1] * *pfVar1;
  FUN_000254c0();
  return;
}


