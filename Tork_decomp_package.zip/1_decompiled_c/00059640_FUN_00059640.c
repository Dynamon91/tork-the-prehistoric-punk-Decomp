// func FUN_00059640 @ 0x00059640 (size 0x149)

void FUN_00059640(void)

{
  ushort uVar1;
  undefined4 uVar2;
  uint uVar3;
  ushort *puVar4;
  uint uVar5;
  ushort *puVar6;
  uint uVar7;
  uint uVar8;
  int unaff_EDI;
  
  uVar7 = (uint)*(ushort *)(unaff_EDI + 0xa2);
  if (uVar7 < 0x401) {
    if (0x7ff < *(ushort *)(unaff_EDI + 0xa0)) {
      uVar2 = FUN_00058070();
      *(undefined4 *)(unaff_EDI + 0x9c) = uVar2;
      uVar1 = *(ushort *)(unaff_EDI + 0xa2);
      *(undefined2 *)(unaff_EDI + 0xa0) = 0x400;
      if (0x3ff < uVar1) {
        uVar1 = 0x400;
      }
      *(ushort *)(unaff_EDI + 0xa2) = uVar1;
      return;
    }
  }
  else {
    uVar8 = (uint)*(ushort *)(unaff_EDI + 0xaa);
    uVar3 = 0;
    if (uVar8 != 0) {
      do {
        uVar5 = uVar3 & 0xffff;
        uVar3 = uVar3 + 1;
        *(undefined4 *)
         (*(int *)(unaff_EDI + 0x9c) +
         (uint)*(ushort *)(*(int *)(unaff_EDI + 0xa4) + uVar5 * 2) * 0x18) = 0xffffedcb;
      } while ((int)uVar3 < (int)uVar8);
    }
    do {
      if (*(int *)(*(int *)(unaff_EDI + 0x9c) + (uVar7 - 1 & 0xffff) * 0x18) != -0x1235) break;
      uVar7 = uVar7 - 1;
    } while (0x400 < (int)uVar7);
    if ((int)uVar7 < (int)(uint)(*(ushort *)(unaff_EDI + 0xa0) >> 1)) {
      uVar2 = FUN_00058070();
      *(undefined4 *)(unaff_EDI + 0x9c) = uVar2;
      *(ushort *)(unaff_EDI + 0xa0) = (ushort)uVar7;
      uVar3 = (uint)*(ushort *)(unaff_EDI + 0xa2);
      if ((ushort)uVar7 <= *(ushort *)(unaff_EDI + 0xa2)) {
        uVar3 = uVar7;
      }
      *(short *)(unaff_EDI + 0xa2) = (short)uVar3;
      puVar6 = *(ushort **)(unaff_EDI + 0xa4);
      puVar4 = puVar6;
      for (; uVar8 != 0; uVar8 = uVar8 - 1) {
        if ((int)(uint)*puVar6 < (int)uVar7) {
          *puVar4 = *puVar6;
          puVar4 = puVar4 + 1;
        }
        puVar6 = puVar6 + 1;
      }
      uVar1 = (ushort)((int)puVar4 - *(int *)(unaff_EDI + 0xa4) >> 1);
      if (uVar1 <= *(ushort *)(unaff_EDI + 0xa8)) {
        *(ushort *)(unaff_EDI + 0xaa) = uVar1;
        return;
      }
      *(ushort *)(unaff_EDI + 0xaa) = *(ushort *)(unaff_EDI + 0xa8);
    }
  }
  return;
}


