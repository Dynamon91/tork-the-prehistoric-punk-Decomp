// func FUN_0004b2b0 @ 0x0004B2B0 (size 0x63)

undefined4 FUN_0004b2b0(undefined *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  bool bVar3;
  
  uVar1 = __wtol(param_1);
  if (((undefined *)(DAT_002411d8 + 0x44) <= param_1) && (param_1 < &DAT_00002044 + DAT_002411d8)) {
    param_1 = param_1 + (-0x44 - DAT_002411d8);
    uVar2 = (uint)param_1 & 0x8000001f;
    bVar3 = uVar2 == 0;
    if ((int)uVar2 < 0) {
      bVar3 = (uVar2 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar3) && ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5 != -1)) &&
       (*(int *)(&DAT_00002064 +
                ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5) * 4 + DAT_002411d8) == 0)) {
      FUN_00019750();
    }
  }
  return uVar1;
}


