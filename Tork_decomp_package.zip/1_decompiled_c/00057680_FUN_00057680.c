// func FUN_00057680 @ 0x00057680 (size 0x1DA)

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_00057680(void)

{
  uint uVar1;
  uint uVar2;
  undefined *puVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int *piVar9;
  undefined *puVar10;
  int local_144;
  int local_140;
  uint local_138;
  undefined1 local_12c [40];
  char local_104 [256];
  undefined4 local_4;
  
  local_4 = DAT_002264b0;
  FUN_00057560(local_12c);
  uVar1 = *(uint *)(DAT_0022a76c + 4) & 0x7ffffffc;
  _sprintf(local_104,s_Free_memory_on_top_of_the_heap___00208544,(int)uVar1 >> 10);
  iVar6 = 0;
  iVar7 = 0;
  uVar4 = 0;
  piVar9 = &DAT_0022a744;
  iVar5 = 10;
  do {
    for (iVar8 = *piVar9; iVar8 != 0; iVar8 = *(int *)(iVar8 + 8)) {
      uVar2 = *(uint *)(iVar8 + 4) & 0x7ffffffc;
      iVar6 = iVar6 + 1;
      iVar7 = iVar7 + uVar2;
      if (uVar4 < uVar2) {
        uVar4 = uVar2;
      }
    }
    piVar9 = piVar9 + 1;
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  _sprintf(local_104,s_Free_memory_in_fast_bins____d_KB_00208500,
           (int)(iVar7 + (iVar7 >> 0x1f & 0x3ffU)) >> 10,iVar6,uVar4);
  local_144 = 0;
  local_140 = 0;
  puVar10 = &DAT_0022a774;
  do {
    puVar3 = *(undefined **)(puVar10 + 0xc);
    iVar8 = 0;
    iVar5 = 0;
    uVar4 = 0;
    local_138 = 0x40000000;
    if (puVar3 != puVar10) {
      do {
        uVar2 = *(uint *)(puVar3 + 4) & 0x7ffffffc;
        if (uVar4 < uVar2) {
          uVar4 = uVar2;
        }
        if (uVar2 < local_138) {
          local_138 = uVar2;
        }
        puVar3 = *(undefined **)(puVar3 + 0xc);
        iVar8 = iVar8 + 1;
        local_144 = local_144 + 1;
        local_140 = local_140 + uVar2;
        iVar5 = iVar5 + uVar2;
      } while (puVar3 != puVar10);
      if (0 < iVar8) {
        puVar3 = &DAT_002084f8;
        if (iVar8 < 2) {
          puVar3 = &DAT_001ca8da;
        }
        _sprintf(local_104,s__d_block_s_of_size_between__d_an_002084c4,iVar8,puVar3,local_138,uVar4,
                 (int)(iVar5 + (iVar5 >> 0x1f & 0x3ffU)) >> 10);
      }
    }
    puVar10 = puVar10 + 8;
  } while ((int)puVar10 < 0x22aa6c);
  _sprintf(local_104,s_Free_memory_in_regular_bins____d_00208490,
           (int)(local_140 + (local_140 >> 0x1f & 0x3ffU)) >> 10,local_144);
  iVar7 = iVar7 + local_140 + uVar1;
  _sprintf(local_104,s_Total_free_memory____d_KB___d_bl_00208468,
           (int)(iVar7 + (iVar7 >> 0x1f & 0x3ffU)) >> 10,local_144 + 1 + iVar6);
  return;
}


