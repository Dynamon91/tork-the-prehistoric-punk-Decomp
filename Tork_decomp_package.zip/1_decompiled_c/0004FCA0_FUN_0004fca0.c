// func FUN_0004fca0 @ 0x0004FCA0 (size 0x12D)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_0004fca0(undefined4 param_1,undefined4 param_2,float *param_3,float *param_4)

{
  float fVar1;
  float fVar2;
  float *pfVar3;
  undefined4 unaff_EBX;
  undefined4 unaff_EDI;
  float10 fVar4;
  float10 fVar5;
  float10 fVar6;
  float local_8;
  
  pfVar3 = param_3;
  fVar4 = (float10)FUN_000683e0(unaff_EBX,unaff_EDI);
  fVar5 = (float10)FUN_000683e0(unaff_EBX,unaff_EDI);
  fVar6 = (float10)FUN_000683e0(unaff_EBX,unaff_EDI);
  fVar1 = _DAT_0020df98 / *param_4;
  fVar2 = (float)fVar4 - *param_3;
  if ((float)fVar4 - *param_3 < _DAT_0020df5c) {
    fVar2 = _DAT_0020df5c;
  }
  param_3 = (float *)(fVar2 * fVar1);
  if (_DAT_0020df98 < (float)param_3) {
    param_3 = (float *)0x3f800000;
  }
  fVar4 = (float10)(float)fVar5 - (float10)pfVar3[1];
  if (fVar4 < (float10)_DAT_0020df5c) {
    fVar4 = (float10)_DAT_0020df5c;
  }
  fVar4 = fVar4 * (float10)fVar1;
  if ((float10)_DAT_0020df98 < fVar4) {
    fVar4 = (float10)_DAT_0020df98;
  }
  local_8 = (float)fVar6 - pfVar3[2];
  if (local_8 < _DAT_0020df5c) {
    local_8 = _DAT_0020df5c;
  }
  local_8 = local_8 * fVar1;
  if (_DAT_0020df98 < local_8) {
    local_8 = 1.0;
  }
  if (fVar4 < (float10)(float)param_3) {
    fVar4 = (float10)(float)param_3;
  }
  if (fVar4 < (float10)local_8) {
    fVar4 = (float10)local_8;
  }
  return (float10)_DAT_0020df98 - fVar4;
}


