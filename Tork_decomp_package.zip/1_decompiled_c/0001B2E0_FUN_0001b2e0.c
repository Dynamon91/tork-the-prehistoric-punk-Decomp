// func FUN_0001b2e0 @ 0x0001B2E0 (size 0x44)

void FUN_0001b2e0(void)

{
  short *psVar1;
  int in_ECX;
  int iVar2;
  int *piVar3;
  
  *(byte *)(in_ECX + 0x25) = *(byte *)(in_ECX + 0x25) & 0xbf;
  iVar2 = 0;
  if (0 < *(short *)(in_ECX + 0x26)) {
    piVar3 = (int *)(in_ECX + 0x28);
    do {
      psVar1 = (short *)*piVar3;
      if ((psVar1 != (short *)0x0) &&
         (*psVar1 = *psVar1 + -1, (*(ushort *)(*piVar3 + 0x24) >> 0xe & 1) != 0)) {
        FUN_0001b2e0();
      }
      iVar2 = iVar2 + 1;
      piVar3 = piVar3 + 1;
    } while (iVar2 < *(short *)(in_ECX + 0x26));
  }
  return;
}


