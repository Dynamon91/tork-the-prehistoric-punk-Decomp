// func FUN_0001ca10 @ 0x0001CA10 (size 0x38)

void FUN_0001ca10(void)

{
  uint *unaff_EBX;
  uint uVar1;
  uint *puVar2;
  
  uVar1 = 0;
  if (*unaff_EBX != 0) {
    puVar2 = unaff_EBX + 3;
    do {
      if (((puVar2[2] & 1) != 0) && (4 < *puVar2)) {
        FUN_00058010();
      }
      uVar1 = uVar1 + 1;
      puVar2 = puVar2 + 5;
    } while (uVar1 < *unaff_EBX);
  }
  FUN_00058010();
  return;
}


