// func FUN_00011910 @ 0x00011910 (size 0x7C)

void FUN_00011910(int param_1)

{
  short *psVar1;
  
  FUN_00118a10();
  FUN_00118eb0();
  if (DAT_002387ec != 0) {
    FUN_000bf6a0();
  }
  if ((DAT_002387d0 != (int *)0x0) && (*DAT_002387d0 != 0)) {
    FUN_00080640(*DAT_002387d0 + 0x24);
  }
  FUN_000d98d0(1);
  psVar1 = *(short **)(*(int *)(param_1 + 8) + 8);
  *psVar1 = *psVar1 + -1;
  if (*psVar1 == 0) {
    FUN_00058010();
  }
  FUN_00058010();
  FUN_000d9030();
  FUN_00011c20();
  FUN_000824b0();
  FUN_00060ba0();
  return;
}


