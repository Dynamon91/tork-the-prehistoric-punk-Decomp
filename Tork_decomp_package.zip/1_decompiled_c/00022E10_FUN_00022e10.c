// func FUN_00022e10 @ 0x00022E10 (size 0x50)

float10 FUN_00022e10(float *param_1,float *param_2,float *param_3)

{
  return (float10)(*param_1 - *param_2) * (float10)*param_3 +
         (float10)((float)((ulonglong)*(undefined8 *)(param_1 + 1) >> 0x20) -
                  (float)((ulonglong)*(undefined8 *)(param_2 + 1) >> 0x20)) * (float10)param_3[2] +
         (float10)((float)*(undefined8 *)(param_1 + 1) - (float)*(undefined8 *)(param_2 + 1)) *
         (float10)param_3[1];
}


