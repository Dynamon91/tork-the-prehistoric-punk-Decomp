// func FUN_0004ace0 @ 0x0004ACE0 (size 0x63)

long FUN_0004ace0(char *param_1)

{
  long lVar1;
  uint uVar2;
  bool bVar3;
  
  lVar1 = _atol(param_1);
  if (((char *)(DAT_002411d8 + 0x44U) <= param_1) && (param_1 < &DAT_00002044 + DAT_002411d8)) {
    param_1 = param_1 + (-0x44 - DAT_002411d8);
    uVar2 = (uint)param_1 & 0x8000001f;
    bVar3 = uVar2 == 0;
    if ((int)uVar2 < 0) {
      bVar3 = (uVar2 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar3) && ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5 != -1)) &&
       (*(int *)(&DAT_00002064 +
                ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5) * 4 + DAT_002411d8) == 0)) {
      FUN_00019750();
    }
  }
  return lVar1;
}


