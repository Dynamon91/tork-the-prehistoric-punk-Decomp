// func FUN_00046690 @ 0x00046690 (size 0x5A)

void FUN_00046690(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int in_EAX;
  int *piVar3;
  int unaff_ESI;
  
  piVar1 = *(int **)(in_EAX + 0x654);
  piVar3 = piVar1;
  if (piVar1 < piVar1 + *(int *)(in_EAX + 0x660) * 2) {
    while (iVar2 = *piVar3, piVar3 = piVar3 + 2, iVar2 != unaff_ESI) {
      if (piVar1 + *(int *)(in_EAX + 0x660) * 2 <= piVar3) {
        FUN_000465c0(unaff_ESI,param_1);
        return;
      }
    }
    if ((int)piVar3 + (-8 - (int)piVar1) >> 3 != -1) {
      return;
    }
  }
  FUN_000465c0(unaff_ESI,param_1);
  return;
}


