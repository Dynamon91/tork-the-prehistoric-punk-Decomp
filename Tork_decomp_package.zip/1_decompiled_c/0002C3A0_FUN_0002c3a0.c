// func FUN_0002c3a0 @ 0x0002C3A0 (size 0x2B0)

int FUN_0002c3a0(void)

{
  ushort uVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  ushort uVar5;
  
  iVar2 = *(int *)(DAT_0022a6c4 + 0x14);
  uVar1 = *(ushort *)(*(int *)(iVar2 + 0x24) + 0x1e);
  iVar4 = 0;
  uVar5 = DAT_002411ec;
  if ((*(uint *)(iVar2 + 4) >> 0x1e & 1) == 0) {
    while ((uVar5 < uVar1 && (iVar4 == 0))) {
      iVar4 = *(int *)(*(int *)(*(int *)(iVar2 + 0x24) + 0x18) + (uint)uVar5 * 4);
      uVar5 = uVar5 + 1;
      DAT_002411ec = uVar5;
      if (((*(uint *)(iVar4 + 4) >> 0x1e & 1) != 0) && (cVar3 = FUN_00070600(), cVar3 == '\0')) {
        iVar4 = 0;
      }
    }
  }
  else if (DAT_002411ec < uVar1) {
    while (iVar4 == 0) {
      iVar4 = *(int *)(*(int *)(*(int *)(iVar2 + 0x24) + 0x18) + (uint)uVar5 * 4);
      uVar5 = uVar5 + 1;
      DAT_002411ec = uVar5;
      if ((*(uint *)(iVar4 + 4) >> 0x1e & 1) == 0) {
        cVar3 = FUN_00070600();
      }
      else {
        cVar3 = FUN_00070480();
      }
      if (cVar3 == '\0') {
        iVar4 = 0;
      }
      if (uVar1 <= uVar5) {
        return iVar4;
      }
    }
  }
  return iVar4;
}


