// func FUN_0001aab0 @ 0x0001AAB0 (size 0x7A)

void FUN_0001aab0(int param_1)

{
  int iVar1;
  int iVar2;
  int in_EAX;
  int iVar3;
  int *piVar4;
  undefined8 uVar5;
  int local_4;
  
  local_4 = 0;
  piVar4 = (int *)(param_1 + 0xc);
  do {
    iVar2 = *piVar4;
    if (((iVar2 != 0) && (1 < (uint)piVar4[1])) && (in_EAX != 0)) {
      uVar5 = FUN_00079920();
      iVar3 = (int)uVar5;
      if ((iVar3 != -1) && (iVar1 = *(int *)(iVar2 + 0x18) + iVar3 * 0xc, *(int *)(iVar1 + 8) != 0))
      {
        FUN_00079830((int)((ulonglong)uVar5 >> 0x20),iVar3);
        *(undefined4 *)(iVar1 + 8) = 0;
        *(int *)(iVar2 + 0x6c) = *(int *)(iVar2 + 0x6c) + -1;
        *(undefined2 *)(iVar1 + 6) = 0;
        return;
      }
    }
    local_4 = local_4 + 1;
    piVar4 = piVar4 + 6;
    if (0xff < local_4) {
      return;
    }
  } while( true );
}


