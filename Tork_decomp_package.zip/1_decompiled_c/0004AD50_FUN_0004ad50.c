// func FUN_0004ad50 @ 0x0004AD50 (size 0x5E)

void FUN_0004ad50(undefined *param_1)

{
  uint uVar1;
  bool bVar2;
  
  FUN_00135873(param_1);
  if (((undefined *)(DAT_002411d8 + 0x44) <= param_1) && (param_1 < &DAT_00002044 + DAT_002411d8)) {
    param_1 = param_1 + (-0x44 - DAT_002411d8);
    uVar1 = (uint)param_1 & 0x8000001f;
    bVar2 = uVar1 == 0;
    if ((int)uVar1 < 0) {
      bVar2 = (uVar1 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar2) && ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5 != -1)) &&
       (*(int *)(&DAT_00002064 +
                ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5) * 4 + DAT_002411d8) == 0)) {
      FUN_00019750();
      return;
    }
  }
  return;
}


