// func FUN_00027d30 @ 0x00027D30 (size 0x34)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00027d30(float *param_1)

{
  float *pfVar1;
  float *pfVar2;
  int iVar3;
  float *pfVar4;
  
  iVar3 = *(int *)(DAT_0022a6c4 + 0x14);
  if ((*(uint *)(iVar3 + 4) >> 7 & 1) != 0) {
    FUN_000e5f10(*(undefined4 *)(iVar3 + 0x1c));
    FUN_000254c0();
    return;
  }
  FUN_000dea30(*(uint *)(iVar3 + 4) | 2);
  pfVar4 = *(float **)(iVar3 + 0x10);
  pfVar1 = pfVar4 + 4;
  *pfVar1 = -*param_1;
  pfVar4[5] = -param_1[1];
  pfVar4[6] = -param_1[2];
  FUN_00021780();
  pfVar2 = pfVar4 + 8;
  if (_DAT_0020e1e4 < ABS(*pfVar1 * *pfVar2 + pfVar4[9] * pfVar4[5] + pfVar4[10] * pfVar4[6])) {
    *pfVar2 = pfVar4[6] * pfVar4[1] - pfVar4[5] * pfVar4[2];
    pfVar4[9] = pfVar4[2] * *pfVar1 - pfVar4[6] * *pfVar4;
    pfVar4[10] = pfVar4[5] * *pfVar4 - pfVar4[1] * *pfVar1;
    FUN_00021780();
    *pfVar4 = pfVar4[10] * pfVar4[5] - pfVar4[6] * pfVar4[9];
    pfVar4[1] = pfVar4[6] * *pfVar2 - *pfVar1 * pfVar4[10];
    pfVar4[2] = *pfVar1 * pfVar4[9] - *pfVar2 * pfVar4[5];
    FUN_000254c0();
    return;
  }
  *pfVar4 = pfVar4[10] * pfVar4[5] - pfVar4[9] * pfVar4[6];
  pfVar4[1] = *pfVar2 * pfVar4[6] - pfVar4[10] * *pfVar1;
  pfVar4[2] = *pfVar1 * pfVar4[9] - *pfVar2 * pfVar4[5];
  FUN_00021780();
  *pfVar2 = pfVar4[1] * pfVar4[6] - pfVar4[5] * pfVar4[2];
  pfVar4[9] = pfVar4[2] * *pfVar1 - *pfVar4 * pfVar4[6];
  pfVar4[10] = *pfVar4 * pfVar4[5] - pfVar4[1] * *pfVar1;
  FUN_000254c0();
  return;
}


