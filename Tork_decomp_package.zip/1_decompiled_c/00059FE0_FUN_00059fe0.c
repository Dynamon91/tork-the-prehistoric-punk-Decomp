// func FUN_00059fe0 @ 0x00059FE0 (size 0x24)

void FUN_00059fe0(void)

{
  int in_ECX;
  
  FUN_0012ebe2(*(undefined4 *)(in_ECX + 0x18),0xffffffff);
  *(undefined4 *)(in_ECX + 0x10) = 0;
  *(undefined4 *)(in_ECX + 0xc) = 0;
  *(undefined4 *)(in_ECX + 8) = 0;
  FUN_0012e945(*(undefined4 *)(in_ECX + 0x18));
  return;
}


