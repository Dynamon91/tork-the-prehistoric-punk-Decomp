// func FUN_00058f00 @ 0x00058F00 (size 0x115)

void FUN_00058f00(undefined4 *param_1)

{
  int iVar1;
  undefined4 *unaff_FS_OFFSET;
  undefined4 local_10;
  undefined4 uStack_c;
  undefined1 *puStack_8;
  undefined4 local_4;
  
  puStack_8 = &LAB_00143f03;
  uStack_c = *unaff_FS_OFFSET;
  *unaff_FS_OFFSET = &uStack_c;
  *param_1 = &PTR_LAB_00208610;
  local_4 = 1;
  local_10 = 0;
  FUN_00058b50(&local_10);
  FUN_0012c0be(param_1[8]);
  iVar1 = 4;
  do {
    FUN_00058010();
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  if (param_1[0x27] != 0) {
    FUN_00058010();
    param_1[0x27] = 0;
    *(undefined2 *)((int)param_1 + 0xa2) = 0;
    *(undefined2 *)(param_1 + 0x28) = 0;
  }
  if (param_1[0x29] != 0) {
    FUN_00058010();
    param_1[0x29] = 0;
    *(undefined2 *)((int)param_1 + 0xaa) = 0;
    *(undefined2 *)(param_1 + 0x2a) = 0;
  }
  ___M_YGXPAXIHP6EX0_Z_Z(param_1 + 0x2b,0x18,0x200,&DAT_00058c50);
  FUN_0012e776(param_1[0x12]);
  FUN_0012c0be(param_1[0x12]);
  *param_1 = &PTR_LAB_002085c0;
  FUN_0012e776(param_1[7]);
  FUN_0012c0be(param_1[7]);
  FUN_0012e945(param_1[6]);
  FUN_0012c0be(param_1[6]);
  *param_1 = &PTR_LAB_00208570;
  *unaff_FS_OFFSET = local_10;
  return;
}


