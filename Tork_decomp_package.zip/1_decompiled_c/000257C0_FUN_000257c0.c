// func FUN_000257c0 @ 0x000257C0 (size 0x7E)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_000257c0(float param_1)

{
  undefined1 uVar1;
  int unaff_ESI;
  
  if (_DAT_0020df98 <= param_1) {
    *(undefined1 *)(unaff_ESI + 0x14) = 0xff;
    *(ushort *)(unaff_ESI + 0x16) =
         (ushort)*(byte *)(unaff_ESI + 0x15) * (ushort)*(byte *)(unaff_ESI + 0x14);
    return;
  }
  if ((NAN(param_1) || NAN(_DAT_0020df5c)) || param_1 < _DAT_0020df5c == (param_1 == _DAT_0020df5c))
  {
    uVar1 = FUN_00140e74();
    *(undefined1 *)(unaff_ESI + 0x14) = uVar1;
    *(ushort *)(unaff_ESI + 0x16) =
         (ushort)*(byte *)(unaff_ESI + 0x15) * (ushort)*(byte *)(unaff_ESI + 0x14);
    return;
  }
  *(undefined1 *)(unaff_ESI + 0x14) = 0;
  *(ushort *)(unaff_ESI + 0x16) =
       (ushort)*(byte *)(unaff_ESI + 0x15) * (ushort)*(byte *)(unaff_ESI + 0x14);
  return;
}


