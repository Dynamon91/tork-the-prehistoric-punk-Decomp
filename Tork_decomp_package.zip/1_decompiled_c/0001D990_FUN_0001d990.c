// func FUN_0001d990 @ 0x0001D990 (size 0x1F)

void FUN_0001d990(void)

{
  uint in_EAX;
  uint *in_ECX;
  undefined1 in_DL;
  
  switch(in_DL) {
  case 1:
    in_EAX = (uint)(in_EAX != 0);
  case 2:
  case 3:
    *(char *)in_ECX = (char)in_EAX;
    return;
  case 4:
  case 5:
    *(short *)in_ECX = (short)in_EAX;
    return;
  case 6:
  case 7:
    *in_ECX = in_EAX;
  default:
    return;
  }
}


