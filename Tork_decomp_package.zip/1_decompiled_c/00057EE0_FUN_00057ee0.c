// func FUN_00057ee0 @ 0x00057EE0 (size 0x75)

void FUN_00057ee0(void)

{
  int iVar1;
  int *unaff_EBX;
  int *unaff_ESI;
  int *unaff_EDI;
  int local_1c [3];
  int local_10;
  int local_c;
  
  *unaff_ESI = 0;
  *unaff_EDI = 0;
  local_1c[0] = 0;
  *unaff_EBX = 0;
  iVar1 = FUN_0013f92e(0,local_1c,0x1c);
  while (iVar1 != 0) {
    if (local_c == 0x1000) {
      *unaff_ESI = *unaff_ESI + local_10;
    }
    else if (local_c == 0x2000) {
      *unaff_EDI = *unaff_EDI + local_10;
    }
    else if (local_c == 0x10000) {
      *unaff_EBX = *unaff_EBX + local_10;
    }
    local_1c[0] = local_1c[0] + local_10;
    iVar1 = FUN_0013f92e(local_1c[0],local_1c,0x1c);
  }
  return;
}


