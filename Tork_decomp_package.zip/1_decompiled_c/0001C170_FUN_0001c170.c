// func FUN_0001c170 @ 0x0001C170 (size 0x80)

byte * FUN_0001c170(void)

{
  byte bVar1;
  ushort uVar2;
  uint in_EAX;
  uint uVar3;
  int iVar4;
  byte *pbVar5;
  byte *unaff_EDI;
  char local_8 [4];
  byte *local_4;
  
  local_4 = unaff_EDI + (in_EAX & 0xff) * 8 + 0x6d;
  uVar3 = (uint)*local_4;
  if (*local_4 == 0xff) {
    bVar1 = *unaff_EDI;
    local_8[0] = '\0';
    local_8[1] = '\0';
    iVar4 = 0;
    local_8[2] = 0;
    if (bVar1 != 0) {
      uVar2 = *(ushort *)(unaff_EDI + 2);
      pbVar5 = unaff_EDI + 0x6d;
      do {
        if ((((uint)uVar2 & 1 << ((byte)iVar4 & 0x1f)) != 0) && (*pbVar5 != 0xff)) {
          local_8[(char)*pbVar5] = '\x01';
        }
        iVar4 = iVar4 + 1;
        pbVar5 = pbVar5 + 8;
      } while (iVar4 < (int)(uint)bVar1);
    }
    uVar3 = 0;
    while (local_8[uVar3] != '\0') {
      uVar3 = uVar3 + 1;
      if (2 < (int)uVar3) {
        return (byte *)0x0;
      }
    }
    *local_4 = (byte)uVar3;
  }
  return unaff_EDI + (char)uVar3 * 8 + 0x50;
}


