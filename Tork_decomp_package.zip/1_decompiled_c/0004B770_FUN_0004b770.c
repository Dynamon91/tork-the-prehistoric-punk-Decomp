// func FUN_0004b770 @ 0x0004B770 (size 0xD7)

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

wchar_t * FUN_0004b770(undefined4 param_1,uint param_2)

{
  wchar_t *__s;
  uint uVar1;
  int iVar2;
  ushort *puVar3;
  ushort *puVar4;
  byte *pbVar5;
  int iVar6;
  ushort local_18 [10];
  undefined4 local_4;
  
  iVar6 = DAT_002411d8;
  local_4 = DAT_002264b0;
  uVar1 = param_2;
  if ((int)param_2 < 0xd) {
    uVar1 = 0xc;
  }
  iVar2 = uVar1 * 2 + 0x21;
  iVar2 = FUN_000550f0((int)(iVar2 + (iVar2 >> 0x1f & 0x1fU)) >> 5);
  *(undefined4 *)(&DAT_00002064 + iVar2 * 4 + iVar6) = 0;
  __s = (wchar_t *)(iVar2 * 0x20 + 0x44 + iVar6);
  pbVar5 = &DAT_00208244;
  iVar6 = 3;
  puVar4 = local_18;
  do {
    puVar3 = puVar4 + 1;
    *puVar4 = (ushort)*pbVar5;
    pbVar5 = pbVar5 + 1;
    iVar6 = iVar6 + -1;
    puVar4 = puVar3;
  } while (iVar6 != 0);
  *puVar3 = 0;
  pbVar5 = &DAT_0020823c;
  iVar6 = 4;
  puVar4 = local_18 + 4;
  do {
    puVar3 = puVar4 + 1;
    *puVar4 = (ushort)*pbVar5;
    pbVar5 = pbVar5 + 1;
    iVar6 = iVar6 + -1;
    puVar4 = puVar3;
  } while (iVar6 != 0);
  *puVar3 = 0;
  puVar4 = local_18;
  if ((int)param_2 < 0) {
    puVar4 = local_18 + 4;
  }
  _swprintf(__s,(size_t)puVar4,
            (wchar_t *)((param_2 ^ (int)param_2 >> 0x1f) - ((int)param_2 >> 0x1f)),param_1);
  return __s;
}


