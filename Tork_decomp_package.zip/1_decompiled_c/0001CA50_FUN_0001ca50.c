// func FUN_0001ca50 @ 0x0001CA50 (size 0x93)

void FUN_0001ca50(uint *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint *puVar6;
  uint local_4;
  
  if ((param_1[-1] >> 0x1e & 1) == 0) {
    param_1[-1] = param_1[-1] | 0x40000000;
    iVar3 = DAT_0024120c;
    iVar2 = DAT_00241208;
    local_4 = 0;
    if (*param_1 != 0) {
      puVar6 = param_1 + 6;
      do {
        if ((((puVar6[-1] & 1) != 0) &&
            (((4 < puVar6[-3] || ((puVar6[-1] & 0x180) != 0)) && (uVar5 = *puVar6, uVar5 != 0)))) &&
           (((iVar4 = FUN_00058910(), iVar4 != -1 &&
             (iVar1 = *(int *)(iVar2 + iVar4 * 4), uVar5 - 8 == iVar1)) &&
            (uVar5 = (*(int *)(iVar3 + iVar4 * 4) - iVar1) + uVar5, uVar5 != 0)))) {
          *puVar6 = uVar5;
        }
        local_4 = local_4 + 1;
        puVar6 = puVar6 + 5;
      } while (local_4 < *param_1);
    }
  }
  return;
}


