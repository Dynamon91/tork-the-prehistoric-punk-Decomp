// func FUN_00025030 @ 0x00025030 (size 0x61)

void FUN_00025030(void)

{
  uint *puVar1;
  uint *in_EAX;
  int in_ECX;
  uint *puVar2;
  
  if ((char)*(uint *)(in_ECX + 4) < '\0') {
    puVar2 = *(uint **)(in_ECX + 0x1c);
    puVar1 = (uint *)puVar2[1];
    *puVar1 = *in_EAX;
    puVar1[1] = in_EAX[1];
    puVar1[2] = in_EAX[2];
    puVar2[2] = *in_EAX;
    puVar2[3] = in_EAX[1];
    puVar2[4] = in_EAX[2];
    FUN_000e47c0(*puVar2 | 0x200);
    return;
  }
  puVar2 = *(uint **)(in_ECX + 0x10);
  if ((*(uint *)(in_ECX + 4) & 2) != 0) {
    puVar2 = puVar2 + 0xc;
  }
  *puVar2 = *in_EAX;
  puVar2[1] = in_EAX[1];
  puVar2[2] = in_EAX[2];
  return;
}


