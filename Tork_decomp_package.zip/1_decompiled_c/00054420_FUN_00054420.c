// func FUN_00054420 @ 0x00054420 (size 0x2B)

int FUN_00054420(void)

{
  ushort *puVar1;
  ushort *puVar2;
  ushort *in_ECX;
  ushort *puVar3;
  char *in_EDX;
  
  puVar1 = in_ECX + 3;
  if ((puVar1 != (ushort *)0x0) &&
     (puVar3 = (ushort *)((uint)*in_ECX + (int)puVar1), puVar1 < puVar3)) {
    puVar2 = puVar1;
    do {
      if ((char)*puVar2 == *in_EDX) {
        if (puVar2 < puVar3) {
          return (int)puVar2 - (int)puVar1;
        }
        return -1;
      }
      puVar2 = (ushort *)((int)puVar2 + 1);
    } while (puVar2 < puVar3);
  }
  return -1;
}


