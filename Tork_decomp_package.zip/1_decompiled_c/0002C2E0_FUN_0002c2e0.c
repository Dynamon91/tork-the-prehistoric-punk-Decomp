// func FUN_0002c2e0 @ 0x0002C2E0 (size 0x8D)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0002c2e0(void)

{
  int iVar1;
  float *pfVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  iVar1 = *(int *)(DAT_0022a6c4 + 0x14);
  DAT_002411ec = 0;
  if ((*(uint *)(iVar1 + 4) >> 0x1e & 1) != 0) {
    puVar4 = (undefined4 *)(*(int *)(iVar1 + 0x28) + 0x30);
    puVar5 = &DAT_00225f20;
    for (iVar3 = 0x13; iVar3 != 0; iVar3 = iVar3 + -1) {
      *puVar5 = *puVar4;
      puVar4 = puVar4 + 1;
      puVar5 = puVar5 + 1;
    }
    if ((*(byte *)(iVar1 + 4) & 1) != 0) {
      pfVar2 = *(float **)(iVar1 + 0x10);
      if ((*(byte *)(iVar1 + 4) & 2) != 0) {
        pfVar2 = pfVar2 + 0xc;
      }
      _DAT_00225f50 = _DAT_00225f50 + *pfVar2;
      _DAT_00225f54 = _DAT_00225f54 + pfVar2[1];
      _DAT_00225f58 = _DAT_00225f58 + pfVar2[2];
    }
  }
  return;
}


