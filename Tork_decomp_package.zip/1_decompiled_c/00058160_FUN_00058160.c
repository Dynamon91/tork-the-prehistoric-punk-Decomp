// func FUN_00058160 @ 0x00058160 (size 0x48)

undefined4 * FUN_00058160(void)

{
  uint in_EAX;
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *unaff_EBX;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  puVar1 = (undefined4 *)FUN_00057f60();
  if (puVar1 != (undefined4 *)0x0) {
    uVar3 = unaff_EBX[-1] & 0x7ffffffc;
    if (in_EAX < (unaff_EBX[-1] & 0x7ffffffc)) {
      uVar3 = in_EAX;
    }
    puVar4 = unaff_EBX;
    puVar5 = puVar1;
    for (uVar2 = uVar3 >> 2; uVar2 != 0; uVar2 = uVar2 - 1) {
      *puVar5 = *puVar4;
      puVar4 = puVar4 + 1;
      puVar5 = puVar5 + 1;
    }
    for (uVar3 = uVar3 & 3; uVar3 != 0; uVar3 = uVar3 - 1) {
      *(undefined1 *)puVar5 = *(undefined1 *)puVar4;
      puVar4 = (undefined4 *)((int)puVar4 + 1);
      puVar5 = (undefined4 *)((int)puVar5 + 1);
    }
  }
  unaff_EBX[-1] = unaff_EBX[-1] & 0x7fffffff;
  FUN_00073b30();
  return puVar1;
}


