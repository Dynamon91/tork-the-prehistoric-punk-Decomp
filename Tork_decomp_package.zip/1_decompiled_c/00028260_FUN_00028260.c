// func FUN_00028260 @ 0x00028260 (size 0xB5)

void FUN_00028260(void)

{
  float *in_EAX;
  float fVar1;
  float fVar2;
  float fVar3;
  int unaff_ESI;
  
  fVar1 = -(in_EAX[8] * in_EAX[0xc] + in_EAX[9] * in_EAX[0xd] + in_EAX[10] * in_EAX[0xe]);
  fVar2 = -(in_EAX[0xc] * in_EAX[4] + in_EAX[5] * in_EAX[0xd] + in_EAX[6] * in_EAX[0xe]);
  fVar3 = -(in_EAX[0xc] * *in_EAX + in_EAX[0xd] * in_EAX[1] + in_EAX[0xe] * in_EAX[2]);
  *(float *)(unaff_ESI + 0x30) = fVar3;
  *(float *)(unaff_ESI + 0x34) = fVar2;
  *(float *)(unaff_ESI + 0x38) = fVar1;
  FUN_00028350(fVar1,fVar2,fVar3);
  *(undefined4 *)(unaff_ESI + 0x3c) = 0x3f800000;
  *(undefined4 *)(unaff_ESI + 0x2c) = 0;
  *(undefined4 *)(unaff_ESI + 0x1c) = 0;
  *(undefined4 *)(unaff_ESI + 0xc) = 0;
  return;
}


