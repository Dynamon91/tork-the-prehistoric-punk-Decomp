// func FUN_00057100 @ 0x00057100 (size 0x11F)

int * FUN_00057100(void)

{
  uint *puVar1;
  int iVar2;
  uint in_EAX;
  int *piVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint in_ECX;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  
  if (in_EAX < 9) {
    piVar3 = (int *)FUN_000568c0();
    return piVar3;
  }
  if (in_EAX < 0x10) {
    in_EAX = 0x10;
  }
  uVar4 = in_EAX;
  if (((in_EAX & in_EAX - 1) != 0) && (uVar4 = 0x10, 0x10 < in_EAX)) {
    do {
      uVar4 = uVar4 << 1;
    } while (uVar4 < in_EAX);
  }
  if (0xffffffdf < in_ECX) {
    puVar5 = (undefined4 *)FUN_00135a61();
    *puVar5 = 0xc;
    return (int *)0x0;
  }
  if (in_ECX + 0xb < 0x10) {
    uVar8 = 0x10;
  }
  else {
    uVar8 = in_ECX + 0xb & 0xfffffff8;
  }
  uVar6 = FUN_000568c0(uVar4 + 0x10 + uVar8);
  if (uVar6 == 0) {
    return (int *)0x0;
  }
  piVar3 = (int *)(uVar6 - 8);
  piVar9 = piVar3;
  if (uVar6 % uVar4 != 0) {
    piVar9 = (int *)(((uVar6 - 1) + uVar4 & -uVar4) - 8);
    if ((uint)((int)piVar9 - (int)piVar3) < 0x10) {
      piVar9 = (int *)((int)piVar9 + uVar4);
    }
    uVar7 = (int)piVar9 - (int)piVar3;
    uVar4 = (*(uint *)(uVar6 - 4) & 0x7ffffffc) - uVar7;
    if ((*(uint *)(uVar6 - 4) & 2) != 0) {
      iVar2 = *piVar3;
      piVar9[1] = uVar4 | 2;
      *piVar9 = iVar2 + uVar7;
      return piVar9 + 2;
    }
    piVar9[1] = uVar4 | 1;
    puVar1 = (uint *)(uVar4 + 4 + (int)piVar9);
    *puVar1 = *puVar1 | 1;
    *(uint *)(uVar6 - 4) = *(uint *)(uVar6 - 4) & 1 | uVar7;
    FUN_00056c90();
  }
  if (((piVar9[1] & 2U) == 0) && (uVar4 = piVar9[1] & 0x7ffffffc, uVar8 + 0x10 < uVar4)) {
    *(uint *)((int)piVar9 + uVar8 + 4) = uVar4 - uVar8 | 1;
    piVar9[1] = piVar9[1] & 1U | uVar8;
    FUN_00056c90();
  }
  return piVar9 + 2;
}


