// func FUN_00025370 @ 0x00025370 (size 0x56)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00025370(void)

{
  int in_EAX;
  float local_2c;
  
  if (((*(uint *)(in_EAX + 4) >> 7 & 1) != 0) && ((**(uint **)(in_EAX + 0x1c) >> 0xb & 1) != 0)) {
    return (float10)*(float *)((*(uint **)(in_EAX + 0x1c))[0x16] + 0x9c);
  }
  if ((*(uint *)(in_EAX + 4) >> 1 & 1) == 0) {
    return (float10)_DAT_0020df98;
  }
  FUN_0006dba0();
  return (float10)local_2c;
}


