// func FUN_00057560 @ 0x00057560 (size 0x116)

void FUN_00057560(int *param_1)

{
  uint *puVar1;
  undefined *puVar2;
  undefined *puVar3;
  int iVar4;
  int *piVar5;
  int *local_34;
  int local_30;
  int local_28 [4];
  undefined4 local_18;
  undefined4 local_14;
  int local_10;
  int local_c;
  int local_8;
  uint local_4;
  
  if (DAT_0022a76c == 0) {
    FUN_00056df0(&DAT_0022a740);
  }
  local_4 = *(uint *)(DAT_0022a76c + 4) & 0x7ffffffc;
  local_28[1] = 1;
  local_10 = 0;
  local_34 = &DAT_0022a744;
  local_30 = 10;
  local_28[2] = 0;
  do {
    iVar4 = *local_34;
    if (iVar4 != 0) {
      do {
        puVar1 = (uint *)(iVar4 + 4);
        iVar4 = *(int *)(iVar4 + 8);
        local_28[2] = local_28[2] + 1;
        local_10 = local_10 + (*puVar1 & 0x7ffffffc);
      } while (iVar4 != 0);
    }
    local_34 = local_34 + 1;
    local_30 = local_30 + -1;
  } while (local_30 != 0);
  local_8 = local_4 + local_10;
  puVar3 = &DAT_0022a774;
  do {
    for (puVar2 = *(undefined **)(puVar3 + 0xc); puVar2 != puVar3;
        puVar2 = *(undefined **)(puVar2 + 0xc)) {
      local_28[1] = local_28[1] + 1;
      local_8 = local_8 + (*(uint *)(puVar2 + 4) & 0x7ffffffc);
    }
    puVar3 = puVar3 + 8;
  } while ((int)puVar3 < 0x22aa6c);
  local_28[0] = DAT_0022aaa8;
  local_c = DAT_0022aaa8 - local_8;
  local_18 = DAT_0022aaa4;
  local_14 = DAT_0022aab4;
  local_28[3] = DAT_0022aa90;
  piVar5 = local_28;
  for (iVar4 = 10; iVar4 != 0; iVar4 = iVar4 + -1) {
    *param_1 = *piVar5;
    piVar5 = piVar5 + 1;
    param_1 = param_1 + 1;
  }
  return;
}


