// func FUN_00030500 @ 0x00030500 (size 0xA2)

undefined1 FUN_00030500(void)

{
  char cVar1;
  int in_EAX;
  
  if ((*(uint *)(in_EAX + 4) >> 0x1e & 1) != 0) {
    FUN_000479c0();
    cVar1 = FUN_00070600();
    if (cVar1 == '\0') {
      return 0;
    }
  }
  return 1;
}


