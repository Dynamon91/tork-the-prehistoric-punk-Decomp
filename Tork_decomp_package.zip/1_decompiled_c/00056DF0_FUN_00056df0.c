// func FUN_00056df0 @ 0x00056DF0 (size 0x157)

void FUN_00056df0(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint *puVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  uint *local_c;
  
  uVar2 = *param_1;
  if (uVar2 == 0) {
    iVar8 = 0x5f;
    puVar6 = param_1 + 0xd;
    do {
      puVar6[3] = (uint)puVar6;
      puVar6[2] = (uint)puVar6;
      puVar6 = puVar6 + 2;
      iVar8 = iVar8 + -1;
    } while (iVar8 != 0);
    param_1[0xd8] = param_1[0xd8] & 0xfffffffe;
    param_1[0xb] = (uint)(param_1 + 0xd);
    param_1[0xd2] = 0;
    param_1[0xd5] = 0x10000;
    param_1[0xd3] = 0x40000;
    param_1[0xd1] = 0x20000;
    *param_1 = *param_1 & 3 | 0x48;
    param_1[0xd7] = 0x1000;
    return;
  }
  *param_1 = uVar2 & 0xfffffffd;
  local_c = param_1;
  do {
    local_c = local_c + 1;
    piVar7 = (int *)*local_c;
    if (piVar7 != (int *)0x0) {
      *local_c = 0;
      do {
        piVar3 = (int *)piVar7[2];
        uVar9 = piVar7[1] & 0xfffffffe;
        uVar1 = uVar9 + (int)piVar7;
        uVar10 = *(uint *)(uVar9 + 4 + (int)piVar7) & 0x7ffffffc;
        if ((piVar7[1] & 1U) == 0) {
          uVar9 = uVar9 + *piVar7;
          piVar7 = (int *)((int)piVar7 - *piVar7);
          iVar8 = piVar7[3];
          iVar4 = piVar7[2];
          *(int *)(iVar4 + 0xc) = iVar8;
          *(int *)(iVar8 + 8) = iVar4;
        }
        if (uVar1 == param_1[0xb]) {
          piVar7[1] = uVar10 + uVar9 | 1;
          param_1[0xb] = (uint)piVar7;
        }
        else {
          uVar5 = *(uint *)(uVar10 + 4 + uVar1);
          *(uint *)(uVar1 + 4) = uVar10;
          if ((uVar5 & 1) == 0) {
            uVar9 = uVar9 + uVar10;
            iVar8 = *(int *)(uVar1 + 8);
            iVar4 = *(int *)(uVar1 + 0xc);
            *(int *)(iVar8 + 0xc) = iVar4;
            *(int *)(iVar4 + 8) = iVar8;
          }
          uVar1 = param_1[0xf];
          param_1[0xf] = (uint)piVar7;
          *(int **)(uVar1 + 0xc) = piVar7;
          piVar7[1] = uVar9 | 1;
          piVar7[3] = (int)(param_1 + 0xd);
          piVar7[2] = uVar1;
          *(uint *)(uVar9 + (int)piVar7) = uVar9;
        }
        piVar7 = piVar3;
      } while (piVar3 != (int *)0x0);
    }
  } while (local_c != param_1 + ((uVar2 >> 3) - 1));
  return;
}


