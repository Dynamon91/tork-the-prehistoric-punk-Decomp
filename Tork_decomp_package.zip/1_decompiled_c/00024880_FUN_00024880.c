// func FUN_00024880 @ 0x00024880 (size 0x68)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00024880(float param_1,float param_2)

{
  param_1 = param_1 / param_2;
  if ((int)param_1 < 0) {
    return (float10)(int)-((uint)(ABS(param_1) + _DAT_0020e014) & 0xb4ffffff) * (float10)param_2;
  }
  return (float10)(int)((uint)(param_1 + _DAT_0020e014) & 0xb4ffffff) * (float10)param_2;
}


