// func FUN_00043690 @ 0x00043690 (size 0x2C)

void FUN_00043690(void)

{
  byte bVar1;
  int iVar2;
  uint in_EAX;
  byte in_CL;
  int in_EDX;
  
  iVar2 = *(int *)(in_EDX + 0x10 + (in_EAX & 0xffff) * 8);
  bVar1 = *(byte *)(iVar2 + 4);
  if ((bVar1 & 2) == 0) {
    *(byte *)(iVar2 + 4) = (bVar1 ^ in_CL) & 1 ^ bVar1;
    return;
  }
  *(byte *)(iVar2 + 4) = (in_CL << 2 ^ bVar1) & 4 ^ bVar1;
  return;
}


