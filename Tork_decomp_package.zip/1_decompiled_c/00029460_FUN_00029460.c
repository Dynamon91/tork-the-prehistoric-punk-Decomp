// func FUN_00029460 @ 0x00029460 (size 0x2B)

float10 FUN_00029460(void)

{
  return (float10)*(float *)(*(int *)(*(int *)(DAT_0022a6c4 + 0x14) + 0x1c) + 0x20);
}


