// func FUN_000215e0 @ 0x000215E0 (size 0x38)

void FUN_000215e0(void)

{
  uint *in_EAX;
  uint *in_ECX;
  
  *in_ECX = *in_EAX ^ 0x80000000;
  in_ECX[1] = in_EAX[1] ^ 0x80000000;
  in_ECX[2] = in_EAX[2] ^ 0x80000000;
  return;
}


