// func FUN_0004c800 @ 0x0004C800 (size 0x234)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0004c800(int param_1,int param_2,byte *param_3)

{
  short *psVar1;
  undefined2 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  byte bVar5;
  int iVar6;
  byte bVar7;
  undefined4 *puVar8;
  undefined1 local_80 [48];
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_40 [12];
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  if (*(float *)(param_3 + 0x20) <= _DAT_0020df5c) goto LAB_0004c9d6;
  bVar7 = param_3[1];
  iVar6 = *(int *)(*(int *)(*(int *)(param_2 + 0x14) + 4) + 4);
  FUN_00047960();
  FUN_000479c0();
  FUN_000286c0((uint)bVar7 * 0xc4 + iVar6 + 0x1d8,local_40);
  if (*(int *)(param_1 + 0xdc) == 0) {
    bVar7 = 7;
  }
  else {
    bVar7 = *(byte *)(*(int *)(param_1 + 0xdc) + (uint)bVar7);
  }
  if ((bVar7 & 7) != 7) {
    bVar5 = bVar7 >> 3 & 3;
    if (bVar5 < 4) {
      puVar3 = (undefined4 *)0x0;
      if (*(int *)(param_1 + 0xe0) != 0) {
        puVar3 = *(undefined4 **)(*(int *)(param_1 + 0xe0) + (uint)bVar5 * 4);
      }
    }
    else {
      puVar3 = (undefined4 *)0x0;
    }
    if ((bVar5 < 4) && (*(int *)(param_1 + 0xe0) != 0)) {
      bVar5 = *(byte *)((uint)bVar5 + *(int *)(param_1 + 0xe4));
      if (bVar5 < 2) {
        puVar8 = local_40;
        for (iVar6 = 0x10; iVar6 != 0; iVar6 = iVar6 + -1) {
          *puVar8 = *puVar3;
          puVar3 = puVar3 + 1;
          puVar8 = puVar8 + 1;
        }
      }
      else if (bVar5 == 2) goto LAB_0004c8ec;
    }
    else {
LAB_0004c8ec:
      FUN_0004c570(local_40);
    }
    if ((bVar7 & 1) == 0) {
      local_50 = local_10;
      local_4c = local_c;
      local_48 = local_8;
    }
    if ((bVar7 & 6) == 0) {
      FUN_000284f0();
    }
    else {
      if ((bVar7 & 2) != 0) {
        FUN_000687c0();
        FUN_000284f0();
        FUN_0004d100();
        FUN_0004d2f0(local_80);
      }
      if ((bVar7 & 4) != 0) {
        FUN_000687c0();
        FUN_0004d100();
        FUN_0004d2f0(local_80);
      }
    }
  }
  if ((*param_3 == 0) || (6 < *param_3)) {
    uVar4 = 0;
  }
  else {
    uVar4 = 1;
  }
  FUN_001113e0(uVar4);
LAB_0004c9d6:
  if (*(short *)(param_1 + 0x3c) == -1) {
    psVar1 = (short *)(DAT_002414f0 + 2);
    *(int *)(*(int *)(DAT_002414f0 + 4) + (uint)*(ushort *)(DAT_002414f0 + 2) * 4) = param_2;
    *psVar1 = *psVar1 + 1;
    uVar2 = FUN_0004c480(param_3);
    *(undefined2 *)(param_1 + 0x3e) = uVar2;
    *(undefined2 *)(param_1 + 0x3c) = uVar2;
    return;
  }
  uVar2 = FUN_0004c480(param_3);
  *(undefined2 *)(param_1 + 0x3e) = uVar2;
  return;
}


