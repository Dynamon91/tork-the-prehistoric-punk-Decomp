// func FUN_00056450 @ 0x00056450 (size 0x3D4)

int * FUN_00056450(uint param_1)

{
  int iVar1;
  undefined4 uVar2;
  byte *in_EAX;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  uint local_20;
  uint local_8;
  
  uVar9 = *(int *)(in_EAX + 0x35c) - 1;
  if ((*in_EAX & 2) != 0) {
    FUN_00056df0();
    piVar3 = (int *)FUN_000568c0();
    return piVar3;
  }
  if ((((*(uint *)(in_EAX + 0x34c) <= param_1) &&
       (*(int *)(in_EAX + 0x350) < *(int *)(in_EAX + 0x354))) &&
      (uVar11 = *(int *)(in_EAX + 0x35c) + 10 + param_1 & ~uVar9, param_1 < uVar11)) &&
     (piVar3 = (int *)FUN_00057e50(uVar11), piVar3 != (int *)0xffffffff)) {
    if (((uint)piVar3 & 7) == 0) {
      *piVar3 = 0;
      piVar3[1] = uVar11 | 2;
    }
    else {
      iVar7 = 8 - ((uint)piVar3 & 7);
      piVar3 = (int *)((int)piVar3 + iVar7);
      *piVar3 = iVar7;
      piVar3[1] = uVar11 - iVar7 | 2;
    }
    iVar7 = *(int *)(in_EAX + 0x350) + 1;
    *(int *)(in_EAX + 0x350) = iVar7;
    if (*(int *)(in_EAX + 0x358) < iVar7) {
      *(int *)(in_EAX + 0x358) = iVar7;
    }
    uVar11 = *(int *)(in_EAX + 0x364) + uVar11;
    *(uint *)(in_EAX + 0x364) = uVar11;
    if (*(uint *)(in_EAX + 0x370) < uVar11) {
      *(uint *)(in_EAX + 0x370) = uVar11;
    }
    if (*(uint *)(in_EAX + 0x374) < uVar11 + *(int *)(in_EAX + 0x368)) {
      *(uint *)(in_EAX + 0x374) = uVar11 + *(int *)(in_EAX + 0x368);
    }
    return piVar3 + 2;
  }
  iVar1 = *(int *)(in_EAX + 0x2c);
  uVar4 = *(uint *)(iVar1 + 4) & 0x7ffffffc;
  uVar11 = uVar4 + iVar1;
  iVar7 = *(int *)(in_EAX + 0x348) + 0x10 + param_1;
  uVar12 = 0xffffffff;
  if ((in_EAX[0x360] & 1) != 0) {
    iVar7 = iVar7 - uVar4;
  }
  uVar8 = ~uVar9;
  local_20 = iVar7 + uVar9 & uVar8;
  if (((int)local_20 < 1) || (uVar5 = FUN_00057a80(local_20), uVar5 == 0xffffffff)) {
    if ((in_EAX[0x360] & 1) != 0) {
      local_20 = uVar4 + local_20 + uVar9 & uVar8;
    }
    if (local_20 < 0x100000) {
      local_20 = 0x100000;
    }
    if ((local_20 <= param_1) || (uVar5 = FUN_00057e50(local_20), uVar5 == 0xffffffff))
    goto LAB_0005680f;
    uVar12 = uVar5 + local_20;
    *(uint *)(in_EAX + 0x360) = *(uint *)(in_EAX + 0x360) & 0xfffffffe;
  }
  iVar7 = *(int *)(in_EAX + 0x368);
  *(uint *)(in_EAX + 0x368) = iVar7 + local_20;
  if ((uVar5 == uVar11) && (uVar12 == 0xffffffff)) {
    *(uint *)(iVar1 + 4) = uVar4 + local_20 | 1;
  }
  else {
    iVar10 = 0;
    if (((*(uint *)(in_EAX + 0x360) & 1) != 0) && ((uVar4 != 0 && (uVar5 < uVar11)))) {
      *(uint *)(in_EAX + 0x360) = *(uint *)(in_EAX + 0x360) & 0xfffffffe;
    }
    local_8 = uVar5;
    if ((in_EAX[0x360] & 1) == 0) {
      if (uVar12 == 0xffffffff) {
        uVar12 = FUN_00057a80(0);
        *(uint *)(in_EAX + 0x368) = *(int *)(in_EAX + 0x368) + ((uVar12 - uVar5) - local_20);
        goto LAB_0005673e;
      }
    }
    else {
      if (uVar4 != 0) {
        *(uint *)(in_EAX + 0x368) = ((iVar7 + local_20) - uVar11) + uVar5;
      }
      if ((uVar5 & 7) != 0) {
        iVar10 = 8 - (uVar5 & 7);
        local_8 = uVar5 + iVar10;
      }
      iVar7 = uVar5 + iVar10 + uVar4 + local_20;
      iVar10 = iVar10 + uVar4 + ((iVar7 + uVar9 & uVar8) - iVar7);
      uVar12 = FUN_00057a80(iVar10);
      if (uVar12 == 0xffffffff) {
        iVar10 = 0;
        uVar12 = FUN_00057a80(0);
      }
      else if (uVar12 < uVar5) {
        uVar12 = uVar5 + local_20;
        iVar10 = 0;
        *(uint *)(in_EAX + 0x360) = *(uint *)(in_EAX + 0x360) & 0xfffffffe;
      }
LAB_0005673e:
      if (uVar12 == 0xffffffff) goto LAB_000567ac;
      uVar5 = local_8;
    }
    *(uint *)(in_EAX + 0x2c) = uVar5;
    *(uint *)(uVar5 + 4) = (uVar12 - uVar5) + iVar10 | 1;
    *(int *)(in_EAX + 0x368) = *(int *)(in_EAX + 0x368) + iVar10;
    if (uVar4 != 0) {
      uVar9 = uVar4 - 0xc & 0xfffffff8;
      *(uint *)(iVar1 + 4) = uVar9 | 1;
      *(undefined4 *)(uVar9 + 4 + iVar1) = 5;
      *(undefined4 *)(uVar9 + 8 + iVar1) = 5;
      if (0xf < uVar9) {
        uVar2 = *(undefined4 *)(in_EAX + 0x344);
        in_EAX[0x344] = 0xff;
        in_EAX[0x345] = 0xff;
        in_EAX[0x346] = 0xff;
        in_EAX[0x347] = 0xff;
        FUN_00056c90();
        *(undefined4 *)(in_EAX + 0x344) = uVar2;
      }
    }
  }
LAB_000567ac:
  uVar9 = *(uint *)(in_EAX + 0x368);
  if (*(uint *)(in_EAX + 0x36c) < uVar9) {
    *(uint *)(in_EAX + 0x36c) = uVar9;
  }
  if (*(uint *)(in_EAX + 0x374) < uVar9 + *(int *)(in_EAX + 0x364)) {
    *(uint *)(in_EAX + 0x374) = uVar9 + *(int *)(in_EAX + 0x364);
  }
  iVar7 = *(int *)(in_EAX + 0x2c);
  uVar9 = *(uint *)(iVar7 + 4) & 0x7ffffffc;
  if (param_1 + 0x10 <= uVar9) {
    *(uint *)(in_EAX + 0x2c) = iVar7 + param_1;
    *(uint *)(iVar7 + 4) = param_1 | 1;
    *(uint *)(iVar7 + param_1 + 4) = uVar9 - param_1 | 1;
    return (int *)(iVar7 + 8);
  }
LAB_0005680f:
  puVar6 = (undefined4 *)FUN_00135a61();
  *puVar6 = 0xc;
  return (int *)0x0;
}


