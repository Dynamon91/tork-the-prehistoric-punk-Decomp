// func FUN_00024200 @ 0x00024200 (size 0xBB)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

float10 FUN_00024200(void)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float *in_ECX;
  float *unaff_ESI;
  float *unaff_EDI;
  float10 fVar4;
  float10 fVar5;
  
  fVar1 = unaff_ESI[1] * in_ECX[2] - in_ECX[1] * unaff_ESI[2];
  fVar2 = *in_ECX * unaff_ESI[2] - *unaff_ESI * in_ECX[2];
  fVar3 = in_ECX[1] * *unaff_ESI - *in_ECX * unaff_ESI[1];
  fVar4 = (float10)FUN_00021640();
  fVar5 = (float10)FUN_00021640();
  fVar4 = SQRT((float10)(fVar1 * fVar1 + fVar2 * fVar2 + fVar3 * fVar3) /
               (fVar5 * (float10)(float)fVar4));
  if (fVar1 * *unaff_EDI + fVar2 * unaff_EDI[1] + fVar3 * unaff_EDI[2] < _DAT_0020df5c) {
    fVar4 = (float10)-(float)fVar4;
  }
  return fVar4;
}


