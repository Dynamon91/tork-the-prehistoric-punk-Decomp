// func FUN_000469c0 @ 0x000469C0 (size 0xBF)

void FUN_000469c0(undefined1 param_1,undefined1 param_2)

{
  undefined1 *puVar1;
  char cVar2;
  uint uVar3;
  undefined4 uVar4;
  byte bVar5;
  uint *unaff_EDI;
  
  if ((*unaff_EDI >> 4 & 1) == 0) {
    FUN_000932d0(unaff_EDI);
  }
  uVar3 = unaff_EDI[4];
  if (*(char *)(uVar3 + 2) == *(char *)(uVar3 + 3)) {
    cVar2 = *(char *)(uVar3 + 3);
    if (cVar2 == '\0') {
      bVar5 = 4;
    }
    else {
      bVar5 = (cVar2 == '\0') - 1U & cVar2 * '\x02';
    }
    if (bVar5 != *(byte *)(uVar3 + 3)) {
      if (bVar5 == 0) {
        FUN_00058010();
      }
      else {
        if (*(byte *)(uVar3 + 3) == 0) {
          uVar4 = FUN_00057f60((uint)bVar5 * 6);
        }
        else {
          uVar4 = FUN_00058070();
        }
        *(undefined4 *)(uVar3 + 0x10) = uVar4;
      }
      *(byte *)(uVar3 + 3) = bVar5;
      if (bVar5 < *(byte *)(uVar3 + 2)) {
        *(byte *)(uVar3 + 2) = bVar5;
      }
    }
  }
  puVar1 = (undefined1 *)(*(int *)(unaff_EDI[4] + 0x10) + (uint)*(byte *)(unaff_EDI[4] + 2) * 6);
  puVar1[2] = param_2;
  *puVar1 = param_1;
  *(undefined2 *)(puVar1 + 4) = 0;
  *(char *)(unaff_EDI[4] + 2) = *(char *)(unaff_EDI[4] + 2) + '\x01';
  FUN_00095060(param_1);
  return;
}


