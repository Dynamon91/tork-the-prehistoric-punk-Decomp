// func FUN_000254c0 @ 0x000254C0 (size 0x245)

void FUN_000254c0(void)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  int unaff_EDI;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  undefined4 local_4;
  
  if ((*(uint *)(unaff_EDI + 4) >> 0xd & 1) != 0) {
    puVar1 = *(undefined4 **)(unaff_EDI + 0x10);
    uVar3 = (uint)**(byte **)(*(int *)(unaff_EDI + 0x24) + 0x2c);
    local_40 = *puVar1;
    local_3c = puVar1[1];
    local_38 = puVar1[2];
    local_30 = puVar1[4];
    local_2c = puVar1[5];
    local_28 = puVar1[6];
    local_20 = puVar1[8];
    local_1c = puVar1[9];
    local_18 = puVar1[10];
    uVar2 = 0;
    local_8 = 0;
    local_c = 0;
    local_10 = 0;
    local_4 = 0x3f800000;
    local_14 = 0;
    local_24 = 0;
    local_34 = 0;
    if (uVar3 != 0) {
      do {
        if ((*(uint *)(*(int *)(*(int *)(*(int *)(*(int *)(unaff_EDI + 0x24) + 0x2c) + 4) +
                               (uVar2 & 0xff) * 4) + 4) >> 1 & 1) != 0) {
          FUN_000286c0(*(int *)(unaff_EDI + 0x10) + 0x40,&local_40);
        }
        FUN_00025030();
        uVar2 = uVar2 + 1;
      } while ((int)uVar2 < (int)uVar3);
    }
  }
  return;
}


