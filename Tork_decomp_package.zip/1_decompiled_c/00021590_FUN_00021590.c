// func FUN_00021590 @ 0x00021590 (size 0x34)

void FUN_00021590(void)

{
  uint *in_EAX;
  
  *in_EAX = *in_EAX ^ 0x80000000;
  in_EAX[1] = in_EAX[1] ^ 0x80000000;
  in_EAX[2] = in_EAX[2] ^ 0x80000000;
  return;
}


