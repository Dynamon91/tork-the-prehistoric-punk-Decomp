// func FUN_00043b20 @ 0x00043B20 (size 0x58)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00043b20(float param_1)

{
  undefined2 uVar1;
  int unaff_ESI;
  
  if (param_1 * *(float *)(*(int *)(unaff_ESI + 0x60) + 4) <= _DAT_0020df5c) {
    uVar1 = FUN_00140e74();
    *(undefined2 *)(unaff_ESI + 0x44) = uVar1;
    return;
  }
  uVar1 = FUN_00140e74();
  *(undefined2 *)(unaff_ESI + 0x44) = uVar1;
  return;
}


