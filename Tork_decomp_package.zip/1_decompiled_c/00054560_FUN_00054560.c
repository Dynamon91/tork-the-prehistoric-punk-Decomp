// func FUN_00054560 @ 0x00054560 (size 0x40)

void FUN_00054560(void)

{
  ushort uVar1;
  ushort in_AX;
  uint uVar2;
  ushort *in_ECX;
  uint uVar3;
  uint uVar4;
  ushort *puVar5;
  ushort *puVar6;
  
  if (in_AX < *in_ECX) {
    uVar1 = *in_ECX - 1;
    uVar2 = (uint)in_AX;
    *in_ECX = uVar1;
    if ((in_ECX + uVar2 + 3 != (ushort *)0x0) && (in_ECX + uVar2 + 4 != (ushort *)0x0)) {
      uVar3 = uVar1 - uVar2;
      puVar5 = in_ECX + uVar2 + 4;
      puVar6 = in_ECX + uVar2 + 3;
      for (uVar4 = (uVar3 & 0x7fffffff) >> 1; uVar4 != 0; uVar4 = uVar4 - 1) {
        *(undefined4 *)puVar6 = *(undefined4 *)puVar5;
        puVar5 = puVar5 + 2;
        puVar6 = puVar6 + 2;
      }
      for (uVar2 = uVar3 * 2 & 3; uVar2 != 0; uVar2 = uVar2 - 1) {
        *(char *)puVar6 = (char)*puVar5;
        puVar5 = (ushort *)((int)puVar5 + 1);
        puVar6 = (ushort *)((int)puVar6 + 1);
      }
    }
  }
  return;
}


