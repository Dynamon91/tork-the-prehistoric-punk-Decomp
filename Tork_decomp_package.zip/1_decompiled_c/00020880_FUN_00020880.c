// func FUN_00020880 @ 0x00020880 (size 0x5C)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00020880(void)

{
  float *in_EAX;
  int in_ECX;
  float *pfVar1;
  float10 fVar2;
  
  pfVar1 = (float *)(in_ECX + 0x88);
  *pfVar1 = *in_EAX;
  *(float *)(in_ECX + 0x8c) = in_EAX[1];
  *(float *)(in_ECX + 0x90) = in_EAX[2];
  fVar2 = (float10)FUN_00021640();
  fVar2 = SQRT((float10)_DAT_0020df98 / fVar2);
  *pfVar1 = (float)(fVar2 * (float10)*pfVar1);
  *(float *)(in_ECX + 0x8c) = (float)(fVar2 * (float10)*(float *)(in_ECX + 0x8c));
  *(float *)(in_ECX + 0x90) = (float)(fVar2 * (float10)*(float *)(in_ECX + 0x90));
  return;
}


