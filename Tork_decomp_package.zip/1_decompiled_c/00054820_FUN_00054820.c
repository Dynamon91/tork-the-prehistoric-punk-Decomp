// func FUN_00054820 @ 0x00054820 (size 0x1C)

ushort * FUN_00054820(void)

{
  ushort uVar1;
  ushort *in_EDX;
  
  uVar1 = *in_EDX - 1;
  if (uVar1 < *in_EDX) {
    return in_EDX + (uint)uVar1 * 6 + 3;
  }
  return (ushort *)0xffffffff;
}


