// func FUN_00023ef0 @ 0x00023EF0 (size 0x1D)

undefined4 FUN_00023ef0(float param_1)

{
  float10 fVar1;
  float10 fVar2;
  
  fVar2 = (float10)FUN_00023f10();
  fVar1 = (float10)param_1;
  if ((NAN(fVar2) || NAN(fVar1)) || fVar2 < fVar1 == (fVar2 == fVar1)) {
    return 0;
  }
  return 1;
}


