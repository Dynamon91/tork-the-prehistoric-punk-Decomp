// func FUN_0001a100 @ 0x0001A100 (size 0x1C4)

undefined4
FUN_0001a100(undefined4 param_1,undefined1 param_2,undefined1 param_3,undefined4 param_4,
            undefined4 param_5,undefined2 param_6,undefined1 param_7)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  int in_EAX;
  undefined4 *puVar5;
  byte bVar6;
  uint uVar7;
  undefined2 local_4 [2];
  
  if ((*(int *)(in_EAX + 0x700) == 0x200) ||
     (puVar5 = (undefined4 *)FUN_0001a450(local_4), puVar5 == (undefined4 *)0x0)) {
    return 0xffffffff;
  }
  iVar4 = *(int *)(in_EAX + 0x700);
  *(int *)(in_EAX + 0x700) = iVar4 + 1;
  puVar2 = (undefined4 *)(iVar4 * 0x20 + 0x704 + in_EAX);
  *puVar2 = param_4;
  puVar2[1] = param_1;
  *(undefined1 *)(puVar2 + 2) = param_2;
  *(undefined1 *)((int)puVar2 + 9) = param_3;
  *(undefined2 *)((int)puVar2 + 10) = param_6;
  puVar2[3] = param_5;
  *(undefined2 *)((int)puVar2 + 0x12) = local_4[0];
  *(undefined2 *)(puVar2 + 4) = 0;
  *(undefined1 *)(puVar2 + 5) = *(undefined1 *)(in_EAX + 0x200);
  *(undefined1 *)((int)puVar2 + 0x15) = *(undefined1 *)(in_EAX + 0x201);
  *(undefined1 *)((int)puVar2 + 0x16) = *(undefined1 *)(in_EAX + 0x202);
  *(undefined1 *)((int)puVar2 + 0x17) = *(undefined1 *)(in_EAX + 0x203);
  *(undefined1 *)((int)puVar2 + 0x1b) = param_7;
  *(undefined1 *)((int)puVar2 + 0x1a) = 0;
  puVar2[7] = *(undefined4 *)(&DAT_00004704 + in_EAX);
  cVar3 = *(char *)(in_EAX + 0x200);
  uVar7 = 0;
  *(int *)(&DAT_00004704 + in_EAX) = *(int *)(&DAT_00004704 + in_EAX) + 1;
  if (cVar3 != '\0') {
    do {
      *puVar5 = *(undefined4 *)(in_EAX + 0x204 + uVar7 * 4);
      bVar6 = (char)uVar7 + 1;
      uVar7 = (uint)bVar6;
      puVar5 = puVar5 + 1;
    } while (bVar6 < *(byte *)(in_EAX + 0x200));
  }
  uVar7 = 0;
  if (*(char *)(in_EAX + 0x201) != '\0') {
    do {
      *puVar5 = *(undefined4 *)(in_EAX + 0x21c + uVar7 * 4);
      bVar6 = (char)uVar7 + 1;
      uVar7 = (uint)bVar6;
      puVar5 = puVar5 + 1;
    } while (bVar6 < *(byte *)(in_EAX + 0x201));
  }
  uVar7 = 0;
  if (*(char *)(in_EAX + 0x202) != '\0') {
    do {
      *puVar5 = *(undefined4 *)(in_EAX + 0x234 + uVar7 * 4);
      bVar6 = (char)uVar7 + 1;
      uVar7 = (uint)bVar6;
      puVar5 = puVar5 + 1;
    } while (bVar6 < *(byte *)(in_EAX + 0x202));
  }
  bVar6 = 0;
  if (*(char *)(in_EAX + 0x203) != '\0') {
    do {
      puVar1 = (undefined4 *)(in_EAX + (bVar6 + 0x31) * 0xc);
      *puVar5 = *puVar1;
      puVar5[1] = puVar1[1];
      puVar5[2] = puVar1[2];
      bVar6 = bVar6 + 1;
      puVar5 = puVar5 + 3;
    } while (bVar6 < *(byte *)(in_EAX + 0x203));
  }
  *(undefined1 *)(in_EAX + 0x200) = 0;
  *(undefined1 *)(in_EAX + 0x201) = 0;
  *(undefined1 *)(in_EAX + 0x202) = 0;
  *(undefined1 *)(in_EAX + 0x203) = 0;
  return puVar2[7];
}


