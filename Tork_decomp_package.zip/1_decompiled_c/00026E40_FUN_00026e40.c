// func FUN_00026e40 @ 0x00026E40 (size 0x4E)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00026e40(float param_1)

{
  int in_ECX;
  
  if (_DAT_0020df5c < param_1) {
    if (_DAT_0020df98 <= param_1) {
      param_1 = 1.0;
    }
  }
  else {
    param_1 = 0.0;
  }
  if ((*(uint *)(in_ECX + 4) >> 3 & 1) != 0) {
    FUN_000257c0(param_1);
  }
  return;
}


