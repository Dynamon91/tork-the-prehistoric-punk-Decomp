// func FUN_0001fc20 @ 0x0001FC20 (size 0x30)

void FUN_0001fc20(float *param_1,float *param_2,float param_3)

{
  undefined8 uVar1;
  
  uVar1 = *(undefined8 *)(param_2 + 1);
  *param_1 = param_3 * *param_2;
  *(ulonglong *)(param_1 + 1) =
       CONCAT44(param_3 * (float)((ulonglong)uVar1 >> 0x20),param_3 * (float)uVar1);
  return;
}


