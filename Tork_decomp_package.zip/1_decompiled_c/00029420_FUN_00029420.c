// func FUN_00029420 @ 0x00029420 (size 0x39)

void FUN_00029420(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(*(int *)(DAT_0022a6c4 + 0x14) + 0x1c);
  *(undefined4 *)(iVar1 + 0x20) = param_1;
  *(undefined4 *)(iVar1 + 0x24) = param_1;
  *(undefined4 *)(iVar1 + 0x28) = *(undefined4 *)(iVar1 + 0x28);
  return;
}


