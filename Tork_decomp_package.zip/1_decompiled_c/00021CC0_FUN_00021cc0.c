// func FUN_00021cc0 @ 0x00021CC0 (size 0x50)

ushort FUN_00021cc0(void)

{
  int iVar1;
  ushort uVar2;
  ushort *unaff_EDI;
  
  if (*unaff_EDI < 0x100) {
    uVar2 = 0;
    do {
      if (*(int *)(unaff_EDI + (uint)uVar2 * 2 + 2) == 0) {
        if (0xff < uVar2) {
          return 0xffff;
        }
        iVar1 = FUN_00064cb0();
        if (iVar1 == 0) {
          return 0xffff;
        }
        *(short *)(iVar1 + 0x28) = *(short *)(iVar1 + 0x28) + 1;
        *(undefined1 *)(iVar1 + 0x2b) = 1;
        *(int *)(unaff_EDI + (uint)uVar2 * 2 + 2) = iVar1;
        *unaff_EDI = *unaff_EDI + 1;
        return uVar2;
      }
      uVar2 = uVar2 + 1;
    } while (uVar2 < 0x100);
  }
  return 0xffff;
}


