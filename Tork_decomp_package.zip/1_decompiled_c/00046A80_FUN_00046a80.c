// func FUN_00046a80 @ 0x00046A80 (size 0xA8)

void FUN_00046a80(int param_1,undefined1 param_2,undefined1 param_3,undefined2 param_4)

{
  char *pcVar1;
  undefined1 *puVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  byte bVar6;
  
  iVar4 = *(int *)(param_1 + 0x10);
  if (*(char *)(iVar4 + 2) == *(char *)(iVar4 + 3)) {
    cVar3 = *(char *)(iVar4 + 3);
    if (cVar3 == '\0') {
      bVar6 = 4;
    }
    else {
      bVar6 = (cVar3 == '\0') - 1U & cVar3 * '\x02';
    }
    if (bVar6 != *(byte *)(iVar4 + 3)) {
      if (bVar6 == 0) {
        FUN_00058010();
      }
      else {
        if (*(byte *)(iVar4 + 3) == 0) {
          uVar5 = FUN_00057f60((uint)bVar6 * 6);
        }
        else {
          uVar5 = FUN_00058070();
        }
        *(undefined4 *)(iVar4 + 0x10) = uVar5;
      }
      *(byte *)(iVar4 + 3) = bVar6;
      if (bVar6 < *(byte *)(iVar4 + 2)) {
        *(byte *)(iVar4 + 2) = bVar6;
      }
    }
  }
  puVar2 = (undefined1 *)
           (*(int *)(*(int *)(param_1 + 0x10) + 0x10) +
           (uint)*(byte *)(*(int *)(param_1 + 0x10) + 2) * 6);
  *puVar2 = param_2;
  *(undefined2 *)(puVar2 + 4) = param_4;
  puVar2[2] = param_3;
  pcVar1 = (char *)(*(int *)(param_1 + 0x10) + 2);
  *pcVar1 = *pcVar1 + '\x01';
  return;
}


