// func FUN_0001d940 @ 0x0001D940 (size 0x30)

uint FUN_0001d940(void)

{
  undefined1 in_AL;
  uint *in_ECX;
  
  switch(in_AL) {
  case 1:
    return (uint)((byte)*in_ECX != 0);
  case 2:
    return (int)(char)(byte)*in_ECX;
  case 3:
    return (uint)(byte)*in_ECX;
  case 4:
    return (int)(short)(ushort)*in_ECX;
  case 5:
    return (uint)(ushort)*in_ECX;
  case 6:
  case 7:
    return *in_ECX;
  default:
    return 0;
  }
}


