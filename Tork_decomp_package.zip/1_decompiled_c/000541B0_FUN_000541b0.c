// func FUN_000541b0 @ 0x000541B0 (size 0x88)

undefined4 FUN_000541b0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  if (param_1 != 0) {
    switch(*(undefined2 *)(param_1 + 4)) {
    case 0:
      uVar1 = FUN_00054420();
      return uVar1;
    case 1:
    case 7:
      uVar1 = FUN_00054520(param_2);
      return uVar1;
    case 2:
      uVar1 = FUN_00054630(param_2);
      return uVar1;
    case 3:
      uVar1 = FUN_00054bd0();
      return uVar1;
    case 4:
      uVar1 = FUN_00054c70();
      return uVar1;
    case 5:
      uVar1 = FUN_00054930(param_2);
      return uVar1;
    case 6:
      uVar1 = FUN_00054a50(param_2);
      return uVar1;
    }
  }
  return 0xffffffff;
}


