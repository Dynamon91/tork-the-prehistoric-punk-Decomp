// func FUN_000196d0 @ 0x000196D0 (size 0x79)

void FUN_000196d0(char param_1)

{
  int in_EAX;
  int iVar1;
  int *in_ECX;
  int iVar2;
  int unaff_EDI;
  
  iVar2 = (int)(in_EAX + 0x1f + (in_EAX + 0x1f >> 0x1f & 0x1fU)) >> 5;
  iVar1 = FUN_000550f0(iVar2);
  if (in_ECX != (int *)0x0) {
    *in_ECX = iVar1 * 0x20 + 0x44 + unaff_EDI;
  }
  *(int **)(&DAT_00002064 + iVar1 * 4 + unaff_EDI) = in_ECX;
  if (param_1 != '\0') {
    iVar2 = iVar1 + iVar2;
    (&DAT_00002464)[unaff_EDI] = 1;
    for (; iVar1 < iVar2; iVar1 = iVar1 + 1) {
      *(uint *)(&DAT_00002044 + (iVar1 >> 5) * 4 + unaff_EDI) =
           *(uint *)(&DAT_00002044 + (iVar1 >> 5) * 4 + unaff_EDI) | 1 << ((byte)iVar1 & 0x1f);
    }
  }
  return;
}


