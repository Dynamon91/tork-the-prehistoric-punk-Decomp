// func FUN_000443b0 @ 0x000443B0 (size 0x30)

void FUN_000443b0(undefined4 param_1)

{
  int in_EAX;
  undefined4 local_44;
  undefined4 local_40;
  
  if (*(int *)(in_EAX + 0x20) != 0) {
    local_44 = 9;
    local_40 = param_1;
    FUN_00043310(*(undefined4 *)(*(int *)(in_EAX + 0x20) + 0x248),&local_44);
  }
  return;
}


