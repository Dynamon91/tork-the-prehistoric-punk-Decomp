// func FUN_00044000 @ 0x00044000 (size 0x2D)

void FUN_00044000(void)

{
  byte bVar1;
  ushort in_AX;
  int in_ECX;
  int iVar2;
  char in_DL;
  
  if (in_AX < 0xff) {
    iVar2 = in_ECX + (uint)in_AX * 0x68;
    bVar1 = *(byte *)(iVar2 + 0x58);
    if ((char)bVar1 < '\0') {
      if (in_DL != '\0') {
        *(undefined1 *)(iVar2 + 0x59) = 2;
        *(byte *)(iVar2 + 0x58) = bVar1 & 0xdf;
        return;
      }
      *(undefined1 *)(iVar2 + 0x59) = 1;
      *(byte *)(iVar2 + 0x58) = bVar1 | 0x20;
    }
  }
  return;
}


