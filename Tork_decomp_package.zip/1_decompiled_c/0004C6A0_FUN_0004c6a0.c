// func FUN_0004c6a0 @ 0x0004C6A0 (size 0xAE)

void FUN_0004c6a0(undefined4 *param_1)

{
  byte bVar1;
  byte bVar2;
  undefined4 *in_EAX;
  int in_ECX;
  int iVar3;
  byte in_DL;
  undefined1 local_80 [64];
  undefined1 local_40 [64];
  
  if ((*(int *)(in_ECX + 0xc) != 0) &&
     (bVar1 = *(byte *)(*(int *)(in_ECX + 0xc) + 2), in_DL < bVar1)) {
    iVar3 = *(int *)(in_ECX + 0x14);
    bVar2 = *(byte *)((uint)in_DL * 0xc4 + 4 + iVar3);
    if (bVar2 < bVar1) {
      FUN_00047960();
      FUN_000479c0();
      FUN_000286c0((uint)bVar2 * 0xc4 + 0x44 + iVar3,local_40);
      FUN_0004d1d0();
      FUN_000286c0(in_EAX,local_80);
      return;
    }
    for (iVar3 = 0x10; iVar3 != 0; iVar3 = iVar3 + -1) {
      *param_1 = *in_EAX;
      in_EAX = in_EAX + 1;
      param_1 = param_1 + 1;
    }
  }
  return;
}


