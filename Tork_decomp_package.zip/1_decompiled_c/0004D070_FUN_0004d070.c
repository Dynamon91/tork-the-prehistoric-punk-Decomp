// func FUN_0004d070 @ 0x0004D070 (size 0x85)

void FUN_0004d070(undefined1 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined1 param_6)

{
  uint uVar1;
  undefined3 uVar3;
  uint uVar2;
  undefined1 local_68 [3];
  undefined1 local_65;
  undefined1 *local_64;
  undefined4 local_48;
  
  uVar1 = CONCAT31((int3)((uint)local_68 >> 8),param_6) & 0xffffff40;
  uVar3 = (undefined3)(uVar1 >> 8);
  local_65 = 0;
  local_48 = 0;
  local_64 = &LAB_00111ca0;
  uVar2 = CONCAT31(uVar3,param_6) & 0xffffff80;
  FUN_00113740(DAT_002414f0,*(undefined4 *)(DAT_0022a6c4 + 0x14),*param_1,param_1 + 1,param_2,
               param_3,0,param_4,0,CONCAT31((int3)((uint)DAT_0022a6c4 >> 8),param_6) & 0xffffff03,
               CONCAT31((int3)(uVar2 >> 8),(char)uVar2 == -0x80),CONCAT31(uVar3,(char)uVar1 == '@'),
               local_68);
  return;
}


