// func FUN_000197b0 @ 0x000197B0 (size 0x79)

void FUN_000197b0(char param_1)

{
  int iVar1;
  int iVar2;
  int in_EAX;
  int *in_ECX;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined8 uVar6;
  
  uVar6 = FUN_000550b0();
  iVar4 = (int)((ulonglong)uVar6 >> 0x20);
  iVar2 = (int)uVar6 + in_EAX;
  iVar1 = in_EAX + 1;
  *in_ECX = in_EAX * 0x20 + 0x44 + iVar4;
  *(int **)(&DAT_00002064 + in_EAX * 4 + iVar4) = in_ECX;
  if (iVar1 < iVar2) {
    puVar5 = (undefined4 *)(&DAT_00002064 + iVar1 * 4 + iVar4);
    for (iVar3 = iVar2 - iVar1; iVar3 != 0; iVar3 = iVar3 + -1) {
      *puVar5 = 0;
      puVar5 = puVar5 + 1;
    }
  }
  if (param_1 != '\0') {
    (&DAT_00002464)[iVar4] = 1;
    for (; in_EAX < iVar2; in_EAX = in_EAX + 1) {
      *(uint *)(&DAT_00002044 + (in_EAX >> 5) * 4 + iVar4) =
           *(uint *)(&DAT_00002044 + (in_EAX >> 5) * 4 + iVar4) | 1 << ((byte)in_EAX & 0x1f);
    }
  }
  return;
}


