// func FUN_00054520 @ 0x00054520 (size 0x3C)

int FUN_00054520(ushort *param_1)

{
  ushort *puVar1;
  ushort *puVar2;
  ushort *puVar3;
  ushort *in_EDX;
  
  puVar1 = in_EDX + 3;
  if ((puVar1 != (ushort *)0x0) && (puVar2 = puVar1 + *in_EDX, puVar1 < puVar2)) {
    puVar3 = puVar1;
    do {
      if (*puVar3 == *param_1) {
        if (puVar3 < puVar2) {
          return (int)puVar3 - (int)puVar1 >> 1;
        }
        return -1;
      }
      puVar3 = puVar3 + 1;
    } while (puVar3 < puVar2);
  }
  return -1;
}


