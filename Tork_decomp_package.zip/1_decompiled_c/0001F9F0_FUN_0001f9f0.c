// func FUN_0001f9f0 @ 0x0001F9F0 (size 0x79)

void FUN_0001f9f0(void)

{
  undefined1 uVar1;
  undefined4 uVar2;
  undefined1 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  int in_ECX;
  
  uVar2 = *(undefined4 *)(in_ECX + 0x30);
  puVar3 = *(undefined1 **)(in_ECX + 0x3c);
  *(undefined1 **)(in_ECX + 0x3c) = puVar3 + 4;
  *(undefined4 *)(in_ECX + 0x30) = *(undefined4 *)(in_ECX + 0xc);
  (**(code **)(&DAT_00241540 + ((byte)puVar3[5] & 0x3f) * 0x10))();
  puVar5 = (undefined4 *)(*(int *)(in_ECX + 8) + -4);
  *(undefined4 **)(in_ECX + 8) = puVar5;
  *(undefined4 *)(in_ECX + 0x30) = uVar2;
  uVar2 = *puVar5;
  (&DAT_00002298)[in_ECX] = 1;
  uVar1 = *puVar3;
  *(short *)(&DAT_0000229a + in_ECX) = (short)uVar2;
  iVar4 = *(int *)(in_ECX + 0x3c);
  (&DAT_00002299)[in_ECX] = uVar1;
  (**(code **)(&DAT_00241540 + (*(byte *)(iVar4 + 1) & 0x3f) * 0x10))();
  (&DAT_00002298)[in_ECX] = 0;
  return;
}


