// func FUN_0001d120 @ 0x0001D120 (size 0x24D)

int * FUN_0001d120(uint *param_1)

{
  int iVar1;
  uint uVar2;
  undefined2 *puVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  uint *puVar9;
  undefined4 *puVar10;
  int *local_10;
  int *local_c;
  int local_8;
  
  iVar1 = *(int *)(DAT_0022d4c0 + 0xc + *(int *)(&DAT_0000281c + DAT_0022d4c0) * 0x18);
  piVar6 = *(int **)(iVar1 + 0x28);
  *(int **)(iVar1 + 0x28) = piVar6 + 1;
  local_8 = *piVar6;
  piVar6 = (int *)FUN_00057f60(local_8 * 8 + 4);
  local_10 = piVar6 + 1;
  *piVar6 = local_8;
  if (local_8 == 0) {
    return piVar6;
  }
  piVar4 = piVar6;
LAB_0001d190:
  local_c = piVar4 + 2;
  iVar1 = *(int *)(DAT_0022d4c0 + 0xc + *(int *)(&DAT_0000281c + DAT_0022d4c0) * 0x18);
  puVar9 = *(uint **)(iVar1 + 0x28);
  *(uint **)(iVar1 + 0x28) = puVar9 + 1;
  uVar2 = *puVar9;
  iVar1 = *(int *)(DAT_0022d4c0 + 0xc + *(int *)(&DAT_0000281c + DAT_0022d4c0) * 0x18);
  puVar3 = *(undefined2 **)(iVar1 + 0x28);
  *(undefined2 **)(iVar1 + 0x28) = puVar3 + 2;
  *(undefined2 *)((int)piVar4 + 6) = *puVar3;
  uVar7 = param_1[1] + 1;
  puVar9 = param_1 + param_1[1] * 5 + 7;
  if (uVar7 < *param_1) {
    do {
      if (*puVar9 == uVar2) goto LAB_0001d26f;
      uVar7 = uVar7 + 1;
      puVar9 = puVar9 + 5;
    } while (uVar7 < *param_1);
  }
  puVar9 = param_1 + 2;
  uVar7 = 0;
  do {
    if (*puVar9 == uVar2) goto LAB_0001d26f;
    uVar7 = uVar7 + 1;
    puVar9 = puVar9 + 5;
  } while (uVar7 <= param_1[1]);
  uVar7 = 0xffff;
  goto LAB_0001d214;
LAB_0001d26f:
  param_1[1] = uVar7;
LAB_0001d214:
  *(short *)local_10 = (short)uVar7;
  uVar2 = param_1[(uVar7 & 0xffff) * 5 + 3];
  if (uVar2 < 5) {
    if (*(char *)((int)piVar4 + 6) < '\0') {
      iVar1 = *(int *)(DAT_0022d4c0 + 0xc + *(int *)(&DAT_0000281c + DAT_0022d4c0) * 0x18);
      piVar4 = *(int **)(iVar1 + 0x2c);
      iVar5 = *piVar4;
      *(int **)(iVar1 + 0x2c) = piVar4 + 1;
      if (iVar5 == -1) {
        *local_c = 0;
      }
      else {
        FUN_000112c0(iVar5,0,local_c);
      }
    }
    else {
      iVar1 = *(int *)(DAT_0022d4c0 + 0xc + *(int *)(&DAT_0000281c + DAT_0022d4c0) * 0x18);
      piVar4 = *(int **)(iVar1 + 0x28);
      *(int **)(iVar1 + 0x28) = piVar4 + 1;
      *local_c = *piVar4;
    }
  }
  else {
    puVar8 = (undefined4 *)FUN_00057f60(uVar2);
    *local_c = (int)puVar8;
    if (*(char *)((int)piVar4 + 6) < '\0') {
      if (uVar2 >> 2 != 0) {
        uVar7 = 0;
        do {
          iVar1 = *(int *)(DAT_0022d4c0 + 0xc + *(int *)(&DAT_0000281c + DAT_0022d4c0) * 0x18);
          piVar4 = *(int **)(iVar1 + 0x2c);
          iVar5 = *piVar4;
          *(int **)(iVar1 + 0x2c) = piVar4 + 1;
          if (iVar5 == -1) {
            *(undefined4 *)(*local_c + uVar7 * 4) = 0;
          }
          else {
            FUN_000112c0(iVar5,0,*local_c + uVar7 * 4);
          }
          uVar7 = uVar7 + 1;
        } while (uVar7 < uVar2 >> 2);
      }
    }
    else {
      iVar1 = *(int *)(DAT_0022d4c0 + 0xc + *(int *)(&DAT_0000281c + DAT_0022d4c0) * 0x18);
      puVar10 = *(undefined4 **)(iVar1 + 0x28);
      for (uVar7 = uVar2 >> 2; uVar7 != 0; uVar7 = uVar7 - 1) {
        *puVar8 = *puVar10;
        puVar10 = puVar10 + 1;
        puVar8 = puVar8 + 1;
      }
      for (uVar7 = uVar2 & 3; uVar7 != 0; uVar7 = uVar7 - 1) {
        *(undefined1 *)puVar8 = *(undefined1 *)puVar10;
        puVar10 = (undefined4 *)((int)puVar10 + 1);
        puVar8 = (undefined4 *)((int)puVar8 + 1);
      }
      *(uint *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + uVar2;
    }
  }
  local_10 = local_10 + 2;
  local_8 = local_8 + -1;
  piVar4 = local_c;
  if (local_8 == 0) {
    return piVar6;
  }
  goto LAB_0001d190;
}


