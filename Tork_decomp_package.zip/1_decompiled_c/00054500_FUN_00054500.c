// func FUN_00054500 @ 0x00054500 (size 0x19)

ushort * FUN_00054500(void)

{
  ushort uVar1;
  ushort *in_EDX;
  
  uVar1 = *in_EDX - 1;
  if (uVar1 < *in_EDX) {
    return in_EDX + uVar1 + 3;
  }
  return (ushort *)0xffffffff;
}


