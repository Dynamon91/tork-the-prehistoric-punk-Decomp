// func FUN_00054c70 @ 0x00054C70 (size 0x50)

int FUN_00054c70(void)

{
  int *piVar1;
  int *piVar2;
  int in_ECX;
  int *in_EDX;
  int *unaff_ESI;
  
  if ((in_EDX != (int *)0x0) && (piVar1 = in_EDX + in_ECX * 3, in_EDX < piVar1)) {
    piVar2 = in_EDX;
    do {
      if (((*piVar2 == *unaff_ESI) && (piVar2[1] == unaff_ESI[1])) && (piVar2[2] == unaff_ESI[2])) {
        if (piVar2 < piVar1) {
          return ((int)piVar2 - (int)in_EDX) / 0xc;
        }
        return -1;
      }
      piVar2 = piVar2 + 3;
    } while (piVar2 < piVar1);
  }
  return -1;
}


