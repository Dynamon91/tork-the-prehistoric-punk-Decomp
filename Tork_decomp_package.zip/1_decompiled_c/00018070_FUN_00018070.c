// func FUN_00018070 @ 0x00018070 (size 0x99)

void FUN_00018070(void)

{
  byte bVar1;
  byte *pbVar2;
  char cVar3;
  byte bVar4;
  int in_EAX;
  ushort uVar5;
  ushort uVar6;
  
  pbVar2 = *(byte **)(in_EAX + 0xc);
  (&DAT_0000229e)[in_EAX] = 1;
  bVar1 = *pbVar2;
  uVar5 = *(ushort *)(pbVar2 + 4);
  uVar6 = 1;
  *(undefined1 *)(in_EAX + 0x18) = 0;
  if (bVar1 != 0) {
    do {
      if ((uVar5 & uVar6) != 0) {
        FUN_00017f40();
        if (*(short *)(*(int *)(in_EAX + 0xc) + 0x6e + (uint)*(byte *)(in_EAX + 0x18) * 8) == -1) {
LAB_000180b5:
          (&DAT_0000229c)[in_EAX] = 0;
          do {
            (**(code **)(&DAT_00241540 + (*(byte *)(*(int *)(in_EAX + 0x3c) + 1) & 0x3f) * 0x10))();
          } while ((&DAT_0000229c)[in_EAX] == '\0');
        }
        else {
          cVar3 = FUN_00018110();
          if (cVar3 != '\0') goto LAB_000180b5;
        }
        uVar5 = *(ushort *)(*(int *)(in_EAX + 0xc) + 4);
      }
      bVar4 = *(char *)(in_EAX + 0x18) + 1;
      uVar6 = uVar6 << 1;
      *(byte *)(in_EAX + 0x18) = bVar4;
    } while (bVar4 < bVar1);
  }
  FUN_00018b20();
  return;
}


