// func FUN_00054a50 @ 0x00054A50 (size 0x3F)

int FUN_00054a50(int *param_1)

{
  ushort *puVar1;
  ushort *puVar2;
  ushort *puVar3;
  ushort *in_EDX;
  
  puVar1 = in_EDX + 3;
  if ((puVar1 != (ushort *)0x0) && (puVar2 = puVar1 + (uint)*in_EDX * 2, puVar1 < puVar2)) {
    puVar3 = puVar1;
    do {
      if (*(int *)puVar3 == *param_1) {
        if (puVar3 < puVar2) {
          return (int)puVar3 - (int)puVar1 >> 2;
        }
        return -1;
      }
      puVar3 = puVar3 + 2;
    } while (puVar3 < puVar2);
  }
  return -1;
}


