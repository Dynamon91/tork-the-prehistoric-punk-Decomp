// func FUN_00043a30 @ 0x00043A30 (size 0x67)

void FUN_00043a30(float param_1,float param_2,char param_3)

{
  float fVar1;
  uint uVar2;
  float *unaff_ESI;
  
  uVar2 = *(uint *)((int)unaff_ESI[0x17] + 4);
  if ((((uVar2 >> 8 & 1) == 0) || ((uVar2 >> 0x16 & 1) == 0)) ||
     (uVar2 = *(uint *)(*(int *)((int)unaff_ESI[0x17] + 0x24) + 8), uVar2 == 0)) {
    uVar2 = 0;
  }
  else {
    uVar2 = uVar2 & (*(short *)(uVar2 + 2) != 1) - 1;
  }
  if (param_3 == '\0') {
    fVar1 = *(float *)(uVar2 + 0x28);
    *unaff_ESI = param_1 * *(float *)(uVar2 + 0x20);
    unaff_ESI[1] = param_2 * fVar1;
    return;
  }
  fVar1 = *(float *)(uVar2 + 0x2c);
  *unaff_ESI = param_1 * *(float *)(uVar2 + 0x24);
  unaff_ESI[1] = param_2 * fVar1;
  return;
}


