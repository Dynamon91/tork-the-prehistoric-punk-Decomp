// func FUN_00052a40 @ 0x00052A40 (size 0x53)

float10 FUN_00052a40(undefined4 param_1,code *param_2)

{
  undefined4 *in_EAX;
  byte unaff_BL;
  uint uVar1;
  float10 fVar2;
  float local_8;
  
  local_8 = 0.0;
  if (unaff_BL != 0) {
    uVar1 = (uint)unaff_BL;
    do {
      fVar2 = (float10)(*param_2)(*in_EAX);
      in_EAX = in_EAX + 1;
      uVar1 = uVar1 - 1;
      local_8 = (float)(fVar2 + (float10)local_8);
    } while (uVar1 != 0);
  }
  fVar2 = (float10)(*param_2)(param_1);
  return (float10)(local_8 / (float)unaff_BL) - fVar2;
}


