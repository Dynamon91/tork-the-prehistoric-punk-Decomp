// func FUN_00036040 @ 0x00036040 (size 0x378)

uint FUN_00036040(uint param_1,byte param_2)

{
  byte bVar1;
  ushort uVar2;
  int iVar3;
  int iVar4;
  char cVar5;
  float *pfVar6;
  int iVar7;
  float *pfVar8;
  uint local_d8;
  uint local_b8;
  float local_a8 [32];
  float local_28;
  float local_24;
  float local_20;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  iVar3 = *(int *)(DAT_0022a6c4 + 0x14);
  local_a8[10] = 1.0;
  local_a8[5] = 1.0;
  local_a8[0] = 1.0;
  local_a8[0xf] = 1.0;
  local_a8[0xe] = 0.0;
  local_a8[0xd] = 0.0;
  local_a8[0xc] = 0.0;
  local_a8[9] = 0.0;
  local_a8[8] = 0.0;
  local_a8[6] = 0.0;
  local_a8[4] = 0.0;
  local_a8[2] = 0.0;
  local_a8[1] = 0.0;
  local_a8[0xb] = 0.0;
  local_a8[7] = 0.0;
  local_a8[3] = 0.0;
  local_a8[0x10] = 0.0;
  local_d8 = 0;
  local_b8 = param_1;
  local_a8[0x11] = 0.0;
  local_a8[0x12] = 0.0;
  if ((*(byte *)(iVar3 + 8) & 1) != 0) {
    if ((param_1 & 0x10000000) != 0) {
      return param_1;
    }
    uVar2 = *(ushort *)(*(int *)(iVar3 + 0x24) + 0x1e);
    local_d8 = (~(param_1 >> 0x1a) & 1) + (param_1 & 0xff);
    if ((*(uint *)(iVar3 + 4) >> 0x1e & 1) == 0) {
      if (local_d8 < uVar2) {
        do {
          if ((*(byte *)(iVar3 + 8) & param_2) != 0) {
            iVar4 = *(int *)(*(int *)(*(int *)(iVar3 + 0x24) + 0x18) + (local_d8 & 0xff) * 4);
            if ((*(uint *)(iVar4 + 4) >> 0x1e & 1) == 0) goto LAB_000363a3;
            iVar7 = *(int *)(iVar4 + 0x28);
            FUN_000479c0();
            local_14 = *(undefined4 *)(iVar7 + 0x74);
            local_18 = *(undefined4 *)(iVar7 + 0x70);
            local_10 = *(undefined4 *)(iVar7 + 0x78);
            if ((*(byte *)(iVar4 + 4) & 1) != 0) {
              pfVar6 = *(float **)(iVar4 + 0x10);
              if ((*(byte *)(iVar4 + 4) & 2) != 0) {
                pfVar6 = pfVar6 + 0xc;
              }
              local_28 = local_28 + *pfVar6;
              local_24 = local_24 + pfVar6[1];
              local_20 = local_20 + pfVar6[2];
            }
            cVar5 = FUN_00070600();
            if (cVar5 != '\0') goto LAB_000363a3;
          }
          local_d8 = local_d8 + 1;
        } while (local_d8 < uVar2);
      }
    }
    else {
      for (; local_d8 < uVar2; local_d8 = local_d8 + 1) {
        iVar4 = *(int *)(*(int *)(*(int *)(iVar3 + 0x24) + 0x18) + (local_d8 & 0xff) * 4);
        if ((*(byte *)(iVar3 + 8) & param_2) != 0) {
          bVar1 = *(byte *)(iVar3 + 4);
          pfVar6 = (float *)(*(int *)(iVar3 + 0x28) + 0x30);
          pfVar8 = local_a8;
          for (iVar7 = 0x13; iVar7 != 0; iVar7 = iVar7 + -1) {
            *pfVar8 = *pfVar6;
            pfVar6 = pfVar6 + 1;
            pfVar8 = pfVar8 + 1;
          }
          if ((bVar1 & 1) != 0) {
            pfVar6 = *(float **)(iVar3 + 0x10);
            if ((bVar1 & 2) != 0) {
              pfVar6 = pfVar6 + 0xc;
            }
            local_a8[0xc] = local_a8[0xc] + *pfVar6;
            local_a8[0xd] = local_a8[0xd] + pfVar6[1];
            local_a8[0xe] = local_a8[0xe] + pfVar6[2];
          }
          if ((*(uint *)(iVar4 + 4) >> 0x1e & 1) == 0) {
            cVar5 = FUN_00070600();
          }
          else {
            iVar7 = *(int *)(iVar4 + 0x28);
            FUN_000479c0();
            local_14 = *(undefined4 *)(iVar7 + 0x74);
            local_10 = *(undefined4 *)(iVar7 + 0x78);
            local_18 = *(undefined4 *)(iVar7 + 0x70);
            if ((*(byte *)(iVar4 + 4) & 1) != 0) {
              pfVar6 = *(float **)(iVar4 + 0x10);
              if ((*(byte *)(iVar4 + 4) & 2) != 0) {
                pfVar6 = pfVar6 + 0xc;
              }
              local_28 = local_28 + *pfVar6;
              local_24 = local_24 + pfVar6[1];
              local_20 = local_20 + pfVar6[2];
            }
            cVar5 = FUN_00070480();
          }
          if (cVar5 != '\0') goto LAB_000363a3;
        }
      }
    }
  }
  local_b8 = param_1 | 0x10000000;
LAB_000363a3:
  return local_b8 & 0xfbffff00 | local_d8 & 0xff;
}


