// func FUN_00023870 @ 0x00023870 (size 0x47)

void FUN_00023870(void)

{
  float *in_EAX;
  float *in_ECX;
  float *in_EDX;
  
  *in_EDX = *in_ECX * *in_EAX + in_ECX[4] * in_EAX[1] + in_ECX[8] * in_EAX[2];
  in_EDX[1] = in_ECX[5] * in_EAX[1] + in_ECX[1] * *in_EAX + in_ECX[9] * in_EAX[2];
  in_EDX[2] = in_ECX[6] * in_EAX[1] + in_ECX[2] * *in_EAX + in_ECX[10] * in_EAX[2];
  return;
}


