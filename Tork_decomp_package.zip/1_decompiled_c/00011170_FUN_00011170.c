// func FUN_00011170 @ 0x00011170 (size 0x14C)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00011170(float param_1)

{
  bool bVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  bool bVar6;
  uint local_10;
  uint local_c;
  uint local_8;
  uint local_4;
  
  if (param_1 == _DAT_0020df5c) {
    bVar1 = false;
  }
  else {
    bVar1 = true;
    FUN_00011020(&local_8);
    uVar2 = FUN_00140e74();
    local_10 = uVar2;
    iVar3 = FUN_00140e74();
    uVar4 = local_8 + iVar3;
    local_4 = local_4 + uVar2;
    bVar6 = uVar4 < local_8;
    local_8 = uVar4;
    if (bVar6) {
      local_4 = local_4 + 1;
    }
  }
  iVar3 = *(int *)(&DAT_00002838 + DAT_0022d4c0);
  iVar5 = DAT_0022d4c0;
  while (iVar3 != 0) {
    if ((*(int *)(&DAT_00002988 + iVar5) != 0) || (*(int *)(&DAT_00002814 + iVar5) + iVar3 * 2 != 0)
       ) {
      FUN_0012e965(0xfffffffe,1,1);
      *(undefined4 *)(&DAT_00002988 + iVar5) = 0;
      iVar5 = DAT_0022d4c0;
    }
    if (bVar1) {
      FUN_00011020(&local_10);
      if ((local_4 < local_c) || ((local_4 <= local_c && (local_8 < local_10)))) break;
      iVar5 = DAT_0022d4c0;
    }
    iVar3 = *(int *)(&DAT_00002838 + iVar5);
  }
  if (param_1 == _DAT_0020df5c) {
    FUN_00059640();
  }
  return (float10)_DAT_0020df5c;
}


