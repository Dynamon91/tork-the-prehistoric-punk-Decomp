// func FUN_0005acb0 @ 0x0005ACB0 (size 0x28)

void FUN_0005acb0(undefined4 param_1)

{
  int in_EAX;
  
  FUN_0005ba50();
  *(undefined4 *)(*(int *)(in_EAX + 4) + (uint)*(ushort *)(in_EAX + 10) * 4) = param_1;
  *(short *)(in_EAX + 10) = *(short *)(in_EAX + 10) + 1;
  return;
}


