// func FUN_0001fb40 @ 0x0001FB40 (size 0x36)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0001fb40(float *param_1,float *param_2,float param_3)

{
  undefined8 uVar1;
  
  param_3 = _DAT_0020df98 / param_3;
  uVar1 = *(undefined8 *)(param_2 + 1);
  *param_1 = param_3 * *param_2;
  *(ulonglong *)(param_1 + 1) =
       CONCAT44(param_3 * (float)((ulonglong)uVar1 >> 0x20),param_3 * (float)uVar1);
  return;
}


