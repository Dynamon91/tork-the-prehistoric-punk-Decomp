// func FUN_00028540 @ 0x00028540 (size 0x115)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00028540(void)

{
  float *pfVar1;
  float *in_EAX;
  float *unaff_EBX;
  float *unaff_EDI;
  float10 fVar2;
  
  pfVar1 = unaff_EDI + 4;
  *pfVar1 = -*in_EAX;
  unaff_EDI[5] = -in_EAX[1];
  unaff_EDI[6] = -in_EAX[2];
  fVar2 = (float10)FUN_00021640();
  fVar2 = SQRT((float10)_DAT_0020df98 / fVar2);
  *pfVar1 = (float)(fVar2 * (float10)*pfVar1);
  unaff_EDI[5] = (float)(fVar2 * (float10)unaff_EDI[5]);
  unaff_EDI[6] = (float)(fVar2 * (float10)unaff_EDI[6]);
  *unaff_EDI = unaff_EBX[2] * unaff_EDI[5] - unaff_EBX[1] * unaff_EDI[6];
  unaff_EDI[1] = unaff_EDI[6] * *unaff_EBX - *pfVar1 * unaff_EBX[2];
  unaff_EDI[2] = *pfVar1 * unaff_EBX[1] - unaff_EDI[5] * *unaff_EBX;
  fVar2 = (float10)FUN_00021640();
  fVar2 = SQRT((float10)_DAT_0020df98 / fVar2);
  *unaff_EDI = (float)(fVar2 * (float10)*unaff_EDI);
  unaff_EDI[1] = (float)(fVar2 * (float10)unaff_EDI[1]);
  unaff_EDI[2] = (float)(fVar2 * (float10)unaff_EDI[2]);
  unaff_EDI[8] = unaff_EDI[6] * unaff_EDI[1] - unaff_EDI[2] * unaff_EDI[5];
  unaff_EDI[9] = *pfVar1 * unaff_EDI[2] - unaff_EDI[6] * *unaff_EDI;
  unaff_EDI[10] = unaff_EDI[5] * *unaff_EDI - *pfVar1 * unaff_EDI[1];
  return;
}


