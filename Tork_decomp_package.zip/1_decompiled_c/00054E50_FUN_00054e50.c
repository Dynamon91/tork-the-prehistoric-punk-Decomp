// func FUN_00054e50 @ 0x00054E50 (size 0x9C)

void FUN_00054e50(float *param_1,float param_2,float param_3,float param_4)

{
  *param_1 = param_2 * *param_1;
  *(ulonglong *)(param_1 + 1) =
       CONCAT44(param_2 * (float)((ulonglong)*(undefined8 *)(param_1 + 1) >> 0x20),
                param_2 * (float)*(undefined8 *)(param_1 + 1));
  param_1[4] = param_3 * param_1[4];
  *(ulonglong *)(param_1 + 5) =
       CONCAT44(param_3 * (float)((ulonglong)*(undefined8 *)(param_1 + 5) >> 0x20),
                param_3 * (float)*(undefined8 *)(param_1 + 5));
  param_1[8] = param_4 * param_1[8];
  *(ulonglong *)(param_1 + 9) =
       CONCAT44(param_4 * (float)((ulonglong)*(undefined8 *)(param_1 + 9) >> 0x20),
                param_4 * (float)*(undefined8 *)(param_1 + 9));
  return;
}


