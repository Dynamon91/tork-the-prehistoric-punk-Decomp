// func FUN_0001cd30 @ 0x0001CD30 (size 0xA0)

void FUN_0001cd30(uint *param_1,int param_2,byte param_3)

{
  uint uVar1;
  uint *puVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  uVar5 = 0;
  if (*param_1 != 0) {
    puVar2 = param_1 + 6;
    do {
      if ((((ushort)puVar2[-1] & 1) != 0) &&
         ((ushort)(((ushort)puVar2[-1] >> 0xe) + (ushort)param_3) < 4)) {
        uVar4 = puVar2[-3];
        uVar1 = puVar2[-2];
        switch(uVar4) {
        case 1:
          *(char *)(uVar1 + param_2) = (char)*puVar2;
          break;
        case 2:
          *(short *)(uVar1 + param_2) = (short)*puVar2;
          break;
        case 3:
          *(undefined2 *)(uVar1 + param_2) = (short)*puVar2;
          *(undefined1 *)((undefined2 *)(uVar1 + param_2) + 1) = *(undefined1 *)((int)puVar2 + 2);
          break;
        case 4:
          *(uint *)(uVar1 + param_2) = *puVar2;
          break;
        default:
          puVar6 = (undefined4 *)*puVar2;
          puVar7 = (undefined4 *)(uVar1 + param_2);
          for (uVar3 = uVar4 >> 2; uVar3 != 0; uVar3 = uVar3 - 1) {
            *puVar7 = *puVar6;
            puVar6 = puVar6 + 1;
            puVar7 = puVar7 + 1;
          }
          for (uVar4 = uVar4 & 3; uVar4 != 0; uVar4 = uVar4 - 1) {
            *(undefined1 *)puVar7 = *(undefined1 *)puVar6;
            puVar6 = (undefined4 *)((int)puVar6 + 1);
            puVar7 = (undefined4 *)((int)puVar7 + 1);
          }
        }
      }
      uVar5 = uVar5 + 1;
      puVar2 = puVar2 + 5;
    } while (uVar5 < *param_1);
  }
  return;
}


