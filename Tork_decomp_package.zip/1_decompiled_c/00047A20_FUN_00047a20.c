// func FUN_00047a20 @ 0x00047A20 (size 0x24)

void FUN_00047a20(undefined4 param_1)

{
  undefined1 local_40 [64];
  
  FUN_000479c0();
  FUN_000286c0(local_40,param_1);
  return;
}


