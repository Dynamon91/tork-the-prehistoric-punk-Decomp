// func FUN_00043bf0 @ 0x00043BF0 (size 0x8C)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00043bf0(float param_1,float param_2)

{
  float fVar1;
  float fVar2;
  byte in_AL;
  int iVar3;
  int in_ECX;
  
  if (in_AL == 0) {
    in_AL = *(byte *)(*(int *)(in_ECX + 0x60) + 0xc);
  }
  if (0x1f < in_AL) {
    FUN_00043b80(param_1,param_2);
  }
  fVar1 = *(float *)(*(int *)(in_ECX + 0x60) + 8);
  fVar2 = (float)in_AL;
  iVar3 = _rand();
  FUN_00043b20((((float)iVar3 * _DAT_0020dfe0 * (fVar2 - -fVar2) + -fVar2) / fVar2) *
               param_2 * fVar1 + param_1);
  return;
}


