// func FUN_0001e280 @ 0x0001E280 (size 0x111)

void FUN_0001e280(void)

{
  char cVar1;
  char cVar2;
  ushort uVar3;
  char *pcVar4;
  int iVar5;
  float *pfVar6;
  int in_ECX;
  undefined4 *puVar7;
  float fVar8;
  bool bVar9;
  float fStack_10;
  undefined4 auStack_c [3];
  
  pcVar4 = *(char **)(in_ECX + 0x3c);
  cVar1 = pcVar4[2];
  cVar2 = *pcVar4;
  uVar3 = *(ushort *)(pcVar4 + 2);
  *(char **)(in_ECX + 0x3c) = pcVar4 + 4;
  (**(code **)(&DAT_00241540 + ((byte)pcVar4[5] & 0x3f) * 0x10))();
  if (cVar2 == '\x05') {
    iVar5 = *(int *)(in_ECX + 8);
    puVar7 = (undefined4 *)(iVar5 + -0xc);
    *(undefined4 **)(in_ECX + 8) = puVar7;
    auStack_c[0] = *puVar7;
    auStack_c[1] = *(undefined4 *)(iVar5 + -8);
    auStack_c[2] = *(undefined4 *)(iVar5 + -4);
    *puVar7 = auStack_c[uVar3];
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  }
  bVar9 = cVar1 != '\b';
  iVar5 = *(int *)(in_ECX + 8);
  if (bVar9) {
    *(float **)(in_ECX + 8) = (float *)(iVar5 + -4);
    fVar8 = *(float *)(iVar5 + -4);
  }
  else {
    *(float **)(in_ECX + 8) = (float *)(iVar5 + -4);
    fVar8 = fStack_10;
    fStack_10 = *(float *)(iVar5 + -4);
  }
  pfVar6 = (float *)(iVar5 + -4);
  switch(cVar2) {
  case '\x01':
    fVar8 = (float)~(uint)fVar8;
    break;
  case '\x02':
    fVar8 = (float)(uint)(fVar8 == 0.0);
    break;
  case '\x03':
    if (bVar9) {
      fVar8 = (float)-(int)fVar8;
      goto LAB_0001e35a;
    }
    fStack_10 = -fStack_10;
    break;
  case '\x04':
    if (bVar9) {
      *pfVar6 = (float)((int)fVar8 * (int)fVar8);
      *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
      return;
    }
    fStack_10 = fStack_10 * fStack_10;
  }
  if (!bVar9) {
    *pfVar6 = fStack_10;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    return;
  }
LAB_0001e35a:
  *pfVar6 = fVar8;
  *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
  return;
}


