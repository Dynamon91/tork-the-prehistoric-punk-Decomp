// func FUN_00053820 @ 0x00053820 (size 0x57)

undefined4 FUN_00053820(float *param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  int iVar3;
  float local_4;
  
  iVar3 = FUN_000530c0(&local_4);
  if (iVar3 == 0) {
    return 0;
  }
  *param_1 = local_4 * *param_3 + *param_2;
  fVar1 = param_3[1];
  fVar2 = param_2[1];
  param_1[2] = local_4;
  param_1[1] = local_4 * fVar1 + fVar2;
  return 1;
}


