// func FUN_0005a3c0 @ 0x0005A3C0 (size 0x29)

void FUN_0005a3c0(undefined2 *param_1)

{
  int *in_EAX;
  
  FUN_0005a4f0();
  *(undefined2 *)(*in_EAX + (uint)*(ushort *)((int)in_EAX + 6) * 2) = *param_1;
  *(short *)((int)in_EAX + 6) = *(short *)((int)in_EAX + 6) + 1;
  return;
}


