// func FUN_000597a0 @ 0x000597A0 (size 0x1C3)

void FUN_000597a0(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  ushort *puVar4;
  int iVar5;
  int in_ECX;
  int *piVar6;
  int iVar7;
  int local_8;
  
  piVar6 = (int *)(in_ECX + 0x4c);
  iVar7 = 4;
  do {
    iVar3 = *piVar6;
    if (iVar3 != 0) {
      iVar2 = FUN_00058910();
      if (((iVar2 != -1) && (iVar5 = *(int *)(DAT_00241208 + iVar2 * 4), iVar3 + -8 == iVar5)) &&
         (iVar3 = (*(int *)(DAT_0024120c + iVar2 * 4) - iVar5) + iVar3, iVar3 != 0)) {
        *piVar6 = iVar3;
      }
    }
    piVar6 = piVar6 + 5;
    iVar7 = iVar7 + -1;
  } while (iVar7 != 0);
  iVar7 = *(int *)(in_ECX + 0x9c);
  if (iVar7 != 0) {
    iVar3 = FUN_00058910();
    if (((iVar3 != -1) && (iVar2 = *(int *)(DAT_00241208 + iVar3 * 4), iVar7 + -8 == iVar2)) &&
       (iVar7 = (*(int *)(DAT_0024120c + iVar3 * 4) - iVar2) + iVar7, iVar7 != 0)) {
      *(int *)(in_ECX + 0x9c) = iVar7;
    }
  }
  piVar6 = (int *)(in_ECX + 0x50);
  local_8 = 4;
  do {
    iVar7 = 0;
    if (0 < piVar6[2]) {
      do {
        iVar3 = *piVar6;
        if (piVar6[1] < iVar3) {
          if (iVar7 < piVar6[3] - iVar3) {
            puVar4 = (ushort *)(piVar6[-1] + (iVar3 + iVar7) * 2);
          }
          else {
            puVar4 = (ushort *)(piVar6[-1] + ((iVar3 - piVar6[3]) + iVar7) * 2);
          }
        }
        else {
          puVar4 = (ushort *)(piVar6[-1] + (iVar3 + iVar7) * 2);
        }
        iVar2 = *(int *)(*(int *)(in_ECX + 0x9c) + 0xc + (uint)*puVar4 * 0x18);
        iVar3 = *(int *)(in_ECX + 0x9c) + (uint)*puVar4 * 0x18;
        if (iVar2 != 0) {
          iVar5 = FUN_00058910();
          if (((iVar5 != -1) && (iVar1 = *(int *)(DAT_00241208 + iVar5 * 4), iVar2 + -8 == iVar1))
             && (iVar2 = (*(int *)(DAT_0024120c + iVar5 * 4) - iVar1) + iVar2, iVar2 != 0)) {
            *(int *)(iVar3 + 0xc) = iVar2;
          }
        }
        if (((*(char *)(iVar3 + 0x13) == '\x01') || (*(char *)(iVar3 + 0x13) == '\x03')) &&
           (iVar2 = *(int *)(iVar3 + 4), iVar2 != 0)) {
          iVar5 = FUN_00058910();
          if (((iVar5 != -1) && (iVar1 = *(int *)(DAT_00241208 + iVar5 * 4), iVar2 + -8 == iVar1))
             && (iVar2 = (*(int *)(DAT_0024120c + iVar5 * 4) - iVar1) + iVar2, iVar2 != 0)) {
            *(int *)(iVar3 + 4) = iVar2;
          }
        }
        iVar7 = iVar7 + 1;
      } while (iVar7 < piVar6[2]);
    }
    piVar6 = piVar6 + 5;
    local_8 = local_8 + -1;
  } while (local_8 != 0);
  iVar7 = *(int *)(in_ECX + 0xa4);
  if (iVar7 != 0) {
    iVar3 = FUN_00058910();
    if (((iVar3 != -1) && (iVar2 = *(int *)(DAT_00241208 + iVar3 * 4), iVar7 + -8 == iVar2)) &&
       (iVar7 = (*(int *)(DAT_0024120c + iVar3 * 4) - iVar2) + iVar7, iVar7 != 0)) {
      *(int *)(in_ECX + 0xa4) = iVar7;
    }
  }
  FUN_00059a20();
  return;
}


