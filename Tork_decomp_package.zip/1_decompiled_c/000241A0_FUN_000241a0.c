// func FUN_000241a0 @ 0x000241A0 (size 0x5B)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_000241a0(void)

{
  float *unaff_ESI;
  float *unaff_EDI;
  float10 fVar1;
  float10 fVar2;
  
  fVar1 = (float10)FUN_00021640();
  fVar2 = (float10)FUN_00021640();
  fVar1 = ((float10)*unaff_ESI * (float10)*unaff_EDI +
          (float10)unaff_ESI[1] * (float10)unaff_EDI[1] +
          (float10)unaff_ESI[2] * (float10)unaff_EDI[2]) / SQRT(fVar2 * (float10)(float)fVar1);
  if (fVar1 < (float10)_DAT_0020e010) {
    return (float10)_DAT_0020e010;
  }
  if ((float10)_DAT_0020df98 < fVar1) {
    fVar1 = (float10)_DAT_0020df98;
  }
  return fVar1;
}


