// func FUN_00023340 @ 0x00023340 (size 0x96)

void FUN_00023340(float *param_1,float *param_2,float *param_3,undefined4 param_4,undefined4 param_5
                 )

{
  float fVar1;
  float fVar2;
  float local_40;
  float local_3c;
  float local_38;
  float local_30;
  float local_2c;
  float local_28;
  float local_20;
  float local_1c;
  float local_18;
  
  FUN_0006e9e0(param_5);
  fVar1 = param_3[1];
  fVar2 = param_3[2];
  *param_1 = local_20 * param_2[2] + local_30 * param_2[1] + local_40 * *param_2 + *param_3;
  param_1[1] = local_1c * param_2[2] + local_2c * param_2[1] + local_3c * *param_2 + fVar1;
  param_1[2] = local_18 * param_2[2] + local_28 * param_2[1] + local_38 * *param_2 + fVar2;
  return;
}


