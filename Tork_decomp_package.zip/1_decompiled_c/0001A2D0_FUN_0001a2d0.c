// func FUN_0001a2d0 @ 0x0001A2D0 (size 0x4E)

undefined4 FUN_0001a2d0(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int in_EDX;
  int unaff_ESI;
  int iVar4;
  
  iVar1 = *(int *)(in_EDX + 0x700);
  iVar3 = -1;
  iVar4 = iVar1;
  iVar2 = iVar1;
  if (iVar1 != 0) {
    do {
      iVar2 = iVar4 + iVar3 >> 1;
      if (*(int *)(in_EDX + (iVar2 + 0x39) * 0x20) < unaff_ESI) {
        iVar3 = iVar2;
        iVar2 = iVar4;
      }
      iVar4 = iVar2;
    } while (iVar2 != iVar3 + 1);
  }
  if ((iVar2 < iVar1) && (*(int *)((iVar2 + 0x39) * 0x20 + in_EDX) == unaff_ESI)) {
    FUN_0001a370();
    return 1;
  }
  return 0;
}


