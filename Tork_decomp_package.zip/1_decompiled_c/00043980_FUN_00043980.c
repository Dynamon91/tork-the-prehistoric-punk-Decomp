// func FUN_00043980 @ 0x00043980 (size 0x4F)

void FUN_00043980(float param_1,char param_2)

{
  uint uVar1;
  float *unaff_ESI;
  
  uVar1 = *(uint *)((int)unaff_ESI[0x17] + 4);
  if ((((uVar1 >> 8 & 1) == 0) || ((uVar1 >> 0x16 & 1) == 0)) ||
     (uVar1 = *(uint *)(*(int *)((int)unaff_ESI[0x17] + 0x24) + 8), uVar1 == 0)) {
    uVar1 = 0;
  }
  else {
    uVar1 = uVar1 & (*(short *)(uVar1 + 2) != 1) - 1;
  }
  if (param_2 == '\0') {
    *unaff_ESI = param_1 * *(float *)(uVar1 + 0x20);
    return;
  }
  *unaff_ESI = param_1 * *(float *)(uVar1 + 0x24);
  return;
}


