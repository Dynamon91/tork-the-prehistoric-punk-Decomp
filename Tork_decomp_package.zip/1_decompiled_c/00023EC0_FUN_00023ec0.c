// func FUN_00023ec0 @ 0x00023EC0 (size 0x2F)

void FUN_00023ec0(void)

{
  float *in_EAX;
  float *in_ECX;
  float *in_EDX;
  
  *in_EDX = in_EAX[2] * in_ECX[1] - in_ECX[2] * in_EAX[1];
  in_EDX[1] = in_ECX[2] * *in_EAX - *in_ECX * in_EAX[2];
  in_EDX[2] = *in_ECX * in_EAX[1] - *in_EAX * in_ECX[1];
  return;
}


