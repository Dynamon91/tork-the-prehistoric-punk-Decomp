// func FUN_000223e0 @ 0x000223E0 (size 0x27)

void FUN_000223e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  return;
}


