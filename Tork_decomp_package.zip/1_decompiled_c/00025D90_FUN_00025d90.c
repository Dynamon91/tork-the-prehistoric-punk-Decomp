// func FUN_00025d90 @ 0x00025D90 (size 0x43)

void FUN_00025d90(uint *param_1)

{
  FUN_00025c20(param_1);
  *param_1 = *param_1 ^ 0x80000000;
  param_1[1] = param_1[1] ^ 0x80000000;
  param_1[2] = param_1[2] ^ 0x80000000;
  return;
}


