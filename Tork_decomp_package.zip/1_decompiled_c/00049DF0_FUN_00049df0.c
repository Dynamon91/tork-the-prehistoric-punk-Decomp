// func FUN_00049df0 @ 0x00049DF0 (size 0x69)

void FUN_00049df0(int param_1,int param_2,int param_3)

{
  int *unaff_ESI;
  
  if (*unaff_ESI != 0) {
    FUN_00075c50();
    *unaff_ESI = 0;
  }
  if (unaff_ESI[2] != 0) {
    FUN_00075c50();
    unaff_ESI[2] = 0;
  }
  if (unaff_ESI[4] != 0) {
    FUN_00075c50();
    unaff_ESI[4] = 0;
  }
  if (*unaff_ESI == 0) {
    unaff_ESI[1] = param_1;
  }
  if (unaff_ESI[2] == 0) {
    unaff_ESI[3] = param_2;
  }
  if (unaff_ESI[4] == 0) {
    unaff_ESI[5] = param_3;
  }
  return;
}


