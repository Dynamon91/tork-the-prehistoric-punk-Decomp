// func FUN_00026f10 @ 0x00026F10 (size 0x5A)

float10 FUN_00026f10(void)

{
  float fVar1;
  float10 fVar2;
  float10 fVar3;
  
  fVar2 = (float10)FUN_00025310();
  fVar3 = (float10)FUN_00025370();
  fVar1 = (float)fVar3;
  fVar3 = (float10)FUN_000253d0();
  if (fVar1 < (float)fVar2) {
    fVar1 = (float)fVar2;
  }
  fVar2 = (float10)fVar1;
  if (fVar2 <= (float10)(float)fVar3) {
    fVar2 = (float10)(float)fVar3;
  }
  return fVar2;
}


