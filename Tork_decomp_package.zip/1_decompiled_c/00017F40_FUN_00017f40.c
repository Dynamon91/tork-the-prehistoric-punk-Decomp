// func FUN_00017f40 @ 0x00017F40 (size 0x66)

void FUN_00017f40(void)

{
  byte *pbVar1;
  byte bVar2;
  int iVar3;
  ushort *puVar4;
  int *in_EAX;
  
  pbVar1 = (byte *)(in_EAX[3] + 0x6a + (uint)*(byte *)(in_EAX + 6) * 8);
  in_EAX[7] = (int)pbVar1;
  bVar2 = *pbVar1;
  *(byte *)(in_EAX + 0xe) = bVar2;
  *(byte *)((int)in_EAX + 0x19) = bVar2;
  iVar3 = *(int *)(in_EAX[3] + 8 + (uint)bVar2 * 4);
  in_EAX[0xd] = iVar3;
  in_EAX[8] = iVar3;
  bVar2 = pbVar1[1];
  *(byte *)((int)in_EAX + 0x1a) = bVar2;
  puVar4 = *(ushort **)(*(int *)(iVar3 + 0xc) + (uint)bVar2 * 4);
  iVar3 = *in_EAX;
  in_EAX[0xf] = (int)puVar4;
  in_EAX[2] = iVar3;
  in_EAX[9] = (int)puVar4;
  in_EAX[0xb] = iVar3;
  *(undefined1 *)((int)in_EAX + 0x1b) = 0xff;
  in_EAX[10] = 0;
  in_EAX[2] = iVar3 + (uint)*puVar4 * 4;
  in_EAX[0xf] = (int)(puVar4 + 2);
  *(undefined1 *)(in_EAX + 0x8a6) = 0;
  return;
}


