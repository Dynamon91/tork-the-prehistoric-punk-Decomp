// func FUN_00027f80 @ 0x00027F80 (size 0x6A)

void FUN_00027f80(undefined4 param_1,undefined4 param_2)

{
  undefined2 uVar1;
  int in_EAX;
  int in_ECX;
  short sVar2;
  
  sVar2 = 0;
  if ((*(uint *)(in_EAX + 4) >> 0xc & 1) != 0) {
    in_ECX = *(int *)(*(int *)(in_EAX + 0x24) + 4);
    sVar2 = *(short *)(in_ECX + 6);
  }
  FUN_000dbe40();
  uVar1 = *(undefined2 *)(in_EAX + 2);
  FUN_000de850(param_1,param_2);
  FUN_000e8050(in_EAX,uVar1);
  if (sVar2 != 0) {
    *(short *)(in_ECX + 6) = sVar2;
    FUN_000187b0(in_ECX);
  }
  return;
}


