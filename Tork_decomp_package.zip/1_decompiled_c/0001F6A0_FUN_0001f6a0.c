// func FUN_0001f6a0 @ 0x0001F6A0 (size 0x42)

void FUN_0001f6a0(void)

{
  int iVar1;
  int in_ECX;
  int *piVar2;
  
  iVar1 = *(int *)(in_ECX + 0x3c);
  *(int *)(in_ECX + 0x3c) = iVar1 + 4;
  (**(code **)(&DAT_00241540 + (*(byte *)(iVar1 + 5) & 0x3f) * 0x10))();
  piVar2 = (int *)(*(int *)(in_ECX + 8) + -4);
  *(int **)(in_ECX + 8) = piVar2;
  if (*piVar2 == 0) {
    *(int *)(in_ECX + 0x3c) = iVar1 + *(short *)(iVar1 + 2) * 4;
  }
  return;
}


