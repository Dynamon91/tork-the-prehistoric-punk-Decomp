// func FUN_00043aa0 @ 0x00043AA0 (size 0x7A)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00043aa0(float param_1,float param_2,char param_3)

{
  float fVar1;
  uint uVar2;
  int unaff_ESI;
  
  uVar2 = *(uint *)(*(int *)(unaff_ESI + 0x5c) + 4);
  if ((((uVar2 >> 8 & 1) == 0) || ((uVar2 >> 0x16 & 1) == 0)) ||
     (uVar2 = *(uint *)(*(int *)(*(int *)(unaff_ESI + 0x5c) + 0x24) + 8), uVar2 == 0)) {
    uVar2 = 0;
  }
  else {
    uVar2 = uVar2 & (*(short *)(uVar2 + 2) != 1) - 1;
  }
  if (param_3 == '\0') {
    fVar1 = *(float *)(uVar2 + 0x18);
  }
  else {
    fVar1 = *(float *)(uVar2 + 0x1c);
  }
  fVar1 = param_1 * fVar1 * **(float **)(unaff_ESI + 0x60);
  if (_DAT_0020df5c < param_2) {
    *(float *)(unaff_ESI + 0x14) = fVar1;
    *(float *)(unaff_ESI + 0x18) = param_2;
    return;
  }
  *(float *)(unaff_ESI + 0x10) = fVar1;
  *(undefined4 *)(unaff_ESI + 0x18) = 0xbf800000;
  *(float *)(unaff_ESI + 0x14) = fVar1;
  return;
}


