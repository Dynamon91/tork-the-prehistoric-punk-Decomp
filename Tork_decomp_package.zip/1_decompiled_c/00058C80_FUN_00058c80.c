// func FUN_00058c80 @ 0x00058C80 (size 0xAA)

void FUN_00058c80(void)

{
  byte bVar1;
  undefined4 *in_EAX;
  int in_ECX;
  undefined4 in_EDX;
  
  bVar1 = *(byte *)((int)in_EAX + 0x13);
  if (1 < bVar1) {
    if (bVar1 < 4) {
      *(uint *)(in_ECX + 0x24) = *(int *)(in_ECX + 0x24) + (in_EAX[4] & 0xffffff);
      if (in_EAX[5] == 0) {
        return;
      }
      *(uint *)(in_EAX[5] + 4) = in_EAX[4] & 0xffffff;
      *(undefined4 *)(in_EAX[5] + 8) = in_EAX[3];
      *(undefined4 *)(in_EAX[5] + 0x10) = in_EDX;
      DAT_00241218 = DAT_00241218 + 1;
      FUN_0012c314(&LAB_00059050,*in_EAX,in_EAX[5]);
      return;
    }
    if (bVar1 == 7) goto LAB_00058ca8;
  }
  *(uint *)(in_ECX + 0x24) = *(int *)(in_ECX + 0x24) + (in_EAX[4] & 0xffffff);
LAB_00058ca8:
  if (in_EAX[5] != 0) {
    *(undefined4 *)(in_EAX[5] + 0x10) = in_EDX;
    DAT_00241218 = DAT_00241218 + 1;
    FUN_0012c314(&LAB_00059050,*in_EAX,in_EAX[5]);
  }
  return;
}


