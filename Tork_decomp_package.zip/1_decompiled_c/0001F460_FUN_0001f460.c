// func FUN_0001f460 @ 0x0001F460 (size 0x111)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0001f460(void)

{
  char cVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int in_ECX;
  float *pfVar5;
  undefined4 *unaff_FS_OFFSET;
  undefined4 uStack_c;
  undefined1 *puStack_8;
  undefined4 uStack_4;
  
  uStack_4 = 0xffffffff;
  puStack_8 = &LAB_00143c2e;
  uStack_c = *unaff_FS_OFFSET;
  *unaff_FS_OFFSET = &uStack_c;
  iVar3 = *(int *)(in_ECX + 0x3c);
  cVar1 = *(char *)(iVar3 + 3);
  cVar2 = *(char *)(iVar3 + 2);
  *(int *)(in_ECX + 0x3c) = iVar3 + 4;
  (**(code **)(&DAT_00241540 + (*(byte *)(iVar3 + 5) & 0x3f) * 0x10))();
  if (cVar2 == '\x06') {
    if (cVar1 == '\b') {
      pfVar5 = (float *)(*(int *)(in_ECX + 8) + -4);
      *(float **)(in_ECX + 8) = pfVar5;
      *pfVar5 = (float)(int)*pfVar5;
      *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
      *unaff_FS_OFFSET = uStack_c;
      return;
    }
  }
  else if ((cVar2 == '\t') && (cVar1 == '\t')) {
    if ((_DAT_00241b40 & 1) == 0) {
      _DAT_00241b40 = _DAT_00241b40 | 1;
      uStack_4 = 0;
      FUN_00011ae0(&DAT_00241ae0,0xc,8,&LAB_0001fc60);
    }
    iVar4 = *(int *)(in_ECX + 8);
    *(undefined4 **)(in_ECX + 8) = (undefined4 *)(iVar4 + -0xc);
    iVar3 = DAT_002419e8 * 0xc;
    *(undefined4 *)(&DAT_00241ae0 + iVar3) = *(undefined4 *)(iVar4 + -0xc);
    *(undefined4 *)(&DAT_00241ae4 + iVar3) = *(undefined4 *)(iVar4 + -8);
    *(undefined4 *)(&DAT_00241ae8 + iVar3) = *(undefined4 *)(iVar4 + -4);
    **(undefined4 **)(in_ECX + 8) = &DAT_00241ae0 + iVar3;
    DAT_002419e8 = DAT_002419e8 + 1 & 7;
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
  }
  *unaff_FS_OFFSET = uStack_c;
  return;
}


