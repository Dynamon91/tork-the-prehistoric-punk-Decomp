// func FUN_00019180 @ 0x00019180 (size 0x18C)

void FUN_00019180(wchar_t *param_1,undefined4 param_2)

{
  wchar_t *pwVar1;
  undefined4 uVar2;
  undefined4 *in_EAX;
  undefined *puVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int in_ECX;
  uint uVar7;
  uint uVar8;
  int iVar9;
  bool bVar10;
  
  pwVar1 = (wchar_t *)*in_EAX;
  if ((pwVar1 < (wchar_t *)(in_ECX + 0x44)) || (&DAT_00002044 + in_ECX <= pwVar1)) {
LAB_000191cd:
    iVar9 = -1;
  }
  else {
    puVar3 = (undefined *)((int)pwVar1 + (-0x44 - in_ECX));
    uVar8 = (uint)puVar3 & 0x8000001f;
    if ((int)uVar8 < 0) {
      uVar8 = (uVar8 - 1 | 0xffffffe0) + 1;
    }
    if ((uVar8 != 0) ||
       ((iVar9 = (int)(puVar3 + ((int)puVar3 >> 0x1f & 0x1f)) >> 5, iVar9 != -1 &&
        (*(undefined4 **)(&DAT_00002064 + iVar9 * 4 + in_ECX) != in_EAX)))) goto LAB_000191cd;
  }
  if (((wchar_t *)(in_ECX + 0x44) <= param_1) && (param_1 < &DAT_00002044 + in_ECX)) {
    uVar8 = (int)param_1 + (-0x44 - in_ECX);
    uVar7 = uVar8 & 0x8000001f;
    bVar10 = uVar7 == 0;
    if ((int)uVar7 < 0) {
      bVar10 = (uVar7 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar10) && (iVar4 = (int)(uVar8 + ((int)uVar8 >> 0x1f & 0x1fU)) >> 5, iVar4 != -1)) &&
       (bVar10 = true, *(int *)(&DAT_00002064 + iVar4 * 4 + in_ECX) == 0)) goto LAB_00019233;
  }
  bVar10 = false;
LAB_00019233:
  iVar4 = FUN_00134fe8(param_1);
  iVar5 = FUN_00134fe8(*in_EAX);
  if (iVar9 == -1) {
    uVar2 = *in_EAX;
    iVar9 = FUN_000196d0(param_2);
    pwVar1 = (wchar_t *)(iVar9 * 0x20 + 0x44 + in_ECX);
    FUN_00134fcc(pwVar1,uVar2);
    _wcscat(pwVar1,param_1);
  }
  else {
    iVar6 = FUN_000550b0();
    iVar4 = (iVar4 + iVar5) * 2 + 0x21;
    if (iVar6 < (int)(iVar4 + (iVar4 >> 0x1f & 0x1fU)) >> 5) {
      uVar2 = *in_EAX;
      iVar9 = FUN_000196d0(param_2);
      pwVar1 = (wchar_t *)(iVar9 * 0x20 + 0x44 + in_ECX);
      FUN_00134fcc(pwVar1,uVar2);
      _wcscat(pwVar1,param_1);
      FUN_00019750();
    }
    else {
      _wcscat((wchar_t *)(iVar9 * 0x20 + 0x44 + in_ECX),param_1);
    }
  }
  if (bVar10) {
    FUN_00019750();
  }
  return;
}


