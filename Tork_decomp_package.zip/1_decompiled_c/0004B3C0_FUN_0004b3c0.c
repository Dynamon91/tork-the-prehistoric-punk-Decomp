// func FUN_0004b3c0 @ 0x0004B3C0 (size 0x129)

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

wchar_t * FUN_0004b3c0(undefined *param_1,uint param_2)

{
  wchar_t *__s;
  uint uVar1;
  int iVar2;
  ushort *puVar3;
  ushort *puVar4;
  byte *pbVar5;
  int iVar6;
  bool bVar7;
  ushort local_18 [10];
  undefined4 local_4;
  
  local_4 = DAT_002264b0;
  uVar1 = FUN_00134fe8(param_1);
  iVar6 = DAT_002411d8;
  if ((int)uVar1 <= (int)param_2) {
    uVar1 = param_2;
  }
  iVar2 = uVar1 * 2 + 0x21;
  iVar2 = FUN_000550f0((int)(iVar2 + (iVar2 >> 0x1f & 0x1fU)) >> 5);
  *(undefined4 *)(&DAT_00002064 + iVar2 * 4 + iVar6) = 0;
  __s = (wchar_t *)(iVar2 * 0x20 + 0x44 + iVar6);
  pbVar5 = &DAT_0020824c;
  iVar6 = 4;
  puVar4 = local_18 + 4;
  do {
    puVar3 = puVar4 + 1;
    *puVar4 = (ushort)*pbVar5;
    pbVar5 = pbVar5 + 1;
    iVar6 = iVar6 + -1;
    puVar4 = puVar3;
  } while (iVar6 != 0);
  *puVar3 = 0;
  pbVar5 = &DAT_00208248;
  iVar6 = 3;
  puVar4 = local_18;
  do {
    puVar3 = puVar4 + 1;
    *puVar4 = (ushort)*pbVar5;
    pbVar5 = pbVar5 + 1;
    iVar6 = iVar6 + -1;
    puVar4 = puVar3;
  } while (iVar6 != 0);
  *puVar3 = 0;
  puVar4 = local_18 + 4;
  if ((int)param_2 < 0) {
    puVar4 = local_18;
  }
  _swprintf(__s,(size_t)puVar4,
            (wchar_t *)((param_2 ^ (int)param_2 >> 0x1f) - ((int)param_2 >> 0x1f)),param_1);
  if (((undefined *)(DAT_002411d8 + 0x44) <= param_1) && (param_1 < &DAT_00002044 + DAT_002411d8)) {
    param_1 = param_1 + (-0x44 - DAT_002411d8);
    uVar1 = (uint)param_1 & 0x8000001f;
    bVar7 = uVar1 == 0;
    if ((int)uVar1 < 0) {
      bVar7 = (uVar1 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar7) && ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5 != -1)) &&
       (*(int *)(&DAT_00002064 +
                ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5) * 4 + DAT_002411d8) == 0)) {
      FUN_00019750();
    }
  }
  return __s;
}


