// func FUN_00043b80 @ 0x00043B80 (size 0x6E)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00043b80(float param_1,float param_2)

{
  float fVar1;
  int in_EAX;
  int iVar2;
  
  if (param_2 == _DAT_0020df5c) {
    FUN_00043b20(param_1);
  }
  param_2 = param_2 * *(float *)(*(int *)(in_EAX + 0x60) + 8);
  fVar1 = -param_2;
  iVar2 = _rand();
  FUN_00043b20((float)iVar2 * _DAT_0020dfe0 * (param_2 - fVar1) + fVar1 + param_1);
  return;
}


