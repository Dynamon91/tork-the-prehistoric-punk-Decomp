// func FUN_0004f020 @ 0x0004F020 (size 0x51)

void FUN_0004f020(int param_1,char *param_2,int param_3)

{
  char cVar1;
  char *pcVar2;
  uint uVar3;
  uint uVar4;
  
  pcVar2 = param_2;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  uVar3 = (int)pcVar2 - (int)(param_2 + 1);
  if (param_3 - 1U < (uint)((int)pcVar2 - (int)(param_2 + 1))) {
    uVar3 = param_3 - 1U;
  }
  pcVar2 = (char *)(DAT_002411dc + param_1);
  for (uVar4 = uVar3 >> 2; uVar4 != 0; uVar4 = uVar4 - 1) {
    *(undefined4 *)pcVar2 = *(undefined4 *)param_2;
    param_2 = param_2 + 4;
    pcVar2 = pcVar2 + 4;
  }
  for (uVar4 = uVar3 & 3; uVar4 != 0; uVar4 = uVar4 - 1) {
    *pcVar2 = *param_2;
    param_2 = param_2 + 1;
    pcVar2 = pcVar2 + 1;
  }
  *(undefined1 *)(DAT_002411dc + uVar3 + param_1) = 0;
  return;
}


