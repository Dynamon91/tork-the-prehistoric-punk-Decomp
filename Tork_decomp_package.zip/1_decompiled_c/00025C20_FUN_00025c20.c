// func FUN_00025c20 @ 0x00025C20 (size 0x73)

void FUN_00025c20(undefined4 *param_1)

{
  int iVar1;
  uint *puVar2;
  uint uVar3;
  
  iVar1 = *(int *)(DAT_0022a6c4 + 0x14);
  if ((*(uint *)(iVar1 + 4) >> 7 & 1) == 0) {
    iVar1 = *(int *)(iVar1 + 0x10);
    *param_1 = *(undefined4 *)(iVar1 + 0x10);
    param_1[1] = *(undefined4 *)(iVar1 + 0x14);
    param_1[2] = *(undefined4 *)(iVar1 + 0x18);
    return;
  }
  puVar2 = *(uint **)(iVar1 + 0x1c);
  if ((*puVar2 >> 0xb & 1) == 0) {
    uVar3 = puVar2[1];
    *param_1 = *(undefined4 *)(uVar3 - 0x20);
    param_1[1] = *(undefined4 *)(uVar3 - 0x1c);
    param_1[2] = *(undefined4 *)(uVar3 - 0x18);
    return;
  }
  uVar3 = puVar2[0x16];
  *param_1 = *(undefined4 *)(uVar3 + 0x58);
  param_1[1] = *(undefined4 *)(uVar3 + 0x5c);
  param_1[2] = *(undefined4 *)(uVar3 + 0x60);
  return;
}


