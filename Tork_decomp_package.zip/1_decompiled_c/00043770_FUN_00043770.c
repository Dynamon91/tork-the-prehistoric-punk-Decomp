// func FUN_00043770 @ 0x00043770 (size 0x26)

void FUN_00043770(float param_1)

{
  int iVar1;
  uint in_EAX;
  int in_ECX;
  
  iVar1 = *(int *)(in_ECX + 0x10 + (in_EAX & 0xffff) * 8);
  *(float *)(iVar1 + 0x28) = param_1;
  *(float *)(iVar1 + 0x30) = param_1 * param_1;
  *(float *)(iVar1 + 0x34) = param_1 - *(float *)(iVar1 + 0x24);
  return;
}


