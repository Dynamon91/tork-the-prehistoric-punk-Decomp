// func FUN_000568c0 @ 0x000568C0 (size 0x3C1)

undefined4 * FUN_000568c0(uint param_1)

{
  int iVar1;
  undefined4 *puVar2;
  uint uVar3;
  uint *puVar4;
  undefined *puVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined *puVar8;
  uint uVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint uVar12;
  
  uVar3 = DAT_0022a740;
  if (0xffffffdf < param_1) {
    puVar2 = (undefined4 *)FUN_00135a61();
    *puVar2 = 0xc;
    return (undefined4 *)0x0;
  }
  if (param_1 + 0xb < 0x10) {
    uVar12 = 0x10;
  }
  else {
    uVar12 = param_1 + 0xb & 0xfffffff8;
  }
  if ((DAT_0022a740 & 1) == 0) {
    if (DAT_0022a740 == 0) {
      FUN_00056df0(&DAT_0022a740);
    }
LAB_0005690b:
    iVar1 = DAT_0022a76c;
    puVar4 = (uint *)(DAT_0022a76c + 4);
    uVar3 = *(uint *)(DAT_0022a76c + 4) & 0x7ffffffc;
    if (uVar3 < uVar12 + 0x10) {
      puVar2 = (undefined4 *)FUN_00056450(uVar12);
      return puVar2;
    }
    iVar6 = DAT_0022a76c + uVar12;
    DAT_0022a76c = iVar6;
    *puVar4 = uVar12 | 1;
    *(uint *)(iVar6 + 4) = uVar3 - uVar12 | 1;
    return (undefined4 *)(iVar1 + 8);
  }
  if (uVar12 <= DAT_0022a740) {
    iVar1 = (&DAT_0022a73c)[uVar12 >> 3];
    if (iVar1 != 0) {
      (&DAT_0022a73c)[uVar12 >> 3] = *(int *)(iVar1 + 8);
      return (undefined4 *)(iVar1 + 8);
    }
  }
  if (uVar12 < 0x100) {
    param_1 = uVar12 >> 3;
    puVar2 = *(undefined4 **)(&DAT_0022a778 + param_1 * 8);
    if (puVar2 != &DAT_0022a76c + param_1 * 2) {
      iVar1 = puVar2[3];
      *(uint *)((int)puVar2 + uVar12 + 4) = *(uint *)((int)puVar2 + uVar12 + 4) | 1;
      *(int *)(&DAT_0022a778 + param_1 * 8) = iVar1;
      *(int **)(iVar1 + 8) = &DAT_0022a76c + param_1 * 2;
      return puVar2 + 2;
    }
  }
  else {
    param_1 = FUN_00056260();
    if ((uVar3 & 2) != 0) {
      FUN_00056df0(&DAT_0022a740);
    }
  }
  puVar8 = DAT_0022a780;
  if (DAT_0022a780 != &DAT_0022a774) {
    do {
      uVar3 = *(uint *)(puVar8 + 4) & 0x7ffffffc;
      DAT_0022a780 = *(undefined **)(puVar8 + 0xc);
      if ((((uVar12 < 0x100) && (DAT_0022a780 == &DAT_0022a774)) && (puVar8 == DAT_0022a770)) &&
         (uVar12 + 0x10 < uVar3)) {
        puVar5 = puVar8 + uVar12;
        uVar3 = uVar3 - uVar12;
        DAT_0022a770 = puVar5;
        DAT_0022a77c = puVar5;
        DAT_0022a780 = puVar5;
        *(undefined **)(puVar5 + 8) = &DAT_0022a774;
        *(undefined **)(puVar5 + 0xc) = &DAT_0022a774;
        *(uint *)(puVar8 + 4) = uVar12 | 1;
        *(uint *)(puVar5 + 4) = uVar3 | 1;
        *(uint *)(puVar5 + uVar3) = uVar3;
        return (undefined4 *)(puVar8 + 8);
      }
      *(undefined **)(DAT_0022a780 + 8) = &DAT_0022a774;
      if (uVar3 == uVar12) {
        *(uint *)(puVar8 + uVar3 + 4) = *(uint *)(puVar8 + uVar3 + 4) | 1;
        return (undefined4 *)(puVar8 + 8);
      }
      if (uVar3 < 0x100) {
        uVar11 = uVar3 >> 3;
        puVar7 = &DAT_0022a76c + uVar11 * 2;
        puVar10 = *(undefined4 **)(&DAT_0022a774 + uVar11 * 8);
      }
      else {
        uVar11 = FUN_00056260();
        puVar10 = *(undefined4 **)(&DAT_0022a774 + uVar11 * 8);
        puVar2 = &DAT_0022a76c + uVar11 * 2;
        puVar7 = puVar2;
        if (puVar10 != puVar2) {
          puVar7 = *(undefined4 **)(&DAT_0022a778 + uVar11 * 8);
          if (uVar3 < (uint)puVar7[1]) {
            puVar10 = puVar2;
          }
          else {
            uVar9 = puVar10[1];
            while ((uVar3 | 1) < uVar9) {
              puVar10 = (undefined4 *)puVar10[2];
              uVar9 = puVar10[1];
            }
            puVar7 = (undefined4 *)puVar10[3];
          }
        }
      }
      (&DAT_0022aa74)[(int)uVar11 >> 5] =
           (&DAT_0022aa74)[(int)uVar11 >> 5] | 1 << ((byte)uVar11 & 0x1f);
      *(undefined4 **)(puVar8 + 8) = puVar10;
      *(undefined4 **)(puVar8 + 0xc) = puVar7;
      puVar10[3] = puVar8;
      puVar7[2] = puVar8;
      puVar8 = DAT_0022a780;
    } while (DAT_0022a780 != &DAT_0022a774);
  }
  if (0xff < uVar12) {
    for (puVar2 = *(undefined4 **)(&DAT_0022a778 + param_1 * 8);
        puVar2 != &DAT_0022a76c + param_1 * 2; puVar2 = (undefined4 *)puVar2[3]) {
      uVar3 = puVar2[1] & 0x7ffffffc;
      if (uVar12 <= uVar3) {
        iVar1 = puVar2[2];
        iVar6 = puVar2[3];
        uVar11 = uVar3 - uVar12;
        *(int *)(iVar1 + 0xc) = iVar6;
        *(int *)(iVar6 + 8) = iVar1;
        if (uVar11 < 0x10) {
          puVar4 = (uint *)(uVar3 + 4 + (int)puVar2);
          *puVar4 = *puVar4 | 1;
          return puVar2 + 2;
        }
        iVar1 = (int)puVar2 + uVar12;
        DAT_0022a77c = (undefined *)iVar1;
        DAT_0022a780 = (undefined *)iVar1;
        *(undefined **)(iVar1 + 8) = &DAT_0022a774;
        *(undefined **)(iVar1 + 0xc) = &DAT_0022a774;
        puVar2[1] = uVar12 | 1;
        *(uint *)(iVar1 + 4) = uVar11 | 1;
        *(uint *)(iVar1 + uVar11) = uVar11;
        return puVar2 + 2;
      }
    }
  }
  param_1 = param_1 + 1;
  puVar2 = &DAT_0022a76c + param_1 * 2;
  uVar9 = param_1 >> 5;
  uVar3 = (&DAT_0022aa74)[uVar9];
  uVar11 = 1 << ((byte)param_1 & 0x1f);
  do {
    if ((uVar3 < uVar11) || (uVar11 == 0)) {
      puVar4 = &DAT_0022aa74 + uVar9;
      do {
        uVar9 = uVar9 + 1;
        puVar4 = puVar4 + 1;
        if (2 < uVar9) goto LAB_0005690b;
        uVar3 = *puVar4;
      } while (uVar3 == 0);
      puVar2 = &DAT_0022a76c + uVar9 * 0x40;
      uVar11 = 1;
    }
    for (; (uVar3 & uVar11) == 0; uVar11 = uVar11 << 1) {
      puVar2 = puVar2 + 2;
    }
    puVar10 = (undefined4 *)puVar2[3];
    if (puVar10 != puVar2) {
      uVar3 = puVar10[1];
      iVar1 = puVar10[3];
      uVar11 = (uVar3 & 0x7ffffffc) - uVar12;
      puVar2[3] = iVar1;
      *(undefined4 **)(iVar1 + 8) = puVar2;
      if (uVar11 < 0x10) {
        puVar4 = (uint *)((uVar3 & 0x7ffffffc) + 4 + (int)puVar10);
        *puVar4 = *puVar4 | 1;
        return puVar10 + 2;
      }
      puVar8 = (undefined *)((int)puVar10 + uVar12);
      DAT_0022a77c = puVar8;
      DAT_0022a780 = puVar8;
      *(undefined **)(puVar8 + 8) = &DAT_0022a774;
      *(undefined **)(puVar8 + 0xc) = &DAT_0022a774;
      if (uVar12 < 0x100) {
        DAT_0022a770 = puVar8;
      }
      puVar10[1] = uVar12 | 1;
      *(uint *)(puVar8 + 4) = uVar11 | 1;
      *(uint *)(puVar8 + uVar11) = uVar11;
      return puVar10 + 2;
    }
    uVar3 = uVar3 & ~uVar11;
    puVar2 = puVar2 + 2;
    (&DAT_0022aa74)[uVar9] = uVar3;
    uVar11 = uVar11 << 1;
  } while( true );
}


