// func FUN_00057e90 @ 0x00057E90 (size 0x47)

undefined4 FUN_00057e90(undefined4 param_1)

{
  int iVar1;
  
  if (DAT_00241a04 == 0) {
    DAT_00241a04 = 0x1000;
  }
  if (DAT_00241a00 == 0) {
    DAT_00241a00 = 0x10000;
  }
  iVar1 = FUN_0013f8c6(param_1,0,0x8000);
  if (iVar1 == 0) {
    return 0xffffffff;
  }
  return 0;
}


