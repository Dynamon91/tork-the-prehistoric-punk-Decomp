// func FUN_00025250 @ 0x00025250 (size 0xB4)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00025250(void)

{
  uint uVar1;
  int in_EAX;
  float10 fVar2;
  float local_40;
  float local_2c;
  float local_18;
  
  if (((*(uint *)(in_EAX + 4) >> 7 & 1) == 0) || ((**(uint **)(in_EAX + 0x1c) >> 0xb & 1) == 0)) {
    if ((*(uint *)(in_EAX + 4) >> 1 & 1) == 0) {
      fVar2 = (float10)_DAT_0020df98;
    }
    else {
      FUN_0006dba0();
      if (local_2c <= local_40) {
        local_40 = local_2c;
      }
      fVar2 = (float10)local_40;
      if ((float10)local_18 <= fVar2) {
        return (float10)local_18;
      }
    }
  }
  else {
    uVar1 = (*(uint **)(in_EAX + 0x1c))[0x16];
    fVar2 = (float10)*(float *)(uVar1 + 0x9c);
    if ((float10)*(float *)(uVar1 + 0x88) < fVar2) {
      fVar2 = (float10)*(float *)(uVar1 + 0x88);
    }
    if ((float10)*(float *)(uVar1 + 0xb0) <= fVar2) {
      return (float10)*(float *)(uVar1 + 0xb0);
    }
  }
  return fVar2;
}


