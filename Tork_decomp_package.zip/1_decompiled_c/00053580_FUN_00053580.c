// func FUN_00053580 @ 0x00053580 (size 0x52)

uint FUN_00053580(undefined2 *param_1)

{
  uint in_EAX;
  uint uVar1;
  int iVar2;
  
  if ((short)in_EAX == 0) {
    return in_EAX;
  }
  uVar1 = FUN_000533e0(param_1);
  param_1[in_EAX & 0xffff] = *param_1;
  iVar2 = FUN_000533e0(param_1 + (uVar1 & 0xffff),(in_EAX - uVar1) + 1,&LAB_00053390);
  return iVar2 + uVar1;
}


