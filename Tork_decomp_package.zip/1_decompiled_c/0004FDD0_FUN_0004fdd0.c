// func FUN_0004fdd0 @ 0x0004FDD0 (size 0x39B)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_0004fdd0(byte param_1,float param_2,float param_3,float param_4,int param_5)

{
  ushort uVar1;
  int iVar2;
  int iVar3;
  float *pfVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  float10 fVar8;
  float fVar9;
  float fVar10;
  int local_4c;
  uint local_44;
  float local_3c;
  float local_38;
  float fStack_34;
  float local_30;
  float local_2c;
  float local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  undefined4 local_4;
  
  iVar2 = *(int *)(DAT_0022a6c4 + 0x14);
  if ((*(uint *)(iVar2 + 4) >> 0x1e & 1) == 0) {
    pfVar4 = *(float **)(iVar2 + 0x10);
    if ((*(uint *)(iVar2 + 4) & 2) != 0) {
      pfVar4 = pfVar4 + 0xc;
    }
    local_30 = *pfVar4;
    local_2c = pfVar4[1];
    local_28 = pfVar4[2];
    local_8 = 0;
    local_10 = 0;
    local_4 = 0;
    local_14 = 0x3f800000;
    local_3c = ((*(float **)(iVar2 + 0x28))[3] - **(float **)(iVar2 + 0x28)) * _DAT_0020df84;
    local_c = 0x3f800000;
    local_18 = 0;
    fVar9 = (*(float *)(*(int *)(iVar2 + 0x28) + 0x10) - *(float *)(*(int *)(iVar2 + 0x28) + 4)) *
            _DAT_0020df84;
    local_24 = 0;
    local_20 = 0;
    local_1c = 0x3f800000;
    fVar10 = (*(float *)(*(int *)(iVar2 + 0x28) + 0x14) - *(float *)(*(int *)(iVar2 + 0x28) + 8)) *
             _DAT_0020df84;
  }
  else {
    iVar3 = *(int *)(iVar2 + 0x28);
    local_30 = *(float *)(iVar3 + 0x60);
    local_2c = *(float *)(iVar3 + 100);
    local_28 = *(float *)(iVar3 + 0x68);
    if ((*(byte *)(iVar2 + 4) & 1) != 0) {
      pfVar4 = *(float **)(iVar2 + 0x10);
      if ((*(byte *)(iVar2 + 4) & 2) != 0) {
        pfVar4 = pfVar4 + 0xc;
      }
      local_30 = local_30 + *pfVar4;
      local_2c = local_2c + pfVar4[1];
      local_28 = local_28 + pfVar4[2];
    }
    iVar3 = *(int *)(iVar2 + 0x28);
    local_c = *(undefined4 *)(iVar3 + 0x30);
    local_8 = *(undefined4 *)(iVar3 + 0x34);
    local_4 = *(undefined4 *)(iVar3 + 0x38);
    local_18 = *(undefined4 *)(iVar3 + 0x40);
    local_14 = *(undefined4 *)(iVar3 + 0x44);
    local_10 = *(undefined4 *)(iVar3 + 0x48);
    local_24 = *(undefined4 *)(iVar3 + 0x50);
    local_20 = *(undefined4 *)(iVar3 + 0x54);
    local_1c = *(undefined4 *)(iVar3 + 0x58);
    local_3c = *(float *)(iVar3 + 0x70) * 0.5;
    fVar9 = (float)*(undefined8 *)(iVar3 + 0x74) * 0.5;
    fVar10 = (float)((ulonglong)*(undefined8 *)(iVar3 + 0x74) >> 0x20) * 0.5;
  }
  param_3 = param_3 + param_4;
  local_3c = local_3c - param_3;
  fVar9 = fVar9 - param_3;
  fVar10 = fVar10 - param_3;
  _local_38 = CONCAT44(fVar10,fVar9);
  if (((((NAN(local_3c) || NAN(_DAT_0020df5c)) ||
         local_3c < _DAT_0020df5c == (local_3c == _DAT_0020df5c)) &&
       ((NAN(fVar9) || NAN(_DAT_0020df5c)) || fVar9 < _DAT_0020df5c == (fVar9 == _DAT_0020df5c))) &&
      ((NAN(fVar10) || NAN(_DAT_0020df5c)) || fVar10 < _DAT_0020df5c == (fVar10 == _DAT_0020df5c)))
     && (uVar1 = *(ushort *)(*(int *)(iVar2 + 0x24) + 0x1e), uVar1 != 0)) {
    local_44 = (uint)uVar1;
    local_4c = 0;
    do {
      iVar3 = *(int *)(local_4c + *(int *)(*(int *)(iVar2 + 0x24) + 0x18));
      if ((((*(uint *)(iVar3 + 4) & 0x408) == 0x408) && ((*(ushort *)(iVar3 + 2) >> 0xe & 1) == 0))
         && (**(byte **)(iVar3 + 0xc) < 5)) {
        fVar8 = (float10)FUN_0004fca0(&local_18,&local_24,&local_3c,&param_4);
        fVar10 = _DAT_0020df98 - (float)(fVar8 * (float10)param_2);
        if ((param_1 & 1) != 0) {
          *(float *)(*(int *)(iVar3 + 0x14) + 0x4c) = fVar10;
        }
        if ((param_1 & 2) != 0) {
          FUN_000257c0(fVar10);
        }
        if ((param_5 != 0) && ((param_1 & 4) != 0)) {
          uVar5 = FUN_00140e74();
          uVar6 = FUN_00140e74();
          uVar7 = FUN_00140e74();
          *(uint *)(*(int *)(iVar3 + 0x14) + 0x20) =
               ((uVar5 & 0xff | 0xffffff00) << 8 | uVar6 & 0xff) << 8 | uVar7 & 0xff;
        }
      }
      local_4c = local_4c + 4;
      local_44 = local_44 - 1;
    } while (local_44 != 0);
  }
  return;
}


