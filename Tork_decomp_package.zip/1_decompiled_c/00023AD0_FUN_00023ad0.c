// func FUN_00023ad0 @ 0x00023AD0 (size 0x63)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00023ad0(void)

{
  float *in_ECX;
  
  if (ABS(*in_ECX) < _DAT_0020e0e0) {
    if (ABS(in_ECX[1]) < _DAT_0020e0e0) {
      if (ABS(in_ECX[2]) < _DAT_0020e0e0) {
        return 1;
      }
    }
  }
  return 0;
}


