// func FUN_0005b940 @ 0x0005B940 (size 0x4F)

void FUN_0005b940(void)

{
  ushort uVar1;
  ushort in_AX;
  ushort uVar2;
  undefined4 uVar3;
  undefined4 *unaff_EBX;
  
  uVar2 = *(ushort *)(unaff_EBX + 1);
  if (uVar2 < in_AX) {
    uVar1 = uVar2 * 2;
    if (uVar2 == 0) {
      uVar1 = in_AX;
    }
    for (; uVar1 < in_AX; uVar1 = uVar1 << 1) {
    }
    uVar3 = FUN_00058070();
    *unaff_EBX = uVar3;
    *(ushort *)(unaff_EBX + 1) = uVar1;
    uVar2 = *(ushort *)((int)unaff_EBX + 6);
    if (uVar1 <= *(ushort *)((int)unaff_EBX + 6)) {
      uVar2 = uVar1;
    }
    *(ushort *)((int)unaff_EBX + 6) = uVar2;
  }
  return;
}


