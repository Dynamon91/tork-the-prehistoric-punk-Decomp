// func FUN_0005a730 @ 0x0005A730 (size 0x16A)

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined4 FUN_0005a730(void)

{
  ushort uVar1;
  ushort uVar2;
  ushort uVar3;
  int iVar4;
  int iVar5;
  int *unaff_EBX;
  ushort local_40c [2];
  int local_408;
  char local_404 [1024];
  undefined4 local_4;
  
  local_4 = DAT_002264b0;
  iVar4 = FID_conflict___open();
  *unaff_EBX = iVar4;
  if (iVar4 == -1) {
    _sprintf(local_404,s_BGL__s_not_found_0020865c);
    return 0;
  }
  __read(iVar4,local_40c,2);
  uVar2 = local_40c[0];
  unaff_EBX[1] = 0;
  *(undefined2 *)(unaff_EBX + 2) = 0;
  *(undefined2 *)((int)unaff_EBX + 10) = 0;
  if (uVar2 != 0) {
    iVar4 = FUN_00058070();
    unaff_EBX[1] = iVar4;
    *(ushort *)(unaff_EBX + 2) = uVar2;
    uVar3 = *(ushort *)((int)unaff_EBX + 10);
    if (uVar2 <= *(ushort *)((int)unaff_EBX + 10)) {
      uVar3 = uVar2;
    }
    *(ushort *)((int)unaff_EBX + 10) = uVar3;
  }
  local_408 = 0;
  if (local_40c[0] != 0) {
    do {
      iVar4 = FUN_00057f60(0x48);
      *(undefined2 *)(iVar4 + 2) = 0xffff;
      *(undefined4 *)(iVar4 + 4) = 0;
      *(undefined2 *)(iVar4 + 8) = 0;
      *(undefined2 *)(iVar4 + 10) = 0;
      FUN_0005ae80(*unaff_EBX);
      uVar2 = *(ushort *)(unaff_EBX + 2);
      uVar3 = *(short *)((int)unaff_EBX + 10) + 1;
      if (uVar2 < uVar3) {
        uVar1 = uVar2 * 2;
        if (uVar2 == 0) {
          uVar1 = uVar3;
        }
        for (; uVar1 < uVar3; uVar1 = uVar1 << 1) {
        }
        iVar5 = FUN_00058070();
        unaff_EBX[1] = iVar5;
        *(ushort *)(unaff_EBX + 2) = uVar1;
        uVar2 = *(ushort *)((int)unaff_EBX + 10);
        if (uVar1 <= *(ushort *)((int)unaff_EBX + 10)) {
          uVar2 = uVar1;
        }
        *(ushort *)((int)unaff_EBX + 10) = uVar2;
      }
      *(int *)(unaff_EBX[1] + (uint)*(ushort *)((int)unaff_EBX + 10) * 4) = iVar4;
      *(short *)((int)unaff_EBX + 10) = *(short *)((int)unaff_EBX + 10) + 1;
      local_408 = local_408 + 1;
    } while ((ushort)local_408 < local_40c[0]);
  }
  return 1;
}


