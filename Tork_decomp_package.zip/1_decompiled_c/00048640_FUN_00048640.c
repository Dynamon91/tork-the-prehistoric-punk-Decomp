// func FUN_00048640 @ 0x00048640 (size 0x6C)

int FUN_00048640(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  char *unaff_EBX;
  ushort uVar4;
  int iVar5;
  
  if (*unaff_EBX == '\0') {
    return 0;
  }
  iVar1 = *(int *)(unaff_EBX + 4);
  iVar2 = 0;
  uVar3 = 0;
  if (*(ushort *)(iVar1 + 10) != 0) {
    do {
      if ((int)uVar3 < (int)(uint)*(ushort *)(iVar1 + 10)) {
        uVar4 = *(ushort *)(*(int *)(*(int *)(iVar1 + 4) + (uVar3 & 0xffff) * 4) + 2);
      }
      else {
        uVar4 = 0xffff;
      }
      if (*(int *)(unaff_EBX + (int)(&DAT_0000180c + (uint)uVar4 * 0x10)) == -1) {
        if ((int)uVar3 < (int)(uint)*(ushort *)(iVar1 + 10)) {
          iVar5 = *(int *)(*(int *)(iVar1 + 4) + (uVar3 & 0xffff) * 4);
        }
        else {
          iVar5 = 0;
        }
        iVar2 = iVar2 + (uint)*(ushort *)(iVar5 + 10);
      }
      uVar3 = uVar3 + 1;
    } while ((int)uVar3 < (int)(uint)*(ushort *)(iVar1 + 10));
  }
  return iVar2;
}


