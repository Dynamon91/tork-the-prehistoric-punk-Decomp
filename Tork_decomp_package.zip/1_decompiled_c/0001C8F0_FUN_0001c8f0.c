// func FUN_0001c8f0 @ 0x0001C8F0 (size 0x35)

void FUN_0001c8f0(undefined4 *param_1)

{
  int iVar1;
  int in_ECX;
  uint uVar2;
  uint in_EDX;
  undefined4 *puVar3;
  
  iVar1 = *(int *)(in_ECX + 0xc + *(int *)(&DAT_0000281c + in_ECX) * 0x18);
  puVar3 = *(undefined4 **)(iVar1 + 0x28);
  for (uVar2 = in_EDX >> 2; uVar2 != 0; uVar2 = uVar2 - 1) {
    *param_1 = *puVar3;
    puVar3 = puVar3 + 1;
    param_1 = param_1 + 1;
  }
  for (uVar2 = in_EDX & 3; uVar2 != 0; uVar2 = uVar2 - 1) {
    *(undefined1 *)param_1 = *(undefined1 *)puVar3;
    puVar3 = (undefined4 *)((int)puVar3 + 1);
    param_1 = (undefined4 *)((int)param_1 + 1);
  }
  *(uint *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + in_EDX;
  return;
}


