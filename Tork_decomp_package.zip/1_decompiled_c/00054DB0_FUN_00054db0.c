// func FUN_00054db0 @ 0x00054DB0 (size 0x25)

void FUN_00054db0(void)

{
  int in_EAX;
  undefined4 *in_ECX;
  uint uVar1;
  int iVar2;
  undefined4 *in_EDX;
  
  if ((in_EDX != (undefined4 *)0x0) && (in_ECX != (undefined4 *)0x0)) {
    for (uVar1 = (uint)(in_EAX * 0xc) >> 2; uVar1 != 0; uVar1 = uVar1 - 1) {
      *in_EDX = *in_ECX;
      in_ECX = in_ECX + 1;
      in_EDX = in_EDX + 1;
    }
    for (iVar2 = 0; iVar2 != 0; iVar2 = iVar2 + -1) {
      *(undefined1 *)in_EDX = *(undefined1 *)in_ECX;
      in_ECX = (undefined4 *)((int)in_ECX + 1);
      in_EDX = (undefined4 *)((int)in_EDX + 1);
    }
  }
  return;
}


