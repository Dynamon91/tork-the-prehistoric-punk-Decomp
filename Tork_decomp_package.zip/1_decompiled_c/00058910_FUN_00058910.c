// func FUN_00058910 @ 0x00058910 (size 0x62)

int FUN_00058910(void)

{
  uint uVar1;
  int in_EAX;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  uVar5 = in_EAX - 8;
  iVar2 = -1;
  iVar4 = DAT_00241210;
  if (DAT_00241210 != 0) {
    do {
      iVar3 = iVar4 + iVar2 >> 1;
      if (*(uint *)(DAT_00241208 + iVar3 * 4) <= uVar5) {
        iVar2 = iVar3;
        iVar3 = iVar4;
      }
      iVar4 = iVar3;
    } while (iVar3 != iVar2 + 1);
    if (-1 < iVar2) {
      uVar1 = *(uint *)(DAT_00241208 + iVar2 * 4);
      if (uVar5 == uVar1) {
        return iVar2;
      }
      if ((uVar1 < uVar5) &&
         (uVar5 < (*(uint *)(*(int *)(DAT_0024120c + iVar2 * 4) + 4) & 0x3ffffffc) + uVar1)) {
        return iVar2;
      }
    }
  }
  return -1;
}


