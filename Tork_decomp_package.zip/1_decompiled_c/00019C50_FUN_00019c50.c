// func FUN_00019c50 @ 0x00019C50 (size 0xE1)

void FUN_00019c50(int param_1,undefined4 param_2,int param_3)

{
  int in_ECX;
  int unaff_EBX;
  int unaff_ESI;
  int unaff_EDI;
  
  if (unaff_EBX != 0) {
    *(int *)(param_1 + 0x214) = param_3;
    *(undefined1 *)(param_1 + 0x200) = 6;
    *(int *)(param_1 + 0x208) = in_ECX;
    *(int *)(param_1 + 0x20c) = unaff_ESI;
    *(int *)(param_1 + 0x210) = unaff_EDI;
    *(int *)(param_1 + 0x218) = unaff_EBX;
    *(undefined4 *)(param_1 + 0x204) = param_2;
    return;
  }
  if (param_3 != 0) {
    *(int *)(param_1 + 0x214) = param_3;
    *(undefined1 *)(param_1 + 0x200) = 5;
    *(int *)(param_1 + 0x208) = in_ECX;
    *(int *)(param_1 + 0x20c) = unaff_ESI;
    *(int *)(param_1 + 0x210) = unaff_EDI;
    *(undefined4 *)(param_1 + 0x204) = param_2;
    return;
  }
  if (unaff_EDI != 0) {
    *(undefined1 *)(param_1 + 0x200) = 4;
    *(int *)(param_1 + 0x208) = in_ECX;
    *(int *)(param_1 + 0x20c) = unaff_ESI;
    *(int *)(param_1 + 0x210) = unaff_EDI;
    *(undefined4 *)(param_1 + 0x204) = param_2;
    return;
  }
  if (unaff_ESI != 0) {
    *(undefined1 *)(param_1 + 0x200) = 3;
    *(int *)(param_1 + 0x208) = in_ECX;
    *(int *)(param_1 + 0x20c) = unaff_ESI;
    *(undefined4 *)(param_1 + 0x204) = param_2;
    return;
  }
  if (in_ECX == 0) {
    *(undefined1 *)(param_1 + 0x200) = 1;
    *(undefined4 *)(param_1 + 0x204) = param_2;
    return;
  }
  *(undefined1 *)(param_1 + 0x200) = 2;
  *(int *)(param_1 + 0x208) = in_ECX;
  *(undefined4 *)(param_1 + 0x204) = param_2;
  return;
}


