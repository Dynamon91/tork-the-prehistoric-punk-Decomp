// func FUN_00023e60 @ 0x00023E60 (size 0x5A)

undefined4 FUN_00023e60(float param_1)

{
  float10 fVar1;
  float *in_EAX;
  float *in_ECX;
  float10 fVar2;
  
  fVar2 = (float10)FUN_00023f10(in_ECX[1] * in_EAX[2] - in_EAX[1] * in_ECX[2],
                                *in_EAX * in_ECX[2] - *in_ECX * in_EAX[2],
                                in_EAX[1] * *in_ECX - *in_EAX * in_ECX[1]);
  fVar1 = (float10)param_1;
  if ((NAN(fVar2) || NAN(fVar1)) || fVar2 < fVar1 == (fVar2 == fVar1)) {
    return 0;
  }
  return 1;
}


