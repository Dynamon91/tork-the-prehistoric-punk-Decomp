// func FUN_0001b330 @ 0x0001B330 (size 0x55)

byte FUN_0001b330(void)

{
  byte bVar1;
  uint uVar2;
  short *in_ECX;
  byte bVar3;
  int *piVar4;
  int iVar5;
  
  *(byte *)((int)in_ECX + 0x25) = *(byte *)((int)in_ECX + 0x25) | 0x40;
  iVar5 = 0;
  bVar3 = 1;
  if (0 < in_ECX[0x13]) {
    piVar4 = (int *)(in_ECX + 0x14);
    do {
      if (*piVar4 != 0) {
        uVar2 = (uint)*(short *)(*piVar4 + 0x24);
        if (((uVar2 >> 0xd & 1) != 0) && (*in_ECX != 0)) {
          bVar3 = 0;
        }
        if ((uVar2 >> 0xe & 1) == 0) {
          bVar1 = FUN_0001b330();
          bVar3 = bVar3 & bVar1;
        }
      }
      iVar5 = iVar5 + 1;
      piVar4 = piVar4 + 1;
    } while (iVar5 < in_ECX[0x13]);
  }
  return bVar3;
}


