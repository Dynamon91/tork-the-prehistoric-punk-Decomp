// func FUN_0001b230 @ 0x0001B230 (size 0x6C)

void FUN_0001b230(void)

{
  int in_ECX;
  int iVar1;
  int *piVar2;
  
  *(byte *)(in_ECX + 0x25) = *(byte *)(in_ECX + 0x25) | 0x40;
  iVar1 = 0;
  if (0 < *(short *)(in_ECX + 0x26)) {
    piVar2 = (int *)(in_ECX + 0x28);
    do {
      if (*piVar2 != 0) {
        if ((*(ushort *)(*piVar2 + 0x24) >> 0xe & 1) == 0) {
          FUN_0001b230();
        }
        if (((*(ushort *)(*piVar2 + 0x24) >> 0xd & 1) != 0) &&
           ((*(ushort *)(in_ECX + 0x24) >> 0xd & 1) == 0)) {
          *(ushort *)(in_ECX + 0x24) = *(ushort *)(in_ECX + 0x24) | 0x2000;
          DAT_0022a6cc = 1;
        }
      }
      iVar1 = iVar1 + 1;
      piVar2 = piVar2 + 1;
    } while (iVar1 < *(short *)(in_ECX + 0x26));
  }
  return;
}


