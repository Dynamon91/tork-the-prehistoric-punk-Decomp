// func FUN_00053670 @ 0x00053670 (size 0xBD)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00053670(float *param_1,float *param_2,float *param_3,float param_4)

{
  undefined8 uVar1;
  float fVar2;
  
  fVar2 = SQRT(*param_2 * *param_2 + param_2[1] * param_2[1]);
  if ((uint)param_4 <= (uint)ABS(fVar2)) {
    fVar2 = _DAT_0020df98 / fVar2;
    uVar1 = *(undefined8 *)(param_2 + 1);
    *param_1 = fVar2 * *param_2;
    *(ulonglong *)(param_1 + 1) =
         CONCAT44(fVar2 * (float)((ulonglong)uVar1 >> 0x20),fVar2 * (float)uVar1);
    param_1[2] = 0.0;
    return;
  }
  if (param_3 == (float *)0x0) {
    *param_1 = 1.0;
    param_1[1] = 0.0;
    param_1[2] = 0.0;
    return;
  }
  *param_1 = *param_3;
  param_1[1] = param_3[1];
  param_1[2] = param_3[2];
  return;
}


