// func FUN_00011b20 @ 0x00011B20 (size 0xFA)

void FUN_00011b20(void)

{
  int iVar1;
  undefined4 extraout_EDX;
  undefined4 extraout_EDX_00;
  undefined4 *puVar2;
  
  DAT_0022a6c4 = FUN_00011f80();
  FUN_00057f60(&DAT_00004128);
  FUN_00018800();
  DAT_002411d4 = extraout_EDX;
  DAT_002411d8 = FUN_00018970();
  FUN_00057f60(&DAT_00006838);
  FUN_00019970();
  DAT_0022a6c8 = extraout_EDX_00;
  DAT_002411dc = (undefined4 *)FUN_00057f60(&DAT_00004800);
  puVar2 = DAT_002411dc;
  for (iVar1 = 0x1000; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar2 = 0;
    puVar2 = puVar2 + 1;
  }
  puVar2 = DAT_002411dc + 0x1000;
  for (iVar1 = 0x200; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar2 = 0;
    puVar2 = puVar2 + 1;
  }
  FUN_000612c0(DAT_0022d4c8,&LAB_0001b410);
  FUN_000612c0(DAT_0022d4c8,&LAB_0001b770);
  FUN_000612c0(DAT_0022d4c8,&LAB_0001b770);
  FUN_000612c0(DAT_0022d4c8,&LAB_0001c850);
  FUN_000612c0(DAT_0022d4c8,&LAB_0001caf0);
  FUN_000612c0(DAT_0022d4c8,&LAB_0001caf0);
  return;
}


