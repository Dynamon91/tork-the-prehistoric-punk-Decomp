// func FUN_00019830 @ 0x00019830 (size 0x58)

void FUN_00019830(undefined4 param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  
  iVar2 = (int)(param_2 + 0x1f + (param_2 + 0x1f >> 0x1f & 0x1fU)) >> 5;
  iVar1 = FUN_000550b0();
  if (iVar2 < iVar1) {
    FUN_00019750();
  }
  else if (iVar1 < iVar2) {
    FUN_00019750();
    FUN_000196d0(param_3);
    return;
  }
  return;
}


