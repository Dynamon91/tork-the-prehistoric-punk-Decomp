// func FUN_0005bb10 @ 0x0005BB10 (size 0xCA)

void FUN_0005bb10(void)

{
  undefined4 *puVar1;
  ushort uVar2;
  int unaff_ESI;
  undefined4 *unaff_EDI;
  
  FUN_0012ebe2(*(undefined4 *)(unaff_ESI + 0x18),0xffffffff);
  if (*(short *)(unaff_ESI + 0xaa) == 0) {
    uVar2 = *(ushort *)(unaff_ESI + 0xa2);
    FUN_000607b0();
    *(short *)(unaff_ESI + 0xa2) = *(short *)(unaff_ESI + 0xa2) + 1;
  }
  else {
    uVar2 = *(ushort *)(*(int *)(unaff_ESI + 0xa4) + -2 + (uint)*(ushort *)(unaff_ESI + 0xaa) * 2);
    *(short *)(unaff_ESI + 0xaa) = *(short *)(unaff_ESI + 0xaa) + -1;
  }
  puVar1 = (undefined4 *)(*(int *)(unaff_ESI + 0x9c) + (uint)uVar2 * 0x18);
  *puVar1 = *unaff_EDI;
  puVar1[1] = unaff_EDI[1];
  puVar1[2] = unaff_EDI[2];
  puVar1[3] = unaff_EDI[3];
  puVar1[4] = unaff_EDI[4];
  puVar1[5] = unaff_EDI[5];
  FUN_000601d0();
  *(int *)(unaff_ESI + 0x34) = *(int *)(unaff_ESI + 0x34) + 1;
  if (*(int *)(unaff_ESI + 0x34) == 1) {
    FUN_0012e756(*(undefined4 *)(unaff_ESI + 0x1c));
  }
  FUN_0012e945(*(undefined4 *)(unaff_ESI + 0x18));
  return;
}


