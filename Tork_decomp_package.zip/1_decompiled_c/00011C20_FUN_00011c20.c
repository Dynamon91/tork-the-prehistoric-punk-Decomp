// func FUN_00011c20 @ 0x00011C20 (size 0x52)

void FUN_00011c20(void)

{
  undefined4 *puVar1;
  
  FUN_00058010();
  FUN_00058010();
  FUN_00058010();
  FUN_00058010();
  puVar1 = DAT_0022a6c4;
  FUN_00058010();
  puVar1[2] = 0;
  puVar1[1] = 0;
  *puVar1 = 0;
  puVar1[0xf] = 0;
  FUN_00058010();
  return;
}


