// func FUN_000187b0 @ 0x000187B0 (size 0x41)

void FUN_000187b0(uint param_1)

{
  uint *in_EAX;
  int in_ECX;
  uint uVar1;
  
  uVar1 = *in_EAX;
  if (uVar1 != in_EAX[1]) {
    do {
      if (((short)in_EAX[uVar1 * 4 + 4] != -1) && (in_EAX[uVar1 * 4 + 2] == param_1)) {
        in_EAX = (uint *)FUN_00018850();
        in_ECX = in_ECX + -1;
        if (in_ECX == 0) {
          return;
        }
      }
      uVar1 = uVar1 + 1 & 0x1ff;
    } while (uVar1 != in_EAX[1]);
  }
  return;
}


