// func FUN_0005ae80 @ 0x0005AE80 (size 0x14C)

void FUN_0005ae80(uint param_1)

{
  undefined4 *puVar1;
  ushort uVar2;
  uint uVar3;
  ushort uVar4;
  short sVar5;
  ushort uVar6;
  undefined4 uVar7;
  int unaff_EDI;
  uint local_14;
  int local_10;
  undefined4 local_c;
  undefined4 local_8;
  undefined4 local_4;
  
  uVar3 = param_1;
  if (param_1 != 0xffffffff) {
    __read(param_1,&param_1,2);
    __read(uVar3,unaff_EDI + 0xc,param_1 & 0xffff);
    __read(uVar3);
    __read(uVar3,unaff_EDI + 2,2);
    __read(uVar3,&local_14,2);
    uVar4 = (ushort)local_14;
    *(undefined4 *)(unaff_EDI + 4) = 0;
    *(undefined2 *)(unaff_EDI + 8) = 0;
    *(undefined2 *)(unaff_EDI + 10) = 0;
    sVar5 = 0;
    if (uVar4 != 0) {
      uVar7 = FUN_00058070();
      *(undefined4 *)(unaff_EDI + 4) = uVar7;
      *(ushort *)(unaff_EDI + 8) = uVar4;
      uVar6 = *(ushort *)(unaff_EDI + 10);
      if (uVar4 <= *(ushort *)(unaff_EDI + 10)) {
        uVar6 = uVar4;
      }
      *(ushort *)(unaff_EDI + 10) = uVar6;
      sVar5 = (short)local_14;
    }
    local_10 = 0;
    if (sVar5 != 0) {
      do {
        __read(uVar3,&local_c,0xc);
        uVar4 = *(ushort *)(unaff_EDI + 8);
        uVar6 = *(short *)(unaff_EDI + 10) + 1;
        if (uVar4 < uVar6) {
          uVar2 = uVar4 * 2;
          if (uVar4 == 0) {
            uVar2 = uVar6;
          }
          for (; uVar2 < uVar6; uVar2 = uVar2 << 1) {
          }
          uVar7 = FUN_00058070();
          *(undefined4 *)(unaff_EDI + 4) = uVar7;
          *(ushort *)(unaff_EDI + 8) = uVar2;
          uVar4 = *(ushort *)(unaff_EDI + 10);
          if (uVar2 <= *(ushort *)(unaff_EDI + 10)) {
            uVar4 = uVar2;
          }
          *(ushort *)(unaff_EDI + 10) = uVar4;
        }
        puVar1 = (undefined4 *)(*(int *)(unaff_EDI + 4) + (uint)*(ushort *)(unaff_EDI + 10) * 0xc);
        *puVar1 = local_c;
        puVar1[1] = local_8;
        puVar1[2] = local_4;
        *(short *)(unaff_EDI + 10) = *(short *)(unaff_EDI + 10) + 1;
        local_10 = local_10 + 1;
      } while (local_10 < (int)(local_14 & 0xffff));
    }
  }
  return;
}


