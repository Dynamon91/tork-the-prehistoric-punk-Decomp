// func FUN_00046960 @ 0x00046960 (size 0x5E)

void FUN_00046960(byte param_1)

{
  byte *pbVar1;
  byte bVar2;
  int iVar3;
  undefined1 uVar4;
  uint uVar5;
  int unaff_EDI;
  
  uVar5 = (uint)param_1;
  uVar4 = FUN_00140e74();
  *(undefined1 *)(*(int *)(*(int *)(unaff_EDI + 0x10) + 0xc) + 1 + uVar5 * 4) = uVar4;
  iVar3 = *(int *)(*(int *)(unaff_EDI + 0x10) + 0xc);
  pbVar1 = (byte *)(iVar3 + uVar5 * 4);
  *(ushort *)(pbVar1 + 2) = (ushort)*(byte *)(iVar3 + 1 + uVar5 * 4) * (ushort)*pbVar1;
  bVar2 = *(byte *)(*(int *)(*(int *)(unaff_EDI + 4) + 0x10 + uVar5 * 4) + 0x34);
  if (bVar2 != 0xff) {
    iVar3 = *(int *)(*(int *)(unaff_EDI + 0x10) + 0xc);
    *(undefined2 *)(iVar3 + 2 + (uint)bVar2 * 4) = *(undefined2 *)(iVar3 + 2 + uVar5 * 4);
  }
  return;
}


