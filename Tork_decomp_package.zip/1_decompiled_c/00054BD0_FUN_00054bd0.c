// func FUN_00054bd0 @ 0x00054BD0 (size 0x98)

int FUN_00054bd0(void)

{
  float *pfVar1;
  int in_EAX;
  int iVar2;
  float *pfVar3;
  float *unaff_EBX;
  float *unaff_EDI;
  
  if (unaff_EBX != (float *)0x0) {
    pfVar1 = unaff_EBX + in_EAX;
    iVar2 = (int)pfVar1 + (3 - (int)unaff_EBX);
    pfVar3 = unaff_EBX;
    if (3 < (int)(iVar2 + (iVar2 >> 0x1f & 3U)) >> 2) {
      do {
        if (*pfVar3 == *unaff_EDI) goto LAB_00054c5b;
        if (pfVar3[1] == *unaff_EDI) {
          pfVar3 = pfVar3 + 1;
          goto LAB_00054c5b;
        }
        if (pfVar3[2] == *unaff_EDI) {
          pfVar3 = pfVar3 + 2;
          goto LAB_00054c5b;
        }
        if (pfVar3[3] == *unaff_EDI) {
          pfVar3 = pfVar3 + 3;
          goto LAB_00054c5b;
        }
        pfVar3 = pfVar3 + 4;
      } while ((int)pfVar3 < (int)(pfVar1 + -3));
    }
    for (; pfVar3 < pfVar1; pfVar3 = pfVar3 + 1) {
      if (*pfVar3 == *unaff_EDI) {
LAB_00054c5b:
        if (pfVar3 < pfVar1) {
          return (int)pfVar3 - (int)unaff_EBX >> 2;
        }
        return -1;
      }
    }
  }
  return -1;
}


