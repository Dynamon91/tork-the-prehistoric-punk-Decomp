// func FUN_00043920 @ 0x00043920 (size 0x2F)

uint FUN_00043920(void)

{
  uint uVar1;
  int in_ECX;
  
  if ((((*(uint *)(in_ECX + 4) >> 8 & 1) == 0) || ((*(uint *)(in_ECX + 4) >> 0x16 & 1) == 0)) ||
     (uVar1 = *(uint *)(*(int *)(in_ECX + 0x24) + 8), uVar1 == 0)) {
    return 0;
  }
  return uVar1 & (*(short *)(uVar1 + 2) != 1) - 1;
}


