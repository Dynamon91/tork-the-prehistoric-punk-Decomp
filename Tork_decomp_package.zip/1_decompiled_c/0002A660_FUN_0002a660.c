// func FUN_0002a660 @ 0x0002A660 (size 0x66)

void FUN_0002a660(void)

{
  int iVar1;
  int in_EAX;
  int *unaff_EDI;
  
  *unaff_EDI = in_EAX;
  unaff_EDI[1] = *(int *)(in_EAX + 0x20);
  unaff_EDI[2] = 0;
  unaff_EDI[3] = 0;
  unaff_EDI[4] = 0;
  unaff_EDI[5] = 0;
  if ((*(uint *)(in_EAX + 4) >> 3 & 1) != 0) {
    iVar1 = *(int *)(in_EAX + 0x14);
    unaff_EDI[2] = iVar1;
    iVar1 = *(int *)(*(int *)(iVar1 + 4) + 4);
    unaff_EDI[3] = iVar1;
    if (iVar1 != 0) {
      FUN_00093ec0();
      unaff_EDI[4] = *(int *)(*(int *)(unaff_EDI[2] + 0x10) + 4);
      unaff_EDI[5] = unaff_EDI[3] + 0x194;
    }
  }
  FUN_0002a5a0();
  return;
}


