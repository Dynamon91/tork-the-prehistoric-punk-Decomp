// func FUN_0002c660 @ 0x0002C660 (size 0x1C2)

int FUN_0002c660(uint param_1)

{
  int iVar1;
  int iVar2;
  byte bVar3;
  char cVar4;
  
  iVar1 = *(int *)(DAT_0022a6c4 + 0x14);
  do {
    do {
      iVar2 = *(int *)(*(int *)(DAT_0022a6c4 + 0x14) + 0x24);
      if (*(ushort *)(iVar2 + 0x1e) <= DAT_002411ec) {
        return 0;
      }
      iVar2 = *(int *)(*(int *)(iVar2 + 0x18) + (uint)DAT_002411ec * 4);
      DAT_002411ec = DAT_002411ec + 1;
      if (iVar2 == 0) {
        return 0;
      }
    } while ((param_1 & *(uint *)(iVar2 + 4)) == 0);
    bVar3 = (byte)(*(uint *)(iVar2 + 4) >> 0x1e);
    if (((byte)((uint)*(undefined4 *)(iVar1 + 4) >> 0x1e) & 1) == 0) {
      if ((bVar3 & 1) == 0) {
        return iVar2;
      }
      FUN_000479c0();
LAB_0002c810:
      cVar4 = FUN_00070600();
    }
    else {
      if ((bVar3 & 1) == 0) goto LAB_0002c810;
      FUN_000479c0();
      cVar4 = FUN_00070480();
    }
    if (cVar4 != '\0') {
      return iVar2;
    }
  } while( true );
}


