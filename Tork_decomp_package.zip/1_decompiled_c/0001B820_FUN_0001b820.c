// func FUN_0001b820 @ 0x0001B820 (size 0xBB)

void FUN_0001b820(int param_1)

{
  ushort uVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  ushort *puVar5;
  
  puVar5 = (ushort *)(param_1 + (uint)*(ushort *)(param_1 + 2) * 4);
  uVar1 = *puVar5;
  while (uVar1 != 0xffff) {
    iVar2 = *(int *)(DAT_0022d4c0 + 0xc + *(int *)(&DAT_0000281c + DAT_0022d4c0) * 0x18);
    puVar3 = *(uint **)(iVar2 + 0x2c);
    uVar4 = *puVar3;
    *(uint **)(iVar2 + 0x2c) = puVar3 + 1;
    iVar2 = DAT_0022d4c0 + (uVar4 >> 0x17) * 0x18;
    if ((*(int *)(iVar2 + 0xc) == 0) || (*(uint *)(iVar2 + 0x10) < 2)) {
      FUN_0005fe30(DAT_0022d4c0,uVar4);
    }
    FUN_000112c0(uVar4,0,param_1 + (uint)uVar1 * 4);
    puVar5 = puVar5 + 1;
    uVar1 = *puVar5;
  }
  return;
}


