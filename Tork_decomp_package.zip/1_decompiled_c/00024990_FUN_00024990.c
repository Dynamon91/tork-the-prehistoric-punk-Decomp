// func FUN_00024990 @ 0x00024990 (size 0x50)

void FUN_00024990(void)

{
  float *in_EAX;
  float *in_ECX;
  float *in_EDX;
  
  *in_EDX = *in_EAX * *in_ECX + in_EAX[4] * in_ECX[1] + in_EAX[8] * in_ECX[2] + in_EAX[0xc];
  in_EDX[1] = in_EAX[5] * in_ECX[1] + in_EAX[1] * *in_ECX + in_EAX[9] * in_ECX[2] + in_EAX[0xd];
  in_EDX[2] = in_EAX[6] * in_ECX[1] + in_EAX[2] * *in_ECX + in_EAX[10] * in_ECX[2] + in_EAX[0xe];
  return;
}


