// func FUN_000284a0 @ 0x000284A0 (size 0x47)

void FUN_000284a0(void)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float *in_EAX;
  float *in_ECX;
  
  fVar1 = *in_ECX;
  fVar2 = in_ECX[1];
  fVar3 = in_ECX[2];
  *in_ECX = fVar1 * *in_EAX + fVar2 * in_EAX[4] + fVar3 * in_EAX[8];
  in_ECX[1] = fVar1 * in_EAX[1] + fVar2 * in_EAX[5] + fVar3 * in_EAX[9];
  in_ECX[2] = fVar1 * in_EAX[2] + fVar2 * in_EAX[6] + fVar3 * in_EAX[10];
  return;
}


