// func FUN_000263c0 @ 0x000263C0 (size 0x7A)

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined4
FUN_000263c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  undefined4 local_6c;
  undefined1 local_68 [100];
  undefined4 local_4;
  
  local_4 = DAT_002264b0;
  local_6c = 0;
  uVar1 = __itoa(param_1,local_68,10,param_2,param_3,param_4,param_5,param_6,0,0,0,0);
  FUN_000e8eb0(&local_6c,uVar1);
  return local_6c;
}


