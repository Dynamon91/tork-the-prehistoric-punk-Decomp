// func FUN_0001a820 @ 0x0001A820 (size 0x19)

float10 FUN_0001a820(float param_1,float param_2)

{
  if (param_1 < param_2) {
    return (float10)param_1;
  }
  return (float10)param_2;
}


