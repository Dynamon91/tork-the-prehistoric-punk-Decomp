// func FUN_0001ced0 @ 0x0001CED0 (size 0xAC)

int * FUN_0001ced0(int param_1)

{
  int iVar1;
  int *in_EAX;
  int *piVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  ushort *puVar7;
  undefined4 *puVar8;
  int local_c;
  
  iVar1 = *in_EAX;
  piVar2 = (int *)FUN_00057f60(iVar1 * 8 + 4);
  *piVar2 = iVar1;
  local_c = *in_EAX;
  puVar7 = (ushort *)(in_EAX + 1);
  if (local_c != 0) {
    puVar6 = (undefined4 *)((int)piVar2 + (4 - (int)in_EAX) + (int)puVar7);
    do {
      *(ushort *)(puVar6 + -1) = *puVar7;
      *(ushort *)((int)puVar6 + -2) = puVar7[1];
      uVar5 = *(uint *)(param_1 + 0xc + (uint)*puVar7 * 0x14);
      if (uVar5 < 5) {
        *puVar6 = *(undefined4 *)(((int)in_EAX - (int)piVar2) + (int)puVar6);
      }
      else {
        puVar3 = (undefined4 *)FUN_00057f60(uVar5);
        *puVar6 = puVar3;
        puVar8 = *(undefined4 **)(((int)in_EAX - (int)piVar2) + (int)puVar6);
        for (uVar4 = uVar5 >> 2; uVar4 != 0; uVar4 = uVar4 - 1) {
          *puVar3 = *puVar8;
          puVar8 = puVar8 + 1;
          puVar3 = puVar3 + 1;
        }
        for (uVar5 = uVar5 & 3; uVar5 != 0; uVar5 = uVar5 - 1) {
          *(undefined1 *)puVar3 = *(undefined1 *)puVar8;
          puVar8 = (undefined4 *)((int)puVar8 + 1);
          puVar3 = (undefined4 *)((int)puVar3 + 1);
        }
      }
      puVar7 = puVar7 + 4;
      puVar6 = puVar6 + 2;
      local_c = local_c + -1;
    } while (local_c != 0);
  }
  return piVar2;
}


