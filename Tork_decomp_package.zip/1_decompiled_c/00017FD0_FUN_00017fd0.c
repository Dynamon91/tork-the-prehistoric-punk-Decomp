// func FUN_00017fd0 @ 0x00017FD0 (size 0x58)

void FUN_00017fd0(void)

{
  char in_AL;
  char cVar1;
  int in_ECX;
  
  if (in_AL != '\0') {
    FUN_00017f40();
  }
  if ((*(short *)(*(int *)(in_ECX + 0xc) + 0x6e + (uint)*(byte *)(in_ECX + 0x18) * 8) != -1) &&
     (cVar1 = FUN_00018110(), cVar1 == '\0')) {
    return;
  }
  (&DAT_0000229c)[in_ECX] = 0;
  do {
    (**(code **)(&DAT_00241540 + (*(byte *)(*(int *)(in_ECX + 0x3c) + 1) & 0x3f) * 0x10))();
  } while ((&DAT_0000229c)[in_ECX] == '\0');
  return;
}


