// func FUN_0001bd30 @ 0x0001BD30 (size 0x389)

void FUN_0001bd30(int param_1)

{
  short sVar1;
  ushort uVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  uint uVar11;
  ushort *puVar12;
  uint uVar13;
  uint uVar14;
  ushort *puVar15;
  int *local_18;
  uint local_10;
  int local_c;
  
  if ((*(uint *)(param_1 + -4) >> 0x1e & 1) == 0) {
    *(uint *)(param_1 + -4) = *(uint *)(param_1 + -4) | 0x40000000;
    local_c = 0;
    if (*(char *)(param_1 + 1) != '\0') {
      local_18 = (int *)(param_1 + 8);
      do {
        iVar7 = *local_18;
        if (iVar7 != 0) {
          iVar6 = FUN_00058910();
          if (((iVar6 != -1) && (iVar10 = *(int *)(DAT_00241208 + iVar6 * 4), iVar7 + -8 == iVar10))
             && (iVar7 = (*(int *)(DAT_0024120c + iVar6 * 4) - iVar10) + iVar7, iVar7 != 0)) {
            *local_18 = iVar7;
          }
          FUN_0001aea0(*local_18);
        }
        iVar7 = local_18[6];
        if (((iVar7 != 0) && (iVar6 = FUN_00058910(), iVar6 != -1)) &&
           ((iVar10 = *(int *)(DAT_00241208 + iVar6 * 4), iVar7 + -8 == iVar10 &&
            (iVar7 = (*(int *)(DAT_0024120c + iVar6 * 4) - iVar10) + iVar7, iVar7 != 0)))) {
          local_18[6] = iVar7;
        }
        iVar7 = local_18[0xc];
        if (((iVar7 != 0) && (iVar6 = FUN_00058910(), iVar6 != -1)) &&
           ((iVar10 = *(int *)(DAT_00241208 + iVar6 * 4), iVar7 + -8 == iVar10 &&
            (iVar7 = (*(int *)(DAT_0024120c + iVar6 * 4) - iVar10) + iVar7, iVar7 != 0)))) {
          local_18[0xc] = iVar7;
        }
        if (local_18[0xc] != 0) {
          FUN_0001cfd0(local_18[0xc],*(undefined4 *)(*local_18 + 0x1c));
        }
        puVar3 = *(uint **)(*local_18 + 0x1c);
        if (puVar3 != (uint *)0x0) {
          uVar4 = *puVar3;
          local_10 = 0;
          if (uVar4 != 0) {
            do {
              uVar8 = local_10 & 0xffff;
              if ((char)puVar3[uVar8 * 5 + 5] < '\0') {
                uVar13 = puVar3[uVar8 * 5 + 3];
                uVar14 = 0;
                if (uVar13 >> 2 != 0) {
                  do {
                    iVar6 = local_18[6];
                    iVar7 = puVar3[uVar8 * 5 + 4] + uVar14 * 4;
                    iVar10 = *(int *)(iVar7 + iVar6);
                    if ((((iVar10 != 0) && (iVar9 = FUN_00058910(), iVar9 != -1)) &&
                        (iVar5 = *(int *)(DAT_00241208 + iVar9 * 4), iVar10 + -8 == iVar5)) &&
                       (iVar10 = (*(int *)(DAT_0024120c + iVar9 * 4) - iVar5) + iVar10, iVar10 != 0)
                       ) {
                      *(int *)(iVar7 + iVar6) = iVar10;
                    }
                    uVar14 = uVar14 + 1;
                  } while (uVar14 < uVar13 >> 2);
                }
              }
              else {
                uVar13 = puVar3[uVar8 * 5 + 3];
                if (uVar13 < 0xe) {
                  if (uVar13 == 4) {
                    uVar13 = puVar3[uVar8 * 5 + 4];
                    iVar7 = local_18[6];
                    puVar15 = *(ushort **)(uVar13 + iVar7);
                    if ((((puVar15 != (ushort *)0x0) && (iVar6 = FUN_00058910(), iVar6 != -1)) &&
                        (puVar12 = (ushort *)
                                   ((*(int *)(DAT_0024120c + iVar6 * 4) -
                                    *(int *)(DAT_00241208 + iVar6 * 4)) + (int)puVar15),
                        puVar12 != (ushort *)0x0)) &&
                       (((puVar12 != puVar15 && (puVar12[2] < 9)) &&
                        ((uVar2 = puVar12[1], 1 < uVar2 && ((uVar2 < 8000 && (*puVar12 <= uVar2)))))
                        ))) {
                      *(ushort **)(uVar13 + iVar7) = puVar12;
                    }
                  }
                }
                else {
                  sVar1 = *(short *)(puVar3[uVar8 * 5 + 4] + 4 + local_18[6]);
                  puVar15 = (ushort *)(puVar3[uVar8 * 5 + 4] + local_18[6]);
                  if (((((sVar1 == 5) || (sVar1 == 6)) && (uVar2 = puVar15[1], 1 < uVar2)) &&
                      (((int)((uint)uVar2 * 4 + 6) <= (int)uVar13 && (*puVar15 <= uVar2)))) &&
                     (uVar13 = 0, *puVar15 != 0)) {
                    puVar12 = puVar15 + 3;
                    do {
                      iVar7 = *(int *)puVar12;
                      if (((iVar7 != 0) && (iVar6 = FUN_00058910(), iVar6 != -1)) &&
                         ((iVar10 = *(int *)(DAT_00241208 + iVar6 * 4), iVar7 + -8 == iVar10 &&
                          (iVar7 = (*(int *)(DAT_0024120c + iVar6 * 4) - iVar10) + iVar7, iVar7 != 0
                          )))) {
                        *(int *)puVar12 = iVar7;
                      }
                      uVar13 = uVar13 + 1;
                      puVar12 = puVar12 + 2;
                    } while (uVar13 < *puVar15);
                  }
                }
                if (((puVar3[uVar8 * 5 + 3] & 3) == 0) && (uVar13 = 0, puVar3[uVar8 * 5 + 3] != 0))
                {
                  do {
                    uVar14 = puVar3[uVar8 * 5 + 4];
                    iVar7 = local_18[6];
                    iVar6 = *(int *)(uVar14 + iVar7 + uVar13);
                    if (((((iVar6 != 0) &&
                          (((iVar10 = FUN_00058910(), iVar10 != -1 &&
                            (iVar10 = (*(int *)(DAT_0024120c + iVar10 * 4) -
                                      *(int *)(DAT_00241208 + iVar10 * 4)) + iVar6, iVar10 != 0)) &&
                           (iVar10 != iVar6)))) &&
                         (((*(char *)(iVar10 + -3) == '\x01' && (*(char *)(iVar10 + -4) == '\v')) &&
                          (uVar11 = (uint)*(ushort *)(iVar10 + -2) * 4,
                          *(ushort *)(iVar10 + -2) != 0)))) && (uVar11 < 0x100)) &&
                       (((*(char *)(iVar10 + -4 + uVar11) == '\0' ||
                         (*(char *)(iVar10 + -3 + uVar11) == '\0')) ||
                        ((*(char *)(iVar10 + -2 + uVar11) == '\0' ||
                         (*(char *)(iVar10 + -1 + uVar11) == '\0')))))) {
                      *(int *)(uVar14 + iVar7 + uVar13) = iVar10;
                    }
                    uVar13 = uVar13 + 4;
                  } while (uVar13 < puVar3[uVar8 * 5 + 3]);
                }
              }
              local_10 = local_10 + 1;
            } while (local_10 < uVar4);
          }
        }
        local_c = local_c + 1;
        local_18 = local_18 + 1;
      } while (local_c < (int)(uint)*(byte *)(param_1 + 1));
    }
  }
  return;
}


