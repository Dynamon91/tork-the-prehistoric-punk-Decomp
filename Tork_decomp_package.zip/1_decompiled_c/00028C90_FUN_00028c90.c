// func FUN_00028c90 @ 0x00028C90 (size 0x213)

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_00028c90(float param_1,float param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined8 uVar5;
  int in_ECX;
  int iVar6;
  undefined4 local_8;
  undefined4 uStack_4;
  
  if (0x358637bd < (uint)ABS(param_1 - param_2)) {
    FUN_000dea30(*(uint *)(in_ECX + 4) | 0x82);
    puVar1 = *(uint **)(in_ECX + 0x1c);
    if ((*puVar1 >> 0xb & 1) == 0) {
      FUN_000e47c0(*puVar1 | 0x800);
    }
    uVar2 = puVar1[0x16];
    *(undefined4 *)(uVar2 + 0xb0) = 0x3f800000;
    *(undefined4 *)(uVar2 + 0x9c) = 0x3f800000;
    *(float *)(uVar2 + 0x88) = 1.0;
    *(undefined4 *)(uVar2 + 0xc4) = 0x3f800000;
    iVar6 = 0;
    *(float *)(uVar2 + 0xb0) = param_2;
    *(float *)(uVar2 + 0x9c) = param_2;
    *(float *)(uVar2 + 0x88) = param_2;
    *(undefined4 *)(uVar2 + 0xc0) = 0;
    *(undefined4 *)(uVar2 + 0xbc) = 0;
    *(undefined4 *)(uVar2 + 0xb8) = 0;
    *(undefined4 *)(uVar2 + 0xac) = 0;
    *(undefined4 *)(uVar2 + 0xa8) = 0;
    *(undefined4 *)(uVar2 + 0xa0) = 0;
    *(undefined4 *)(uVar2 + 0x98) = 0;
    *(undefined4 *)(uVar2 + 0x90) = 0;
    *(undefined4 *)(uVar2 + 0x8c) = 0;
    *(undefined4 *)(uVar2 + 0xb4) = 0;
    *(undefined4 *)(uVar2 + 0xa4) = 0;
    *(undefined4 *)(uVar2 + 0x94) = 0;
    uVar3 = *(undefined4 *)puVar1[1];
    uVar5 = *(undefined8 *)((undefined4 *)puVar1[1] + 1);
    FUN_000286c0(puVar1[0x16] + 0x88,puVar1[0x16] + 0x48);
    uStack_4 = (undefined4)((ulonglong)uVar5 >> 0x20);
    local_8 = (undefined4)uVar5;
    puVar4 = (undefined4 *)puVar1[1];
    *puVar4 = uVar3;
    puVar4[1] = local_8;
    puVar4[2] = uStack_4;
    FUN_00028970();
    if (((*(uint *)(in_ECX + 4) >> 0xd & 1) != 0) &&
       (**(char **)(*(int *)(in_ECX + 0x24) + 0x2c) != '\0')) {
      do {
        FUN_00028c90(param_1,param_2);
        FUN_00025030();
        FUN_000250a0();
        iVar6 = iVar6 + 1;
      } while (iVar6 < (int)(uint)**(byte **)(*(int *)(in_ECX + 0x24) + 0x2c));
      return;
    }
  }
  return;
}


