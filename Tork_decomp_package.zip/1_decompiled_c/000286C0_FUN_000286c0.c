// func FUN_000286c0 @ 0x000286C0 (size 0xCF)

void FUN_000286c0(float *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float *in_ECX;
  
  fVar1 = *param_1;
  fVar2 = param_1[1];
  fVar3 = param_1[2];
  fVar4 = param_1[4];
  fVar5 = param_1[5];
  fVar6 = param_1[6];
  fVar7 = *param_2;
  fVar8 = param_2[1];
  fVar9 = param_2[2];
  fVar10 = param_2[3];
  fVar11 = param_2[4];
  fVar12 = param_2[5];
  fVar13 = param_2[6];
  fVar14 = param_2[7];
  fVar15 = param_2[8];
  fVar16 = param_2[9];
  fVar17 = param_2[10];
  fVar18 = param_2[0xb];
  fVar19 = param_2[0xc];
  fVar20 = param_2[0xd];
  fVar21 = param_2[0xe];
  fVar22 = param_2[0xf];
  *in_ECX = fVar1 * fVar7 + fVar2 * fVar11 + fVar3 * fVar15;
  in_ECX[1] = fVar1 * fVar8 + fVar2 * fVar12 + fVar3 * fVar16;
  in_ECX[2] = fVar1 * fVar9 + fVar2 * fVar13 + fVar3 * fVar17;
  in_ECX[3] = fVar1 * fVar10 + fVar2 * fVar14 + fVar3 * fVar18;
  fVar1 = param_1[8];
  fVar2 = param_1[9];
  fVar3 = param_1[10];
  in_ECX[4] = fVar4 * fVar7 + fVar5 * fVar11 + fVar6 * fVar15;
  in_ECX[5] = fVar4 * fVar8 + fVar5 * fVar12 + fVar6 * fVar16;
  in_ECX[6] = fVar4 * fVar9 + fVar5 * fVar13 + fVar6 * fVar17;
  in_ECX[7] = fVar4 * fVar10 + fVar5 * fVar14 + fVar6 * fVar18;
  fVar4 = param_1[0xc];
  fVar5 = param_1[0xd];
  fVar6 = param_1[0xe];
  in_ECX[8] = fVar1 * fVar7 + fVar2 * fVar11 + fVar3 * fVar15;
  in_ECX[9] = fVar1 * fVar8 + fVar2 * fVar12 + fVar3 * fVar16;
  in_ECX[10] = fVar1 * fVar9 + fVar2 * fVar13 + fVar3 * fVar17;
  in_ECX[0xb] = fVar1 * fVar10 + fVar2 * fVar14 + fVar3 * fVar18;
  in_ECX[0xc] = fVar4 * fVar7 + fVar5 * fVar11 + fVar6 * fVar15 + fVar19;
  in_ECX[0xd] = fVar4 * fVar8 + fVar5 * fVar12 + fVar6 * fVar16 + fVar20;
  in_ECX[0xe] = fVar4 * fVar9 + fVar5 * fVar13 + fVar6 * fVar17 + fVar21;
  in_ECX[0xf] = fVar4 * fVar10 + fVar5 * fVar14 + fVar6 * fVar18 + fVar22;
  return;
}


