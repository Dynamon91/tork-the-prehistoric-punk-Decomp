// func FUN_00058670 @ 0x00058670 (size 0x299)

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00058670(void)

{
  float fVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  int local_d0;
  char acStack_84 [128];
  undefined4 local_4;
  
  local_4 = DAT_002264b0;
  iVar2 = FUN_0012a37c();
  uVar3 = FUN_0012c18c(0xfffffffe);
  FUN_0012c13a(0xfffffffe,1);
  FUN_00056df0(&DAT_0022a740);
  iVar9 = *(int *)(DAT_0022a73c + 0x10);
  iVar8 = DAT_0022a73c;
  while ((iVar4 = iVar9, iVar4 != 0 && (*(int *)(iVar4 + 8) != 0))) {
    iVar8 = iVar4;
    iVar9 = *(int *)(iVar4 + 0x10);
  }
  iVar9 = *(int *)(iVar8 + 8) - *(int *)(iVar8 + 0xc);
  iVar8 = iVar9;
  do {
    iVar4 = iVar8;
    if (iVar4 == DAT_0022a76c) break;
    uVar7 = *(uint *)(iVar4 + 4) & 0xfffffffe;
    iVar8 = uVar7 + iVar4;
  } while ((*(byte *)(uVar7 + 4 + iVar4) & 1) != 0);
  iVar8 = 0;
  local_d0 = 0;
  if (iVar4 != DAT_0022a76c) {
    do {
      iVar4 = iVar4 + (*(uint *)(iVar4 + 4) & 0xfffffffe);
      if ((*(byte *)(iVar4 + 4) & 1) != 0) {
        iVar8 = iVar8 + 1;
      }
    } while (iVar4 != DAT_0022a76c);
    local_d0 = iVar8;
  }
  DAT_00241208 = __2_YAPAXI_Z();
  piVar5 = (int *)__2_YAPAXI_Z(local_d0 * 4);
  DAT_0024120c = piVar5;
  if (DAT_00241208 != 0) {
    if (piVar5 != (int *)0x0) {
      DAT_00241210 = local_d0;
      if (iVar9 != DAT_0022a76c) {
        iVar6 = DAT_00241208 - (int)piVar5;
        iVar8 = iVar9;
        iVar4 = iVar9;
        do {
          uVar7 = *(uint *)(iVar8 + 4);
          if ((*(byte *)(iVar8 + 4 + (uVar7 & 0xfffffffe)) & 1) != 0) {
            if (iVar8 != iVar4) {
              *(int *)(iVar6 + (int)piVar5) = iVar8;
              *piVar5 = iVar4;
              piVar5 = piVar5 + 1;
            }
            uVar7 = *(uint *)(iVar8 + 4);
            iVar4 = iVar4 + (uVar7 & 0x7ffffffc);
          }
          iVar8 = iVar8 + (uVar7 & 0xfffffffe);
        } while (iVar8 != DAT_0022a76c);
      }
      iVar8 = 0;
      if (0 < local_d0) {
        do {
          FUN_00058470();
          iVar8 = iVar8 + 1;
        } while (iVar8 < local_d0);
      }
      (*DAT_00241214)();
      thunk_FUN_00138640();
      thunk_FUN_00138640(DAT_00241208);
      DAT_0024120c = (int *)0x0;
      DAT_00241208 = 0;
      DAT_00241210 = 0;
      if (iVar9 != DAT_0022a76c) {
        do {
          uVar7 = *(uint *)(iVar9 + 4);
          *(uint *)(iVar9 + 4) = uVar7 & 0xbfffffff;
          iVar9 = iVar9 + (uVar7 & 0xbffffffe);
        } while (iVar9 != DAT_0022a76c);
      }
      FUN_0013f9a8();
      FUN_00056df0();
      FUN_00056830(0);
      FUN_0013f9a8();
      _sprintf(acStack_84,s_MEM_RemapEntireMemory___Give__d_K_002082cc);
      FUN_0012c13a(0xfffffffe,uVar3);
      iVar8 = FUN_0012a37c();
      fVar1 = (float)(iVar8 - iVar2);
      if (iVar8 - iVar2 < 0) {
        fVar1 = fVar1 + _DAT_0020dfb4;
      }
      _sprintf(acStack_84,s_MEM_RemapEntireMemory_is_success_00208288,
               (double)(fVar1 * _DAT_0020e0ac));
      return;
    }
    thunk_FUN_00138640();
  }
  FUN_0012c13a(0xfffffffe,uVar3);
  return;
}


