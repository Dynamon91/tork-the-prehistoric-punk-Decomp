// func FUN_00024150 @ 0x00024150 (size 0x48)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00024150(void)

{
  float10 fVar1;
  float fVar2;
  
  fVar1 = (float10)FUN_000241a0();
  fVar2 = (float)fVar1;
  if (fVar1 <= (float10)_DAT_0020e010) {
    FUN_00142480(0xbf800000);
    return;
  }
  if (_DAT_0020df98 <= fVar2) {
    fVar2 = 1.0;
  }
  FUN_00142480(fVar2);
  return;
}


