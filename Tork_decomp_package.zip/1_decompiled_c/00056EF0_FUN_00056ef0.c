// func FUN_00056ef0 @ 0x00056EF0 (size 0x208)

undefined4 * FUN_00056ef0(undefined4 *param_1)

{
  uint *puVar1;
  int iVar2;
  uint in_EAX;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  
  if (param_1 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)FUN_000568c0();
    return puVar3;
  }
  if (0xffffffdf < in_EAX) {
    puVar3 = (undefined4 *)FUN_00135a61();
    *puVar3 = 0xc;
    return (undefined4 *)0x0;
  }
  if (in_EAX + 0xb < 0x10) {
    uVar8 = 0x10;
  }
  else {
    uVar8 = in_EAX + 0xb & 0xfffffff8;
  }
  uVar6 = param_1[-1];
  uVar9 = uVar6 & 0x7ffffffc;
  if ((uVar6 & 2) != 0) {
    if (uVar8 + 4 <= uVar9) {
      return param_1;
    }
    puVar3 = (undefined4 *)FUN_000568c0(uVar8 - 7);
    if (puVar3 != (undefined4 *)0x0) {
      puVar5 = puVar3;
      for (uVar8 = uVar9 - 8 >> 2; uVar8 != 0; uVar8 = uVar8 - 1) {
        *puVar5 = *param_1;
        param_1 = param_1 + 1;
        puVar5 = puVar5 + 1;
      }
      for (iVar7 = 0; iVar7 != 0; iVar7 = iVar7 + -1) {
        *(undefined1 *)puVar5 = *(undefined1 *)param_1;
        param_1 = (undefined4 *)((int)param_1 + 1);
        puVar5 = (undefined4 *)((int)puVar5 + 1);
      }
      FUN_00056c90();
    }
    return puVar3;
  }
  if (uVar9 < uVar8) {
    puVar3 = (undefined4 *)((uVar9 - 8) + (int)param_1);
    uVar4 = puVar3[1];
    if (puVar3 == DAT_0022a76c) {
      uVar4 = (uVar4 & 0x7ffffffc) + uVar9;
      if (uVar8 + 0x10 <= uVar4) {
        param_1[-1] = uVar6 & 1 | uVar8;
        DAT_0022a76c = (undefined4 *)((uVar8 - 8) + (int)param_1);
        *(uint *)((int)DAT_0022a76c + 4) = uVar4 - uVar8 | 1;
        return param_1;
      }
    }
    else if (((*(byte *)((uVar4 & 0xfffffffe) + 4 + (int)puVar3) & 1) == 0) &&
            (uVar6 = (uVar4 & 0x7ffffffc) + uVar9, uVar8 <= uVar6)) {
      iVar7 = puVar3[2];
      iVar2 = puVar3[3];
      *(int *)(iVar7 + 0xc) = iVar2;
      *(int *)(iVar2 + 8) = iVar7;
      goto LAB_00056fd9;
    }
    puVar5 = (undefined4 *)FUN_000568c0(uVar8 - 7);
    if (puVar5 == (undefined4 *)0x0) {
      return (undefined4 *)0x0;
    }
    if (puVar5 + -2 != puVar3) {
      uVar8 = uVar9 - 4 >> 2;
      if (9 < uVar8) {
        puVar3 = puVar5;
        for (uVar8 = uVar9 - 4 >> 2; uVar8 != 0; uVar8 = uVar8 - 1) {
          *puVar3 = *param_1;
          param_1 = param_1 + 1;
          puVar3 = puVar3 + 1;
        }
        for (iVar7 = 0; iVar7 != 0; iVar7 = iVar7 + -1) {
          *(undefined1 *)puVar3 = *(undefined1 *)param_1;
          param_1 = (undefined4 *)((int)param_1 + 1);
          puVar3 = (undefined4 *)((int)puVar3 + 1);
        }
        FUN_00056c90();
        return puVar5;
      }
      *puVar5 = *param_1;
      puVar5[1] = param_1[1];
      puVar5[2] = param_1[2];
      if (4 < uVar8) {
        puVar5[3] = param_1[3];
        puVar5[4] = param_1[4];
        if (6 < uVar8) {
          puVar5[5] = param_1[5];
          puVar5[6] = param_1[6];
          if (8 < uVar8) {
            puVar5[7] = param_1[7];
            puVar5[8] = param_1[8];
          }
        }
      }
      FUN_00056c90();
      return puVar5;
    }
    uVar6 = (puVar5[-1] & 0x7ffffffc) + uVar9;
  }
  else {
    uVar6 = uVar9;
  }
LAB_00056fd9:
  uVar9 = uVar6 - uVar8;
  if (uVar9 < 0x10) {
    param_1[-1] = param_1[-1] & 1 | uVar6;
    *(uint *)((uVar6 - 4) + (int)param_1) = *(uint *)((uVar6 - 4) + (int)param_1) | 1;
    return param_1;
  }
  param_1[-1] = param_1[-1] & 1 | uVar8;
  *(uint *)((int)param_1 + (uVar8 - 4)) = uVar9 | 1;
  puVar1 = (uint *)((int)param_1 + uVar9 + (uVar8 - 4));
  *puVar1 = *puVar1 | 1;
  FUN_00056c90();
  return param_1;
}


