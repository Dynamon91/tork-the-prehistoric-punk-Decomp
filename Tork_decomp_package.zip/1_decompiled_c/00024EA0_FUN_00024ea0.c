// func FUN_00024ea0 @ 0x00024EA0 (size 0x140)

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_00024ea0(undefined4 param_1)

{
  int unaff_ESI;
  
  FUN_000e01d0(unaff_ESI,param_1);
  if (((((*(uint *)(unaff_ESI + 4) >> 0x1d & 1) != 0) || ((*(byte *)(unaff_ESI + 2) >> 4 & 1) != 0))
      && ((*(uint *)(unaff_ESI + 4) >> 7 & 1) != 0)) &&
     (((**(uint **)(unaff_ESI + 0x1c) >> 8 & 1) != 0 &&
      ((**(uint **)(unaff_ESI + 0x1c) >> 9 & 1) == 0)))) {
    FUN_00024ce0();
  }
  return;
}


