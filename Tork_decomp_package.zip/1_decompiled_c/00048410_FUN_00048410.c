// func FUN_00048410 @ 0x00048410 (size 0x9B)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00048410(void)

{
  uint uVar1;
  char *in_EAX;
  uint uVar2;
  float10 fVar3;
  float10 fVar4;
  
  if (*in_EAX == '\0') {
    return (float10)_DAT_0020df5c;
  }
  uVar2 = FUN_0005aba0();
  if (((uVar2 != 0xffffffff) &&
      (uVar2 = uVar2 >> 0x17, *(int *)(in_EAX + (int)(&DAT_00001808 + uVar2 * 0x10)) != -1)) &&
     (*(int *)(in_EAX + uVar2 * 0x18 + 8) != -1)) {
    uVar1 = *(uint *)(in_EAX + uVar2 * 0x18 + 0x18);
    uVar2 = *(uint *)(in_EAX + (uVar2 + 0x181) * 0x10);
    if (uVar2 != 0xffffffff) {
      if (uVar1 <= uVar2) {
        return (float10)_DAT_0020df98;
      }
      fVar3 = (float10)(int)uVar2;
      if ((int)uVar2 < 0) {
        fVar3 = fVar3 + (float10)_DAT_0020dfb4;
      }
      fVar4 = (float10)(int)uVar1;
      if ((int)uVar1 < 0) {
        fVar4 = fVar4 + (float10)_DAT_0020dfb4;
      }
      return fVar3 / fVar4;
    }
  }
  return (float10)_DAT_0020df5c;
}


