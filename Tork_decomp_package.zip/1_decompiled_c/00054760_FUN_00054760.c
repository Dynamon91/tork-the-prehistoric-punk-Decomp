// func FUN_00054760 @ 0x00054760 (size 0x41)

void FUN_00054760(void)

{
  ushort uVar1;
  ushort in_AX;
  uint uVar2;
  ushort *in_ECX;
  uint uVar3;
  int iVar4;
  ushort *puVar5;
  ushort *puVar6;
  
  if (in_AX < *in_ECX) {
    uVar1 = *in_ECX - 1;
    uVar2 = (uint)in_AX;
    *in_ECX = uVar1;
    if ((in_ECX + uVar2 * 2 + 3 != (ushort *)0x0) && (in_ECX + uVar2 * 2 + 5 != (ushort *)0x0)) {
      puVar5 = in_ECX + uVar2 * 2 + 5;
      puVar6 = in_ECX + uVar2 * 2 + 3;
      for (uVar3 = uVar1 - uVar2 & 0x3fffffff; uVar3 != 0; uVar3 = uVar3 - 1) {
        *(undefined4 *)puVar6 = *(undefined4 *)puVar5;
        puVar5 = puVar5 + 2;
        puVar6 = puVar6 + 2;
      }
      for (iVar4 = 0; iVar4 != 0; iVar4 = iVar4 + -1) {
        *(char *)puVar6 = (char)*puVar5;
        puVar5 = (ushort *)((int)puVar5 + 1);
        puVar6 = (ushort *)((int)puVar6 + 1);
      }
    }
  }
  return;
}


