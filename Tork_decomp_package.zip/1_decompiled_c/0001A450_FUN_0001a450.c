// func FUN_0001a450 @ 0x0001A450 (size 0xA3)

int FUN_0001a450(undefined2 *param_1)

{
  int in_EAX;
  int iVar1;
  int iVar2;
  int iVar3;
  int unaff_ESI;
  
  iVar1 = *(int *)(&DAT_00004734 + unaff_ESI);
  if (iVar1 + in_EAX < 0x801) {
    *(int *)(&DAT_00004734 + unaff_ESI) = iVar1 + in_EAX;
  }
  else {
    iVar3 = 0;
    iVar2 = 0;
    if (0 < iVar1) {
      do {
        if ((*(uint *)(&DAT_00004738 + (iVar2 >> 5) * 4 + unaff_ESI) & 1 << ((byte)iVar2 & 0x1f)) ==
            0) {
          iVar3 = iVar3 + 1;
          if (iVar3 == in_EAX) goto LAB_0001a494;
        }
        else {
          iVar3 = 0;
        }
        iVar2 = iVar2 + 1;
      } while (iVar2 < *(int *)(&DAT_00004734 + unaff_ESI));
    }
    if (iVar3 < in_EAX) {
      return 0;
    }
LAB_0001a494:
    iVar1 = (iVar2 - iVar3) + 1;
  }
  *param_1 = (short)iVar1;
  for (iVar2 = iVar1; iVar2 < in_EAX + iVar1; iVar2 = iVar2 + 1) {
    *(uint *)(&DAT_00004738 + (iVar2 >> 5) * 4 + unaff_ESI) =
         *(uint *)(&DAT_00004738 + (iVar2 >> 5) * 4 + unaff_ESI) | 1 << ((byte)iVar2 & 0x1f);
  }
  return unaff_ESI + 0x4838 + iVar1 * 4;
}


