// func FUN_0001dac0 @ 0x0001DAC0 (size 0x10A)

void FUN_0001dac0(void)

{
  undefined1 *puVar1;
  int in_ECX;
  
  puVar1 = *(undefined1 **)(in_ECX + 0x3c);
  switch(*puVar1) {
  case 1:
    **(uint **)(in_ECX + 8) = (uint)(puVar1[2] != '\0');
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    *(undefined1 **)(in_ECX + 0x3c) = puVar1 + 4;
    return;
  case 2:
    **(int **)(in_ECX + 8) = (int)(char)puVar1[2];
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    *(undefined1 **)(in_ECX + 0x3c) = puVar1 + 4;
    return;
  case 3:
    **(uint **)(in_ECX + 8) = (uint)(byte)puVar1[2];
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    *(undefined1 **)(in_ECX + 0x3c) = puVar1 + 4;
    return;
  case 4:
    **(int **)(in_ECX + 8) = (int)*(short *)(puVar1 + 2);
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    *(undefined1 **)(in_ECX + 0x3c) = puVar1 + 4;
    return;
  case 5:
  case 0x20:
    **(uint **)(in_ECX + 8) = (uint)*(ushort *)(puVar1 + 2);
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    *(undefined1 **)(in_ECX + 0x3c) = puVar1 + 4;
    return;
  case 6:
  case 7:
    **(undefined4 **)(in_ECX + 8) = *(undefined4 *)(puVar1 + 4);
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    *(undefined1 **)(in_ECX + 0x3c) = puVar1 + 8;
    return;
  default:
    **(undefined4 **)(in_ECX + 8) = *(undefined4 *)(puVar1 + 4);
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    *(int *)(in_ECX + 0x3c) = *(int *)(in_ECX + 0x3c) + 8;
    return;
  case 9:
    FUN_0001d790();
    *(int *)(in_ECX + 0x3c) = *(int *)(in_ECX + 0x3c) + 0x10;
    return;
  case 0xb:
    **(int **)(in_ECX + 8) = (int)(puVar1 + 4);
    *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
    *(undefined1 **)(in_ECX + 0x3c) = puVar1 + (uint)*(ushort *)(puVar1 + 2) * 4 + 4;
    return;
  }
}


