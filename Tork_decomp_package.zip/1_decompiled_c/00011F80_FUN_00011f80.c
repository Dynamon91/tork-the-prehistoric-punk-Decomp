// func FUN_00011f80 @ 0x00011F80 (size 0x5F)

int * FUN_00011f80(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  piVar1 = (int *)FUN_00057f60(&DAT_000022a0);
  iVar2 = FUN_00057f60(0x2000);
  *piVar1 = iVar2;
  piVar1[1] = iVar2 + 0x2000;
  piVar1[2] = iVar2;
  piVar1[0xf] = 0;
  FUN_00012240();
  piVar3 = piVar1 + 0x826;
  for (iVar2 = 0x80; iVar2 != 0; iVar2 = iVar2 + -1) {
    *piVar3 = 0;
    piVar3 = piVar3 + 1;
  }
  piVar1[0x827] = (int)&LAB_00054ef0;
  piVar1[0x828] = (int)&LAB_00054f60;
  return piVar1;
}


