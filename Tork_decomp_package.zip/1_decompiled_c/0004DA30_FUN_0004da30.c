// func FUN_0004da30 @ 0x0004DA30 (size 0xA8)

void FUN_0004da30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  byte *pbVar1;
  int iVar2;
  byte bVar3;
  uint uVar4;
  byte *pbVar5;
  
  pbVar1 = *(byte **)(*(int *)(*(int *)(DAT_0022a6c4 + 0x14) + 0x24) + 4);
  iVar2 = 0;
  if (pbVar1[1] != 0) {
    pbVar5 = pbVar1 + 8;
    do {
      if (*(int *)pbVar5 == *(int *)(DAT_0022a6c4 + 0x34)) break;
      iVar2 = iVar2 + 1;
      pbVar5 = pbVar5 + 4;
    } while (iVar2 < (int)(uint)pbVar1[1]);
  }
  uVar4 = 0;
  bVar3 = 0;
  if (*pbVar1 != 0) {
    do {
      bVar3 = (byte)uVar4;
      if ((((uint)*(ushort *)(pbVar1 + 2) & 1 << (bVar3 & 0x1f)) != 0) &&
         (*(int *)(pbVar1 + (uint)pbVar1[uVar4 * 8 + 0x6a] * 4 + 8) == *(int *)(DAT_0022a6c4 + 0x34)
         )) break;
      bVar3 = bVar3 + 1;
      uVar4 = (uint)bVar3;
    } while (bVar3 < *pbVar1);
  }
  FUN_0001a100(*(int *)(DAT_0022a6c4 + 0x14),bVar3,param_1,param_2,param_3,param_4,param_5);
  return;
}


