// func FUN_0001b390 @ 0x0001B390 (size 0x79)

void FUN_0001b390(int param_1)

{
  int in_ECX;
  int iVar1;
  void *__src;
  int *__dest;
  
  *(byte *)(in_ECX + 0x25) = *(byte *)(in_ECX + 0x25) & 0x9f;
  iVar1 = 0;
  if (0 < *(short *)(in_ECX + 0x26)) {
    __dest = (int *)(in_ECX + 0x28);
    __src = (void *)(in_ECX + 0x2c);
    do {
      if (*__dest != 0) {
        if ((*(ushort *)(*__dest + 0x24) >> 0xe & 1) != 0) {
          FUN_0001b390(param_1);
        }
        if (*__dest == param_1) {
          *(short *)(in_ECX + 0x26) = *(short *)(in_ECX + 0x26) + -1;
          _memmove(__dest,__src,(*(short *)(in_ECX + 0x26) - iVar1) * 4);
          iVar1 = iVar1 + -1;
          __src = (void *)((int)__src + -4);
          __dest = __dest + -1;
        }
        else {
          *(short *)*__dest = *(short *)*__dest + 1;
        }
      }
      iVar1 = iVar1 + 1;
      __src = (void *)((int)__src + 4);
      __dest = __dest + 1;
    } while (iVar1 < *(short *)(in_ECX + 0x26));
  }
  return;
}


