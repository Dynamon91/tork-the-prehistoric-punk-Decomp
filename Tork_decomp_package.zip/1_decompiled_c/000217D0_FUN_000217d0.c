// func FUN_000217d0 @ 0x000217D0 (size 0x40)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_000217d0(void)

{
  float fVar1;
  float fVar2;
  float *unaff_ESI;
  float *unaff_EDI;
  float10 fVar3;
  
  fVar3 = (float10)FUN_00021640();
  fVar3 = SQRT((float10)_DAT_0020df98 / fVar3);
  fVar1 = unaff_ESI[1];
  fVar2 = unaff_ESI[2];
  *unaff_EDI = (float)(fVar3 * (float10)*unaff_ESI);
  unaff_EDI[1] = (float)(fVar3 * (float10)fVar1);
  unaff_EDI[2] = (float)(fVar3 * (float10)fVar2);
  return;
}


