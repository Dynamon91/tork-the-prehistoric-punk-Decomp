// func FUN_0001d380 @ 0x0001D380 (size 0xBF)

void FUN_0001d380(uint *param_1,uint param_2,byte param_3,int param_4)

{
  int iVar1;
  uint *puVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  uint *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  
  iVar3 = param_2;
  puVar7 = param_1 + 1;
  param_2 = 0;
  if (*param_1 != 0) {
    puVar2 = param_1;
    do {
      puVar6 = puVar2 + 2;
      iVar1 = param_4 + 8 + (uint)(ushort)*puVar7 * 0x14;
      if ((ushort)((*(ushort *)(param_4 + 0x14 + (uint)(ushort)*puVar7 * 0x14) >> 0xe) +
                  (ushort)param_3) < 4) {
        uVar5 = *(uint *)(iVar1 + 4);
        iVar1 = *(int *)(iVar1 + 8);
        switch(uVar5) {
        case 1:
          *(char *)(iVar1 + iVar3) = (char)*puVar6;
          break;
        case 2:
          *(short *)(iVar1 + iVar3) = (short)*puVar6;
          break;
        case 3:
          *(undefined2 *)(iVar1 + iVar3) = (short)*puVar6;
          *(undefined1 *)((undefined2 *)(iVar1 + iVar3) + 1) = *(undefined1 *)((int)puVar2 + 10);
          break;
        case 4:
          *(uint *)(iVar1 + iVar3) = *puVar6;
          break;
        default:
          puVar8 = (undefined4 *)*puVar6;
          puVar9 = (undefined4 *)(iVar1 + iVar3);
          for (uVar4 = uVar5 >> 2; uVar4 != 0; uVar4 = uVar4 - 1) {
            *puVar9 = *puVar8;
            puVar8 = puVar8 + 1;
            puVar9 = puVar9 + 1;
          }
          for (uVar5 = uVar5 & 3; uVar5 != 0; uVar5 = uVar5 - 1) {
            *(undefined1 *)puVar9 = *(undefined1 *)puVar8;
            puVar8 = (undefined4 *)((int)puVar8 + 1);
            puVar9 = (undefined4 *)((int)puVar9 + 1);
          }
        }
      }
      param_2 = param_2 + 1;
      puVar7 = puVar7 + 2;
      puVar2 = puVar6;
    } while (param_2 < *param_1);
  }
  return;
}


