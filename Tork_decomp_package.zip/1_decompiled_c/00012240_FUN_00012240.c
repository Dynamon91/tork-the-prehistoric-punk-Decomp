// func FUN_00012240 @ 0x00012240 (size 0x5CBD)

void FUN_00012240(undefined4 param_1,undefined4 param_2,undefined *param_3,undefined2 param_4,
                 undefined *param_5,undefined2 param_6,undefined1 *param_7,undefined2 param_8,
                 undefined1 *param_9,undefined2 param_10,undefined4 param_11,undefined2 param_12,
                 undefined4 param_13,undefined2 param_14,undefined1 *param_15,undefined2 param_16,
                 undefined1 *param_17,undefined2 param_18,undefined *param_19,undefined2 param_20,
                 undefined1 *param_21,undefined2 param_22,undefined1 *param_23,undefined2 param_24,
                 undefined1 *param_25,undefined2 param_26,undefined1 *param_27,undefined2 param_28,
                 undefined1 *param_29,undefined2 param_30,undefined1 *param_31,undefined2 param_32,
                 undefined1 *param_33,undefined2 param_34,undefined1 *param_35,undefined2 param_36,
                 undefined1 *param_37,undefined2 param_38,undefined1 *param_39,undefined2 param_40,
                 undefined1 *param_41,undefined2 param_42,undefined1 *param_43,undefined2 param_44,
                 undefined1 *param_45,undefined2 param_46,undefined1 *param_47,undefined2 param_48,
                 undefined1 *param_49,undefined2 param_50,undefined1 *param_51,undefined2 param_52,
                 undefined1 *param_53,undefined2 param_54,undefined1 *param_55,undefined2 param_56,
                 undefined1 *param_57,undefined2 param_58,undefined1 *param_59,undefined2 param_60,
                 undefined1 *param_61,undefined2 param_62,undefined1 *param_63,undefined2 param_64,
                 undefined1 *param_65,undefined2 param_66,undefined1 *param_67,undefined2 param_68,
                 undefined1 *param_69,undefined2 param_70,undefined1 *param_71,undefined2 param_72,
                 undefined1 *param_73,undefined2 param_74,undefined1 *param_75,undefined2 param_76,
                 undefined1 *param_77,undefined2 param_78,undefined1 *param_79,undefined2 param_80,
                 undefined1 *param_81,undefined2 param_82,undefined1 *param_83,undefined2 param_84,
                 undefined1 *param_85,undefined2 param_86,undefined1 *param_87,undefined2 param_88,
                 undefined1 *param_89,undefined2 param_90,undefined1 *param_91,undefined2 param_92,
                 undefined1 *param_93,undefined2 param_94,undefined1 *param_95,undefined2 param_96,
                 undefined1 *param_97,undefined2 param_98,undefined1 *param_99,undefined2 param_100,
                 undefined1 *param_101,undefined2 param_102,undefined1 *param_103,
                 undefined2 param_104,undefined1 *param_105,undefined2 param_106,
                 undefined1 *param_107,undefined2 param_108,undefined1 *param_109,
                 undefined2 param_110,undefined1 *param_111,undefined2 param_112,
                 undefined1 *param_113,undefined2 param_114,undefined1 *param_115,
                 undefined2 param_116,undefined1 *param_117,undefined2 param_118,
                 undefined1 *param_119,undefined2 param_120,undefined1 *param_121,
                 undefined2 param_122,undefined1 *param_123,undefined2 param_124,
                 undefined1 *param_125)

{
  ushort *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  int extraout_EDX;
  
  FUN_00134d30();
  param_3 = &DAT_0001ff10;
  param_4 = 0xc;
  param_5 = &DAT_0001ff20;
  param_6 = 0xd;
  param_7 = &LAB_0001ff30;
  param_8 = 0xe;
  param_9 = &LAB_0001ff90;
  param_10 = 0xf;
  param_11 = 0x1fff0;
  param_12 = 0x10;
  param_13 = 0x20000;
  param_14 = 0x11;
  param_15 = &LAB_00020030;
  param_16 = 0x12;
  param_17 = &LAB_00020040;
  param_18 = 0x13;
  param_19 = &DAT_00020050;
  param_20 = 0x14;
  param_21 = &LAB_00020060;
  param_22 = 0x15;
  param_23 = &LAB_00020070;
  param_24 = 0x16;
  param_25 = &LAB_00020090;
  param_26 = 0x17;
  param_27 = &LAB_000200a0;
  param_28 = 0x18;
  param_29 = &LAB_000200b0;
  param_30 = 0x19;
  param_31 = &LAB_00020020;
  param_32 = 0x1a;
  param_33 = &LAB_00020010;
  param_34 = 0x7d1;
  param_35 = &LAB_00020110;
  param_36 = 0x7d2;
  param_37 = &LAB_00020130;
  param_38 = 0x7d3;
  param_39 = &LAB_00020140;
  param_40 = 0x7d4;
  param_41 = &LAB_00020160;
  param_42 = 0x7d5;
  param_43 = &LAB_00020170;
  param_44 = 0x7d6;
  param_45 = &LAB_00020180;
  param_46 = 0x1e;
  param_47 = &LAB_000202f0;
  param_48 = 0x1f;
  param_49 = &LAB_00020360;
  param_50 = 0x20;
  param_51 = &LAB_000203a0;
  param_52 = 0x21;
  param_53 = &LAB_000203e0;
  param_54 = 0x22;
  param_55 = &LAB_00020440;
  param_56 = 0x23;
  param_57 = &LAB_00020470;
  param_58 = 0x24;
  param_59 = &LAB_000204d0;
  param_60 = 0x25;
  param_61 = &LAB_00020540;
  param_62 = 0x26;
  param_63 = &LAB_00020550;
  param_64 = 0x27;
  param_65 = &LAB_00020570;
  param_66 = 0x28;
  param_67 = &LAB_00020590;
  param_68 = 0x29;
  param_69 = &LAB_000204b0;
  param_70 = 0x2a;
  param_71 = &LAB_00020620;
  param_72 = 0x2b;
  param_73 = &LAB_00020630;
  param_74 = 0x2d;
  param_75 = &LAB_00020660;
  param_76 = 0x2e;
  param_77 = &LAB_00020690;
  param_78 = 0x2f;
  param_79 = &LAB_000206c0;
  param_80 = 0x30;
  param_81 = &LAB_00020720;
  param_82 = 0x32;
  param_83 = &LAB_00020950;
  param_84 = 0x33;
  param_85 = &LAB_000209b0;
  param_86 = 0x34;
  param_87 = &LAB_00020a10;
  param_88 = 0x35;
  param_89 = &LAB_00020a70;
  param_90 = 0x36;
  param_91 = &LAB_00020ad0;
  param_92 = 0x37;
  param_93 = &LAB_00020b30;
  param_94 = 0x38;
  param_95 = &LAB_00020b90;
  param_96 = 0x39;
  param_97 = &LAB_00020d50;
  param_98 = 0x3a;
  param_99 = &LAB_00020da0;
  param_100 = 0x3b;
  param_101 = &LAB_00020df0;
  param_102 = 0x3c;
  param_103 = &LAB_00020e40;
  param_104 = 0x3d;
  param_105 = &LAB_00020e90;
  param_106 = 0x3e;
  param_107 = &LAB_00020eb0;
  param_108 = 0x3f;
  param_109 = &LAB_00020ef0;
  param_110 = 0x40;
  param_111 = &LAB_00020f20;
  param_112 = 0x41;
  param_113 = &LAB_00020f50;
  param_114 = 0x42;
  param_115 = &LAB_00020f80;
  param_116 = 0x43;
  param_117 = &LAB_00020fb0;
  param_118 = 0x44;
  param_119 = &LAB_00020fe0;
  param_120 = 0x45;
  param_121 = &LAB_00021010;
  param_122 = 0x46;
  param_123 = &LAB_00021060;
  param_124 = 0x47;
  param_125 = &LAB_00021120;
  puVar3 = (undefined4 *)(extraout_EDX + 0x44);
  for (iVar4 = 0x815; iVar4 != 0; iVar4 = iVar4 + -1) {
    *puVar3 = 0;
    puVar3 = puVar3 + 1;
  }
  puVar3 = &param_3;
  iVar4 = 0xe2;
  do {
    *(undefined4 *)(extraout_EDX + 0x44 + (uint)*(ushort *)(puVar3 + -3) * 4) = puVar3[-2];
    *(undefined4 *)(extraout_EDX + 0x44 + (uint)*(ushort *)(puVar3 + -1) * 4) = *puVar3;
    *(undefined4 *)(extraout_EDX + 0x44 + (uint)*(ushort *)(puVar3 + 1) * 4) = puVar3[2];
    *(undefined4 *)(extraout_EDX + 0x44 + (uint)*(ushort *)(puVar3 + 3) * 4) = puVar3[4];
    puVar1 = (ushort *)(puVar3 + 5);
    puVar2 = puVar3 + 6;
    puVar3 = puVar3 + 10;
    iVar4 = iVar4 + -1;
    *(undefined4 *)(extraout_EDX + 0x44 + (uint)*puVar1 * 4) = *puVar2;
  } while (iVar4 != 0);
  return;
}


