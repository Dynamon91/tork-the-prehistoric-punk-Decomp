// func FUN_00054cc0 @ 0x00054CC0 (size 0x2F)

int FUN_00054cc0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int in_ECX;
  int *in_EDX;
  
  if ((in_EDX != (int *)0x0) && (piVar1 = in_EDX + in_ECX, in_EDX < piVar1)) {
    piVar2 = in_EDX;
    do {
      if (*piVar2 == *param_1) {
        if (piVar2 < piVar1) {
          return (int)piVar2 - (int)in_EDX >> 2;
        }
        return -1;
      }
      piVar2 = piVar2 + 1;
    } while (piVar2 < piVar1);
  }
  return -1;
}


