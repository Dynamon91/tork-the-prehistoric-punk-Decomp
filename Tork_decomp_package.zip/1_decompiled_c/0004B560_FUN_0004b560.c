// func FUN_0004b560 @ 0x0004B560 (size 0x9C)

wchar_t * FUN_0004b560(wchar_t *param_1,size_t param_2)

{
  uint uVar1;
  wchar_t *__dest;
  int iVar2;
  int iVar3;
  uint uVar4;
  bool bVar5;
  
  iVar2 = DAT_002411d8;
  iVar3 = param_2 * 2 + 0x21;
  iVar3 = FUN_000550f0((int)(iVar3 + (iVar3 >> 0x1f & 0x1fU)) >> 5);
  *(undefined4 *)(&DAT_00002064 + iVar3 * 4 + iVar2) = 0;
  __dest = (wchar_t *)(iVar3 * 0x20 + 0x44 + iVar2);
  _wcsncpy(__dest,param_1,param_2);
  __dest[param_2] = L'\0';
  if (((wchar_t *)(DAT_002411d8 + 0x44U) <= param_1) && (param_1 < &DAT_00002044 + DAT_002411d8)) {
    uVar1 = (int)param_1 + (-0x44 - DAT_002411d8);
    uVar4 = uVar1 & 0x8000001f;
    bVar5 = uVar4 == 0;
    if ((int)uVar4 < 0) {
      bVar5 = (uVar4 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar5) && (iVar3 = (int)(uVar1 + ((int)uVar1 >> 0x1f & 0x1fU)) >> 5, iVar3 != -1)) &&
       (*(int *)(&DAT_00002064 + iVar3 * 4 + DAT_002411d8) == 0)) {
      FUN_00019750();
    }
  }
  return __dest;
}


