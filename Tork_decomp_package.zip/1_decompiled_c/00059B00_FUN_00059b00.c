// func FUN_00059b00 @ 0x00059B00 (size 0x167)

void FUN_00059b00(void)

{
  code *pcVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 *in_EAX;
  int iVar5;
  int iVar6;
  
  iVar4 = DAT_0024120c;
  iVar3 = DAT_00241208;
  pcVar1 = (code *)*in_EAX;
  if (((pcVar1 == (code *)&LAB_0005ef70) || (pcVar1 == FUN_0005edd0)) ||
     (pcVar1 == (code *)&LAB_0005f120)) {
    iVar6 = in_EAX[2];
    if (iVar6 != 0) {
      iVar5 = FUN_00058910();
      if ((iVar5 != -1) &&
         (iVar6 = (*(int *)(iVar4 + iVar5 * 4) - *(int *)(iVar3 + iVar5 * 4)) + iVar6, iVar6 != 0))
      {
        in_EAX[2] = iVar6;
      }
    }
    iVar6 = in_EAX[3];
    if (iVar6 != 0) {
      iVar5 = FUN_00058910();
      if (((iVar5 != -1) && (iVar3 = *(int *)(iVar3 + iVar5 * 4), iVar6 + -8 == iVar3)) &&
         (iVar6 = (*(int *)(iVar4 + iVar5 * 4) - iVar3) + iVar6, iVar6 != 0)) {
        in_EAX[3] = iVar6;
      }
      FUN_000611a0();
      return;
    }
  }
  else if ((pcVar1 == (code *)&LAB_0005f490) || (pcVar1 == (code *)&LAB_0005f620)) {
    iVar6 = in_EAX[2];
    if (iVar6 != 0) {
      iVar5 = FUN_00058910();
      if (((iVar5 != -1) && (iVar2 = *(int *)(iVar3 + iVar5 * 4), iVar6 + -8 == iVar2)) &&
         (iVar6 = (*(int *)(iVar4 + iVar5 * 4) - iVar2) + iVar6, iVar6 != 0)) {
        in_EAX[2] = iVar6;
      }
    }
    iVar6 = in_EAX[3];
    if (iVar6 != 0) {
      iVar5 = FUN_00058910();
      if (((iVar5 != -1) && (iVar3 = *(int *)(iVar3 + iVar5 * 4), iVar6 + -8 == iVar3)) &&
         (iVar6 = (*(int *)(iVar4 + iVar5 * 4) - iVar3) + iVar6, iVar6 != 0)) {
        in_EAX[3] = iVar6;
      }
      FUN_00059970();
      return;
    }
  }
  else if (pcVar1 == (code *)&LAB_0005f840) {
    FUN_0005a410();
  }
  else if ((pcVar1 != FUN_0005f1f0) && (pcVar1 != (code *)&LAB_0005f310)) {
    if (pcVar1 == (code *)&LAB_00076f20) {
      FUN_0005a430();
      return;
    }
    FUN_00018930();
    FUN_00018930();
    FUN_00018930();
    return;
  }
  return;
}


