// func FUN_0001fce0 @ 0x0001FCE0 (size 0x2E)

void FUN_0001fce0(float *param_1,float *param_2)

{
  undefined8 uVar1;
  undefined8 uVar2;
  float *in_ECX;
  
  uVar1 = *(undefined8 *)(param_1 + 1);
  uVar2 = *(undefined8 *)(param_2 + 1);
  *in_ECX = *param_1 - *param_2;
  *(ulonglong *)(in_ECX + 1) =
       CONCAT44((float)((ulonglong)uVar1 >> 0x20) - (float)((ulonglong)uVar2 >> 0x20),
                (float)uVar1 - (float)uVar2);
  return;
}


