// func FUN_0005b430 @ 0x0005B430 (size 0x4B)

void FUN_0005b430(void)

{
  undefined4 *puVar1;
  undefined4 *in_EAX;
  uint in_ECX;
  int in_EDX;
  uint local_4;
  
  if ((int)in_ECX < (int)(uint)*(ushort *)(in_EDX + 10)) {
    puVar1 = (undefined4 *)(*(int *)(in_EDX + 4) + (in_ECX & 0xffff) * 0xc);
    *in_EAX = *puVar1;
    in_EAX[1] = puVar1[1];
    in_EAX[2] = puVar1[2];
    return;
  }
  *in_EAX = 0xffffffff;
  in_EAX[1] = 0;
  local_4 = local_4 & 0xffffff00;
  in_EAX[2] = local_4;
  return;
}


