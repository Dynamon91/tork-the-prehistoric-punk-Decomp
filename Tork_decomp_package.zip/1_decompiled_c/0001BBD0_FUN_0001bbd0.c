// func FUN_0001bbd0 @ 0x0001BBD0 (size 0xF0)

byte * FUN_0001bbd0(int param_1)

{
  byte *pbVar1;
  undefined4 uVar2;
  byte *pbVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  byte *local_c;
  int local_8;
  
  pbVar1 = (byte *)FUN_0001bb50();
  local_8 = 0;
  if (*(char *)(param_1 + 1) != '\0') {
    local_c = pbVar1 + 0x38;
    piVar7 = (int *)(param_1 + 8);
    do {
      FUN_0001c200(*piVar7);
      uVar5 = *(uint *)(*piVar7 + 8);
      puVar8 = (undefined4 *)piVar7[6];
      puVar9 = *(undefined4 **)(local_c + -0x18);
      for (uVar4 = uVar5 >> 2; uVar4 != 0; uVar4 = uVar4 - 1) {
        *puVar9 = *puVar8;
        puVar8 = puVar8 + 1;
        puVar9 = puVar9 + 1;
      }
      for (uVar5 = uVar5 & 3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *(undefined1 *)puVar9 = *(undefined1 *)puVar8;
        puVar8 = (undefined4 *)((int)puVar8 + 1);
        puVar9 = (undefined4 *)((int)puVar9 + 1);
      }
      if (piVar7[0xc] != 0) {
        uVar2 = FUN_0001ced0(*(undefined4 *)(*(int *)(((int)pbVar1 - param_1) + (int)piVar7) + 0x1c)
                            );
        *(undefined4 *)local_c = uVar2;
      }
      local_8 = local_8 + 1;
      local_c = local_c + 4;
      piVar7 = piVar7 + 1;
    } while (local_8 < (int)(uint)*(byte *)(param_1 + 1));
  }
  *(undefined2 *)(pbVar1 + 2) = *(undefined2 *)(param_1 + 2);
  *(undefined2 *)(pbVar1 + 4) = *(undefined2 *)(param_1 + 4);
  pbVar1[0x68] = *(byte *)(param_1 + 0x68);
  iVar6 = 0;
  if (*pbVar1 != 0) {
    pbVar3 = pbVar1 + 0x6a;
    do {
      *(undefined4 *)pbVar3 = *(undefined4 *)(pbVar3 + (param_1 - (int)pbVar1));
      *(undefined4 *)(pbVar3 + 4) = *(undefined4 *)(pbVar3 + (param_1 - (int)pbVar1) + 4);
      iVar6 = iVar6 + 1;
      pbVar3 = pbVar3 + 8;
    } while (iVar6 < (int)(uint)*pbVar1);
  }
  return pbVar1;
}


