// func FUN_00057f60 @ 0x00057F60 (size 0xB0)

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

int FUN_00057f60(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  undefined1 local_10 [12];
  undefined4 local_4;
  
  local_4 = DAT_002264b0;
  while( true ) {
    iVar2 = 0;
    LOCK();
    if (DAT_0022aab8 == 0) {
      DAT_0022aab8 = 1;
    }
    else {
      iVar2 = DAT_0022aab8;
    }
    UNLOCK();
    while (iVar2 != 0) {
      FUN_0012ec0e(0);
      iVar2 = 0;
      LOCK();
      if (DAT_0022aab8 == 0) {
        DAT_0022aab8 = 1;
      }
      else {
        iVar2 = DAT_0022aab8;
      }
      UNLOCK();
    }
    iVar2 = FUN_000568c0(param_1);
    LOCK();
    DAT_0022aab8 = 0;
    UNLOCK();
    if (iVar2 != 0) break;
    cVar1 = FUN_000581b0();
    if (cVar1 == '\0') {
      iVar2 = FUN_00073a30(param_1);
      if ((iVar2 == 0) || (*(uint *)(iVar2 + -4) = *(uint *)(iVar2 + -4) | 0x80000000, iVar2 == 0))
      {
        DAT_002411f4 = 1;
        __itoa(param_1,local_10,10);
        FUN_00057680();
        FUN_00075680();
      }
      return iVar2;
    }
  }
  DAT_0022aab8 = 0;
  return iVar2;
}


