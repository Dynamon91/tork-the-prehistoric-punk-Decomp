// func FUN_0005a410 @ 0x0005A410 (size 0x20)

void FUN_0005a410(void)

{
  int iVar1;
  int *unaff_ESI;
  
  if (*unaff_ESI != 0) {
    iVar1 = FUN_00058980(*unaff_ESI);
    if (iVar1 != 0) {
      *unaff_ESI = iVar1;
    }
    FUN_00059970();
  }
  return;
}


