// func FUN_000485a0 @ 0x000485A0 (size 0x70)

void FUN_000485a0(char param_1)

{
  char *pcVar1;
  int iVar2;
  char *unaff_ESI;
  uint local_4;
  
  if ((*unaff_ESI != '\0') && (local_4 = FUN_0005aba0(), local_4 != 0xffffffff)) {
    local_4 = local_4 >> 0x17;
    iVar2 = local_4 * 0x10;
    if (param_1 != '\0') {
      if (*(int *)(unaff_ESI + iVar2 + 0x1808) == -1) {
        FUN_00049ab0(&local_4);
      }
      pcVar1 = unaff_ESI + iVar2 + 0x180c;
      pcVar1[0] = -1;
      pcVar1[1] = -1;
      pcVar1[2] = -1;
      pcVar1[3] = -1;
      return;
    }
    if (*(int *)(unaff_ESI + (int)(&DAT_00001808 + iVar2)) != -1) {
      *(undefined4 *)(unaff_ESI + iVar2 + 0x180c) = *(undefined4 *)(unaff_ESI + 0x2828);
    }
  }
  return;
}


