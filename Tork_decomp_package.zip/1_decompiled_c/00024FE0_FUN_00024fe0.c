// func FUN_00024fe0 @ 0x00024FE0 (size 0x4D)

void FUN_00024fe0(void)

{
  char cVar1;
  int iVar2;
  undefined4 *in_EDX;
  int unaff_EBX;
  undefined4 *puVar3;
  
  if ((*(byte *)(unaff_EBX + 4) & 2) != 0) {
    puVar3 = *(undefined4 **)(unaff_EBX + 0x10);
    for (iVar2 = 0x10; iVar2 != 0; iVar2 = iVar2 + -1) {
      *puVar3 = *in_EDX;
      in_EDX = in_EDX + 1;
      puVar3 = puVar3 + 1;
    }
  }
  if ((*(uint *)(unaff_EBX + 4) >> 7 & 1) != 0) {
    cVar1 = FUN_00028790();
    if (cVar1 != '\0') {
      FUN_000e47c0(**(uint **)(unaff_EBX + 0x1c) | 0x800);
      return;
    }
    FUN_000e47c0(**(uint **)(unaff_EBX + 0x1c) & 0xfffff7ff);
  }
  return;
}


