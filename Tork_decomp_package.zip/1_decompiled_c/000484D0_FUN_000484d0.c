// func FUN_000484d0 @ 0x000484D0 (size 0xD0)

int FUN_000484d0(void)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  char *unaff_EDI;
  
  if (*unaff_EDI == '\0') {
    return 0;
  }
  iVar1 = 0;
  uVar2 = 0;
  piVar4 = (int *)(unaff_EDI + 0x1818);
  do {
    if (piVar4[-4] != -1) {
      if ((int)uVar2 < (int)(uint)*(ushort *)(*(int *)(unaff_EDI + 4) + 10)) {
        iVar3 = *(int *)(*(int *)(*(int *)(unaff_EDI + 4) + 4) + (uVar2 & 0xffff) * 4);
      }
      else {
        iVar3 = 0;
      }
      iVar1 = iVar1 + (uint)*(ushort *)(iVar3 + 10);
    }
    if (*piVar4 != -1) {
      if ((int)(uVar2 + 1) < (int)(uint)*(ushort *)(*(int *)(unaff_EDI + 4) + 10)) {
        iVar3 = *(int *)(*(int *)(*(int *)(unaff_EDI + 4) + 4) + (uVar2 + 1 & 0xffff) * 4);
      }
      else {
        iVar3 = 0;
      }
      iVar1 = iVar1 + (uint)*(ushort *)(iVar3 + 10);
    }
    if (piVar4[4] != -1) {
      if ((int)(uVar2 + 2) < (int)(uint)*(ushort *)(*(int *)(unaff_EDI + 4) + 10)) {
        iVar3 = *(int *)(*(int *)(*(int *)(unaff_EDI + 4) + 4) + (uVar2 + 2 & 0xffff) * 4);
      }
      else {
        iVar3 = 0;
      }
      iVar1 = iVar1 + (uint)*(ushort *)(iVar3 + 10);
    }
    if (piVar4[8] != -1) {
      if ((int)(uVar2 + 3) < (int)(uint)*(ushort *)(*(int *)(unaff_EDI + 4) + 10)) {
        iVar3 = *(int *)(*(int *)(*(int *)(unaff_EDI + 4) + 4) + (uVar2 + 3 & 0xffff) * 4);
      }
      else {
        iVar3 = 0;
      }
      iVar1 = iVar1 + (uint)*(ushort *)(iVar3 + 10);
    }
    uVar2 = uVar2 + 4;
    piVar4 = piVar4 + 0x10;
  } while ((int)uVar2 < 0x100);
  return iVar1;
}


