// func FUN_00043810 @ 0x00043810 (size 0x5F)

void FUN_00043810(ushort *param_1)

{
  undefined2 *puVar1;
  ushort uVar2;
  ushort uVar3;
  uint uVar4;
  ushort *unaff_EBX;
  int unaff_ESI;
  ushort unaff_DI;
  
  uVar4 = (uint)unaff_DI;
  uVar2 = *(ushort *)(unaff_ESI + 0xc + uVar4 * 8);
  uVar3 = *(ushort *)(unaff_ESI + 0xe + uVar4 * 8);
  puVar1 = (undefined2 *)(unaff_ESI + 0xc + uVar4 * 8);
  if (uVar2 == 0xffff) {
    *param_1 = uVar3;
  }
  else {
    *(ushort *)(unaff_ESI + 0xe + (uint)uVar2 * 8) = uVar3;
  }
  if (uVar3 != 0xffff) {
    *(ushort *)(unaff_ESI + 0xc + (uint)uVar3 * 8) = uVar2;
  }
  if (*unaff_EBX != 0xffff) {
    *(ushort *)(unaff_ESI + 0xc + (uint)*unaff_EBX * 8) = unaff_DI;
  }
  *puVar1 = 0xffff;
  puVar1[1] = *unaff_EBX;
  *unaff_EBX = unaff_DI;
  return;
}


