// func FUN_00054e20 @ 0x00054E20 (size 0x27)

void FUN_00054e20(float param_1)

{
  float *in_EAX;
  float *in_ECX;
  float *in_EDX;
  
  *in_EDX = param_1 * *in_EAX + *in_ECX;
  in_EDX[1] = param_1 * in_EAX[1] + in_ECX[1];
  in_EDX[2] = param_1 * in_EAX[2] + in_ECX[2];
  return;
}


