// func FUN_000593d0 @ 0x000593D0 (size 0x23B)

void FUN_000593d0(void)

{
  bool bVar1;
  int iVar2;
  int *in_ECX;
  int iVar3;
  int *piVar4;
  int local_40;
  int local_3c;
  int aiStack_38 [6];
  undefined1 auStack_20 [12];
  uint uStack_14;
  
  local_3c = 0;
  local_40 = 0;
  iVar3 = 0;
LAB_000593f0:
  do {
    while( true ) {
      do {
        iVar2 = (**(code **)(*in_ECX + 0x2c))(0xffffffff);
      } while (iVar2 != 0);
      FUN_0012ebe2(in_ECX[6],0xffffffff);
      if (in_ECX[4] == 0) break;
      if (*(int *)(in_ECX[1] + in_ECX[2] * 4) == 0) {
        (**(code **)(*in_ECX + 0x40))(0);
      }
      iVar2 = in_ECX[2] + 1;
      in_ECX[2] = iVar2;
      if (in_ECX[5] <= iVar2) {
        in_ECX[2] = iVar2 - in_ECX[5];
      }
      in_ECX[4] = in_ECX[4] + -1;
      in_ECX[0xd] = in_ECX[0xd] + -1;
      if (in_ECX[0xd] != 0) break;
      FUN_0012e776(in_ECX[7]);
      FUN_0012e945(in_ECX[6]);
    }
    if (*(char *)((int)in_ECX + 0x30ad) == '\0') {
      bVar1 = false;
      if (((char)in_ECX[0xc2b] != '\0') && (FUN_0013f9a8(auStack_20), uStack_14 < 0x180000)) {
        if ((in_ECX[0x1b] == 0) && (in_ECX[0x25] == 0)) {
          FUN_0012e945(in_ECX[6]);
          (**(code **)(*in_ECX + 0x20))();
          goto LAB_000593f0;
        }
        bVar1 = true;
      }
      FUN_00058c30();
      piVar4 = aiStack_38;
      if (((bVar1) || (in_ECX[0x16] == 0)) && (in_ECX[0x1b] == 0)) {
        if ((bVar1) || ((iVar2 = in_ECX[0x20], iVar2 == 0 && (local_3c - iVar3 < 1)))) {
          if (in_ECX[0x25] != 0) goto LAB_00059586;
        }
        else if (local_3c - iVar3 < 1) {
          if (iVar2 < 0x40) goto LAB_00059586;
          if (0x1ff < iVar2) {
            iVar2 = 0x200;
          }
          iVar3 = iVar2;
          if (0 < iVar2) {
            do {
              FUN_00058ac0();
              iVar3 = iVar3 + -1;
            } while (iVar3 != 0);
          }
          piVar4 = in_ECX + 0x2b;
          local_40 = 1;
          local_3c = iVar2;
        }
        else {
          local_40 = iVar3 + 1;
          piVar4 = in_ECX + iVar3 * 6 + 0x2b;
        }
      }
      else {
LAB_00059586:
        FUN_00058ac0();
      }
      iVar3 = in_ECX[0xd];
      in_ECX[0xd] = iVar3 + -1;
      if (iVar3 + -1 == 0) {
        FUN_0012e776(in_ECX[7]);
      }
      FUN_0012e945(in_ECX[6]);
      FUN_000590b0();
      in_ECX[0xe] = in_ECX[0xe] + 1;
      FUN_00058c80();
      FUN_0012c0be(*piVar4);
      *piVar4 = 0;
      piVar4[5] = 0;
      piVar4[3] = 0;
      in_ECX[0x10] = (-(uint)((piVar4[4] & 0xffffffU) < 0x400) & 0xfffffffc) + 5 + in_ECX[0x10];
      if (0x4b < (uint)in_ECX[0x10]) {
        (**(code **)(*in_ECX + 0x20))();
      }
      iVar3 = local_40;
      goto LAB_000593f0;
    }
    FUN_0012e945(in_ECX[6]);
    (**(code **)(*in_ECX + 0x20))();
  } while( true );
}


