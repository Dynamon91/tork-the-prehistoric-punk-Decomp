// func FUN_0004c480 @ 0x0004C480 (size 0x54)

void FUN_0004c480(undefined4 *param_1)

{
  ushort in_AX;
  int iVar1;
  int in_EDX;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)((uint)*(ushort *)(in_EDX + 10) * 0x68 + *(int *)(in_EDX + 0xc));
  for (iVar1 = 0x1a; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar2 = *param_1;
    param_1 = param_1 + 1;
    puVar2 = puVar2 + 1;
  }
  if (in_AX != 0xffff) {
    *(undefined2 *)((uint)in_AX * 0x68 + 100 + *(int *)(in_EDX + 0xc)) =
         *(undefined2 *)(in_EDX + 10);
  }
  *(undefined2 *)((uint)*(ushort *)(in_EDX + 10) * 0x68 + 100 + *(int *)(in_EDX + 0xc)) = 0xffff;
  *(short *)(in_EDX + 10) = *(short *)(in_EDX + 10) + 1;
  return;
}


