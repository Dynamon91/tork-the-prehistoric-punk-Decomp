// func FUN_00023df0 @ 0x00023DF0 (size 0x46)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00023df0(float param_1)

{
  if (param_1 <= _DAT_0020e010) {
    FUN_00142480();
    return;
  }
  FUN_00142480();
  return;
}


