// func FUN_0004d5e0 @ 0x0004D5E0 (size 0xB9)

int FUN_0004d5e0(undefined *param_1)

{
  int iVar1;
  uint uVar2;
  bool bVar3;
  int local_4;
  
  local_4 = 0;
  FUN_000e9030(&local_4,param_1,DAT_00241704,DAT_00241701,DAT_00241708,DAT_0024170c,DAT_00241710,
               DAT_00241702,&DAT_00241714,0,0);
  iVar1 = local_4;
  FUN_000dea30(*(uint *)(local_4 + 4) | 0x200);
  if (((undefined *)(DAT_002411d8 + 0x44) <= param_1) && (param_1 < &DAT_00002044 + DAT_002411d8)) {
    param_1 = param_1 + (-0x44 - DAT_002411d8);
    uVar2 = (uint)param_1 & 0x8000001f;
    bVar3 = uVar2 == 0;
    if ((int)uVar2 < 0) {
      bVar3 = (uVar2 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar3) && ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5 != -1)) &&
       (*(int *)(&DAT_00002064 +
                ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5) * 4 + DAT_002411d8) == 0)) {
      FUN_00019750();
    }
  }
  return iVar1;
}


