// func FUN_00023a70 @ 0x00023A70 (size 0x4B)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00023a70(void)

{
  float fVar1;
  float fVar2;
  char cVar3;
  float *unaff_ESI;
  float *unaff_EDI;
  float10 fVar4;
  
  cVar3 = FUN_00023ad0();
  if (cVar3 == '\0') {
    fVar4 = (float10)FUN_00021640();
    fVar4 = SQRT((float10)_DAT_0020df98 / fVar4);
    fVar1 = unaff_ESI[1];
    fVar2 = unaff_ESI[2];
    *unaff_EDI = (float)(fVar4 * (float10)*unaff_ESI);
    unaff_EDI[1] = (float)(fVar4 * (float10)fVar1);
    unaff_EDI[2] = (float)(fVar4 * (float10)fVar2);
  }
  return;
}


