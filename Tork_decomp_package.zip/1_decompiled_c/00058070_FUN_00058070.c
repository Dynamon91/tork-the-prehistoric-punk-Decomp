// func FUN_00058070 @ 0x00058070 (size 0xB7)

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

int FUN_00058070(void)

{
  char cVar1;
  int iVar2;
  int in_ECX;
  
  if ((in_ECX != 0) && (*(int *)(in_ECX + -4) < 0)) {
    iVar2 = FUN_00058160();
    return iVar2;
  }
  while( true ) {
    iVar2 = 0;
    LOCK();
    if (DAT_0022aab8 == 0) {
      DAT_0022aab8 = 1;
    }
    else {
      iVar2 = DAT_0022aab8;
    }
    UNLOCK();
    while (iVar2 != 0) {
      FUN_0012ec0e(0);
      iVar2 = 0;
      LOCK();
      if (DAT_0022aab8 == 0) {
        DAT_0022aab8 = 1;
      }
      else {
        iVar2 = DAT_0022aab8;
      }
      UNLOCK();
    }
    if (in_ECX == 0) {
      iVar2 = FUN_000568c0();
    }
    else {
      iVar2 = FUN_00056ef0(in_ECX);
    }
    LOCK();
    DAT_0022aab8 = 0;
    UNLOCK();
    if (iVar2 != 0) break;
    cVar1 = FUN_000581b0();
    in_ECX = 0;
    if (cVar1 == '\0') {
      __itoa();
      FUN_00057680();
      FUN_00075680();
      return 0;
    }
  }
  DAT_0022aab8 = 0;
  return iVar2;
}


