// func FUN_0001aa20 @ 0x0001AA20 (size 0x4D)

uint FUN_0001aa20(void)

{
  int in_EAX;
  uint uVar1;
  int in_ECX;
  int *piVar2;
  uint uVar3;
  
  uVar3 = 0;
  piVar2 = (int *)(in_ECX + 0xc);
  do {
    if (((*piVar2 != 0) && (1 < (uint)piVar2[1])) && (in_EAX != 0)) {
      uVar1 = FUN_00079920();
      if (uVar1 != 0xffffffff) {
        return uVar3 << 0x17 | uVar1;
      }
    }
    uVar3 = uVar3 + 1;
    piVar2 = piVar2 + 6;
  } while (uVar3 < 0x100);
  return 0xffffffff;
}


