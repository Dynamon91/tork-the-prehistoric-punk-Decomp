// func FUN_0001bb50 @ 0x0001BB50 (size 0x71)

void FUN_0001bb50(void)

{
  byte *pbVar1;
  byte unaff_BL;
  
  pbVar1 = (byte *)FUN_00057f60((uint)unaff_BL * 8 + 0x6c);
  pbVar1[2] = 0;
  pbVar1[3] = 0;
  pbVar1[4] = 0;
  pbVar1[5] = 0;
  pbVar1[1] = 0;
  pbVar1[0x68] = 0;
  pbVar1[0x20] = 0;
  pbVar1[0x21] = 0;
  pbVar1[0x22] = 0;
  pbVar1[0x23] = 0;
  pbVar1[0x38] = 0;
  pbVar1[0x39] = 0;
  pbVar1[0x3a] = 0;
  pbVar1[0x3b] = 0;
  pbVar1[8] = 0;
  pbVar1[9] = 0;
  pbVar1[10] = 0;
  pbVar1[0xb] = 0;
  pbVar1[0x24] = 0;
  pbVar1[0x25] = 0;
  pbVar1[0x26] = 0;
  pbVar1[0x27] = 0;
  pbVar1[0x3c] = 0;
  pbVar1[0x3d] = 0;
  pbVar1[0x3e] = 0;
  pbVar1[0x3f] = 0;
  pbVar1[0xc] = 0;
  pbVar1[0xd] = 0;
  pbVar1[0xe] = 0;
  pbVar1[0xf] = 0;
  pbVar1[0x28] = 0;
  pbVar1[0x29] = 0;
  pbVar1[0x2a] = 0;
  pbVar1[0x2b] = 0;
  pbVar1[0x40] = 0;
  pbVar1[0x41] = 0;
  pbVar1[0x42] = 0;
  pbVar1[0x43] = 0;
  pbVar1[0x10] = 0;
  pbVar1[0x11] = 0;
  pbVar1[0x12] = 0;
  pbVar1[0x13] = 0;
  pbVar1[0x2c] = 0;
  pbVar1[0x2d] = 0;
  pbVar1[0x2e] = 0;
  pbVar1[0x2f] = 0;
  pbVar1[0x44] = 0;
  pbVar1[0x45] = 0;
  pbVar1[0x46] = 0;
  pbVar1[0x47] = 0;
  pbVar1[0x14] = 0;
  pbVar1[0x15] = 0;
  pbVar1[0x16] = 0;
  pbVar1[0x17] = 0;
  pbVar1[0x30] = 0;
  pbVar1[0x31] = 0;
  pbVar1[0x32] = 0;
  pbVar1[0x33] = 0;
  pbVar1[0x48] = 0;
  pbVar1[0x49] = 0;
  pbVar1[0x4a] = 0;
  pbVar1[0x4b] = 0;
  pbVar1[0x18] = 0;
  pbVar1[0x19] = 0;
  pbVar1[0x1a] = 0;
  pbVar1[0x1b] = 0;
  pbVar1[0x34] = 0;
  pbVar1[0x35] = 0;
  pbVar1[0x36] = 0;
  pbVar1[0x37] = 0;
  pbVar1[0x4c] = 0;
  pbVar1[0x4d] = 0;
  pbVar1[0x4e] = 0;
  pbVar1[0x4f] = 0;
  pbVar1[0x1c] = 0;
  pbVar1[0x1d] = 0;
  pbVar1[0x1e] = 0;
  pbVar1[0x1f] = 0;
  pbVar1[6] = 0;
  pbVar1[7] = 0;
  pbVar1[0x69] = DAT_002419e4;
  DAT_002419e4 = DAT_002419e4 + 1;
  *pbVar1 = unaff_BL;
  return;
}


