// func FUN_00021d50 @ 0x00021D50 (size 0x77)

void FUN_00021d50(void)

{
  int iVar1;
  ushort in_AX;
  int in_ECX;
  ushort in_DX;
  uint uVar2;
  uint uVar3;
  
  uVar3 = (uint)in_DX;
  if ((in_AX < 0x100) && (iVar1 = *(int *)(in_ECX + 4 + (uint)in_AX * 4), iVar1 != 0)) {
    FUN_00021b70();
    if (in_DX != 0) {
      do {
        FUN_00065930();
        uVar3 = uVar3 - 1;
      } while (uVar3 != 0);
    }
    FUN_00064de0();
    FUN_000655b0(iVar1);
    uVar3 = 0;
    *(undefined4 *)(iVar1 + 0x24) = 0;
    if (*(short *)(iVar1 + 0x1e) != 0) {
      do {
        uVar2 = uVar3 & 0xffff;
        uVar3 = uVar3 + 1;
        *(float *)(iVar1 + 0x24) =
             *(float *)(*(int *)(iVar1 + 0x18) + uVar2 * 4) + *(float *)(iVar1 + 0x24);
      } while ((int)uVar3 < (int)(uint)*(ushort *)(iVar1 + 0x1e));
    }
  }
  return;
}


