// func FUN_00019970 @ 0x00019970 (size 0xBC)

void FUN_00019970(void)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *in_EDX;
  undefined4 *puVar4;
  
  in_EDX[0x11c4] = 0xffffffff;
  *(undefined2 *)((int)in_EDX + 0x471a) = 0xffff;
  in_EDX[0x11cb] = 0xffffffff;
  in_EDX[0x11c3] = 0xffffffff;
  in_EDX[0x11c2] = in_EDX + 0x11c4;
  in_EDX[0x1c0] = 0;
  *(undefined1 *)(in_EDX + 0x80) = 0;
  *(undefined1 *)((int)in_EDX + 0x201) = 0;
  *(undefined1 *)((int)in_EDX + 0x202) = 0;
  *(undefined1 *)((int)in_EDX + 0x203) = 0;
  in_EDX[0x11c5] = 0;
  *(undefined1 *)(in_EDX + 0x11c9) = 0;
  *(undefined1 *)((int)in_EDX + 0x4725) = 0;
  *(undefined1 *)((int)in_EDX + 0x4726) = 0;
  *(undefined1 *)((int)in_EDX + 0x4727) = 0;
  *(undefined1 *)((int)in_EDX + 0x472a) = 0;
  in_EDX[0x11c1] = 1;
  in_EDX[0x11c7] = 0xbf800000;
  puVar4 = in_EDX + 0x11ce;
  for (iVar3 = 0x40; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
  }
  in_EDX[0x11cd] = 0;
  puVar4 = in_EDX;
  for (iVar3 = 0x80; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
  }
  piVar2 = &DAT_00225f90;
  do {
    iVar3 = *piVar2;
    piVar1 = piVar2 + 1;
    piVar2 = piVar2 + 2;
    in_EDX[iVar3] = *piVar1;
  } while ((int)piVar2 < 0x225fe8);
  return;
}


