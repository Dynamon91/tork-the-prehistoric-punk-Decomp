// func FUN_00049ab0 @ 0x00049AB0 (size 0x29)

void FUN_00049ab0(undefined4 *param_1)

{
  int *in_EAX;
  int iVar1;
  
  *(undefined4 *)(*in_EAX + in_EAX[2] * 4) = *param_1;
  iVar1 = in_EAX[2] + 1;
  in_EAX[2] = iVar1;
  if (in_EAX[4] <= iVar1) {
    in_EAX[2] = iVar1 - in_EAX[4];
  }
  in_EAX[3] = in_EAX[3] + 1;
  return;
}


