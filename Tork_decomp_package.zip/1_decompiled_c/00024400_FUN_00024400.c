// func FUN_00024400 @ 0x00024400 (size 0x68)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_00024400(float param_1)

{
  float fVar1;
  uint uVar2;
  uint uVar3;
  
  if ((int)param_1 < 0) {
    uVar3 = -((uint)(ABS(param_1) + _DAT_0020e014) & 0xb4ffffff);
  }
  else {
    uVar3 = (uint)(param_1 + _DAT_0020e014) & 0xb4ffffff;
  }
  fVar1 = (float)(int)uVar3;
  if ((int)uVar3 < 0) {
    fVar1 = fVar1 + _DAT_0020dfb4;
  }
  uVar2 = uVar3 - 1;
  if (fVar1 <= param_1) {
    uVar2 = uVar3;
  }
  return uVar2;
}


