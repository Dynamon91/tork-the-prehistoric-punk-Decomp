// func FUN_000496e0 @ 0x000496E0 (size 0x2C)

undefined4 FUN_000496e0(void)

{
  undefined4 local_8;
  int local_4;
  
  FUN_0012ed27(&DAT_0020882c,&local_8,0,0);
  if (local_4 == 0) {
    return local_8;
  }
  return 0xffffffff;
}


