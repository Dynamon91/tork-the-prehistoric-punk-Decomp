// func FUN_00052910 @ 0x00052910 (size 0x5F)

ushort FUN_00052910(undefined4 param_1,float param_2,ushort param_3,int param_4,int param_5,
                   int param_6)

{
  ushort uVar1;
  float10 fVar2;
  
  uVar1 = 0;
  if (param_3 != 0) {
    do {
      fVar2 = (float10)FUN_00024070(param_5 + (uint)uVar1 * 0xc);
      if (SQRT(fVar2) < (float10)param_2 + (float10)*(float *)(param_6 + (uint)uVar1 * 4)) {
        return *(ushort *)(param_4 + 2 + (uint)uVar1 * 4) >> 1;
      }
      uVar1 = uVar1 + 1;
    } while (uVar1 < param_3);
  }
  return 0xffff;
}


