// func FUN_000492a0 @ 0x000492A0 (size 0xC)

void FUN_000492a0(void)

{
  FUN_000d87a0();
  return;
}


