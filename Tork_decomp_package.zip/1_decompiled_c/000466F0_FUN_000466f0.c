// func FUN_000466f0 @ 0x000466F0 (size 0x85)

void FUN_000466f0(void)

{
  int iVar1;
  int *piVar2;
  int in_EAX;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  int unaff_ESI;
  
  piVar2 = *(int **)(unaff_ESI + 0x654);
  piVar3 = piVar2;
  if (piVar2 < piVar2 + *(int *)(unaff_ESI + 0x660) * 2) {
    while (piVar4 = piVar3 + 2, *piVar3 != in_EAX) {
      piVar3 = piVar4;
      if (piVar2 + *(int *)(unaff_ESI + 0x660) * 2 <= piVar4) {
        return;
      }
    }
    uVar5 = (int)piVar4 + (-8 - (int)piVar2) >> 3;
    if (uVar5 != 0xffffffff) {
      iVar1 = uVar5 * 8;
      FUN_0010a7c0(DAT_00238834,*(undefined4 *)(iVar1 + *(int *)(unaff_ESI + 0x654)),0);
      if (uVar5 < *(uint *)(unaff_ESI + 0x66c)) {
        *(int *)(unaff_ESI + 0x670) = *(int *)(unaff_ESI + 0x670) + 1;
      }
      *(uint *)(*(int *)(unaff_ESI + 0x654) + iVar1) =
           *(uint *)(*(int *)(unaff_ESI + 0x654) + iVar1) | 1;
      *(int *)(unaff_ESI + 0x65c) = *(int *)(unaff_ESI + 0x65c) + 1;
    }
  }
  return;
}


