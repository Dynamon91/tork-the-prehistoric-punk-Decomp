// func FUN_00025fc0 @ 0x00025FC0 (size 0x56)

void FUN_00025fc0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  
  uVar1 = *param_2;
  uVar2 = param_1[1];
  uVar3 = param_1[2];
  uVar4 = param_2[1];
  uVar5 = param_2[2];
  if ((*(uint *)(*(int *)(DAT_0022a6c4 + 0x14) + 4) >> 9 & 1) != 0) {
    puVar6 = *(undefined4 **)(*(int *)(DAT_0022a6c4 + 0x14) + 0x28);
    *puVar6 = *param_1;
    puVar6[1] = uVar2;
    puVar6[2] = uVar3;
    puVar6[3] = uVar1;
    puVar6[4] = uVar4;
    puVar6[5] = uVar5;
  }
  return;
}


