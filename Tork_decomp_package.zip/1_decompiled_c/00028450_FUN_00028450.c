// func FUN_00028450 @ 0x00028450 (size 0x50)

void FUN_00028450(void)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float *in_EAX;
  float *in_ECX;
  
  fVar1 = *in_ECX;
  fVar2 = in_ECX[1];
  fVar3 = in_ECX[2];
  *in_ECX = fVar1 * *in_EAX + fVar2 * in_EAX[4] + fVar3 * in_EAX[8] + in_EAX[0xc];
  in_ECX[1] = fVar1 * in_EAX[1] + fVar2 * in_EAX[5] + fVar3 * in_EAX[9] + in_EAX[0xd];
  in_ECX[2] = fVar1 * in_EAX[2] + fVar2 * in_EAX[6] + fVar3 * in_EAX[10] + in_EAX[0xe];
  return;
}


