// func FUN_00059f60 @ 0x00059F60 (size 0x49)

void FUN_00059f60(undefined4 *param_1)

{
  int iVar1;
  int in_ECX;
  
  FUN_0012ebe2(*(undefined4 *)(in_ECX + 0x18),0xffffffff);
  *(undefined4 *)(*(int *)(in_ECX + 4) + *(int *)(in_ECX + 0xc) * 4) = *param_1;
  iVar1 = *(int *)(in_ECX + 0xc) + 1;
  *(int *)(in_ECX + 0xc) = iVar1;
  if (*(int *)(in_ECX + 0x14) <= iVar1) {
    *(int *)(in_ECX + 0xc) = iVar1 - *(int *)(in_ECX + 0x14);
  }
  *(int *)(in_ECX + 0x10) = *(int *)(in_ECX + 0x10) + 1;
  FUN_0012e756(*(undefined4 *)(in_ECX + 0x1c));
  FUN_0012e945();
  return;
}


