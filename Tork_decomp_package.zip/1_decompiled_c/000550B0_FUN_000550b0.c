// func FUN_000550b0 @ 0x000550B0 (size 0x30)

int FUN_000550b0(void)

{
  int iVar1;
  int in_EDX;
  int unaff_ESI;
  
  iVar1 = unaff_ESI;
  do {
    iVar1 = iVar1 + 1;
    if (0xff < iVar1) break;
  } while ((*(uint *)(in_EDX + 0x24 + (iVar1 >> 5) * 4) & 1 << ((byte)iVar1 & 0x1f)) != 0);
  return iVar1 - unaff_ESI;
}


