// func FUN_0002a860 @ 0x0002A860 (size 0x66)

uint FUN_0002a860(void)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  uint *in_EAX;
  uint uVar4;
  undefined3 uVar5;
  byte in_CL;
  byte bVar6;
  int *piVar7;
  uint uVar8;
  
  uVar4 = *in_EAX;
  if ((in_CL < *(byte *)(uVar4 + 2)) &&
     (iVar2 = *(int *)(uVar4 + 0xc + (uint)in_CL * 4), iVar2 != 0)) {
    bVar1 = *(byte *)(iVar2 + 4);
    uVar4 = CONCAT31((int3)(uVar4 >> 8),bVar1);
    uVar8 = 0;
    if (bVar1 != 0) {
      do {
        iVar3 = *(int *)(iVar2 + (uVar8 + 2) * 0xc);
        piVar7 = (int *)(iVar3 + 0x10);
        uVar5 = (undefined3)((uint)iVar3 >> 8);
        bVar6 = 0;
        if (*(byte *)(iVar3 + 6) != 0) {
          do {
            if (*(char *)(*piVar7 + 6) == '\x05') {
              return CONCAT31(uVar5,1);
            }
            bVar6 = bVar6 + 1;
            piVar7 = piVar7 + 1;
          } while (bVar6 < *(byte *)(iVar3 + 6));
        }
        uVar4 = CONCAT31(uVar5,bVar1);
        bVar6 = (char)uVar8 + 1;
        uVar8 = (uint)bVar6;
      } while (bVar6 < bVar1);
    }
  }
  return uVar4 & 0xffffff00;
}


