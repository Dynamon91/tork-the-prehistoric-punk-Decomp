// func FUN_00022490 @ 0x00022490 (size 0x40)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00022490(void)

{
  float10 fVar1;
  
  fVar1 = (float10)FUN_00024200();
  if ((float10)_DAT_0020df5c <= fVar1) {
    fVar1 = (float10)FUN_00024150();
    return fVar1;
  }
  fVar1 = (float10)FUN_00024150();
  return -fVar1;
}


