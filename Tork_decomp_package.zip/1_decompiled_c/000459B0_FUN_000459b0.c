// func FUN_000459b0 @ 0x000459B0 (size 0x97)

undefined2 FUN_000459b0(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  undefined2 *puVar4;
  int iVar5;
  uint uVar6;
  
  piVar1 = (int *)*param_1;
  piVar2 = piVar1;
  do {
    piVar3 = piVar1;
    if (piVar1 + param_1[3] <= piVar2) {
      uVar6 = 0xffffffff;
      goto joined_r0x000459e5;
    }
    iVar5 = *piVar2;
    piVar2 = piVar2 + 1;
  } while (iVar5 != param_2);
  uVar6 = (int)piVar2 + (-4 - (int)piVar1) >> 2;
joined_r0x000459e5:
  do {
    if (piVar1 + param_1[3] <= piVar3) {
      iVar5 = -1;
      goto LAB_00045a00;
    }
    iVar5 = *piVar3;
    piVar3 = piVar3 + 1;
  } while (iVar5 != param_3);
  iVar5 = (int)piVar3 + (-4 - (int)piVar1) >> 2;
LAB_00045a00:
  if (((uVar6 & 0xffff) == 0xffffffff) ||
     ((puVar4 = (undefined2 *)FUN_00108610(iVar5), puVar4 == (undefined2 *)0x0 &&
      (puVar4 = (undefined2 *)FUN_00108610(uVar6), puVar4 == (undefined2 *)0x0)))) {
    return 0xffff;
  }
  return *puVar4;
}


