// func FUN_00043ef0 @ 0x00043EF0 (size 0x61)

void FUN_00043ef0(void)

{
  int iVar1;
  ushort in_AX;
  int in_ECX;
  
  if ((in_AX < 0xff) || (in_AX == 0xffff)) {
    iVar1 = (uint)in_AX * 0x68 + in_ECX;
    if (((char)*(byte *)(iVar1 + 0x58) < '\0') && ((*(byte *)(iVar1 + 0x58) & 0x40) == 0)) {
      FUN_00043d10();
      *(undefined1 *)(iVar1 + 0x58) = 0;
      FUN_00043e80(in_ECX + 2);
      *(short *)(in_ECX + 4) = *(short *)(in_ECX + 4) + 1;
      *(undefined1 *)(iVar1 + 0x5a) = 1;
      if (*(int *)(iVar1 + 0x6c) != 0) {
        FUN_000de780();
        *(undefined4 *)(iVar1 + 0x6c) = 0;
      }
    }
  }
  return;
}


