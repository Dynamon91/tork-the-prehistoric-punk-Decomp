// func FUN_000244c0 @ 0x000244C0 (size 0x43)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_000244c0(float param_1)

{
  if ((int)param_1 < 0) {
    return -((uint)(ABS(param_1) + _DAT_0020e014) & 0xb4ffffff);
  }
  return (uint)(param_1 + _DAT_0020e014) & 0xb4ffffff;
}


