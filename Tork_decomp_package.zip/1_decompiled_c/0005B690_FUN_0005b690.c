// func FUN_0005b690 @ 0x0005B690 (size 0x32)

void FUN_0005b690(void)

{
  undefined4 *puVar1;
  int *in_EAX;
  undefined4 *unaff_ESI;
  
  FUN_0005b940();
  puVar1 = (undefined4 *)(*in_EAX + (uint)*(ushort *)((int)in_EAX + 6) * 0xc);
  *puVar1 = *unaff_ESI;
  puVar1[1] = unaff_ESI[1];
  puVar1[2] = unaff_ESI[2];
  *(short *)((int)in_EAX + 6) = *(short *)((int)in_EAX + 6) + 1;
  return;
}


