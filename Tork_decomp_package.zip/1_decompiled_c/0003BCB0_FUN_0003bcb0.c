// func FUN_0003bcb0 @ 0x0003BCB0 (size 0x339)

uint FUN_0003bcb0(uint param_1,int param_2,uint param_3)

{
  byte bVar1;
  ushort uVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  float *pfVar6;
  float *pfVar7;
  uint local_c8;
  float local_a8 [32];
  float local_28;
  float local_24;
  float local_20;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  local_a8[0x12] = 0.0;
  local_a8[10] = 1.0;
  local_a8[5] = 1.0;
  local_a8[0] = 1.0;
  local_a8[0xf] = 1.0;
  local_a8[0xe] = 0.0;
  local_a8[0xd] = 0.0;
  local_a8[0xc] = 0.0;
  local_a8[9] = 0.0;
  local_a8[8] = 0.0;
  local_a8[6] = 0.0;
  local_a8[4] = 0.0;
  local_a8[2] = 0.0;
  local_a8[1] = 0.0;
  local_a8[0xb] = 0.0;
  local_a8[7] = 0.0;
  local_a8[3] = 0.0;
  local_a8[0x10] = 0.0;
  local_c8 = 0;
  local_a8[0x11] = 0.0;
  if ((*(byte *)(param_2 + 8) & 1) != 0) {
    if ((param_1 & 0x10000000) != 0) {
      return param_1;
    }
    uVar2 = *(ushort *)(*(int *)(param_2 + 0x24) + 0x1e);
    local_c8 = (~(param_1 >> 0x1a) & 1) + (param_1 & 0xff);
    if ((*(uint *)(param_2 + 4) >> 0x1e & 1) == 0) {
      for (; local_c8 < uVar2; local_c8 = local_c8 + 1) {
        iVar3 = *(int *)(*(int *)(*(int *)(param_2 + 0x24) + 0x18) + (local_c8 & 0xff) * 4);
        if ((*(uint *)(iVar3 + 4) & param_3) == param_3) {
          if ((*(uint *)(iVar3 + 4) >> 0x1e & 1) == 0) goto LAB_0003bfdc;
          iVar5 = *(int *)(iVar3 + 0x28);
          FUN_000479c0();
          local_14 = *(undefined4 *)(iVar5 + 0x74);
          local_18 = *(undefined4 *)(iVar5 + 0x70);
          local_10 = *(undefined4 *)(iVar5 + 0x78);
          if ((*(byte *)(iVar3 + 4) & 1) != 0) {
            pfVar6 = *(float **)(iVar3 + 0x10);
            if ((*(byte *)(iVar3 + 4) & 2) != 0) {
              pfVar6 = pfVar6 + 0xc;
            }
            local_28 = local_28 + *pfVar6;
            local_24 = local_24 + pfVar6[1];
            local_20 = local_20 + pfVar6[2];
          }
          cVar4 = FUN_00070600();
          if (cVar4 != '\0') goto LAB_0003bfdc;
        }
      }
    }
    else {
      for (; local_c8 < uVar2; local_c8 = local_c8 + 1) {
        iVar3 = *(int *)(*(int *)(*(int *)(param_2 + 0x24) + 0x18) + (local_c8 & 0xff) * 4);
        if ((*(uint *)(iVar3 + 4) & param_3) == param_3) {
          bVar1 = *(byte *)(param_2 + 4);
          pfVar6 = (float *)(*(int *)(param_2 + 0x28) + 0x30);
          pfVar7 = local_a8;
          for (iVar5 = 0x13; iVar5 != 0; iVar5 = iVar5 + -1) {
            *pfVar7 = *pfVar6;
            pfVar6 = pfVar6 + 1;
            pfVar7 = pfVar7 + 1;
          }
          if ((bVar1 & 1) != 0) {
            pfVar6 = *(float **)(param_2 + 0x10);
            if ((bVar1 & 2) != 0) {
              pfVar6 = pfVar6 + 0xc;
            }
            local_a8[0xc] = local_a8[0xc] + *pfVar6;
            local_a8[0xd] = local_a8[0xd] + pfVar6[1];
            local_a8[0xe] = local_a8[0xe] + pfVar6[2];
          }
          if ((*(uint *)(iVar3 + 4) >> 0x1e & 1) == 0) {
            cVar4 = FUN_00070600();
          }
          else {
            iVar5 = *(int *)(iVar3 + 0x28);
            FUN_000479c0();
            local_18 = *(undefined4 *)(iVar5 + 0x70);
            local_14 = *(undefined4 *)(iVar5 + 0x74);
            local_10 = *(undefined4 *)(iVar5 + 0x78);
            if ((*(byte *)(iVar3 + 4) & 1) != 0) {
              pfVar6 = *(float **)(iVar3 + 0x10);
              if ((*(byte *)(iVar3 + 4) & 2) != 0) {
                pfVar6 = pfVar6 + 0xc;
              }
              local_28 = local_28 + *pfVar6;
              local_24 = local_24 + pfVar6[1];
              local_20 = local_20 + pfVar6[2];
            }
            cVar4 = FUN_00070480();
          }
          if (cVar4 != '\0') goto LAB_0003bfdc;
        }
      }
    }
  }
  param_1 = param_1 | 0x10000000;
LAB_0003bfdc:
  return param_1 & 0xfbffff00 | local_c8 & 0xff;
}


