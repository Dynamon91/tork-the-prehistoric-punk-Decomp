// func res_bgl_d_tork_bgl @ 0x00011690 (size 0x80)

/* [ASSET] /bgl D:\TORK.bgl */

void res_bgl_d_tork_bgl(void)

{
  char *pcVar1;
  int iVar2;
  int unaff_ESI;
  
  pcVar1 = (char *)FUN_00134a00();
  if (pcVar1 == (char *)0x0) {
    pcVar1 = s__bgl_D__TORK_bgl_002080d4;
  }
  FUN_00134a86(pcVar1,s__bgl_s_00208098,unaff_ESI + 0xc);
  iVar2 = FUN_00134a00();
  if (iVar2 != 0) {
    *(undefined1 *)(unaff_ESI + 0x96) = 1;
  }
  iVar2 = FUN_00134a00();
  if (iVar2 != 0) {
    *(undefined1 *)(unaff_ESI + 0x97) = 1;
  }
  iVar2 = FUN_00134a00();
  if (iVar2 != 0) {
    *(undefined1 *)(unaff_ESI + 0x98) = 1;
  }
  return;
}


