// func FUN_00057a80 @ 0x00057A80 (size 0x3C2)

uint FUN_00057a80(uint param_1)

{
  bool bVar1;
  bool bVar2;
  undefined4 uVar3;
  uint *puVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  uint *puVar10;
  undefined4 uVar11;
  uint local_30;
  uint local_2c;
  uint local_1c [3];
  uint local_10;
  int local_c;
  
  uVar6 = param_1;
  if (DAT_00241a4c == 0) {
    param_1 = 0x8000000;
    DAT_00241a4c = 0x1000;
    DAT_00241a48 = 0x1000;
  }
  if (DAT_00241a44 == 0) {
    DAT_00241a44 = 0x10000;
    DAT_00241a40 = 0x10000;
  }
  iVar8 = DAT_00241a48;
  if (DAT_0022a73c == (uint *)0x0) {
    uVar11 = 0x14;
    uVar9 = 0;
    uVar3 = FUN_0012c6d6(0,0x14);
    puVar4 = (uint *)FUN_001314ea(uVar3,uVar9,uVar11);
    iVar8 = DAT_00241a48;
    if (puVar4 == (uint *)0x0) {
      return 0xffffffff;
    }
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4[2] = 0;
    puVar4[3] = 0;
    puVar4[4] = (uint)DAT_0022a73c;
    DAT_0022a73c = puVar4;
  }
  if ((int)param_1 < 0) {
    iVar7 = -param_1;
    if (*DAT_0022a73c + param_1 < DAT_0022a73c[2] - DAT_0022a73c[3]) {
      do {
        uVar6 = DAT_0022a73c[2];
        uVar5 = DAT_0022a73c[3];
        iVar8 = FUN_0013f8c6(uVar6 - uVar5,0,0x8000);
        if (iVar8 == 0) {
          return 0xffffffff;
        }
        iVar7 = iVar7 + ((uVar6 - uVar5) - *DAT_0022a73c);
        puVar4 = (uint *)DAT_0022a73c[4];
        uVar9 = 0x14;
        puVar10 = DAT_0022a73c;
        uVar3 = FUN_0012c6d6(0x14,DAT_0022a73c);
        iVar8 = FUN_0012c6bf(uVar3,uVar9,puVar10);
        if (iVar8 == 0) {
          return 0xffffffff;
        }
        DAT_0022a73c = puVar4;
      } while (*puVar4 - iVar7 < puVar4[2] - puVar4[3]);
      iVar8 = DAT_00241a48;
    }
    uVar6 = (DAT_0022a73c[1] - *DAT_0022a73c) + iVar7;
    if (iVar8 <= (int)uVar6) {
      uVar6 = ~(iVar8 - 1U) & uVar6;
      uVar5 = DAT_0022a73c[1] - uVar6;
      iVar8 = FUN_0013f8c6(uVar5,uVar6,0x4000);
      if (iVar8 == 0) {
        return 0xffffffff;
      }
      uVar6 = *DAT_0022a73c;
      DAT_0022a73c[1] = uVar5;
      *DAT_0022a73c = uVar5;
      iVar7 = iVar7 + (uVar5 - uVar6);
    }
    *DAT_0022a73c = *DAT_0022a73c - iVar7;
    uVar6 = *DAT_0022a73c;
    if ((DAT_0022a73c[2] - DAT_0022a73c[3] <= uVar6) && (uVar6 <= DAT_0022a73c[1])) {
      return uVar6;
    }
    *DAT_0022a73c = DAT_0022a73c[2] - DAT_0022a73c[3];
  }
  else {
    uVar5 = DAT_0022a73c[1];
    iVar7 = (*DAT_0022a73c - uVar5) + param_1;
    local_2c = param_1;
    if (iVar7 < 1) {
LAB_00057d33:
      *DAT_0022a73c = *DAT_0022a73c + local_2c;
      return *DAT_0022a73c - param_1;
    }
    local_30 = iVar8 + -1 + iVar7 & ~(iVar8 - 1U);
    iVar8 = (uVar5 - DAT_0022a73c[2]) + local_30;
    if (iVar8 < 1) {
LAB_00057ce7:
      if (local_30 == 0x8000000) {
        if (local_2c == 0x8000000) {
          local_2c = uVar6;
          param_1 = uVar6;
          local_30 = uVar6;
        }
      }
      uVar6 = FUN_0013f898(DAT_0022a73c[1],local_30,0x1000,4);
      if (uVar6 == DAT_0022a73c[1]) {
        DAT_0022a73c[1] = uVar6 + local_30;
        goto LAB_00057d33;
      }
    }
    else {
      iVar7 = DAT_0022a73c[2] - uVar5;
      if (0 < iVar7) {
        uVar5 = FUN_0013f898(uVar5,iVar7,0x1000,4);
        if (uVar5 != DAT_0022a73c[1]) {
          return 0xffffffff;
        }
        DAT_0022a73c[1] = uVar5 + iVar7;
      }
      bVar2 = false;
      do {
        local_1c[0] = DAT_0022a73c[2];
        bVar1 = true;
        uVar5 = iVar8 + -1 + DAT_00241a40 & ~(DAT_00241a40 - 1U);
        iVar7 = FUN_0013f92e(local_1c[0],local_1c,0x1c);
        while (iVar7 != 0) {
          if (((local_c == 0x10000) && (local_1c[0] % DAT_00241a44 == 0)) && (uVar5 <= local_10)) {
            bVar2 = true;
            goto LAB_00057c1f;
          }
          bVar1 = false;
          uVar5 = DAT_00241a40 + -1 + param_1 & ~(DAT_00241a40 - 1U);
          local_1c[0] = local_1c[0] + local_10;
          iVar7 = FUN_0013f92e(local_1c[0],local_1c,0x1c);
        }
        if (!bVar2) {
          return 0xffffffff;
        }
LAB_00057c1f:
        uVar5 = FUN_0013f898(local_1c[0],uVar5,0x2000,1);
        if (uVar5 != 0) {
          if ((local_1c[0] != 0) && (uVar5 != local_1c[0])) {
            return 0xffffffff;
          }
          if (bVar1) {
            puVar4 = DAT_0022a73c + 1;
            uVar5 = *DAT_0022a73c;
            *DAT_0022a73c = *puVar4;
            local_2c = (uVar5 - *puVar4) + param_1;
            local_30 = (*DAT_0022a73c - DAT_0022a73c[1]) + DAT_00241a48 + -1 + local_2c &
                       ~(DAT_00241a48 - 1U);
          }
          iVar8 = FUN_00057a10();
          if (iVar8 == 0) {
            return 0xffffffff;
          }
          if (!bVar1) {
            local_30 = (*DAT_0022a73c - DAT_0022a73c[1]) + DAT_00241a48 + -1 + local_2c &
                       ~(DAT_00241a48 - 1U);
          }
          goto LAB_00057ce7;
        }
        iVar7 = FUN_0012b603();
      } while (iVar7 == 0x1e7);
    }
  }
  return 0xffffffff;
}


