// func FUN_000560f0 @ 0x000560F0 (size 0x66)

undefined8 FUN_000560f0(void)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int unaff_ESI;
  
  iVar3 = 0;
  LOCK();
  if (DAT_0022aab8 == 0) {
    DAT_0022aab8 = 1;
  }
  else {
    iVar3 = DAT_0022aab8;
  }
  UNLOCK();
  iVar2 = DAT_0022aab8;
  while (iVar3 != 0) {
    DAT_0022aab8 = iVar2;
    FUN_0012ec0e(0);
    iVar3 = 0;
    LOCK();
    if (DAT_0022aab8 == 0) {
      DAT_0022aab8 = 1;
    }
    else {
      iVar3 = DAT_0022aab8;
    }
    UNLOCK();
    iVar2 = DAT_0022aab8;
  }
  if (unaff_ESI != 0) {
    uVar1 = *(uint *)(unaff_ESI + -4);
    if ((uVar1 & 2) != 0) {
      iVar3 = (uVar1 & 0x7ffffffc) - 8;
      goto LAB_0005614c;
    }
    if ((*(byte *)(((uVar1 & 0xfffffffe) - 4) + unaff_ESI) & 1) != 0) {
      iVar3 = (uVar1 & 0x7ffffffc) - 4;
      goto LAB_0005614c;
    }
  }
  iVar3 = 0;
LAB_0005614c:
  LOCK();
  DAT_0022aab8 = 0;
  UNLOCK();
  return CONCAT44(iVar2,iVar3);
}


