// func FUN_0001abe0 @ 0x0001ABE0 (size 0x6C)

void FUN_0001abe0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int unaff_ESI;
  undefined4 unaff_EDI;
  
  if (*(int *)(&DAT_00004004 + unaff_ESI) == 0) {
    uVar2 = FUN_00057f60(0x18);
    *(undefined4 *)(&DAT_00004004 + unaff_ESI) = uVar2;
  }
  puVar1 = *(undefined4 **)(&DAT_00004004 + unaff_ESI);
  *(undefined4 *)(unaff_ESI + 0x4000) = unaff_EDI;
  *puVar1 = param_1;
  *(undefined4 *)(*(int *)(&DAT_00004004 + unaff_ESI) + 4) = unaff_EDI;
  *(undefined4 *)(*(int *)(&DAT_00004004 + unaff_ESI) + 8) = param_2;
  *(undefined4 *)(*(int *)(&DAT_00004004 + unaff_ESI) + 0xc) = param_3;
  *(undefined4 *)(*(int *)(&DAT_00004004 + unaff_ESI) + 0x10) = param_4;
  *(undefined4 *)(*(int *)(&DAT_00004004 + unaff_ESI) + 0x14) = param_5;
  return;
}


