// func FUN_000550f0 @ 0x000550F0 (size 0xE5)

int FUN_000550f0(int param_1)

{
  int iVar1;
  int *in_EAX;
  uint uVar2;
  uint *puVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  
  iVar1 = *in_EAX;
  uVar2 = 1 << ((byte)iVar1 & 0x1f);
  puVar3 = (uint *)(in_EAX + (iVar1 >> 5) + 1);
  uVar5 = *puVar3;
  iVar6 = 0;
  iVar7 = iVar1;
  while (iVar7 < 0x100) {
    if ((uVar2 & uVar5) == 0) {
      iVar6 = iVar6 + 1;
      if (iVar6 == param_1) {
        iVar7 = iVar7 + (1 - param_1);
        goto LAB_000551bd;
      }
    }
    else {
      iVar6 = 0;
    }
    iVar7 = iVar7 + 1;
    if (uVar2 == 0x80000000) {
      uVar5 = puVar3[1];
      puVar3 = puVar3 + 1;
      uVar2 = 1;
    }
    else {
      uVar2 = uVar2 << 1;
    }
  }
  uVar5 = in_EAX[1];
  iVar7 = 0;
  piVar4 = in_EAX + 1;
  iVar6 = 0;
  uVar2 = 1;
  if (0 < iVar1) {
    do {
      if ((uVar2 & uVar5) == 0) {
        iVar6 = iVar6 + 1;
        if (iVar6 == param_1) {
          iVar7 = iVar7 + (1 - param_1);
LAB_000551bd:
          FUN_000552b0(param_1);
          FUN_00055220();
          return iVar7;
        }
      }
      else {
        iVar6 = 0;
      }
      iVar7 = iVar7 + 1;
      if (uVar2 == 0x80000000) {
        uVar5 = piVar4[1];
        piVar4 = piVar4 + 1;
        uVar2 = 1;
      }
      else {
        uVar2 = uVar2 << 1;
      }
    } while (iVar7 < iVar1);
  }
  return -1;
}


