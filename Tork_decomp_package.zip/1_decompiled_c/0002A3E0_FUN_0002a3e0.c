// func FUN_0002a3e0 @ 0x0002A3E0 (size 0x41)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0002a3e0(float *param_1,float param_2)

{
  float fVar1;
  float10 fVar2;
  
  fVar2 = (float10)FUN_00021640();
  fVar1 = (float)(SQRT((float10)_DAT_0020df98 / fVar2) * (float10)param_2);
  *param_1 = fVar1 * *param_1;
  *(ulonglong *)(param_1 + 1) =
       CONCAT44(fVar1 * (float)((ulonglong)*(undefined8 *)(param_1 + 1) >> 0x20),
                fVar1 * (float)*(undefined8 *)(param_1 + 1));
  return;
}


