// func FUN_00026960 @ 0x00026960 (size 0xAF)

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_00026960(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  ushort uVar1;
  int iVar2;
  int iVar3;
  undefined1 local_68 [100];
  undefined4 local_4;
  
  local_4 = DAT_002264b0;
  iVar2 = *(int *)(DAT_0022a6c4 + 0x14);
  __itoa(param_1,local_68,10);
  FUN_000bfaf0();
  iVar3 = DAT_002387ec;
  *(undefined4 *)(DAT_002387ec + 0x14) = param_4;
  *(undefined4 *)(iVar3 + 0x10) = param_3;
  iVar3 = DAT_002387ec;
  *(undefined1 *)(DAT_002387ec + 0x26) = 0;
  *(undefined4 *)(iVar3 + 0x28) = 0;
  *(undefined4 *)(iVar3 + 0x2c) = 0;
  FUN_000c3030(DAT_002387ec,local_68,0,0,0,0);
  uVar1 = *(ushort *)(iVar2 + 2);
  *(ushort *)(iVar2 + 2) = uVar1 | 0x10;
  FUN_00024ea0(0x3f000000);
  *(ushort *)(iVar2 + 2) = uVar1;
  return;
}


