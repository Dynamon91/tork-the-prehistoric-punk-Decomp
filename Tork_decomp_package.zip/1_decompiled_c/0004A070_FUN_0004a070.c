// func FUN_0004a070 @ 0x0004A070 (size 0xE3)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0004a070(undefined4 param_1,float param_2,float param_3,float param_4)

{
  float local_10;
  
  local_10 = param_2;
  if (_DAT_0020df5c < param_2) {
    if (_DAT_0020df98 <= param_2) {
      local_10 = 1.0;
    }
  }
  else {
    local_10 = 0.0;
  }
  if (param_3 <= _DAT_0020df5c) {
    param_3 = _DAT_0020df5c;
  }
  if (_DAT_0020df98 <= param_3) {
    param_3 = _DAT_0020df98;
  }
  if (param_4 <= _DAT_0020df5c) {
    param_4 = _DAT_0020df5c;
  }
  if (_DAT_0020df98 <= param_4) {
    param_4 = _DAT_0020df98;
  }
  FUN_00049c10();
  FUN_00049c90();
  FUN_00049df0(local_10,param_3,param_4);
  return;
}


