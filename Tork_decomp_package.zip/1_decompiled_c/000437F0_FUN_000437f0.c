// func FUN_000437f0 @ 0x000437F0 (size 0x17)

void FUN_000437f0(void)

{
  int iVar1;
  short *in_EAX;
  int *in_ECX;
  
  iVar1 = *in_ECX;
  *in_ECX = (int)in_EAX;
  if (in_EAX != (short *)0x0) {
    *in_EAX = *in_EAX + 1;
  }
  if (iVar1 != 0) {
    FUN_00102a90();
  }
  return;
}


