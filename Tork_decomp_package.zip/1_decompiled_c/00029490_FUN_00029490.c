// func FUN_00029490 @ 0x00029490 (size 0x37)

void FUN_00029490(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(*(int *)(DAT_0022a6c4 + 0x14) + 0x1c);
  *(undefined4 *)(iVar1 + 0x20) = *(undefined4 *)(iVar1 + 0x20);
  *(undefined4 *)(iVar1 + 0x24) = *(undefined4 *)(iVar1 + 0x24);
  *(undefined4 *)(iVar1 + 0x28) = param_1;
  return;
}


