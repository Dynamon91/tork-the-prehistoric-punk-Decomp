
undefined4 FUN_000113f0(void)

{
  int iVar1;
  undefined4 *puVar2;
  
  func_0x0012a11f(&DAT_0022a6c0,&DAT_00229ac0);
  FUN_00057f60(0);
  puRam002411d0 = (undefined4 *)FUN_00057f60(0x9c);
  if (puRam002411d0 == (undefined4 *)0x0) {
    puRam002411d0 = (undefined4 *)0x0;
  }
  else {
    puVar2 = puRam002411d0;
    for (iVar1 = 0x27; iVar1 != 0; iVar1 = iVar1 + -1) {
      *puVar2 = 0;
      puVar2 = puVar2 + 1;
    }
  }
  _sprintf((char *)0x241a10,s__bgl_D__TORK_bgl_002080d4,uRam00222f00);
  FUN_00011480();
  FUN_00058010();
  return 0;
}


