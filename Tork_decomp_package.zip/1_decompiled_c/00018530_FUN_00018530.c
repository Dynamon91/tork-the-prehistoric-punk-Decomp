// func FUN_00018530 @ 0x00018530 (size 0x42)

uint FUN_00018530(short param_1)

{
  uint uVar1;
  uint *in_EDX;
  short unaff_BX;
  uint unaff_EDI;
  
  uVar1 = *in_EDX;
  while( true ) {
    if (uVar1 == in_EDX[1]) {
      return uVar1 & 0xffffff00;
    }
    if (((in_EDX[uVar1 * 4 + 2] == unaff_EDI) && (unaff_BX <= (short)in_EDX[uVar1 * 4 + 4])) &&
       ((short)in_EDX[uVar1 * 4 + 4] <= param_1)) break;
    uVar1 = uVar1 + 1 & 0x1ff;
  }
  return CONCAT31((int3)(uVar1 >> 8),1);
}


