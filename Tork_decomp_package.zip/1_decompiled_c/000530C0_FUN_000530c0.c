// func FUN_000530c0 @ 0x000530C0 (size 0x5B)

undefined4 FUN_000530c0(float *param_1)

{
  float fVar1;
  float *in_EAX;
  float *in_ECX;
  float *in_EDX;
  float *unaff_ESI;
  
  fVar1 = in_ECX[1] * *in_EAX - in_EAX[1] * *in_ECX;
  if ((uint)ABS(fVar1) < 0x38d1b717) {
    return 0;
  }
  *param_1 = ((*unaff_ESI - *in_EDX) * in_EAX[1] + (in_EDX[1] - unaff_ESI[1]) * *in_EAX) / fVar1;
  return 1;
}


