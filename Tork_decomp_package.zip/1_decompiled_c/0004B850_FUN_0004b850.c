// func FUN_0004b850 @ 0x0004B850 (size 0xB1)

undefined1 * FUN_0004b850(undefined *param_1)

{
  undefined1 *puVar1;
  int iVar2;
  int iVar3;
  undefined1 *puVar4;
  undefined *puVar5;
  uint uVar6;
  bool bVar7;
  
  iVar2 = FUN_00134fe8(param_1);
  iVar3 = DAT_002411d8;
  iVar2 = FUN_000550f0((int)(iVar2 + 0x21 + (iVar2 + 0x21 >> 0x1f & 0x1fU)) >> 5);
  *(undefined4 *)(&DAT_00002064 + iVar2 * 4 + iVar3) = 0;
  puVar1 = (undefined1 *)(iVar2 * 0x20 + 0x44 + iVar3);
  iVar3 = FUN_00134fe8(param_1);
  puVar4 = puVar1;
  if (iVar3 != 0) {
    puVar5 = param_1;
    do {
      *puVar4 = *puVar5;
      puVar4 = puVar4 + 1;
      puVar5 = puVar5 + 2;
      iVar3 = iVar3 + -1;
    } while (iVar3 != 0);
  }
  *puVar4 = 0;
  if (((undefined *)(DAT_002411d8 + 0x44) <= param_1) && (param_1 < &DAT_00002044 + DAT_002411d8)) {
    param_1 = param_1 + (-0x44 - DAT_002411d8);
    uVar6 = (uint)param_1 & 0x8000001f;
    bVar7 = uVar6 == 0;
    if ((int)uVar6 < 0) {
      bVar7 = (uVar6 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar7) && ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5 != -1)) &&
       (*(int *)(&DAT_00002064 +
                ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5) * 4 + DAT_002411d8) == 0)) {
      FUN_00019750();
    }
  }
  return puVar1;
}


