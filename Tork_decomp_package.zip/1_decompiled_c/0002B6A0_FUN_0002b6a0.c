// func FUN_0002b6a0 @ 0x0002B6A0 (size 0x2C)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0002b6a0(void)

{
  float *in_EAX;
  float *in_ECX;
  
  *in_ECX = (in_EAX[3] + *in_EAX) * _DAT_0020df84;
  in_ECX[1] = (in_EAX[4] + in_EAX[1]) * _DAT_0020df84;
  in_ECX[2] = (in_EAX[5] + in_EAX[2]) * _DAT_0020df84;
  return;
}


