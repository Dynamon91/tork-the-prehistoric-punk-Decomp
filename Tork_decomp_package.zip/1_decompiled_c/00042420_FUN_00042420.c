// func FUN_00042420 @ 0x00042420 (size 0x4F)

void FUN_00042420(void)

{
  int in_EAX;
  ushort in_CX;
  ushort uVar1;
  ushort in_DX;
  
  uVar1 = (*(ushort *)(in_EAX + 2) | in_DX) & ~in_CX;
  *(ushort *)(in_EAX + 2) = uVar1;
  if (((in_DX & 1) != 0) && ((uVar1 & 0xff00) == 0x1000)) {
    *(undefined4 *)(in_EAX + 0x10) = 0;
    *(undefined4 *)(in_EAX + 0xc) = 0;
    *(undefined4 *)(in_EAX + 8) = 0;
    *(undefined4 *)(in_EAX + 0x1c) = 0;
    *(undefined4 *)(in_EAX + 0x18) = 0;
    *(undefined4 *)(in_EAX + 0x14) = 0;
    *(undefined4 *)(in_EAX + 0x2c) = 0;
    *(undefined4 *)(in_EAX + 0x28) = 0;
    *(undefined4 *)(in_EAX + 0x24) = 0;
    *(undefined4 *)(in_EAX + 0x38) = 0;
    *(undefined4 *)(in_EAX + 0x34) = 0;
    *(undefined4 *)(in_EAX + 0x30) = 0;
  }
  return;
}


