// func FUN_000376b0 @ 0x000376B0 (size 0x3F1E)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_000376b0(int param_1,uint param_2,byte param_3,undefined1 param_4)

{
  ushort uVar1;
  ushort uVar2;
  float *pfVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  uint uVar7;
  byte bVar8;
  char cVar9;
  byte bVar10;
  uint uVar11;
  uint in_EDX;
  uint uVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  byte local_692;
  byte local_691;
  uint local_634;
  int local_630;
  float local_62c;
  float local_628;
  float local_620;
  float local_61c;
  float local_614;
  float local_610;
  float local_608;
  float local_604;
  float local_5fc;
  float local_5f8;
  float local_5f4;
  float local_5f0;
  float local_5ec;
  float local_5e8;
  uint local_5e4;
  float local_5dc;
  float local_5d8;
  float local_5d4;
  float local_5d0;
  float local_5cc;
  float local_5c8;
  float local_5c4;
  float local_5c0;
  float local_5bc;
  float local_5b8;
  float local_5b4;
  float local_5b0;
  float local_5ac;
  float local_5a8;
  float local_5a4;
  float local_5a0;
  float local_59c;
  float local_598;
  float local_594;
  float local_590;
  float local_58c;
  float local_588;
  float local_584;
  float local_580;
  uint local_57c;
  float local_578;
  float local_574;
  float local_570;
  uint local_56c;
  float local_568;
  float local_564;
  float local_560;
  float local_55c;
  float local_558;
  float local_554;
  float local_550;
  float local_54c;
  float local_548;
  float local_544;
  float local_540;
  float local_53c;
  float local_538;
  float local_534;
  float local_530;
  float local_52c;
  float local_528;
  float local_524;
  float local_520;
  float local_51c;
  float local_518;
  float local_514;
  float local_510;
  float local_50c;
  float local_508;
  float local_504;
  float local_500;
  float local_4fc;
  float local_4f8;
  float local_4f4;
  float local_4f0;
  float local_4ec;
  float local_4e8;
  float local_4e4;
  float local_4e0;
  float local_4dc;
  float local_4d8;
  float local_4d4;
  float local_4d0;
  float local_4cc;
  float local_4c8;
  float local_4c4;
  float local_4c0;
  float local_4bc;
  float local_4b8;
  float local_4b4;
  float local_4b0;
  float local_4ac;
  float local_4a8;
  float local_4a4;
  float local_4a0;
  float local_49c;
  float local_498;
  float local_494;
  float local_490;
  float local_48c;
  float local_488;
  uint local_484;
  float local_440;
  float local_43c;
  float local_438;
  float local_430;
  float local_42c;
  float local_428;
  float local_420;
  float local_41c;
  float local_418;
  float local_410;
  float local_40c;
  float local_408;
  float local_380;
  float local_37c;
  float local_378;
  float local_370;
  float local_36c;
  float local_368;
  float local_360;
  float local_35c;
  float local_358;
  float local_350;
  float local_34c;
  float local_348;
  float local_340;
  float local_33c;
  float local_338;
  float local_330;
  float local_32c;
  float local_328;
  float local_320;
  float local_31c;
  float local_318;
  float local_310;
  float local_30c;
  float local_308;
  float local_300;
  float local_2fc;
  float local_2f8;
  float local_2f0;
  float local_2ec;
  float local_2e8;
  float local_2e0;
  float local_2dc;
  float local_2d8;
  float local_2d0;
  float local_2cc;
  float local_2c8;
  float local_280;
  float local_27c;
  float local_278;
  float local_270;
  float local_26c;
  float local_268;
  float local_260;
  float local_25c;
  float local_258;
  float local_250;
  float local_24c;
  float local_248;
  float local_200;
  float local_1fc;
  float local_1f8;
  float local_1f0;
  float local_1ec;
  float local_1e8;
  float local_1e0;
  float local_1dc;
  float local_1d8;
  float local_1d0;
  float local_1cc;
  float local_1c8;
  
  if ((in_EDX & 0x10000000) != 0) {
    return in_EDX;
  }
  if ((in_EDX & 0x8000000) != 0) {
    bVar8 = FUN_000e9ed0();
    while( true ) {
      if (local_634 == 0) {
        return in_EDX | 0x10000000;
      }
      if ((((*(byte *)(local_634 + 2) >> 5 & 1) != 0) &&
          ((1 << (bVar8 & 0x1f) & (uint)*(ushort *)(*(int *)(param_1 + 0x24) + 0x16)) != 0)) &&
         ((*(byte *)(*(int *)(DAT_002414b0 + 0x120 + (uint)*(byte *)(local_634 + 4) * 4) + 8) &
          param_3) != 0)) break;
      bVar8 = FUN_000e9f10();
    }
    in_EDX = in_EDX & 0xf40000ff | ((bVar8 | 0x200) << 6 | (uint)bVar8) << 0xe;
  }
  if (param_2 == 0xffffffff) {
    uVar12 = 0;
    local_56c = (uint)CONCAT11(param_3,param_4);
    if ((*(byte *)(param_1 + 8) & 1) != 0) {
      if ((in_EDX & 0x10000000) != 0) goto LAB_0003b59a;
      iVar13 = *(int *)(param_1 + 0x24);
      uVar1 = *(ushort *)(iVar13 + 0x1e);
      iVar16 = local_630;
      for (uVar12 = (~(in_EDX >> 0x1a) & 1) + (in_EDX & 0xff); uVar12 < uVar1; uVar12 = uVar12 + 1)
      {
        iVar15 = *(int *)(*(int *)(iVar13 + 0x18) + (uVar12 & 0xff) * 4);
        local_630 = iVar16;
        if ((*(uint *)(iVar15 + 4) >> 0xb & 1) != 0) {
          local_57c = *(int *)(*(int *)(iVar15 + 0x24) + 0x10);
          local_691 = (byte)(in_EDX >> 0xe) & 0x3f;
          local_634 = in_EDX & 0xfff000ff;
          if ((in_EDX & 0x20000000) == 0) {
            local_692 = FUN_000e9f10();
            if (iVar16 != 0) goto LAB_00037874;
          }
          else {
            local_634 = in_EDX & 0xdff000ff;
            local_692 = FUN_000e9ed0();
LAB_00037874:
            if (local_691 < *(byte *)(*(int *)(iVar13 + 0x10) + 3) >> 3) {
              iVar14 = *(int *)(*(int *)(*(int *)(iVar13 + 0x10) + 8) + (uint)local_691 * 4);
            }
            else {
              iVar14 = 0;
            }
            uVar7 = local_56c >> 8;
            if (iVar14 != 0) {
              do {
                if ((((*(byte *)(iVar14 + 2) >> 5 & 1) != 0) &&
                    ((1 << (local_691 & 0x1f) & (uint)*(ushort *)(iVar13 + 0x16)) != 0)) &&
                   ((*(byte *)(*(int *)(DAT_002414b0 + 0x120 + (uint)*(byte *)(iVar14 + 4) * 4) + 8)
                    & (byte)uVar7) != 0)) {
                  if (iVar16 != 0) {
                    do {
                      if (((((byte)*(ushort *)(iVar16 + 2) >> 5 & 1) != 0) &&
                          (((uint)*(ushort *)(*(int *)(iVar15 + 0x24) + 0x16) &
                           1 << (local_692 & 0x1f)) != 0)) &&
                         ((*(byte *)(*(int *)(DAT_002414b0 + 0x120 + (uint)*(byte *)(iVar16 + 4) * 4
                                             ) + 8) & (byte)local_56c) != 0)) {
                        uVar2 = *(ushort *)(iVar14 + 2);
                        bVar8 = (byte)uVar2;
                        if ((uVar2 & 0x100) == 0) {
                          if ((uVar2 & 0x200) == 0) {
                            if ((uVar2 & 0x1000) == 0) goto LAB_00039c16;
                            if ((*(byte *)(iVar16 + 3) & 1) == 0) {
                              if ((*(ushort *)(iVar16 + 2) >> 9 & 1) == 0) {
                                if ((*(ushort *)(iVar16 + 2) >> 0xc & 1) == 0) goto LAB_00039c16;
                                if ((bVar8 >> 6 & 1) == 0) {
                                  if (((bVar8 >> 3 & 1) != 0) || ((*(byte *)(iVar14 + 2) & 1) != 0))
                                  {
                                    FUN_000941f0();
                                    FUN_00028450();
                                    if ((*(byte *)(iVar14 + 2) & 1) != 0) {
                                      FUN_000941f0();
                                      FUN_00028450();
                                    }
                                  }
                                  FUN_00028450();
                                }
                                bVar8 = (byte)*(undefined2 *)(iVar16 + 2);
                                if ((bVar8 >> 6 & 1) == 0) {
                                  if (((bVar8 >> 3 & 1) != 0) || ((*(byte *)(iVar16 + 2) & 1) != 0))
                                  {
                                    FUN_000941f0();
                                    FUN_00028450();
                                    if ((*(byte *)(iVar16 + 2) & 1) != 0) {
                                      FUN_000941f0();
                                      FUN_00028450();
                                    }
                                  }
                                  FUN_00028450();
                                }
                                cVar9 = FUN_00069ea0();
                              }
                              else {
                                if ((bVar8 >> 6 & 1) == 0) {
                                  if (((bVar8 >> 3 & 1) != 0) || ((*(byte *)(iVar14 + 2) & 1) != 0))
                                  {
                                    FUN_000941f0();
                                    FUN_00028450();
                                    if ((*(byte *)(iVar14 + 2) & 1) != 0) {
                                      FUN_000941f0();
                                      FUN_00028450();
                                    }
                                  }
                                  FUN_00028450();
                                }
                                fVar4 = (*(float *)(iVar16 + 0x14) + *(float *)(iVar16 + 8)) *
                                        _DAT_0020df84;
                                fVar5 = (*(float *)(iVar16 + 0x18) + *(float *)(iVar16 + 0xc)) *
                                        _DAT_0020df84;
                                fVar6 = (*(float *)(iVar16 + 0x1c) + *(float *)(iVar16 + 0x10)) *
                                        _DAT_0020df84;
                                local_594 = *(float *)(iVar16 + 0x14) - fVar4;
                                local_590 = *(float *)(iVar16 + 0x18) - fVar5;
                                local_58c = *(float *)(iVar16 + 0x1c) - fVar6;
                                local_620 = fVar4;
                                local_61c = fVar5;
                                local_544 = local_594;
                                local_540 = local_590;
                                local_53c = local_58c;
                                if ((*(byte *)(iVar16 + 2) >> 3 & 1) != 0) {
                                  FUN_000941f0();
                                  local_620 = local_340 * fVar4 +
                                              local_330 * fVar5 + local_320 * fVar6 + local_310;
                                  local_61c = fVar4 * local_33c +
                                              local_32c * fVar5 + local_31c * fVar6 + local_30c;
                                  fVar6 = fVar4 * local_338 + fVar5 * local_328 + local_318 * fVar6
                                          + local_308;
                                }
                                pfVar3 = *(float **)(iVar15 + 0x10);
                                local_5c4 = local_620 * *pfVar3 +
                                            local_61c * pfVar3[4] + fVar6 * pfVar3[8] + pfVar3[0xc];
                                local_5c0 = local_620 * pfVar3[1] +
                                            local_61c * pfVar3[5] + fVar6 * pfVar3[9] + pfVar3[0xd];
                                local_5bc = local_620 * pfVar3[2] +
                                            local_61c * pfVar3[6] + fVar6 * pfVar3[10] + pfVar3[0xe]
                                ;
                                local_5b8 = local_594 + local_5c4;
                                local_5b4 = local_590 + local_5c0;
                                local_5b0 = local_58c + local_5bc;
                                local_5c4 = local_5c4 - local_594;
                                local_5c0 = local_5c0 - local_590;
                                local_5bc = local_5bc - local_58c;
                                local_52c = local_5b8;
                                local_528 = local_5b4;
                                local_524 = local_5b0;
                                local_508 = local_5c4;
                                local_504 = local_5c0;
                                local_500 = local_5bc;
                                cVar9 = FUN_00069750();
                              }
                            }
                            else {
                              if ((bVar8 >> 6 & 1) == 0) {
                                if (((bVar8 >> 3 & 1) != 0) || ((*(byte *)(iVar14 + 2) & 1) != 0)) {
                                  FUN_000941f0();
                                  FUN_00028450();
                                  if ((*(byte *)(iVar14 + 2) & 1) != 0) {
                                    FUN_000941f0();
                                    FUN_00028450();
                                  }
                                }
                                FUN_00028450();
                              }
                              if ((*(byte *)(iVar16 + 2) >> 3 & 1) != 0) {
                                FUN_000941f0();
                              }
                              cVar9 = FUN_000697f0();
                            }
                          }
                          else if ((*(byte *)(iVar16 + 3) & 1) == 0) {
                            if ((*(ushort *)(iVar16 + 2) >> 9 & 1) == 0) {
                              if ((*(ushort *)(iVar16 + 2) >> 0xc & 1) == 0) goto LAB_00039c16;
                              fVar4 = (*(float *)(iVar14 + 8) + *(float *)(iVar14 + 0x14)) *
                                      _DAT_0020df84;
                              fVar5 = (*(float *)(iVar14 + 0x18) + *(float *)(iVar14 + 0xc)) *
                                      _DAT_0020df84;
                              fVar6 = (*(float *)(iVar14 + 0x1c) + *(float *)(iVar14 + 0x10)) *
                                      _DAT_0020df84;
                              local_568 = *(float *)(iVar14 + 0x14) - fVar4;
                              local_564 = *(float *)(iVar14 + 0x18) - fVar5;
                              local_560 = *(float *)(iVar14 + 0x1c) - fVar6;
                              local_608 = fVar4;
                              local_604 = fVar5;
                              local_4fc = local_568;
                              local_4f8 = local_564;
                              local_4f4 = local_560;
                              if ((bVar8 >> 3 & 1) != 0) {
                                FUN_000941f0();
                                local_608 = local_430 * fVar5 +
                                            local_420 * fVar6 + local_440 * fVar4 + local_410;
                                local_604 = local_43c * fVar4 +
                                            local_42c * fVar5 + local_41c * fVar6 + local_40c;
                                fVar6 = local_438 * fVar4 + local_428 * fVar5 + local_418 * fVar6 +
                                        local_408;
                              }
                              pfVar3 = *(float **)(param_1 + 0x10);
                              local_5dc = local_608 * *pfVar3 +
                                          local_604 * pfVar3[4] + fVar6 * pfVar3[8] + pfVar3[0xc];
                              local_5d8 = local_604 * pfVar3[5] +
                                          fVar6 * pfVar3[9] + local_608 * pfVar3[1] + pfVar3[0xd];
                              local_5d4 = fVar6 * pfVar3[10] +
                                          local_608 * pfVar3[2] + local_604 * pfVar3[6] +
                                          pfVar3[0xe];
                              local_5d0 = local_568 + local_5dc;
                              local_5cc = local_564 + local_5d8;
                              local_5c8 = local_560 + local_5d4;
                              local_5dc = local_5dc - local_568;
                              local_5d8 = local_5d8 - local_564;
                              local_5d4 = local_5d4 - local_560;
                              bVar8 = (byte)*(undefined2 *)(iVar16 + 2);
                              local_4e4 = local_5dc;
                              local_4e0 = local_5d8;
                              local_4dc = local_5d4;
                              local_49c = local_5d0;
                              local_498 = local_5cc;
                              local_494 = local_5c8;
                              if ((bVar8 >> 6 & 1) == 0) {
                                if (((bVar8 >> 3 & 1) != 0) || ((*(byte *)(iVar16 + 2) & 1) != 0)) {
                                  FUN_000941f0();
                                  FUN_00028450();
                                  if ((*(byte *)(iVar16 + 2) & 1) != 0) {
                                    FUN_000941f0();
                                    FUN_00028450();
                                  }
                                }
                                FUN_00028450();
                              }
                              else if (((*(uint *)(iVar15 + 4) >> 7 & 1) != 0) &&
                                      ((**(uint **)(iVar15 + 0x1c) >> 0xb & 1) != 0)) {
                                cVar9 = FUN_00069750();
                                goto LAB_00039c0e;
                              }
                              cVar9 = FUN_00069750();
                            }
                            else {
                              fVar4 = (*(float *)(iVar14 + 0x14) + *(float *)(iVar14 + 8)) *
                                      _DAT_0020df84;
                              fVar5 = (*(float *)(iVar14 + 0x18) + *(float *)(iVar14 + 0xc)) *
                                      _DAT_0020df84;
                              fVar6 = (*(float *)(iVar14 + 0x1c) + *(float *)(iVar14 + 0x10)) *
                                      _DAT_0020df84;
                              local_588 = *(float *)(iVar14 + 0x14) - fVar4;
                              local_584 = *(float *)(iVar14 + 0x18) - fVar5;
                              local_580 = *(float *)(iVar14 + 0x1c) - fVar6;
                              local_614 = fVar4;
                              local_610 = fVar5;
                              local_514 = local_588;
                              local_510 = local_584;
                              local_50c = local_580;
                              if ((bVar8 >> 3 & 1) != 0) {
                                FUN_000941f0();
                                local_614 = local_280 * fVar4 +
                                            local_270 * fVar5 + local_260 * fVar6 + local_250;
                                local_610 = local_26c * fVar5 +
                                            local_25c * fVar6 + local_27c * fVar4 + local_24c;
                                fVar6 = local_258 * fVar6 + local_278 * fVar4 + local_268 * fVar5 +
                                        local_248;
                              }
                              pfVar3 = *(float **)(param_1 + 0x10);
                              local_5dc = local_614 * *pfVar3 +
                                          local_610 * pfVar3[4] + fVar6 * pfVar3[8] + pfVar3[0xc];
                              local_5d8 = local_610 * pfVar3[5] +
                                          fVar6 * pfVar3[9] + local_614 * pfVar3[1] + pfVar3[0xd];
                              local_5d4 = fVar6 * pfVar3[10] +
                                          local_614 * pfVar3[2] + local_610 * pfVar3[6] +
                                          pfVar3[0xe];
                              local_5d0 = local_588 + local_5dc;
                              local_5cc = local_584 + local_5d8;
                              local_5c8 = local_580 + local_5d4;
                              local_5dc = local_5dc - local_588;
                              local_5d8 = local_5d8 - local_584;
                              local_5d4 = local_5d4 - local_580;
                              fVar4 = (*(float *)(iVar16 + 8) + *(float *)(iVar16 + 0x14)) *
                                      _DAT_0020df84;
                              fVar5 = (*(float *)(iVar16 + 0x18) + *(float *)(iVar16 + 0xc)) *
                                      _DAT_0020df84;
                              fVar6 = (*(float *)(iVar16 + 0x1c) + *(float *)(iVar16 + 0x10)) *
                                      _DAT_0020df84;
                              local_5ac = *(float *)(iVar16 + 0x14) - fVar4;
                              local_5a8 = *(float *)(iVar16 + 0x18) - fVar5;
                              local_5a4 = *(float *)(iVar16 + 0x1c) - fVar6;
                              local_62c = fVar4;
                              local_628 = fVar5;
                              local_55c = local_5ac;
                              local_558 = local_5a8;
                              local_554 = local_5a4;
                              local_538 = local_5d0;
                              local_534 = local_5cc;
                              local_530 = local_5c8;
                              local_4b4 = local_5dc;
                              local_4b0 = local_5d8;
                              local_4ac = local_5d4;
                              if ((*(byte *)(iVar16 + 2) >> 3 & 1) != 0) {
                                FUN_000941f0();
                                local_62c = local_200 * fVar4 +
                                            local_1f0 * fVar5 + local_1e0 * fVar6 + local_1d0;
                                local_628 = local_1ec * fVar5 +
                                            local_1dc * fVar6 + local_1fc * fVar4 + local_1cc;
                                fVar6 = local_1d8 * fVar6 + local_1f8 * fVar4 + local_1e8 * fVar5 +
                                        local_1c8;
                              }
                              pfVar3 = *(float **)(iVar15 + 0x10);
                              local_5c4 = local_62c * *pfVar3 +
                                          local_628 * pfVar3[4] + fVar6 * pfVar3[8] + pfVar3[0xc];
                              local_5c0 = local_628 * pfVar3[5] +
                                          fVar6 * pfVar3[9] + local_62c * pfVar3[1] + pfVar3[0xd];
                              local_5bc = fVar6 * pfVar3[10] +
                                          local_62c * pfVar3[2] + local_628 * pfVar3[6] +
                                          pfVar3[0xe];
                              local_5b8 = local_5ac + local_5c4;
                              local_5b4 = local_5a8 + local_5c0;
                              local_5b0 = local_5a4 + local_5bc;
                              local_5c4 = local_5c4 - local_5ac;
                              local_5c0 = local_5c0 - local_5a8;
                              local_5bc = local_5bc - local_5a4;
                              local_520 = local_5b8;
                              local_51c = local_5b4;
                              local_518 = local_5b0;
                              local_4cc = local_5c4;
                              local_4c8 = local_5c0;
                              local_4c4 = local_5bc;
                              cVar9 = FUN_000689a0(&local_5dc,&local_5c4);
                            }
                          }
                          else {
                            fVar4 = (*(float *)(iVar14 + 0x14) + *(float *)(iVar14 + 8)) *
                                    _DAT_0020df84;
                            fVar5 = (*(float *)(iVar14 + 0x18) + *(float *)(iVar14 + 0xc)) *
                                    _DAT_0020df84;
                            fVar6 = (*(float *)(iVar14 + 0x1c) + *(float *)(iVar14 + 0x10)) *
                                    _DAT_0020df84;
                            local_5a0 = *(float *)(iVar14 + 0x14) - fVar4;
                            local_59c = *(float *)(iVar14 + 0x18) - fVar5;
                            local_598 = *(float *)(iVar14 + 0x1c) - fVar6;
                            local_5f0 = fVar4;
                            local_5ec = fVar5;
                            local_4a8 = local_5a0;
                            local_4a4 = local_59c;
                            local_4a0 = local_598;
                            if ((bVar8 >> 3 & 1) != 0) {
                              FUN_000941f0();
                              local_5f0 = local_2f0 * fVar5 + local_2e0 * fVar6 + local_300 * fVar4
                                          + local_2d0;
                              local_5ec = local_2ec * fVar5 + local_2dc * fVar6 + fVar4 * local_2fc
                                          + local_2cc;
                              fVar6 = local_2d8 * fVar6 + fVar4 * local_2f8 + fVar5 * local_2e8 +
                                      local_2c8;
                            }
                            pfVar3 = *(float **)(param_1 + 0x10);
                            local_5dc = local_5f0 * *pfVar3 +
                                        local_5ec * pfVar3[4] + fVar6 * pfVar3[8] + pfVar3[0xc];
                            local_5d8 = local_5f0 * pfVar3[1] +
                                        local_5ec * pfVar3[5] + fVar6 * pfVar3[9] + pfVar3[0xd];
                            local_5d4 = local_5f0 * pfVar3[2] +
                                        local_5ec * pfVar3[6] + fVar6 * pfVar3[10] + pfVar3[0xe];
                            local_5d0 = local_5a0 + local_5dc;
                            local_5cc = local_59c + local_5d8;
                            local_5c8 = local_598 + local_5d4;
                            local_5dc = local_5dc - local_5a0;
                            local_5d8 = local_5d8 - local_59c;
                            local_5d4 = local_5d4 - local_598;
                            local_550 = local_5dc;
                            local_54c = local_5d8;
                            local_548 = local_5d4;
                            local_490 = local_5d0;
                            local_48c = local_5cc;
                            local_488 = local_5c8;
                            if ((*(byte *)(iVar16 + 2) >> 3 & 1) != 0) {
                              FUN_000941f0();
                            }
                            cVar9 = FUN_000696a0();
                          }
                        }
                        else if ((*(ushort *)(iVar16 + 2) & 0x100) == 0) {
                          if ((*(ushort *)(iVar16 + 2) >> 9 & 1) == 0) {
                            if ((*(ushort *)(iVar16 + 2) >> 0xc & 1) == 0) goto LAB_00039c16;
                            if ((bVar8 >> 3 & 1) != 0) {
                              FUN_000941f0();
                            }
                            bVar8 = (byte)*(undefined2 *)(iVar16 + 2);
                            if ((bVar8 >> 6 & 1) == 0) {
                              if (((bVar8 >> 3 & 1) != 0) || ((*(byte *)(iVar16 + 2) & 1) != 0)) {
                                FUN_000941f0();
                                FUN_00028450();
                                if ((*(byte *)(iVar16 + 2) & 1) != 0) {
                                  FUN_000941f0();
                                  FUN_00028450();
                                }
                              }
                              FUN_00028450();
                            }
                            cVar9 = FUN_000697f0();
                          }
                          else {
                            if ((bVar8 >> 3 & 1) != 0) {
                              FUN_000941f0();
                            }
                            fVar4 = (*(float *)(iVar16 + 0x14) + *(float *)(iVar16 + 8)) *
                                    _DAT_0020df84;
                            fVar5 = (*(float *)(iVar16 + 0x18) + *(float *)(iVar16 + 0xc)) *
                                    _DAT_0020df84;
                            fVar6 = (*(float *)(iVar16 + 0x1c) + *(float *)(iVar16 + 0x10)) *
                                    _DAT_0020df84;
                            local_578 = *(float *)(iVar16 + 0x14) - fVar4;
                            local_574 = *(float *)(iVar16 + 0x18) - fVar5;
                            local_570 = *(float *)(iVar16 + 0x1c) - fVar6;
                            local_5fc = fVar4;
                            local_5f8 = fVar5;
                            local_4f0 = local_578;
                            local_4ec = local_574;
                            local_4e8 = local_570;
                            if ((*(byte *)(iVar16 + 2) >> 3 & 1) != 0) {
                              FUN_000941f0();
                              local_5fc = local_370 * fVar5 + local_360 * fVar6 + local_380 * fVar4
                                          + local_350;
                              local_5f8 = local_36c * fVar5 + local_35c * fVar6 + fVar4 * local_37c
                                          + local_34c;
                              fVar6 = local_358 * fVar6 + fVar4 * local_378 + fVar5 * local_368 +
                                      local_348;
                            }
                            pfVar3 = *(float **)(iVar15 + 0x10);
                            local_5c4 = local_5fc * *pfVar3 +
                                        local_5f8 * pfVar3[4] + fVar6 * pfVar3[8] + pfVar3[0xc];
                            local_5c0 = local_5f8 * pfVar3[5] +
                                        fVar6 * pfVar3[9] + local_5fc * pfVar3[1] + pfVar3[0xd];
                            local_5bc = fVar6 * pfVar3[10] +
                                        local_5fc * pfVar3[2] + local_5f8 * pfVar3[6] + pfVar3[0xe];
                            local_5b8 = local_578 + local_5c4;
                            local_5b4 = local_574 + local_5c0;
                            local_5b0 = local_570 + local_5bc;
                            local_5c4 = local_5c4 - local_578;
                            local_5c0 = local_5c0 - local_574;
                            local_5bc = local_5bc - local_570;
                            local_4d8 = local_5b8;
                            local_4d4 = local_5b4;
                            local_4d0 = local_5b0;
                            local_4c0 = local_5c4;
                            local_4bc = local_5c0;
                            local_4b8 = local_5bc;
                            cVar9 = FUN_000696a0();
                          }
                        }
                        else {
                          if ((bVar8 >> 3 & 1) != 0) {
                            FUN_000941f0();
                          }
                          if ((*(byte *)(iVar16 + 2) >> 3 & 1) != 0) {
                            FUN_000941f0();
                          }
                          cVar9 = FUN_00069f30();
                        }
LAB_00039c0e:
                        if (cVar9 != '\0') {
                          in_EDX = local_634 & 0xfbffff00 |
                                   ((uint)local_691 << 6 | (uint)local_692) << 8 | uVar12 & 0xff;
                          goto LAB_0003b59a;
                        }
                      }
LAB_00039c16:
                      local_692 = local_692 + 1;
                      bVar8 = *(byte *)(local_57c + 3) >> 3;
                      if (local_692 < bVar8) {
                        do {
                          iVar16 = *(int *)(*(int *)(local_57c + 8) + (uint)local_692 * 4);
                          if (iVar16 != 0) goto LAB_00039c44;
                          local_692 = local_692 + 1;
                        } while (local_692 < bVar8);
                      }
                      iVar16 = 0;
                      local_692 = 0xff;
LAB_00039c44:
                    } while (iVar16 != 0);
                  }
                  bVar8 = *(byte *)(local_57c + 3) >> 3;
                  uVar11 = 0;
                  if (bVar8 != 0) {
                    do {
                      local_692 = (byte)uVar11;
                      local_630 = *(int *)(*(int *)(local_57c + 8) + uVar11 * 4);
                      if (local_630 != 0) goto LAB_00039c82;
                      uVar11 = (uint)(byte)(local_692 + 1);
                    } while ((byte)(local_692 + 1) < bVar8);
                  }
                  local_630 = 0;
                  local_692 = 0xff;
LAB_00039c82:
                  iVar16 = local_630;
                }
                iVar13 = *(int *)(param_1 + 0x24);
                local_691 = local_691 + 1;
                bVar8 = *(byte *)(*(int *)(iVar13 + 0x10) + 3) >> 3;
                if (local_691 < bVar8) {
                  do {
                    iVar14 = *(int *)(*(int *)(*(int *)(iVar13 + 0x10) + 8) + (uint)local_691 * 4);
                    if (iVar14 != 0) goto LAB_00039cba;
                    local_691 = local_691 + 1;
                  } while (local_691 < bVar8);
                }
                iVar14 = 0;
                local_691 = 0xff;
LAB_00039cba:
              } while (iVar14 != 0);
            }
          }
          in_EDX = local_634 | local_634 >> 6 & 0xfc000 | 0x20000000;
        }
        iVar16 = local_630;
      }
    }
    in_EDX = in_EDX & 0xfbffff00 | 0x10000000 | uVar12 & 0xff;
  }
  else {
    local_57c = (uint)CONCAT11(param_3,param_4);
    local_634 = 0;
    if ((*(byte *)(param_1 + 8) & 1) != 0) {
      if ((in_EDX & 0x10000000) != 0) goto LAB_0003b59a;
      local_484 = (uint)*(ushort *)(*(int *)(param_1 + 0x24) + 0x1e);
      local_634 = (~(in_EDX >> 0x1a) & 1) + (in_EDX & 0xff);
      if (local_634 < local_484) {
        do {
          iVar16 = *(int *)(param_1 + 0x24);
          iVar13 = *(int *)(*(int *)(iVar16 + 0x18) + (local_634 & 0xff) * 4);
          if (((*(uint *)(iVar13 + 4) & param_2) == param_2) &&
             ((*(uint *)(iVar13 + 4) >> 0xb & 1) != 0)) {
            local_56c = *(undefined4 *)(*(int *)(iVar13 + 0x24) + 0x10);
            bVar8 = (byte)(in_EDX >> 0xe) & 0x3f;
            local_5e4 = in_EDX & 0xfff000ff;
            if ((in_EDX & 0x20000000) == 0) {
              local_692 = FUN_000e9f10();
              if (local_630 != 0) goto LAB_00039e4d;
            }
            else {
              local_5e4 = in_EDX & 0xdff000ff;
              local_692 = FUN_000e9ed0();
LAB_00039e4d:
              if (bVar8 < *(byte *)(*(int *)(iVar16 + 0x10) + 3) >> 3) {
                iVar15 = *(int *)(*(int *)(*(int *)(iVar16 + 0x10) + 8) + (uint)bVar8 * 4);
              }
              else {
                iVar15 = 0;
              }
              uVar12 = local_57c >> 8;
              while (iVar15 != 0) {
                if ((((*(byte *)(iVar15 + 2) >> 5 & 1) != 0) &&
                    ((1 << (bVar8 & 0x1f) & (uint)*(ushort *)(iVar16 + 0x16)) != 0)) &&
                   ((*(byte *)(*(int *)(DAT_002414b0 + 0x120 + (uint)*(byte *)(iVar15 + 4) * 4) + 8)
                    & (byte)uVar12) != 0)) {
                  if (local_630 != 0) {
                    do {
                      if (((((byte)*(ushort *)(local_630 + 2) >> 5 & 1) != 0) &&
                          ((1 << (local_692 & 0x1f) &
                           (uint)*(ushort *)(*(int *)(iVar13 + 0x24) + 0x16)) != 0)) &&
                         ((*(byte *)(*(int *)(DAT_002414b0 + 0x120 +
                                             (uint)*(byte *)(local_630 + 4) * 4) + 8) &
                          (byte)local_57c) != 0)) {
                        if ((*(ushort *)(iVar15 + 2) & 0x100) == 0) {
                          if ((*(ushort *)(iVar15 + 2) >> 9 & 1) == 0) {
                            if ((*(ushort *)(iVar15 + 2) >> 0xc & 1) == 0) goto LAB_0003b4ce;
                            if ((*(byte *)(local_630 + 3) & 1) == 0) {
                              if ((*(ushort *)(local_630 + 2) >> 9 & 1) == 0) {
                                if ((*(ushort *)(local_630 + 2) >> 0xc & 1) == 0) goto LAB_0003b4ce;
                                bVar10 = (byte)*(undefined2 *)(iVar15 + 2);
                                if ((bVar10 >> 6 & 1) == 0) {
                                  if (((bVar10 >> 3 & 1) != 0) || ((*(byte *)(iVar15 + 2) & 1) != 0)
                                     ) {
                                    FUN_000941f0();
                                    FUN_00028450();
                                    if ((*(byte *)(iVar15 + 2) & 1) != 0) {
                                      FUN_000941f0();
                                      FUN_00028450();
                                    }
                                  }
                                  FUN_00028450();
                                  FUN_00028450();
                                }
                                bVar10 = (byte)*(undefined2 *)(local_630 + 2);
                                if ((bVar10 >> 6 & 1) == 0) {
                                  if (((bVar10 >> 3 & 1) != 0) ||
                                     ((*(byte *)(local_630 + 2) & 1) != 0)) {
                                    FUN_000941f0();
                                    FUN_00028450();
                                    if ((*(byte *)(local_630 + 2) & 1) != 0) {
                                      FUN_000941f0();
                                      FUN_00028450();
                                    }
                                  }
                                  FUN_00028450();
                                  FUN_00028450();
                                }
                                cVar9 = FUN_00069ea0();
                              }
                              else {
                                bVar10 = (byte)*(undefined2 *)(iVar15 + 2);
                                if ((bVar10 >> 6 & 1) == 0) {
                                  if (((bVar10 >> 3 & 1) != 0) || ((*(byte *)(iVar15 + 2) & 1) != 0)
                                     ) {
                                    FUN_000941f0();
                                    FUN_00028450();
                                    if ((*(byte *)(iVar15 + 2) & 1) != 0) {
                                      FUN_000941f0();
                                      FUN_00028450();
                                    }
                                  }
                                  FUN_00028450();
                                  FUN_00028450();
                                }
                                FUN_0002b6a0();
                                local_578 = *(float *)(local_630 + 0x14) - local_5fc;
                                local_574 = *(float *)(local_630 + 0x18) - local_5f8;
                                local_570 = *(float *)(local_630 + 0x1c) - local_5f4;
                                local_4c0 = local_578;
                                local_4bc = local_574;
                                local_4b8 = local_570;
                                if ((*(byte *)(local_630 + 2) >> 3 & 1) != 0) {
                                  FUN_000941f0();
                                  FUN_00028450();
                                }
                                FUN_00028450();
                                local_5d0 = local_578 + local_5fc;
                                local_5cc = local_574 + local_5f8;
                                local_5c8 = local_5f4 + local_570;
                                local_5dc = local_5fc - local_578;
                                local_5d8 = local_5f8 - local_574;
                                local_5d4 = local_5f4 - local_570;
                                local_4f0 = local_5dc;
                                local_4ec = local_5d8;
                                local_4e8 = local_5d4;
                                local_4d8 = local_5d0;
                                local_4d4 = local_5cc;
                                local_4d0 = local_5c8;
                                cVar9 = FUN_00069750();
                              }
                            }
                            else {
                              bVar10 = (byte)*(ushort *)(iVar15 + 2);
                              if ((bVar10 >> 6 & 1) == 0) {
                                if (((bVar10 >> 3 & 1) != 0) || ((*(byte *)(iVar15 + 2) & 1) != 0))
                                {
                                  FUN_000941f0();
                                  FUN_00028450();
                                  if ((*(byte *)(iVar15 + 2) & 1) != 0) {
                                    FUN_000941f0();
                                    FUN_00028450();
                                  }
                                }
                                FUN_00028450();
                                FUN_00028450();
                              }
                              if ((*(byte *)(local_630 + 2) >> 3 & 1) != 0) {
                                FUN_000941f0();
                                FUN_00028450();
                              }
                              FUN_00028450();
                              cVar9 = FUN_000697f0();
                            }
                          }
                          else if ((*(byte *)(local_630 + 3) & 1) == 0) {
                            if ((*(ushort *)(local_630 + 2) >> 9 & 1) == 0) {
                              if ((*(ushort *)(local_630 + 2) >> 0xc & 1) == 0) goto LAB_0003b4ce;
                              FUN_0002b6a0();
                              local_5a0 = *(float *)(iVar15 + 0x14) - local_5f0;
                              local_59c = *(float *)(iVar15 + 0x18) - local_5ec;
                              local_598 = *(float *)(iVar15 + 0x1c) - local_5e8;
                              local_550 = local_5a0;
                              local_54c = local_59c;
                              local_548 = local_598;
                              if ((*(byte *)(iVar15 + 2) >> 3 & 1) != 0) {
                                FUN_000941f0();
                                FUN_00028450();
                              }
                              FUN_00028450();
                              local_5b8 = local_5a0 + local_5f0;
                              local_5b4 = local_59c + local_5ec;
                              local_5b0 = local_598 + local_5e8;
                              local_5c4 = local_5f0 - local_5a0;
                              local_5c0 = local_5ec - local_59c;
                              local_5bc = local_5e8 - local_598;
                              bVar10 = (byte)*(undefined2 *)(local_630 + 2);
                              local_4a8 = local_5c4;
                              local_4a4 = local_5c0;
                              local_4a0 = local_5bc;
                              local_490 = local_5b8;
                              local_48c = local_5b4;
                              local_488 = local_5b0;
                              if ((bVar10 >> 6 & 1) == 0) {
                                if (((bVar10 >> 3 & 1) != 0) ||
                                   ((*(byte *)(local_630 + 2) & 1) != 0)) {
                                  FUN_000941f0();
                                  FUN_00028450();
                                  if ((*(byte *)(local_630 + 2) & 1) != 0) {
                                    FUN_000941f0();
                                    FUN_00028450();
                                  }
                                }
                                FUN_00028450();
                                FUN_00028450();
                              }
                              cVar9 = FUN_00069750();
                            }
                            else {
                              fVar4 = (*(float *)(iVar15 + 8) + *(float *)(iVar15 + 0x14)) *
                                      _DAT_0020df84;
                              fVar5 = (*(float *)(iVar15 + 0x18) + *(float *)(iVar15 + 0xc)) *
                                      _DAT_0020df84;
                              fVar6 = (*(float *)(iVar15 + 0x1c) + *(float *)(iVar15 + 0x10)) *
                                      _DAT_0020df84;
                              local_5ac = *(float *)(iVar15 + 0x14) - fVar4;
                              local_5a8 = *(float *)(iVar15 + 0x18) - fVar5;
                              local_5a4 = *(float *)(iVar15 + 0x1c) - fVar6;
                              local_4cc = local_5ac;
                              local_4c8 = local_5a8;
                              local_4c4 = local_5a4;
                              if ((*(byte *)(iVar15 + 2) >> 3 & 1) != 0) {
                                FUN_000941f0();
                                FUN_00028450();
                              }
                              FUN_00028450();
                              local_5b8 = local_5ac + fVar4;
                              local_5b4 = local_5a8 + fVar5;
                              local_5b0 = local_5a4 + fVar6;
                              local_5c4 = fVar4 - local_5ac;
                              local_5c0 = fVar5 - local_5a8;
                              local_5bc = fVar6 - local_5a4;
                              fVar4 = (*(float *)(local_630 + 8) + *(float *)(local_630 + 0x14)) *
                                      _DAT_0020df84;
                              fVar5 = (*(float *)(local_630 + 0x18) + *(float *)(local_630 + 0xc)) *
                                      _DAT_0020df84;
                              fVar6 = (*(float *)(local_630 + 0x1c) + *(float *)(local_630 + 0x10))
                                      * _DAT_0020df84;
                              local_588 = *(float *)(local_630 + 0x14) - fVar4;
                              local_584 = *(float *)(local_630 + 0x18) - fVar5;
                              local_580 = *(float *)(local_630 + 0x1c) - fVar6;
                              local_55c = local_5c4;
                              local_558 = local_5c0;
                              local_554 = local_5bc;
                              local_520 = local_5b8;
                              local_51c = local_5b4;
                              local_518 = local_5b0;
                              local_4b4 = local_588;
                              local_4b0 = local_584;
                              local_4ac = local_580;
                              if ((*(byte *)(local_630 + 2) >> 3 & 1) != 0) {
                                FUN_000941f0();
                                FUN_00028450();
                              }
                              FUN_00028450();
                              local_5d0 = local_588 + fVar4;
                              local_5cc = local_584 + fVar5;
                              local_5c8 = local_580 + fVar6;
                              local_5dc = fVar4 - local_588;
                              local_5d8 = fVar5 - local_584;
                              local_5d4 = fVar6 - local_580;
                              local_538 = local_5d0;
                              local_534 = local_5cc;
                              local_530 = local_5c8;
                              local_514 = local_5dc;
                              local_510 = local_5d8;
                              local_50c = local_5d4;
                              cVar9 = FUN_000689a0(&local_5c4,&local_5dc);
                            }
                          }
                          else {
                            fVar4 = (*(float *)(iVar15 + 0x14) + *(float *)(iVar15 + 8)) *
                                    _DAT_0020df84;
                            fVar5 = (*(float *)(iVar15 + 0x18) + *(float *)(iVar15 + 0xc)) *
                                    _DAT_0020df84;
                            fVar6 = (*(float *)(iVar15 + 0x1c) + *(float *)(iVar15 + 0x10)) *
                                    _DAT_0020df84;
                            local_568 = *(float *)(iVar15 + 0x14) - fVar4;
                            local_564 = *(float *)(iVar15 + 0x18) - fVar5;
                            local_560 = *(float *)(iVar15 + 0x1c) - fVar6;
                            local_4e4 = local_568;
                            local_4e0 = local_564;
                            local_4dc = local_560;
                            if (((byte)*(ushort *)(iVar15 + 2) >> 3 & 1) != 0) {
                              FUN_000941f0();
                              FUN_00028450();
                            }
                            FUN_00028450();
                            local_5b8 = local_568 + fVar4;
                            local_5b4 = local_564 + fVar5;
                            local_5b0 = local_560 + fVar6;
                            local_5c4 = fVar4 - local_568;
                            local_5c0 = fVar5 - local_564;
                            local_5bc = fVar6 - local_560;
                            local_4fc = local_5c4;
                            local_4f8 = local_5c0;
                            local_4f4 = local_5bc;
                            local_49c = local_5b8;
                            local_498 = local_5b4;
                            local_494 = local_5b0;
                            if ((*(byte *)(local_630 + 2) >> 3 & 1) != 0) {
                              FUN_000941f0();
                              FUN_00028450();
                            }
                            FUN_00028450();
                            cVar9 = FUN_000696a0();
                          }
                        }
                        else if ((*(ushort *)(local_630 + 2) & 0x100) == 0) {
                          if ((*(ushort *)(local_630 + 2) >> 9 & 1) == 0) {
                            if ((*(ushort *)(local_630 + 2) >> 0xc & 1) == 0) goto LAB_0003b4ce;
                            if ((*(byte *)(iVar15 + 2) >> 3 & 1) != 0) {
                              FUN_000941f0();
                              FUN_00028450();
                            }
                            FUN_00028450();
                            bVar10 = (byte)*(undefined2 *)(local_630 + 2);
                            if ((bVar10 >> 6 & 1) == 0) {
                              if (((bVar10 >> 3 & 1) != 0) || ((*(byte *)(local_630 + 2) & 1) != 0))
                              {
                                FUN_000941f0();
                                FUN_00028450();
                                if ((*(byte *)(local_630 + 2) & 1) != 0) {
                                  FUN_000941f0();
                                  FUN_00028450();
                                }
                              }
                              FUN_00028450();
                              FUN_00028450();
                            }
                            cVar9 = FUN_000697f0();
                          }
                          else {
                            if ((*(byte *)(iVar15 + 2) >> 3 & 1) != 0) {
                              FUN_000941f0();
                              FUN_00028450();
                            }
                            FUN_00028450();
                            fVar4 = (*(float *)(local_630 + 8) + *(float *)(local_630 + 0x14)) *
                                    _DAT_0020df84;
                            fVar5 = (*(float *)(local_630 + 0x18) + *(float *)(local_630 + 0xc)) *
                                    _DAT_0020df84;
                            fVar6 = (*(float *)(local_630 + 0x1c) + *(float *)(local_630 + 0x10)) *
                                    _DAT_0020df84;
                            local_594 = *(float *)(local_630 + 0x14) - fVar4;
                            local_590 = *(float *)(local_630 + 0x18) - fVar5;
                            local_58c = *(float *)(local_630 + 0x1c) - fVar6;
                            local_508 = local_594;
                            local_504 = local_590;
                            local_500 = local_58c;
                            if ((*(byte *)(local_630 + 2) >> 3 & 1) != 0) {
                              FUN_000941f0();
                              FUN_00028450();
                            }
                            FUN_00028450();
                            local_5d0 = local_594 + fVar4;
                            local_5cc = local_590 + fVar5;
                            local_5c8 = local_58c + fVar6;
                            local_5dc = fVar4 - local_594;
                            local_5d8 = fVar5 - local_590;
                            local_5d4 = fVar6 - local_58c;
                            local_544 = local_5dc;
                            local_540 = local_5d8;
                            local_53c = local_5d4;
                            local_52c = local_5d0;
                            local_528 = local_5cc;
                            local_524 = local_5c8;
                            cVar9 = FUN_000696a0();
                          }
                        }
                        else {
                          if (((byte)*(ushort *)(iVar15 + 2) >> 3 & 1) != 0) {
                            FUN_000941f0();
                            FUN_00028450();
                          }
                          FUN_00028450();
                          if ((*(byte *)(local_630 + 2) >> 3 & 1) != 0) {
                            FUN_000941f0();
                            FUN_00028450();
                          }
                          FUN_00028450();
                          cVar9 = FUN_00069f30();
                        }
                        if (cVar9 != '\0') {
                          local_5e4 = local_5e4 | ((uint)bVar8 << 6 | (uint)local_692) << 8;
                          goto LAB_0003b58b;
                        }
                      }
LAB_0003b4ce:
                      local_692 = FUN_000e9f10();
                    } while (local_630 != 0);
                  }
                  local_692 = FUN_000e9ed0();
                }
                iVar16 = *(int *)(param_1 + 0x24);
                bVar8 = FUN_000e9f10();
              }
            }
            in_EDX = local_5e4 | local_5e4 >> 6 & 0xfc000 | 0x20000000;
          }
          local_634 = local_634 + 1;
        } while (local_634 < local_484);
      }
    }
    local_5e4 = in_EDX | 0x10000000;
LAB_0003b58b:
    in_EDX = local_634 & 0xff | local_5e4 & 0xfbffff00;
  }
LAB_0003b59a:
  return ~in_EDX >> 2 & 0x4000000 | in_EDX;
}


