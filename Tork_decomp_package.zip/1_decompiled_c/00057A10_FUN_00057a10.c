// func FUN_00057a10 @ 0x00057A10 (size 0x33)

undefined4 FUN_00057a10(void)

{
  int in_EAX;
  undefined4 uVar1;
  int *piVar2;
  int *unaff_EBX;
  int unaff_EDI;
  undefined4 uVar3;
  undefined4 uVar4;
  
  uVar4 = 0x14;
  uVar3 = 0;
  uVar1 = FUN_0012c6d6(0,0x14);
  piVar2 = (int *)FUN_001314ea(uVar1,uVar3,uVar4);
  if (piVar2 == (int *)0x0) {
    return 0;
  }
  *piVar2 = in_EAX;
  piVar2[1] = in_EAX;
  piVar2[2] = in_EAX + unaff_EDI;
  piVar2[3] = unaff_EDI;
  piVar2[4] = *unaff_EBX;
  *unaff_EBX = (int)piVar2;
  return 1;
}


