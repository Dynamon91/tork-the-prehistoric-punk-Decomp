// func FUN_000489a0 @ 0x000489A0 (size 0x51)

uint FUN_000489a0(uint param_1)

{
  int iVar1;
  uint in_EAX;
  
  if (param_1 == 0xffffffff) {
    return in_EAX & 0xffffff00;
  }
  iVar1 = DAT_0022d4c0 + (param_1 >> 0x17) * 0x18;
  if ((*(int *)(iVar1 + 0xc) == 0) || (*(uint *)(iVar1 + 0x10) < 2)) {
    FUN_0005fe30(DAT_0022d4c0,param_1);
  }
  return (uint)(*(short *)(*(int *)(*(int *)(iVar1 + 0xc) + 0x18) + 4 + (param_1 & 0x7fffff) * 0xc)
               == 0x48a3);
}


