// func FUN_0001b8e0 @ 0x0001B8E0 (size 0xC3)

void FUN_0001b8e0(char param_1)

{
  int iVar1;
  ushort uVar2;
  short *psVar3;
  uint uVar4;
  ushort *puVar5;
  int unaff_EBX;
  
  puVar5 = (ushort *)(unaff_EBX + (uint)*(ushort *)(unaff_EBX + 2) * 4);
  uVar2 = *puVar5;
  while (uVar2 != 0xffff) {
    psVar3 = *(short **)(unaff_EBX + (uint)uVar2 * 4);
    uVar4 = FUN_0001aa20();
    if (param_1 != '\0') {
      *(uint *)(unaff_EBX + (uint)uVar2 * 4) = uVar4;
    }
    if (uVar4 != 0xffffffff) {
      iVar1 = DAT_0022d4c0 + (uVar4 >> 0x17) * 0x18;
      if ((*(int *)(DAT_0022d4c0 + 0xc + (uVar4 >> 0x17) * 0x18) == 0) ||
         (*(uint *)(iVar1 + 0x10) < 2)) {
        FUN_0005fe30(DAT_0022d4c0,uVar4);
      }
      if ((*(short *)(*(int *)(*(int *)(iVar1 + 0xc) + 0x18) + 4 + (uVar4 & 0x7fffff) * 0xc) ==
           0x1c2f) && (*psVar3 = *psVar3 + -1, *psVar3 == 0)) {
        FUN_000dea30(0);
        FUN_0001aab0(DAT_0022d4c0);
        FUN_00058010();
      }
    }
    puVar5 = puVar5 + 1;
    uVar2 = *puVar5;
  }
  return;
}


