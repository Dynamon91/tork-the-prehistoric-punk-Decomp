// func FUN_00024070 @ 0x00024070 (size 0x47)

float10 FUN_00024070(float *param_1)

{
  float *in_ECX;
  float fVar1;
  float fVar2;
  
  fVar1 = (float)*(undefined8 *)(in_ECX + 1) - (float)*(undefined8 *)(param_1 + 1);
  fVar2 = (float)((ulonglong)*(undefined8 *)(in_ECX + 1) >> 0x20) -
          (float)((ulonglong)*(undefined8 *)(param_1 + 1) >> 0x20);
  return (float10)((*in_ECX - *param_1) * (*in_ECX - *param_1) + fVar1 * fVar1 + fVar2 * fVar2);
}


