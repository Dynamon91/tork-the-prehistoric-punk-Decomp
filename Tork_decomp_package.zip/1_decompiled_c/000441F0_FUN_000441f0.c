// func FUN_000441f0 @ 0x000441F0 (size 0x2D)

void FUN_000441f0(undefined4 param_1,undefined4 param_2)

{
  ushort in_AX;
  int in_ECX;
  undefined4 in_EDX;
  
  if ((in_AX < 0xff) && (*(char *)((uint)in_AX * 0x68 + in_ECX + 0x58) < '\0')) {
    FUN_00043a30(param_1,param_2,in_EDX);
  }
  return;
}


