// func FUN_0004c520 @ 0x0004C520 (size 0x4E)

void FUN_0004c520(void)

{
  int iVar1;
  byte in_CL;
  int unaff_EBX;
  undefined1 local_40 [64];
  
  if ((*(int *)(unaff_EBX + 0xc) != 0) && (in_CL < *(byte *)(*(int *)(unaff_EBX + 0xc) + 2))) {
    FUN_00047960();
    iVar1 = *(int *)(unaff_EBX + 0x14);
    FUN_000479c0();
    FUN_000286c0((uint)in_CL * 0xc4 + 0x44 + iVar1,local_40);
  }
  return;
}


