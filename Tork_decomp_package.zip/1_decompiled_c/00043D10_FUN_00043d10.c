// func FUN_00043d10 @ 0x00043D10 (size 0x13D)

void FUN_00043d10(void)

{
  char *pcVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  int unaff_ESI;
  undefined4 local_44;
  uint local_40;
  
  if ((*(byte *)(unaff_ESI + 0x48) & 2) == 0) {
    if (*(int *)(unaff_ESI + 100) != 0) {
      FUN_000431d0();
      piVar3 = *(int **)(unaff_ESI + 100);
      if (((~*(byte *)(*piVar3 + 0x2c) & 1) != 0) && ((char)piVar3[0x1a] != '\0')) {
        *(undefined1 *)(piVar3 + 0x1a) = 0;
        if (((int *)piVar3[6] != (int *)0x0) && (iVar2 = *(int *)piVar3[6], iVar2 != 0)) {
          FUN_001689c6(iVar2,2,0);
        }
      }
      iVar5 = (uint)*(ushort *)(unaff_ESI + 0x46) * 0x10;
      iVar2 = iVar5 + 0x7fc + DAT_002414dc;
      *(undefined4 *)(*(int *)(iVar2 + 4) + (uint)*(byte *)(iVar5 + 0x805 + DAT_002414dc) * 4) =
           *(undefined4 *)(unaff_ESI + 100);
      pcVar1 = (char *)(iVar2 + 9);
      *pcVar1 = *pcVar1 + '\x01';
      *(undefined4 *)(unaff_ESI + 100) = 0;
    }
  }
  else if (*(int *)(unaff_ESI + 100) != 0) {
    local_44 = 9;
    local_40 = 0;
    FUN_00043310(*(undefined4 *)(*(int *)(unaff_ESI + 100) + 0x248),&local_44);
    local_44 = 0xc;
    local_40 = local_40 & 0xffffff00;
    FUN_00043310(*(undefined4 *)(*(int *)(unaff_ESI + 100) + 0x248),&local_44);
    uVar4 = (uint)(byte)((1 < (byte)*(undefined4 *)(*(int *)(unaff_ESI + 100) + 4)) + 2);
    iVar2 = uVar4 + DAT_00241240;
    *(undefined1 *)(uVar4 + 0xd8 + (uint)*(byte *)(uVar4 + 0xcc + DAT_00241240) * 4 + DAT_00241240)
         = *(undefined1 *)(*(int *)(unaff_ESI + 100) + 0x51);
    *(char *)(iVar2 + 0xcc) = *(char *)(iVar2 + 0xcc) + '\x01';
    *(undefined4 *)(unaff_ESI + 100) = 0;
    return;
  }
  return;
}


