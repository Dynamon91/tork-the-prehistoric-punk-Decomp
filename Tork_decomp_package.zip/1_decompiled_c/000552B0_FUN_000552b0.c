// func FUN_000552b0 @ 0x000552B0 (size 0x52)

void FUN_000552b0(int param_1)

{
  uint *puVar1;
  int in_EAX;
  int iVar2;
  int unaff_ESI;
  uint uVar3;
  
  puVar1 = (uint *)(unaff_ESI + 4 + (in_EAX >> 5) * 4);
  *puVar1 = *puVar1 | 1 << ((byte)in_EAX & 0x1f);
  param_1 = in_EAX + param_1;
  while (in_EAX = in_EAX + 1, in_EAX < param_1) {
    uVar3 = 1 << ((byte)in_EAX & 0x1f);
    iVar2 = in_EAX >> 5;
    puVar1 = (uint *)(unaff_ESI + 4 + iVar2 * 4);
    *puVar1 = *puVar1 | uVar3;
    *(uint *)(unaff_ESI + 0x24 + iVar2 * 4) = *(uint *)(unaff_ESI + 0x24 + iVar2 * 4) | uVar3;
  }
  return;
}


