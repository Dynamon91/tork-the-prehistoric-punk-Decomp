// func FUN_0005afd0 @ 0x0005AFD0 (size 0x13E)

void FUN_0005afd0(ushort *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  ushort uVar4;
  ushort uVar5;
  ushort uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  uint uVar9;
  undefined2 *unaff_EBX;
  undefined2 *puVar10;
  undefined4 *puVar11;
  ushort *puVar12;
  
  if (param_1 != (ushort *)0x0) {
    uVar6 = *param_1;
    puVar12 = param_1 + 1;
    puVar11 = (undefined4 *)(unaff_EBX + 6);
    for (uVar9 = (uint)(uVar6 >> 2); uVar9 != 0; uVar9 = uVar9 - 1) {
      *puVar11 = *(undefined4 *)puVar12;
      puVar12 = puVar12 + 2;
      puVar11 = puVar11 + 1;
    }
    puVar10 = (undefined2 *)((int)(param_1 + 1) + (uint)uVar6);
    for (uVar9 = uVar6 & 3; uVar9 != 0; uVar9 = uVar9 - 1) {
      *(char *)puVar11 = (char)*puVar12;
      puVar12 = (ushort *)((int)puVar12 + 1);
      puVar11 = (undefined4 *)((int)puVar11 + 1);
    }
    *unaff_EBX = *puVar10;
    unaff_EBX[1] = puVar10[1];
    uVar6 = puVar10[2];
    puVar11 = (undefined4 *)(puVar10 + 3);
    *(undefined4 *)(unaff_EBX + 2) = 0;
    unaff_EBX[4] = 0;
    unaff_EBX[5] = 0;
    if (uVar6 != 0) {
      uVar7 = FUN_00058070();
      *(undefined4 *)(unaff_EBX + 2) = uVar7;
      unaff_EBX[4] = uVar6;
      uVar5 = unaff_EBX[5];
      if (uVar6 <= (ushort)unaff_EBX[5]) {
        uVar5 = uVar6;
      }
      unaff_EBX[5] = uVar5;
    }
    param_1 = (ushort *)(uint)uVar6;
    if (param_1 != (ushort *)0x0) {
      do {
        uVar7 = *puVar11;
        uVar2 = puVar11[1];
        uVar3 = puVar11[2];
        puVar11 = puVar11 + 3;
        uVar6 = unaff_EBX[4];
        uVar5 = unaff_EBX[5] + 1;
        if (uVar6 < uVar5) {
          uVar4 = uVar6 * 2;
          if (uVar6 == 0) {
            uVar4 = uVar5;
          }
          for (; uVar4 < uVar5; uVar4 = uVar4 << 1) {
          }
          uVar8 = FUN_00058070();
          *(undefined4 *)(unaff_EBX + 2) = uVar8;
          unaff_EBX[4] = uVar4;
          uVar6 = unaff_EBX[5];
          if (uVar4 <= (ushort)unaff_EBX[5]) {
            uVar6 = uVar4;
          }
          unaff_EBX[5] = uVar6;
        }
        puVar1 = (undefined4 *)(*(int *)(unaff_EBX + 2) + (uint)(ushort)unaff_EBX[5] * 0xc);
        *puVar1 = uVar7;
        puVar1[1] = uVar2;
        puVar1[2] = uVar3;
        unaff_EBX[5] = unaff_EBX[5] + 1;
        param_1 = (ushort *)((int)param_1 - 1);
      } while (param_1 != (ushort *)0x0);
    }
  }
  return;
}


