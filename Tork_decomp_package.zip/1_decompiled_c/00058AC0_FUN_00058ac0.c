// func FUN_00058ac0 @ 0x00058AC0 (size 0x8D)

void FUN_00058ac0(void)

{
  ushort uVar1;
  int in_EAX;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *unaff_ESI;
  int unaff_EDI;
  
  iVar3 = *(int *)(unaff_EDI + 0x50 + in_EAX * 0x14);
  iVar2 = unaff_EDI + 0x4c + in_EAX * 0x14;
  uVar1 = *(ushort *)(*(int *)(unaff_EDI + 0x4c + in_EAX * 0x14) + iVar3 * 2);
  iVar3 = iVar3 + 1;
  *(int *)(iVar2 + 4) = iVar3;
  if (*(int *)(iVar2 + 0x10) <= iVar3) {
    *(int *)(iVar2 + 4) = iVar3 - *(int *)(iVar2 + 0x10);
  }
  *(int *)(iVar2 + 0xc) = *(int *)(iVar2 + 0xc) + -1;
  FUN_0005a4f0();
  *(ushort *)(*(int *)(unaff_EDI + 0xa4) + (uint)*(ushort *)(unaff_EDI + 0xaa) * 2) = uVar1;
  *(short *)(unaff_EDI + 0xaa) = *(short *)(unaff_EDI + 0xaa) + 1;
  iVar2 = (uint)uVar1 * 0x18;
  puVar4 = (undefined4 *)(*(int *)(unaff_EDI + 0x9c) + iVar2);
  *unaff_ESI = *puVar4;
  unaff_ESI[1] = puVar4[1];
  unaff_ESI[2] = puVar4[2];
  unaff_ESI[3] = puVar4[3];
  unaff_ESI[4] = puVar4[4];
  unaff_ESI[5] = puVar4[5];
  *(undefined4 *)(*(int *)(unaff_EDI + 0x9c) + 0x14 + iVar2) = 0;
  return;
}


