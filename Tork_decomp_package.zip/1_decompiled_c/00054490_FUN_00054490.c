// func FUN_00054490 @ 0x00054490 (size 0x1A)

int FUN_00054490(void)

{
  ushort uVar1;
  ushort *in_ECX;
  
  if (*in_ECX == 0) {
    return -1;
  }
  uVar1 = *in_ECX - 1;
  *in_ECX = uVar1;
  return uVar1 + 6 + (int)in_ECX;
}


