// func FUN_0001fb00 @ 0x0001FB00 (size 0x1F)

undefined4 FUN_0001fb00(void)

{
  int *in_EAX;
  int *in_ECX;
  
  if (((*in_ECX == *in_EAX) && (in_ECX[1] == in_EAX[1])) && (in_ECX[2] == in_EAX[2])) {
    return 0;
  }
  return 1;
}


