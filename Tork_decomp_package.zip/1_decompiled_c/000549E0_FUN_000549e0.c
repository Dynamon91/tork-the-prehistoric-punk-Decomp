// func FUN_000549e0 @ 0x000549E0 (size 0x24)

undefined4 FUN_000549e0(undefined4 *param_1)

{
  ushort *in_EAX;
  
  if ((int)(uint)*in_EAX < (int)(in_EAX[1] - 1)) {
    *(undefined4 *)(in_EAX + (uint)*in_EAX * 2 + 3) = *param_1;
    *in_EAX = *in_EAX + 1;
    return 0;
  }
  return 0xffffffff;
}


