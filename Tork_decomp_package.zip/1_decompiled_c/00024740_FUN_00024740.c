// func FUN_00024740 @ 0x00024740 (size 0x31)

void FUN_00024740(void)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float *in_EAX;
  float *in_ECX;
  float *in_EDX;
  
  fVar1 = *in_EAX;
  fVar2 = in_ECX[2];
  fVar3 = in_EAX[2];
  fVar4 = *in_ECX;
  fVar5 = *in_ECX;
  fVar6 = in_EAX[1];
  fVar7 = in_ECX[1];
  fVar8 = *in_EAX;
  *in_EDX = in_EAX[2] * in_ECX[1] - in_EAX[1] * in_ECX[2];
  in_EDX[1] = fVar1 * fVar2 - fVar3 * fVar4;
  in_EDX[2] = fVar5 * fVar6 - fVar7 * fVar8;
  return;
}


