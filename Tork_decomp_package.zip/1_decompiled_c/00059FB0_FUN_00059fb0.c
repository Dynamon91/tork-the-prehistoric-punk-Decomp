// func FUN_00059fb0 @ 0x00059FB0 (size 0x25)

bool FUN_00059fb0(void)

{
  int iVar1;
  int in_ECX;
  
  FUN_0012ebe2(*(undefined4 *)(in_ECX + 0x18),0xffffffff);
  iVar1 = *(int *)(in_ECX + 0x10);
  FUN_0012e945(*(undefined4 *)(in_ECX + 0x18));
  return iVar1 != 0;
}


