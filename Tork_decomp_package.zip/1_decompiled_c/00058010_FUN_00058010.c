// func FUN_00058010 @ 0x00058010 (size 0x5C)

int FUN_00058010(void)

{
  int iVar1;
  int unaff_ESI;
  
  if ((int)*(uint *)(unaff_ESI + -4) < 0) {
    *(uint *)(unaff_ESI + -4) = *(uint *)(unaff_ESI + -4) & 0x7fffffff;
    iVar1 = FUN_00073b30();
    return iVar1;
  }
  iVar1 = 0;
  LOCK();
  if (DAT_0022aab8 == 0) {
    DAT_0022aab8 = 1;
  }
  else {
    iVar1 = DAT_0022aab8;
  }
  UNLOCK();
  while (iVar1 != 0) {
    FUN_0012ec0e(0);
    iVar1 = 0;
    LOCK();
    if (DAT_0022aab8 == 0) {
      DAT_0022aab8 = 1;
    }
    else {
      iVar1 = DAT_0022aab8;
    }
    UNLOCK();
  }
  FUN_00056c90();
  iVar1 = DAT_0022aab8;
  LOCK();
  DAT_0022aab8 = 0;
  UNLOCK();
  return iVar1;
}


