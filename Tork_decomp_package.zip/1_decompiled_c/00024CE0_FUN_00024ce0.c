// func FUN_00024ce0 @ 0x00024CE0 (size 0x6F)

void FUN_00024ce0(void)

{
  float *in_ECX;
  float *in_EDX;
  
  if (*in_ECX < *in_EDX) {
    *in_EDX = *in_ECX;
  }
  if (in_ECX[1] < in_EDX[1]) {
    in_EDX[1] = in_ECX[1];
  }
  if (in_ECX[2] < in_EDX[2]) {
    in_EDX[2] = in_ECX[2];
  }
  if (in_EDX[3] < in_ECX[3]) {
    in_EDX[3] = in_ECX[3];
  }
  if (in_EDX[4] < in_ECX[4]) {
    in_EDX[4] = in_ECX[4];
  }
  if (in_EDX[5] < in_ECX[5]) {
    in_EDX[5] = in_ECX[5];
  }
  return;
}


