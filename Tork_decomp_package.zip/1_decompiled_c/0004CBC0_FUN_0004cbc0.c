// func FUN_0004cbc0 @ 0x0004CBC0 (size 0x6F)

void FUN_0004cbc0(undefined1 param_1,undefined2 param_2,undefined4 *param_3,undefined4 param_4,
                 undefined1 param_5,undefined1 param_6)

{
  undefined1 local_68;
  undefined1 local_67;
  undefined1 local_66;
  undefined1 local_65;
  undefined1 *local_64;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_48;
  undefined2 local_2;
  
  local_67 = param_1;
  local_66 = param_5;
  local_65 = param_6;
  local_60 = *param_3;
  local_5c = param_3[1];
  local_58 = param_3[2];
  local_48 = param_4;
  local_2 = param_2;
  local_68 = 2;
  local_64 = &LAB_00111ca0;
  FUN_0004c800(*(undefined4 *)(*(int *)(DAT_0022a6c4 + 0x14) + 0x20),*(int *)(DAT_0022a6c4 + 0x14),
               &local_68);
  return;
}


