// func FUN_000112c0 @ 0x000112C0 (size 0xA0)

undefined4 FUN_000112c0(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int in_EAX;
  undefined4 *puVar2;
  uint in_ECX;
  int unaff_EBX;
  uint uVar3;
  undefined4 unaff_retaddr;
  
  (*(code *)IAT_xboxkrnl_RtlEnterCriticalSection)(unaff_EBX + 0x4008);
  puVar2 = (undefined4 *)FUN_00057f60(0x14);
  puVar2[1] = param_1;
  uVar3 = in_EAX * 0x10;
  puVar2[2] = param_2;
  *puVar2 = unaff_retaddr;
  puVar2[4] = in_ECX & 0xf | uVar3;
  if (uVar3 != 0xfffffff0) {
    puVar2[4] = uVar3 + 0x40 ^ in_ECX & 0xf;
  }
  piVar1 = (int *)(unaff_EBX + 0x4000);
  *piVar1 = *piVar1 + -1;
  if (*piVar1 < 0) {
    puVar2[3] = 0;
  }
  else {
    puVar2[3] = *(undefined4 *)(&DAT_00004004 + unaff_EBX);
    if (*(int *)(unaff_EBX + 0x4000) != 0) goto LAB_00011343;
  }
  *(undefined4 *)(&DAT_00004004 + unaff_EBX) = 0;
LAB_00011343:
  FUN_0005d0c0(DAT_0022d4c0,unaff_retaddr,puVar2);
  (*(code *)IAT_xboxkrnl_RtlLeaveCriticalSection)(unaff_EBX + 0x4008);
  return 1;
}


