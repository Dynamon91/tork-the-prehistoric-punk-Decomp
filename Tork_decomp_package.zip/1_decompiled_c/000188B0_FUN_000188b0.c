// func FUN_000188b0 @ 0x000188B0 (size 0x6B)

void FUN_000188b0(void)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint *in_EDX;
  int iVar4;
  
  iVar4 = 0;
  uVar2 = in_EDX[1] - 1 & 0x1ff;
  uVar3 = uVar2;
  while( true ) {
    if ((short)in_EDX[uVar3 * 4 + 4] == -1) {
      iVar4 = iVar4 + 1;
    }
    else {
      if (uVar3 != uVar2) {
        puVar1 = in_EDX + uVar2 * 4 + 2;
        *puVar1 = in_EDX[uVar3 * 4 + 2];
        puVar1[1] = in_EDX[uVar3 * 4 + 3];
        puVar1[2] = in_EDX[uVar3 * 4 + 4];
        puVar1[3] = in_EDX[uVar3 * 4 + 5];
      }
      uVar2 = uVar2 - 1 & 0x1ff;
    }
    if (uVar3 == *in_EDX) break;
    uVar3 = uVar3 - 1 & 0x1ff;
  }
  *in_EDX = *in_EDX + iVar4 & 0x1ff;
  return;
}


