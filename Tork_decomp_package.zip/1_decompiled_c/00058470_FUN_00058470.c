// func FUN_00058470 @ 0x00058470 (size 0x19B)

void FUN_00058470(int param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int in_EAX;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  
  iVar4 = *(int *)(in_EAX + 0xc);
  iVar3 = *(int *)(in_EAX + 8);
  uVar8 = *(uint *)(in_EAX + 4);
  uVar5 = *(uint *)(param_1 + 4) & 0x7ffffffc;
  *(uint *)(in_EAX + 4) = *(uint *)(in_EAX + 4) & 1 | uVar5;
  iVar7 = uVar5 + in_EAX;
  *(int *)(iVar4 + 8) = iVar7;
  uVar8 = uVar8 & 0x7ffffffc;
  *(int *)(iVar3 + 0xc) = iVar7;
  _memmove((void *)(in_EAX + 8),(void *)(param_1 + 8),uVar5 - 4);
  *(uint *)(iVar7 + 4) = uVar8 | 1;
  *(int *)(iVar7 + 8) = iVar3;
  *(int *)(iVar7 + 0xc) = iVar4;
  *(uint *)(iVar7 + uVar8) = uVar8;
  uVar5 = *(uint *)(iVar7 + 4) & 0xfffffffe;
  *(uint *)(uVar5 + 4 + iVar7) = *(uint *)(uVar5 + 4 + iVar7) & 0xfffffffe;
  iVar4 = (*(uint *)(iVar7 + 4) & 0xfffffffe) + iVar7;
  if (iVar4 == DAT_0022a76c) {
    if (*(int *)(iVar7 + 0xc) != 0) {
      *(undefined4 *)(*(int *)(iVar7 + 0xc) + 8) = *(undefined4 *)(iVar7 + 8);
    }
    if (*(int *)(iVar7 + 8) != 0) {
      *(undefined4 *)(*(int *)(iVar7 + 8) + 0xc) = *(undefined4 *)(iVar7 + 0xc);
    }
    *(uint *)(iVar7 + 4) = (*(uint *)(iVar4 + 4) & 0x7ffffffc) + uVar8 | 1;
    DAT_0022a76c = iVar7;
  }
  else if ((*(byte *)((*(uint *)(iVar4 + 4) & 0xfffffffe) + 4 + iVar4) & 1) == 0) {
    if (*(int *)(iVar4 + 0xc) != 0) {
      *(undefined4 *)(*(int *)(iVar4 + 0xc) + 8) = *(undefined4 *)(iVar4 + 8);
    }
    if (*(int *)(iVar4 + 8) != 0) {
      *(undefined4 *)(*(int *)(iVar4 + 8) + 0xc) = *(undefined4 *)(iVar4 + 0xc);
    }
    if (*(int *)(iVar7 + 0xc) != 0) {
      *(undefined4 *)(*(int *)(iVar7 + 0xc) + 8) = *(undefined4 *)(iVar7 + 8);
    }
    if (*(int *)(iVar7 + 8) != 0) {
      *(undefined4 *)(*(int *)(iVar7 + 8) + 0xc) = *(undefined4 *)(iVar7 + 0xc);
    }
    uVar8 = (*(uint *)(iVar4 + 4) & 0x7ffffffc) + uVar8;
    *(uint *)(iVar7 + 4) = uVar8 | 1;
    *(uint *)(uVar8 + iVar7) = uVar8;
    if (uVar8 < 0x100) {
      uVar5 = uVar8 >> 3;
      puVar6 = &DAT_0022a76c + uVar5 * 2;
      puVar9 = *(undefined4 **)(&DAT_0022a774 + uVar5 * 8);
    }
    else {
      uVar5 = FUN_00056260();
      puVar9 = *(undefined4 **)(&DAT_0022a774 + uVar5 * 8);
      puVar1 = &DAT_0022a76c + uVar5 * 2;
      puVar6 = puVar1;
      if (puVar9 != puVar1) {
        puVar6 = *(undefined4 **)(&DAT_0022a778 + uVar5 * 8);
        if (uVar8 < (uint)puVar6[1]) {
          puVar9 = puVar1;
        }
        else {
          uVar2 = puVar9[1];
          while ((uVar8 | 1) < uVar2) {
            puVar9 = (undefined4 *)puVar9[2];
            uVar2 = puVar9[1];
          }
          puVar6 = (undefined4 *)puVar9[3];
        }
      }
    }
    (&DAT_0022aa74)[(int)uVar5 >> 5] = (&DAT_0022aa74)[(int)uVar5 >> 5] | 1 << ((byte)uVar5 & 0x1f);
    *(undefined4 **)(iVar7 + 8) = puVar9;
    *(undefined4 **)(iVar7 + 0xc) = puVar6;
    puVar9[3] = iVar7;
    puVar6[2] = iVar7;
    return;
  }
  return;
}


