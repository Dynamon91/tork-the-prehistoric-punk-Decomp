// func FUN_00021bc0 @ 0x00021BC0 (size 0x37)

void FUN_00021bc0(void)

{
  int in_EAX;
  uint uVar1;
  uint uVar2;
  
  FUN_00064de0();
  FUN_000655b0(in_EAX);
  uVar1 = 0;
  *(undefined4 *)(in_EAX + 0x24) = 0;
  if (*(short *)(in_EAX + 0x1e) != 0) {
    do {
      uVar2 = uVar1 & 0xffff;
      uVar1 = uVar1 + 1;
      *(float *)(in_EAX + 0x24) =
           *(float *)(*(int *)(in_EAX + 0x18) + uVar2 * 4) + *(float *)(in_EAX + 0x24);
    } while ((int)uVar1 < (int)(uint)*(ushort *)(in_EAX + 0x1e));
  }
  return;
}


