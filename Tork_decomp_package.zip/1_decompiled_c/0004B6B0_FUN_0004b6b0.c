// func FUN_0004b6b0 @ 0x0004B6B0 (size 0xB2)

wchar_t * FUN_0004b6b0(int param_1,int param_2,size_t param_3)

{
  wchar_t *pwVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = FUN_00134fe8(param_1);
  iVar2 = DAT_002411d8;
  if (iVar3 < param_2) {
    FUN_00018c30();
    iVar2 = DAT_002411d8;
    iVar3 = FUN_000550f0(1);
    *(undefined4 *)(&DAT_00002064 + iVar3 * 4 + iVar2) = 0;
    pwVar1 = (wchar_t *)(iVar3 * 0x20 + 0x44 + iVar2);
    *pwVar1 = L'\0';
    return pwVar1;
  }
  if (param_3 == 0) {
    param_3 = (iVar3 - param_2) + 1;
  }
  iVar3 = param_3 * 2 + 0x21;
  iVar3 = FUN_000550f0((int)(iVar3 + (iVar3 >> 0x1f & 0x1fU)) >> 5);
  *(undefined4 *)(&DAT_00002064 + iVar3 * 4 + iVar2) = 0;
  pwVar1 = (wchar_t *)(iVar3 * 0x20 + 0x44 + iVar2);
  _wcsncpy(pwVar1,(wchar_t *)(param_1 + 2 + param_2 * 2),param_3);
  pwVar1[param_3] = L'\0';
  FUN_00018c30();
  return pwVar1;
}


