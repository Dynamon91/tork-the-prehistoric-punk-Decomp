// func FUN_0004cb20 @ 0x0004CB20 (size 0x8F)

void FUN_0004cb20(undefined1 param_1,undefined2 param_2,undefined4 *param_3,undefined4 *param_4,
                 undefined4 param_5,byte param_6)

{
  undefined1 local_68;
  undefined1 local_67;
  byte local_66;
  undefined1 local_65;
  undefined1 *local_64;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined2 local_2;
  
  local_67 = param_1;
  local_66 = param_6 & 3;
  local_65 = (param_6 & 0x80) == 0x80;
  local_60 = *param_3;
  local_5c = param_3[1];
  local_58 = param_3[2];
  local_54 = *param_4;
  local_50 = param_4[1];
  local_4c = param_4[2];
  local_48 = param_5;
  local_2 = param_2;
  local_68 = 1;
  local_64 = &LAB_001118b0;
  FUN_0004c800(*(undefined4 *)(*(int *)(DAT_0022a6c4 + 0x14) + 0x20),*(int *)(DAT_0022a6c4 + 0x14),
               &local_68);
  return;
}


