// func FUN_00043c80 @ 0x00043C80 (size 0x7E)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00043c80(void)

{
  int iVar1;
  char cVar2;
  int in_EAX;
  
  if (-1 < (char)*(byte *)(in_EAX + 0x48)) {
    return 0;
  }
  if ((*(byte *)(in_EAX + 0x48) & 2) == 0) {
    if ((*(int *)(in_EAX + 100) != 0) && (cVar2 = FUN_00043270(), cVar2 != '\0')) {
      if (*(float *)(in_EAX + 0x14) != _DAT_0020df5c) {
        return 0;
      }
      if (*(float *)(*(int *)(in_EAX + 100) + 4) == _DAT_0020df5c) {
        return 1;
      }
      return 0;
    }
  }
  else {
    iVar1 = *(int *)(in_EAX + 100);
    if (iVar1 != 0) {
      if (*(char *)(iVar1 + 0x209) == '\0') {
        cVar2 = FUN_000433a0();
        if (cVar2 != '\0') {
          return 1;
        }
        if (*(char *)(iVar1 + 0xbb) == '\0') {
          return 1;
        }
      }
      return 0;
    }
  }
  return 1;
}


