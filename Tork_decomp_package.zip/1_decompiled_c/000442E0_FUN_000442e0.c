// func FUN_000442e0 @ 0x000442E0 (size 0x20)

void FUN_000442e0(void)

{
  ushort in_AX;
  int in_ECX;
  
  if ((in_AX < 0xff) && (*(char *)((uint)in_AX * 0x68 + in_ECX + 0x58) < '\0')) {
    FUN_00043b80();
    return;
  }
  return;
}


