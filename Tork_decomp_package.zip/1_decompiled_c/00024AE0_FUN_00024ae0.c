// func FUN_00024ae0 @ 0x00024AE0 (size 0x29)

undefined4 FUN_00024ae0(void)

{
  int iVar1;
  uint in_ECX;
  int in_EDX;
  
  if ((in_ECX == 0xffffffff) ||
     (iVar1 = *(int *)(in_EDX + 0xc + (in_ECX >> 0x17) * 0x18), iVar1 == 0)) {
    return 0;
  }
  return *(undefined4 *)(*(int *)(iVar1 + 0x18) + 8 + (in_ECX & 0x7fffff) * 0xc);
}


