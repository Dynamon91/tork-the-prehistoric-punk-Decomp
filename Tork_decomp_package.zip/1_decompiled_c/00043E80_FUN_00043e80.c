// func FUN_00043e80 @ 0x00043E80 (size 0x6C)

void FUN_00043e80(ushort *param_1)

{
  ushort uVar1;
  ushort uVar2;
  int iVar3;
  ushort *unaff_EBX;
  int unaff_ESI;
  ushort unaff_DI;
  
  iVar3 = (uint)unaff_DI * 0x68;
  uVar1 = *(ushort *)(iVar3 + 0x68 + unaff_ESI);
  uVar2 = *(ushort *)(iVar3 + 0x6a + unaff_ESI);
  iVar3 = iVar3 + 0x10 + unaff_ESI;
  if (uVar1 == 0xffff) {
    *param_1 = uVar2;
  }
  else {
    *(ushort *)(unaff_ESI + 0x6a + (uint)uVar1 * 0x68) = uVar2;
  }
  if (uVar2 != 0xffff) {
    *(ushort *)((uVar2 + 1) * 0x68 + unaff_ESI) = uVar1;
  }
  if (*unaff_EBX != 0xffff) {
    *(ushort *)((*unaff_EBX + 1) * 0x68 + unaff_ESI) = unaff_DI;
  }
  *(undefined2 *)(iVar3 + 0x58) = 0xffff;
  *(ushort *)(iVar3 + 0x5a) = *unaff_EBX;
  *unaff_EBX = unaff_DI;
  return;
}


