// func FUN_000267e0 @ 0x000267E0 (size 0x11A)

void FUN_000267e0(void)

{
  undefined1 local_40 [64];
  
  FUN_0006f5f0(local_40);
  FUN_00025030();
  return;
}


