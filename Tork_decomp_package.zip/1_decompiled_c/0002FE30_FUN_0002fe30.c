// func FUN_0002fe30 @ 0x0002FE30 (size 0xAC)

undefined4
FUN_0002fe30(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 *param_5)

{
  int iVar1;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  undefined4 local_4;
  
  local_1c = *param_1;
  local_18 = param_1[1];
  local_14 = param_1[2];
  local_c = param_2[1];
  local_10 = *param_2;
  local_8 = param_2[2];
  local_4 = param_3;
  FUN_000fc460(&local_1c,0,0xff,0);
  iVar1 = DAT_002414cc;
  if ((&DAT_000067a0)[DAT_002414cc] == '\0') {
    return 0;
  }
  *param_4 = *(undefined4 *)(&DAT_000067a4 + DAT_002414cc);
  param_4[1] = *(undefined4 *)(&DAT_000067a8 + iVar1);
  param_4[2] = *(undefined4 *)(&DAT_000067ac + iVar1);
  *param_5 = *(undefined4 *)(&DAT_000067b0 + iVar1);
  param_5[1] = *(undefined4 *)(&DAT_000067b4 + iVar1);
  param_5[2] = *(undefined4 *)(&DAT_000067b8 + iVar1);
  return *(undefined4 *)(&DAT_000067bc + iVar1);
}


