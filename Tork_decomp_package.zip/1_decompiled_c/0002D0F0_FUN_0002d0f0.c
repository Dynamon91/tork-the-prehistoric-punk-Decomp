// func FUN_0002d0f0 @ 0x0002D0F0 (size 0x25FB)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_0002d0f0(byte param_1,byte param_2)

{
  ushort uVar1;
  int iVar2;
  float *pfVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  char cVar7;
  int iVar8;
  byte bVar9;
  uint uVar10;
  int in_stack_0000001c;
  int *in_stack_00000020;
  byte *in_stack_00000024;
  int *in_stack_00000028;
  int *in_stack_0000002c;
  byte *in_stack_00000030;
  float local_618;
  float local_614;
  float local_60c;
  float local_608;
  float local_600;
  float local_5fc;
  float local_5f4;
  float local_5f0;
  float local_5e8;
  float local_5e4;
  float local_5dc;
  float local_5d8;
  float local_5d0;
  float local_5cc;
  float local_5c8;
  float local_5c4;
  float local_5c0;
  float local_5bc;
  float local_5b8;
  float local_5b4;
  float local_5b0;
  float local_5ac;
  float local_5a8;
  float local_5a4;
  float local_5a0;
  float local_59c;
  float local_598;
  float local_594;
  float local_590;
  float local_58c;
  float local_588;
  float local_584;
  float local_580;
  float local_57c;
  float local_578;
  float local_574;
  float local_570;
  float local_56c;
  float local_568;
  float local_564;
  float local_560;
  float local_55c;
  float local_558;
  float local_554;
  float local_550;
  float local_54c;
  float local_548;
  float local_544;
  float local_540;
  float local_53c;
  float local_538;
  float local_534;
  float local_530;
  float local_52c;
  float local_528;
  float local_524;
  float local_520;
  float local_51c;
  float local_518;
  float local_514;
  float local_510;
  float local_50c;
  float local_508;
  float local_504;
  float local_500;
  float local_4fc;
  float local_4f8;
  float local_4f4;
  float local_4f0;
  float local_4ec;
  float local_4e8;
  float local_4e4;
  float local_4e0;
  float local_4dc;
  float local_4d8;
  float local_4d4;
  float local_4d0;
  float local_4cc;
  float local_4c8;
  float local_4c4;
  float local_4c0;
  float local_4bc;
  float local_4b8;
  float local_4b4;
  float local_4b0;
  float local_4ac;
  float local_4a8;
  float local_4a4;
  float local_4a0;
  float local_49c;
  float local_498;
  float local_494;
  float local_490;
  float local_48c;
  float local_488;
  float local_484;
  float local_3c0;
  float local_3bc;
  float local_3b8;
  float local_3b0;
  float local_3ac;
  float local_3a8;
  float local_3a0;
  float local_39c;
  float local_398;
  float local_390;
  float local_38c;
  float local_388;
  float local_380;
  float local_37c;
  float local_378;
  float local_370;
  float local_36c;
  float local_368;
  float local_360;
  float local_35c;
  float local_358;
  float local_350;
  float local_34c;
  float local_348;
  float local_340;
  float local_33c;
  float local_338;
  float local_330;
  float local_32c;
  float local_328;
  float local_320;
  float local_31c;
  float local_318;
  float local_310;
  float local_30c;
  float local_308;
  float local_300;
  float local_2fc;
  float local_2f8;
  float local_2f0;
  float local_2ec;
  float local_2e8;
  float local_2e0;
  float local_2dc;
  float local_2d8;
  float local_2d0;
  float local_2cc;
  float local_2c8;
  float local_2c0;
  float local_2bc;
  float local_2b8;
  float local_2b0;
  float local_2ac;
  float local_2a8;
  float local_2a0;
  float local_29c;
  float local_298;
  float local_290;
  float local_28c;
  float local_288;
  float local_1c0;
  float local_1bc;
  float local_1b8;
  float local_1b0;
  float local_1ac;
  float local_1a8;
  float local_1a0;
  float local_19c;
  float local_198;
  float local_190;
  float local_18c;
  float local_188;
  
  iVar8 = *in_stack_00000020;
  do {
    if (iVar8 == 0) {
      return 0;
    }
    if ((((*(byte *)(*in_stack_00000020 + 2) >> 5 & 1) != 0) &&
        ((1 << (*in_stack_00000024 - 1 & 0x1f) &
         (uint)*(ushort *)(*(int *)(in_stack_0000001c + 0x24) + 0x16)) != 0)) &&
       ((*(byte *)(*(int *)(DAT_002414b0 + 0x120 + (uint)*(byte *)(*in_stack_00000020 + 4) * 4) + 8)
        & param_1) != 0)) {
      iVar8 = *in_stack_00000028;
      DAT_002411ee = *in_stack_00000024 - 1;
      while (iVar8 != 0) {
        if (*in_stack_0000002c != 0) goto LAB_0002d1e0;
        iVar8 = *(int *)(*(int *)(*in_stack_00000028 + 0x24) + 0x10);
        uVar10 = 0;
        if ((*(byte *)(iVar8 + 3) & 0xf8) != 0) {
          do {
            iVar2 = *(int *)(*(int *)(iVar8 + 8) + uVar10 * 4);
            bVar9 = (char)uVar10 + 1;
            uVar10 = (uint)bVar9;
            *in_stack_0000002c = iVar2;
            if (iVar2 != 0) goto LAB_0002d1c8;
          } while (bVar9 < *(byte *)(iVar8 + 3) >> 3);
        }
        *in_stack_0000002c = 0;
        bVar9 = 0xff;
LAB_0002d1c8:
        *in_stack_00000030 = bVar9;
        iVar8 = *in_stack_0000002c;
        while (iVar8 != 0) {
LAB_0002d1e0:
          uVar1 = *(ushort *)(*in_stack_0000002c + 2);
          if (((((byte)uVar1 >> 5 & 1) != 0) &&
              (((uint)*(ushort *)(*(int *)(*in_stack_00000028 + 0x24) + 0x16) &
               1 << (*in_stack_00000030 - 1 & 0x1f)) != 0)) &&
             ((*(byte *)(*(int *)(DAT_002414b0 + 0x120 + (uint)*(byte *)(*in_stack_0000002c + 4) * 4
                                 ) + 8) & param_2) != 0)) {
            if (((*(byte *)(*in_stack_00000020 + 3) & 1) != 0) && ((uVar1 & 0x100) != 0)) {
              if ((*(byte *)(*in_stack_00000020 + 2) >> 3 & 1) != 0) {
                FUN_000941f0();
              }
              if ((*(byte *)(*in_stack_0000002c + 2) >> 3 & 1) != 0) {
                FUN_000941f0();
              }
              cVar7 = FUN_00069f30();
              if (cVar7 != '\0') goto LAB_0002d544;
            }
            iVar8 = *in_stack_00000020;
            if (((*(ushort *)(iVar8 + 2) >> 9 & 1) != 0) &&
               ((*(ushort *)(*in_stack_0000002c + 2) >> 9 & 1) != 0)) {
              fVar4 = (*(float *)(iVar8 + 8) + *(float *)(iVar8 + 0x14)) * _DAT_0020df84;
              fVar5 = (*(float *)(iVar8 + 0x18) + *(float *)(iVar8 + 0xc)) * _DAT_0020df84;
              fVar6 = (*(float *)(iVar8 + 0x1c) + *(float *)(iVar8 + 0x10)) * _DAT_0020df84;
              local_564 = *(float *)(iVar8 + 0x14) - fVar4;
              local_560 = *(float *)(iVar8 + 0x18) - fVar5;
              local_55c = *(float *)(iVar8 + 0x1c) - fVar6;
              local_5f4 = fVar4;
              local_5f0 = fVar5;
              local_4f8 = local_564;
              local_4f4 = local_560;
              local_4f0 = local_55c;
              if ((*(byte *)(iVar8 + 2) >> 3 & 1) != 0) {
                FUN_000941f0();
                local_5f4 = local_2c0 * fVar4 + local_2b0 * fVar5 + local_2a0 * fVar6 + local_290;
                local_5f0 = local_2ac * fVar5 + local_29c * fVar6 + fVar4 * local_2bc + local_28c;
                fVar6 = local_298 * fVar6 + fVar4 * local_2b8 + fVar5 * local_2a8 + local_288;
              }
              pfVar3 = *(float **)(in_stack_0000001c + 0x10);
              local_5b8 = local_5f4 * *pfVar3 + local_5f0 * pfVar3[4] + fVar6 * pfVar3[8] +
                          pfVar3[0xc];
              local_5b4 = local_5f4 * pfVar3[1] + local_5f0 * pfVar3[5] + fVar6 * pfVar3[9] +
                          pfVar3[0xd];
              local_5b0 = local_5f4 * pfVar3[2] + local_5f0 * pfVar3[6] + fVar6 * pfVar3[10] +
                          pfVar3[0xe];
              local_5ac = local_564 + local_5b8;
              local_5a8 = local_560 + local_5b4;
              local_5a4 = local_55c + local_5b0;
              local_5b8 = local_5b8 - local_564;
              local_5b4 = local_5b4 - local_560;
              iVar8 = *in_stack_00000028;
              local_5b0 = local_5b0 - local_55c;
              iVar2 = *in_stack_0000002c;
              fVar4 = (*(float *)(iVar2 + 8) + *(float *)(iVar2 + 0x14)) * _DAT_0020df84;
              fVar5 = (*(float *)(iVar2 + 0x18) + *(float *)(iVar2 + 0xc)) * _DAT_0020df84;
              fVar6 = (*(float *)(iVar2 + 0x1c) + *(float *)(iVar2 + 0x10)) * _DAT_0020df84;
              local_5a0 = *(float *)(iVar2 + 0x14) - fVar4;
              local_59c = *(float *)(iVar2 + 0x18) - fVar5;
              local_598 = *(float *)(iVar2 + 0x1c) - fVar6;
              local_5dc = fVar4;
              local_5d8 = fVar5;
              local_504 = local_5ac;
              local_500 = local_5a8;
              local_4fc = local_5a4;
              local_4ec = local_5b8;
              local_4e8 = local_5b4;
              local_4e4 = local_5b0;
              local_4d4 = local_5a0;
              local_4d0 = local_59c;
              local_4cc = local_598;
              if ((*(byte *)(iVar2 + 2) >> 3 & 1) != 0) {
                FUN_000941f0();
                local_5dc = local_370 * fVar5 + local_360 * fVar6 + local_380 * fVar4 + local_350;
                local_5d8 = local_36c * fVar5 + local_35c * fVar6 + fVar4 * local_37c + local_34c;
                fVar6 = local_358 * fVar6 + fVar4 * local_378 + fVar5 * local_368 + local_348;
              }
              pfVar3 = *(float **)(iVar8 + 0x10);
              local_5d0 = local_5dc * *pfVar3 + local_5d8 * pfVar3[4] + fVar6 * pfVar3[8] +
                          pfVar3[0xc];
              local_5cc = local_5dc * pfVar3[1] + local_5d8 * pfVar3[5] + fVar6 * pfVar3[9] +
                          pfVar3[0xd];
              local_5c8 = local_5dc * pfVar3[2] + local_5d8 * pfVar3[6] + fVar6 * pfVar3[10] +
                          pfVar3[0xe];
              local_5c4 = local_5a0 + local_5d0;
              local_5c0 = local_59c + local_5cc;
              local_5bc = local_598 + local_5c8;
              local_5d0 = local_5d0 - local_5a0;
              local_5cc = local_5cc - local_59c;
              local_5c8 = local_5c8 - local_598;
              local_4bc = local_5c4;
              local_4b8 = local_5c0;
              local_4b4 = local_5bc;
              local_4a4 = local_5d0;
              local_4a0 = local_5cc;
              local_49c = local_5c8;
              cVar7 = FUN_000689a0(&local_5b8,&local_5d0);
              if (cVar7 != '\0') goto LAB_0002d544;
            }
            if (((*(byte *)(*in_stack_00000020 + 3) & 1) != 0) &&
               ((*(ushort *)(*in_stack_0000002c + 2) >> 9 & 1) != 0)) {
              if ((*(byte *)(*in_stack_00000020 + 2) >> 3 & 1) != 0) {
                FUN_000941f0();
              }
              iVar8 = *in_stack_00000028;
              iVar2 = *in_stack_0000002c;
              fVar4 = (*(float *)(iVar2 + 8) + *(float *)(iVar2 + 0x14)) * _DAT_0020df84;
              fVar5 = (*(float *)(iVar2 + 0x18) + *(float *)(iVar2 + 0xc)) * _DAT_0020df84;
              fVar6 = (*(float *)(iVar2 + 0x1c) + *(float *)(iVar2 + 0x10)) * _DAT_0020df84;
              local_588 = *(float *)(iVar2 + 0x14) - fVar4;
              local_584 = *(float *)(iVar2 + 0x18) - fVar5;
              local_580 = *(float *)(iVar2 + 0x1c) - fVar6;
              local_5e8 = fVar4;
              local_5e4 = fVar5;
              local_48c = local_588;
              local_488 = local_584;
              local_484 = local_580;
              if ((*(byte *)(iVar2 + 2) >> 3 & 1) != 0) {
                FUN_000941f0();
                local_5e8 = local_300 * fVar4 + local_2f0 * fVar5 + local_2e0 * fVar6 + local_2d0;
                local_5e4 = fVar4 * local_2fc + local_2ec * fVar5 + local_2dc * fVar6 + local_2cc;
                fVar6 = fVar4 * local_2f8 + fVar5 * local_2e8 + local_2d8 * fVar6 + local_2c8;
              }
              pfVar3 = *(float **)(iVar8 + 0x10);
              local_5d0 = local_5e8 * *pfVar3 + local_5e4 * pfVar3[4] + fVar6 * pfVar3[8] +
                          pfVar3[0xc];
              local_5cc = local_5e4 * pfVar3[5] + fVar6 * pfVar3[9] + local_5e8 * pfVar3[1] +
                          pfVar3[0xd];
              local_5c8 = fVar6 * pfVar3[10] + local_5e8 * pfVar3[2] + local_5e4 * pfVar3[6] +
                          pfVar3[0xe];
              local_5c4 = local_588 + local_5d0;
              local_5c0 = local_584 + local_5cc;
              local_5bc = local_580 + local_5c8;
              local_5d0 = local_5d0 - local_588;
              local_5cc = local_5cc - local_584;
              local_5c8 = local_5c8 - local_580;
              local_540 = local_5c4;
              local_53c = local_5c0;
              local_538 = local_5bc;
              local_4e0 = local_5d0;
              local_4dc = local_5cc;
              local_4d8 = local_5c8;
              cVar7 = FUN_000696a0();
              if (cVar7 != '\0') goto LAB_0002d544;
            }
            iVar8 = *in_stack_00000020;
            if (((*(ushort *)(iVar8 + 2) >> 9 & 1) != 0) &&
               ((*(byte *)(*in_stack_0000002c + 3) & 1) != 0)) {
              fVar4 = (*(float *)(iVar8 + 0x14) + *(float *)(iVar8 + 8)) * _DAT_0020df84;
              fVar5 = (*(float *)(iVar8 + 0x18) + *(float *)(iVar8 + 0xc)) * _DAT_0020df84;
              fVar6 = (*(float *)(iVar8 + 0x1c) + *(float *)(iVar8 + 0x10)) * _DAT_0020df84;
              local_570 = *(float *)(iVar8 + 0x14) - fVar4;
              local_56c = *(float *)(iVar8 + 0x18) - fVar5;
              local_568 = *(float *)(iVar8 + 0x1c) - fVar6;
              local_60c = fVar4;
              local_608 = fVar5;
              local_528 = local_570;
              local_524 = local_56c;
              local_520 = local_568;
              if ((*(byte *)(iVar8 + 2) >> 3 & 1) != 0) {
                FUN_000941f0();
                local_60c = local_1c0 * fVar4 + local_1b0 * fVar5 + local_1a0 * fVar6 + local_190;
                local_608 = fVar4 * local_1bc + local_1ac * fVar5 + local_19c * fVar6 + local_18c;
                fVar6 = fVar4 * local_1b8 + fVar5 * local_1a8 + local_198 * fVar6 + local_188;
              }
              pfVar3 = *(float **)(in_stack_0000001c + 0x10);
              local_5b8 = local_60c * *pfVar3 + local_608 * pfVar3[4] + fVar6 * pfVar3[8] +
                          pfVar3[0xc];
              local_5b4 = local_608 * pfVar3[5] + fVar6 * pfVar3[9] + local_60c * pfVar3[1] +
                          pfVar3[0xd];
              local_5b0 = fVar6 * pfVar3[10] + local_60c * pfVar3[2] + local_608 * pfVar3[6] +
                          pfVar3[0xe];
              local_5ac = local_570 + local_5b8;
              local_5a8 = local_56c + local_5b4;
              local_5a4 = local_568 + local_5b0;
              local_5b8 = local_5b8 - local_570;
              local_5b4 = local_5b4 - local_56c;
              local_5b0 = local_5b0 - local_568;
              local_510 = local_5b8;
              local_50c = local_5b4;
              local_508 = local_5b0;
              local_4b0 = local_5ac;
              local_4ac = local_5a8;
              local_4a8 = local_5a4;
              if ((*(byte *)(*in_stack_0000002c + 2) >> 3 & 1) != 0) {
                FUN_000941f0();
              }
              cVar7 = FUN_000696a0();
              if (cVar7 != '\0') goto LAB_0002d544;
            }
            iVar8 = *in_stack_00000020;
            if (((*(ushort *)(iVar8 + 2) >> 0xc & 1) != 0) &&
               ((*(ushort *)(*in_stack_0000002c + 2) >> 0xc & 1) != 0)) {
              bVar9 = (byte)*(undefined2 *)(iVar8 + 2);
              if ((bVar9 >> 6 & 1) == 0) {
                if (((bVar9 >> 3 & 1) != 0) || ((*(byte *)(iVar8 + 2) & 1) != 0)) {
                  FUN_000941f0();
                  FUN_00028450();
                  if ((*(byte *)(iVar8 + 2) & 1) != 0) {
                    FUN_000941f0();
                    FUN_00028450();
                  }
                }
                FUN_00028450();
              }
              iVar8 = *in_stack_0000002c;
              bVar9 = (byte)*(undefined2 *)(iVar8 + 2);
              if ((bVar9 >> 6 & 1) == 0) {
                if (((bVar9 >> 3 & 1) != 0) || ((*(byte *)(iVar8 + 2) & 1) != 0)) {
                  FUN_000941f0();
                  FUN_00028450();
                  if ((*(byte *)(iVar8 + 2) & 1) != 0) {
                    FUN_000941f0();
                    FUN_00028450();
                  }
                }
                FUN_00028450();
              }
              cVar7 = FUN_00069ea0();
              if (cVar7 != '\0') goto LAB_0002d544;
            }
            iVar8 = *in_stack_00000020;
            if (((*(ushort *)(iVar8 + 2) >> 0xc & 1) != 0) &&
               ((*(byte *)(*in_stack_0000002c + 3) & 1) != 0)) {
              bVar9 = (byte)*(undefined2 *)(iVar8 + 2);
              if ((bVar9 >> 6 & 1) == 0) {
                if (((bVar9 >> 3 & 1) != 0) || ((*(byte *)(iVar8 + 2) & 1) != 0)) {
                  FUN_000941f0();
                  FUN_00028450();
                  if ((*(byte *)(iVar8 + 2) & 1) != 0) {
                    FUN_000941f0();
                    FUN_00028450();
                  }
                }
                FUN_00028450();
              }
              if ((*(byte *)(*in_stack_0000002c + 2) >> 3 & 1) != 0) {
                FUN_000941f0();
              }
              cVar7 = FUN_000697f0();
              if (cVar7 != '\0') goto LAB_0002d544;
            }
            if (((*(byte *)(*in_stack_00000020 + 3) & 1) != 0) &&
               ((*(ushort *)(*in_stack_0000002c + 2) >> 0xc & 1) != 0)) {
              if ((*(byte *)(*in_stack_00000020 + 2) >> 3 & 1) != 0) {
                FUN_000941f0();
              }
              iVar8 = *in_stack_0000002c;
              bVar9 = (byte)*(undefined2 *)(iVar8 + 2);
              if ((bVar9 >> 6 & 1) == 0) {
                if (((bVar9 >> 3 & 1) != 0) || ((*(byte *)(iVar8 + 2) & 1) != 0)) {
                  FUN_000941f0();
                  FUN_00028450();
                  if ((*(byte *)(iVar8 + 2) & 1) != 0) {
                    FUN_000941f0();
                    FUN_00028450();
                  }
                }
                FUN_00028450();
              }
              cVar7 = FUN_000697f0();
              if (cVar7 != '\0') goto LAB_0002d544;
            }
            iVar8 = *in_stack_00000020;
            if (((*(ushort *)(iVar8 + 2) >> 0xc & 1) != 0) &&
               ((*(ushort *)(*in_stack_0000002c + 2) >> 9 & 1) != 0)) {
              bVar9 = (byte)*(undefined2 *)(iVar8 + 2);
              if ((bVar9 >> 6 & 1) == 0) {
                if (((bVar9 >> 3 & 1) != 0) || ((*(byte *)(iVar8 + 2) & 1) != 0)) {
                  FUN_000941f0();
                  FUN_00028450();
                  if ((*(byte *)(iVar8 + 2) & 1) != 0) {
                    FUN_000941f0();
                    FUN_00028450();
                  }
                }
                FUN_00028450();
              }
              iVar8 = *in_stack_0000002c;
              iVar2 = *in_stack_00000028;
              fVar4 = (*(float *)(iVar8 + 0x14) + *(float *)(iVar8 + 8)) * _DAT_0020df84;
              fVar5 = (*(float *)(iVar8 + 0x18) + *(float *)(iVar8 + 0xc)) * _DAT_0020df84;
              fVar6 = (*(float *)(iVar8 + 0x1c) + *(float *)(iVar8 + 0x10)) * _DAT_0020df84;
              local_594 = *(float *)(iVar8 + 0x14) - fVar4;
              local_590 = *(float *)(iVar8 + 0x18) - fVar5;
              local_58c = *(float *)(iVar8 + 0x1c) - fVar6;
              local_618 = fVar4;
              local_614 = fVar5;
              local_4c8 = local_594;
              local_4c4 = local_590;
              local_4c0 = local_58c;
              if ((*(byte *)(iVar8 + 2) >> 3 & 1) != 0) {
                FUN_000941f0();
                local_618 = local_3b0 * fVar5 + local_3a0 * fVar6 + local_3c0 * fVar4 + local_390;
                local_614 = local_3ac * fVar5 + local_39c * fVar6 + fVar4 * local_3bc + local_38c;
                fVar6 = local_398 * fVar6 + fVar4 * local_3b8 + fVar5 * local_3a8 + local_388;
              }
              pfVar3 = *(float **)(iVar2 + 0x10);
              local_5d0 = local_618 * *pfVar3 + local_614 * pfVar3[4] + fVar6 * pfVar3[8] +
                          pfVar3[0xc];
              local_5cc = local_618 * pfVar3[1] + local_614 * pfVar3[5] + fVar6 * pfVar3[9] +
                          pfVar3[0xd];
              local_5c8 = local_618 * pfVar3[2] + local_614 * pfVar3[6] + fVar6 * pfVar3[10] +
                          pfVar3[0xe];
              local_5c4 = local_594 + local_5d0;
              local_5c0 = local_590 + local_5cc;
              local_5bc = local_58c + local_5c8;
              local_5d0 = local_5d0 - local_594;
              local_5cc = local_5cc - local_590;
              local_5c8 = local_5c8 - local_58c;
              local_558 = local_5c4;
              local_554 = local_5c0;
              local_550 = local_5bc;
              local_498 = local_5d0;
              local_494 = local_5cc;
              local_490 = local_5c8;
              cVar7 = FUN_00069750();
              if (cVar7 != '\0') goto LAB_0002d544;
            }
            iVar8 = *in_stack_00000020;
            if (((*(ushort *)(iVar8 + 2) >> 9 & 1) != 0) &&
               ((*(ushort *)(*in_stack_0000002c + 2) >> 0xc & 1) != 0)) {
              fVar4 = (*(float *)(iVar8 + 0x14) + *(float *)(iVar8 + 8)) * _DAT_0020df84;
              fVar5 = (*(float *)(iVar8 + 0x18) + *(float *)(iVar8 + 0xc)) * _DAT_0020df84;
              fVar6 = (*(float *)(iVar8 + 0x1c) + *(float *)(iVar8 + 0x10)) * _DAT_0020df84;
              local_57c = *(float *)(iVar8 + 0x14) - fVar4;
              local_578 = *(float *)(iVar8 + 0x18) - fVar5;
              local_574 = *(float *)(iVar8 + 0x1c) - fVar6;
              local_600 = fVar4;
              local_5fc = fVar5;
              local_54c = local_57c;
              local_548 = local_578;
              local_544 = local_574;
              if ((*(byte *)(iVar8 + 2) >> 3 & 1) != 0) {
                FUN_000941f0();
                local_600 = local_330 * fVar5 + local_320 * fVar6 + local_340 * fVar4 + local_310;
                local_5fc = local_32c * fVar5 + local_31c * fVar6 + fVar4 * local_33c + local_30c;
                fVar6 = local_318 * fVar6 + fVar4 * local_338 + fVar5 * local_328 + local_308;
              }
              pfVar3 = *(float **)(in_stack_0000001c + 0x10);
              local_5b8 = local_600 * *pfVar3 + local_5fc * pfVar3[4] + fVar6 * pfVar3[8] +
                          pfVar3[0xc];
              local_5b4 = local_600 * pfVar3[1] + local_5fc * pfVar3[5] + fVar6 * pfVar3[9] +
                          pfVar3[0xd];
              local_5b0 = local_600 * pfVar3[2] + local_5fc * pfVar3[6] + fVar6 * pfVar3[10] +
                          pfVar3[0xe];
              local_5ac = local_57c + local_5b8;
              local_5a8 = local_578 + local_5b4;
              local_5a4 = local_574 + local_5b0;
              local_5b8 = local_5b8 - local_57c;
              local_5b4 = local_5b4 - local_578;
              local_5b0 = local_5b0 - local_574;
              iVar8 = *in_stack_0000002c;
              bVar9 = (byte)*(undefined2 *)(iVar8 + 2);
              local_534 = local_5ac;
              local_530 = local_5a8;
              local_52c = local_5a4;
              local_51c = local_5b8;
              local_518 = local_5b4;
              local_514 = local_5b0;
              if ((bVar9 >> 6 & 1) == 0) {
                if (((bVar9 >> 3 & 1) != 0) || ((*(byte *)(iVar8 + 2) & 1) != 0)) {
                  FUN_000941f0();
                  FUN_00028450();
                  if ((*(byte *)(iVar8 + 2) & 1) != 0) {
                    FUN_000941f0();
                    FUN_00028450();
                  }
                }
                FUN_00028450();
              }
              cVar7 = FUN_00069750();
              if (cVar7 != '\0') {
LAB_0002d544:
                FUN_0002d090();
                FUN_0002d090();
                DAT_002411ef = *in_stack_00000030 - 1;
                DAT_0022a6f8 = *in_stack_00000028;
                return *in_stack_00000028;
              }
            }
          }
          iVar8 = *(int *)(*(int *)(*in_stack_00000028 + 0x24) + 0x10);
          bVar9 = *in_stack_00000030;
          if (bVar9 < *(byte *)(iVar8 + 3) >> 3) {
            do {
              iVar2 = *(int *)(*(int *)(iVar8 + 8) + (uint)bVar9 * 4);
              bVar9 = bVar9 + 1;
              *in_stack_0000002c = iVar2;
              if (iVar2 != 0) goto LAB_0002f643;
            } while (bVar9 < *(byte *)(iVar8 + 3) >> 3);
          }
          *in_stack_0000002c = 0;
          bVar9 = 0xff;
LAB_0002f643:
          *in_stack_00000030 = bVar9;
          iVar8 = *in_stack_0000002c;
        }
        iVar8 = FUN_0002c660(0x800);
        *in_stack_00000028 = iVar8;
      }
      FUN_0002c2e0();
      iVar8 = FUN_0002c660(0x800);
      *in_stack_00000028 = iVar8;
    }
    iVar8 = *(int *)(*(int *)(in_stack_0000001c + 0x24) + 0x10);
    bVar9 = *in_stack_00000024;
    if (bVar9 < *(byte *)(iVar8 + 3) >> 3) {
      do {
        iVar2 = *(int *)(*(int *)(iVar8 + 8) + (uint)bVar9 * 4);
        bVar9 = bVar9 + 1;
        *in_stack_00000020 = iVar2;
        if (iVar2 != 0) goto LAB_0002f6d3;
      } while (bVar9 < *(byte *)(iVar8 + 3) >> 3);
    }
    *in_stack_00000020 = 0;
    bVar9 = 0xff;
LAB_0002f6d3:
    *in_stack_00000024 = bVar9;
    iVar8 = *in_stack_00000020;
  } while( true );
}


