// func FUN_0001a370 @ 0x0001A370 (size 0xA7)

void FUN_0001a370(void)

{
  void *__dest;
  int in_EDX;
  int extraout_EDX;
  int extraout_EDX_00;
  int iVar1;
  int unaff_EDI;
  
  if (unaff_EDI < *(int *)(in_EDX + 0x700)) {
    __dest = (void *)(unaff_EDI * 0x20 + 0x704 + in_EDX);
    if ((uint)*(byte *)((int)__dest + 0x17) * 3 + (uint)*(byte *)(unaff_EDI * 0x20 + 0x71a + in_EDX)
        + (uint)*(byte *)((int)__dest + 0x15) + (uint)*(byte *)((int)__dest + 0x14) != 0) {
      FUN_0001a500();
      in_EDX = extraout_EDX;
    }
    if (*(char *)((int)__dest + 0x1a) != '\0') {
      FUN_0001a500();
      in_EDX = extraout_EDX_00;
    }
    if (unaff_EDI < *(int *)(&DAT_0000470c + in_EDX)) {
      *(int *)(&DAT_0000470c + in_EDX) = *(int *)(&DAT_0000470c + in_EDX) + -1;
      *(int *)(&DAT_00004708 + in_EDX) = *(int *)(&DAT_00004708 + in_EDX) + -0x20;
    }
    iVar1 = *(int *)(in_EDX + 0x700) + -1;
    *(int *)(in_EDX + 0x700) = iVar1;
    if (0 < iVar1) {
      _memmove(__dest,(void *)((int)__dest + 0x20),(iVar1 - unaff_EDI) * 0x20);
      return;
    }
    *(undefined **)(&DAT_00004708 + in_EDX) = &DAT_00004710 + in_EDX;
  }
  return;
}


