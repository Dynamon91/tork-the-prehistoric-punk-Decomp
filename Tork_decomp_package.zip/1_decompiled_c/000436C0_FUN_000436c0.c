// func FUN_000436c0 @ 0x000436C0 (size 0x3D)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_000436c0(undefined4 param_1,float param_2)

{
  int iVar1;
  uint in_EAX;
  int in_ECX;
  
  iVar1 = *(int *)(in_ECX + 0x10 + (in_EAX & 0xffff) * 8);
  if (_DAT_0020df5c < param_2) {
    *(undefined4 *)(iVar1 + 0x3c) = param_1;
    *(float *)(iVar1 + 0x40) = param_2;
    return;
  }
  *(undefined4 *)(iVar1 + 0x38) = param_1;
  *(undefined4 *)(iVar1 + 0x3c) = param_1;
  *(undefined4 *)(iVar1 + 0x40) = 0xbf800000;
  return;
}


