// func FUN_00053120 @ 0x00053120 (size 0xC0)

uint FUN_00053120(int param_1)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  ushort uVar6;
  uint uVar7;
  float *pfVar8;
  ushort unaff_BX;
  uint uVar9;
  float *unaff_ESI;
  ushort uVar10;
  ushort uVar11;
  
  uVar9 = 0;
  if (unaff_BX != 0) {
    pfVar8 = (float *)(param_1 + 4);
    uVar6 = unaff_BX - 1;
    uVar10 = 0;
    do {
      pfVar1 = (float *)(param_1 + (uint)uVar6 * 0xc);
      fVar4 = (*unaff_ESI - pfVar8[-1]) * (pfVar1[1] - *pfVar8);
      fVar5 = (*pfVar1 - pfVar8[-1]) * (unaff_ESI[1] - *pfVar8);
      fVar2 = *pfVar8;
      fVar3 = unaff_ESI[1];
      if ((((NAN(fVar2) || NAN(fVar3)) || fVar2 < fVar3 == (fVar2 == fVar3)) ||
          (pfVar1[1] <= unaff_ESI[1])) || (fVar5 <= fVar4)) {
        fVar2 = pfVar1[1];
        fVar3 = unaff_ESI[1];
        if ((((!NAN(fVar2) && !NAN(fVar3)) && fVar2 < fVar3 != (fVar2 == fVar3)) &&
            (unaff_ESI[1] < *pfVar8)) && (fVar5 < fVar4)) goto LAB_000531bd;
        uVar7 = 0;
      }
      else {
LAB_000531bd:
        uVar7 = 1;
      }
      uVar9 = uVar9 ^ uVar7;
      uVar11 = uVar10 + 1;
      pfVar8 = pfVar8 + 3;
      uVar6 = uVar10;
      uVar10 = uVar11;
    } while (uVar11 < unaff_BX);
  }
  return uVar9;
}


