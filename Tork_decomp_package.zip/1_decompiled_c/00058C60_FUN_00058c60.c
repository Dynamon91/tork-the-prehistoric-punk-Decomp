// func FUN_00058c60 @ 0x00058C60 (size 0x1C)

void FUN_00058c60(void)

{
  undefined4 *in_EAX;
  
  if ((code *)*in_EAX != (code *)0x0) {
    (*(code *)*in_EAX)(in_EAX[1],in_EAX[2],in_EAX[3],in_EAX[4]);
  }
  return;
}


