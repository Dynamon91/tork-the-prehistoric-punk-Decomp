// func FUN_00025960 @ 0x00025960 (size 0xA8)

void FUN_00025960(uint param_1)

{
  undefined2 uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  iVar3 = param_1;
  uVar1 = *(undefined2 *)(param_1 + 2);
  FUN_000dfc60();
  FUN_000e8050(param_1,uVar1);
  if ((*(uint *)(param_1 + 4) >> 0xd & 1) != 0) {
    uVar4 = (uint)**(byte **)(*(int *)(param_1 + 0x24) + 0x2c);
    param_1 = 0;
    if (uVar4 != 0) {
      do {
        iVar2 = *(int *)(*(int *)(*(int *)(*(int *)(iVar3 + 0x24) + 0x2c) + 4) +
                        (param_1 & 0xff) * 4);
        uVar1 = *(undefined2 *)(iVar2 + 2);
        FUN_000dfc60();
        FUN_000e8050(iVar2,uVar1);
        param_1 = param_1 + 1;
      } while ((int)param_1 < (int)uVar4);
    }
  }
  return;
}


