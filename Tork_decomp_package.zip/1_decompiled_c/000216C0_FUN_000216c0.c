// func FUN_000216c0 @ 0x000216C0 (size 0x1F)

bool FUN_000216c0(float param_1,float param_2,float param_3)

{
  return (uint)ABS(param_1 - param_2) <= (uint)param_3;
}


