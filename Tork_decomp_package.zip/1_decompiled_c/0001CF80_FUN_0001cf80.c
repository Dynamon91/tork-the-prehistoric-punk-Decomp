// func FUN_0001cf80 @ 0x0001CF80 (size 0x46)

void FUN_0001cf80(uint *param_1,int param_2)

{
  uint uVar1;
  uint *puVar2;
  
  uVar1 = 0;
  puVar2 = param_1 + 1;
  if (*param_1 != 0) {
    do {
      if (4 < *(uint *)(param_2 + 0xc + (uint)(ushort)*puVar2 * 0x14)) {
        FUN_00058010();
      }
      uVar1 = uVar1 + 1;
      puVar2 = puVar2 + 2;
    } while (uVar1 < *param_1);
  }
  FUN_00058010();
  return;
}


