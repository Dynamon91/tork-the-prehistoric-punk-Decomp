// func FUN_000194f0 @ 0x000194F0 (size 0x182)

wchar_t * FUN_000194f0(wchar_t *param_1)

{
  undefined *puVar1;
  wchar_t *pwVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  wchar_t *unaff_EBX;
  int iVar8;
  int unaff_EDI;
  bool bVar9;
  bool bVar10;
  
  if ((param_1 < (wchar_t *)(unaff_EDI + 0x44)) || (&DAT_00002044 + unaff_EDI <= param_1)) {
LAB_00019522:
    iVar8 = -1;
LAB_00019547:
    bVar9 = false;
  }
  else {
    puVar1 = (undefined *)((int)param_1 + (-0x44 - unaff_EDI));
    uVar6 = (uint)puVar1 & 0x8000001f;
    bVar9 = uVar6 == 0;
    if ((int)uVar6 < 0) {
      bVar9 = (uVar6 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (!bVar9) goto LAB_00019522;
    iVar8 = (int)(puVar1 + ((int)puVar1 >> 0x1f & 0x1f)) >> 5;
    if ((iVar8 == -1) || (bVar9 = true, *(int *)(&DAT_00002064 + iVar8 * 4 + unaff_EDI) != 0))
    goto LAB_00019547;
  }
  if (((wchar_t *)(unaff_EDI + 0x44) <= unaff_EBX) && (unaff_EBX < &DAT_00002044 + unaff_EDI)) {
    uVar6 = (int)unaff_EBX + (-0x44 - unaff_EDI);
    uVar7 = uVar6 & 0x8000001f;
    bVar10 = uVar7 == 0;
    if ((int)uVar7 < 0) {
      bVar10 = (uVar7 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar10) && (iVar3 = (int)(uVar6 + ((int)uVar6 >> 0x1f & 0x1fU)) >> 5, iVar3 != -1)) &&
       (bVar10 = true, *(int *)(&DAT_00002064 + iVar3 * 4 + unaff_EDI) == 0)) goto LAB_000195a3;
  }
  bVar10 = false;
LAB_000195a3:
  iVar3 = FUN_00134fe8(param_1);
  iVar4 = FUN_00134fe8();
  iVar3 = (iVar3 + iVar4) * 2;
  if ((bVar9) &&
     (iVar5 = FUN_000550b0(), iVar4 = iVar3 + 0x21,
     (int)(iVar4 + (iVar4 >> 0x1f & 0x1fU)) >> 5 <= iVar5)) {
    pwVar2 = (wchar_t *)(iVar8 * 0x20 + 0x44 + unaff_EDI);
    _wcscat(pwVar2,unaff_EBX);
    if (bVar10) {
      FUN_00019750();
    }
    return pwVar2;
  }
  iVar3 = iVar3 + 0x21;
  iVar8 = FUN_000550f0((int)(iVar3 + (iVar3 >> 0x1f & 0x1fU)) >> 5);
  *(undefined4 *)(&DAT_00002064 + iVar8 * 4 + unaff_EDI) = 0;
  pwVar2 = (wchar_t *)(iVar8 * 0x20 + 0x44 + unaff_EDI);
  FUN_00134fcc(pwVar2,param_1);
  _wcscat(pwVar2,unaff_EBX);
  if (bVar9) {
    FUN_00019750();
  }
  if (bVar10) {
    FUN_00019750();
  }
  return pwVar2;
}


