// func FUN_00054d20 @ 0x00054D20 (size 0x1F)

void FUN_00054d20(void)

{
  undefined4 *in_EAX;
  uint in_ECX;
  uint uVar1;
  undefined4 *in_EDX;
  
  if ((in_EDX != (undefined4 *)0x0) && (in_EAX != (undefined4 *)0x0)) {
    for (uVar1 = in_ECX >> 2; uVar1 != 0; uVar1 = uVar1 - 1) {
      *in_EDX = *in_EAX;
      in_EAX = in_EAX + 1;
      in_EDX = in_EDX + 1;
    }
    for (uVar1 = in_ECX & 3; uVar1 != 0; uVar1 = uVar1 - 1) {
      *(undefined1 *)in_EDX = *(undefined1 *)in_EAX;
      in_EAX = (undefined4 *)((int)in_EAX + 1);
      in_EDX = (undefined4 *)((int)in_EDX + 1);
    }
  }
  return;
}


