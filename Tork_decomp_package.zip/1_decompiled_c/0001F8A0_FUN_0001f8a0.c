// func FUN_0001f8a0 @ 0x0001F8A0 (size 0x5C)

void FUN_0001f8a0(void)

{
  int iVar1;
  int in_ECX;
  
  iVar1 = *(int *)(in_ECX + 0x3c);
  *(int *)(in_ECX + 0x3c) = iVar1 + 4;
  (**(code **)(&DAT_00241540 + (*(byte *)(iVar1 + 5) & 0x3f) * 0x10))();
  (**(code **)(&DAT_00241540 + (*(byte *)(*(int *)(in_ECX + 0x3c) + 1) & 0x3f) * 0x10))();
                    /* WARNING: Jumptable at 0x0001f8f6 did not pass sanity check. */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(&DAT_00241540 + (*(byte *)(*(int *)(in_ECX + 0x3c) + 1) & 0x3f) * 0x10))();
  return;
}


