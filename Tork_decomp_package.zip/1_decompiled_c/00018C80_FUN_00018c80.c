// func FUN_00018c80 @ 0x00018C80 (size 0x182)

void FUN_00018c80(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  char *in_EAX;
  char *pcVar2;
  int in_ECX;
  int iVar3;
  uint uVar4;
  bool bVar5;
  bool bVar6;
  
  pcVar2 = (char *)*param_1;
  if ((pcVar2 < (char *)(in_ECX + 0x44)) || (&DAT_00002044 + in_ECX <= pcVar2)) {
LAB_00018cd0:
    iVar3 = -1;
LAB_00018cd3:
    bVar5 = iVar3 == -1;
  }
  else {
    pcVar2 = pcVar2 + (-0x44 - in_ECX);
    uVar4 = (uint)pcVar2 & 0x8000001f;
    bVar5 = uVar4 == 0;
    if ((int)uVar4 < 0) {
      bVar5 = (uVar4 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (!bVar5) goto LAB_00018cd0;
    iVar3 = (int)(pcVar2 + ((int)pcVar2 >> 0x1f & 0x1f)) >> 5;
    bVar5 = iVar3 == -1;
    if (!bVar5) {
      if (*(undefined4 **)(&DAT_00002064 + iVar3 * 4 + in_ECX) != param_1) goto LAB_00018cd0;
      goto LAB_00018cd3;
    }
  }
  if ((in_EAX < (char *)(in_ECX + 0x44)) || (&DAT_00002044 + in_ECX <= in_EAX)) {
LAB_00018d0e:
    iVar3 = -1;
  }
  else {
    pcVar2 = in_EAX + (-0x44 - in_ECX);
    uVar4 = (uint)pcVar2 & 0x8000001f;
    bVar6 = uVar4 == 0;
    if ((int)uVar4 < 0) {
      bVar6 = (uVar4 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (!bVar6) goto LAB_00018d0e;
    iVar3 = (int)(pcVar2 + ((int)pcVar2 >> 0x1f & 0x1f)) >> 5;
  }
  if ((iVar3 == -1) || (*(int *)(&DAT_00002064 + iVar3 * 4 + in_ECX) != 0)) {
    bVar6 = false;
  }
  else {
    bVar6 = true;
  }
  if (bVar5) {
    if (!bVar6) {
      if (iVar3 != -1) {
        pcVar2 = in_EAX;
        do {
          cVar1 = *pcVar2;
          pcVar2 = pcVar2 + 1;
        } while (cVar1 != '\0');
        iVar3 = FUN_000196d0(param_2);
        iVar3 = (iVar3 * 0x20 + 0x44 + in_ECX) - (int)in_EAX;
        do {
          cVar1 = *in_EAX;
          in_EAX[iVar3] = cVar1;
          in_EAX = in_EAX + 1;
        } while (cVar1 != '\0');
        return;
      }
      goto LAB_00018dae;
    }
  }
  else {
    if (!bVar6) {
      if (iVar3 != -1) {
        pcVar2 = in_EAX;
        do {
          cVar1 = *pcVar2;
          pcVar2 = pcVar2 + 1;
        } while (cVar1 != '\0');
        iVar3 = FUN_00019830(param_1,pcVar2 + (1 - (int)(in_EAX + 1)),param_2);
        iVar3 = (iVar3 * 0x20 + 0x44 + in_ECX) - (int)in_EAX;
        do {
          cVar1 = *in_EAX;
          in_EAX[iVar3] = cVar1;
          in_EAX = in_EAX + 1;
        } while (cVar1 != '\0');
        return;
      }
      FUN_00019750();
LAB_00018dae:
      *param_1 = in_EAX;
      return;
    }
    FUN_00019750();
  }
  FUN_000197b0(param_2);
  return;
}


