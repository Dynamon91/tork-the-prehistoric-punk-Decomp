// func FUN_00059970 @ 0x00059970 (size 0x72)

void FUN_00059970(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int unaff_EDI;
  
  iVar3 = DAT_0024120c;
  iVar2 = DAT_00241208;
  iVar5 = *(int *)(unaff_EDI + 0xc);
  if (iVar5 != 0) {
    iVar4 = FUN_00058910();
    if (((iVar4 != -1) && (iVar1 = *(int *)(iVar2 + iVar4 * 4), iVar5 + -8 == iVar1)) &&
       (iVar5 = (*(int *)(iVar3 + iVar4 * 4) - iVar1) + iVar5, iVar5 != 0)) {
      *(int *)(unaff_EDI + 0xc) = iVar5;
    }
  }
  if (((*(char *)(unaff_EDI + 0x13) == '\x01') || (*(char *)(unaff_EDI + 0x13) == '\x03')) &&
     (iVar5 = *(int *)(unaff_EDI + 4), iVar5 != 0)) {
    iVar4 = FUN_00058910();
    if (((iVar4 != -1) && (iVar2 = *(int *)(iVar2 + iVar4 * 4), iVar5 + -8 == iVar2)) &&
       (iVar5 = (*(int *)(iVar3 + iVar4 * 4) - iVar2) + iVar5, iVar5 != 0)) {
      *(int *)(unaff_EDI + 4) = iVar5;
    }
  }
  return;
}


