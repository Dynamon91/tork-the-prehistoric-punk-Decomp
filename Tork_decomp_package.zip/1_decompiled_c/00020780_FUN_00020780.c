// func FUN_00020780 @ 0x00020780 (size 0x59)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00020780(void)

{
  float *in_EAX;
  int in_ECX;
  float *pfVar1;
  float10 fVar2;
  
  pfVar1 = (float *)(in_ECX + 0x40);
  *pfVar1 = *in_EAX;
  *(float *)(in_ECX + 0x44) = in_EAX[1];
  *(float *)(in_ECX + 0x48) = in_EAX[2];
  fVar2 = (float10)FUN_00021640();
  fVar2 = SQRT((float10)_DAT_0020df98 / fVar2);
  *pfVar1 = (float)(fVar2 * (float10)*pfVar1);
  *(float *)(in_ECX + 0x44) = (float)(fVar2 * (float10)*(float *)(in_ECX + 0x44));
  *(float *)(in_ECX + 0x48) = (float)(fVar2 * (float10)*(float *)(in_ECX + 0x48));
  return;
}


