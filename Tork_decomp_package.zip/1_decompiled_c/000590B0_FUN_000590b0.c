// func FUN_000590b0 @ 0x000590B0 (size 0x2F7)

undefined4 FUN_000590b0(void)

{
  char cVar1;
  int *in_EAX;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  bool bVar8;
  uint local_8;
  undefined1 local_4 [4];
  
  cVar1 = *(char *)((int)in_EAX + 0xf);
  if (cVar1 == '\x05') {
    iVar2 = FUN_0012d2c2(*in_EAX,0xc0000000,0,0,4,0x8000080,0);
    FUN_00058010();
    if (iVar2 == -1) {
      return 1;
    }
  }
  else if ((cVar1 == '\x01') || (cVar1 == '\x03')) {
    iVar2 = FUN_0012d2c2(*in_EAX,0x80000000,0,0,3,0x8000080,0);
    FUN_00058010();
    if (iVar2 == -1) {
      return 2;
    }
  }
  else {
    iVar2 = *in_EAX;
  }
  switch(*(undefined1 *)((int)in_EAX + 0xf)) {
  case 0:
  case 1:
    FUN_0012caa5(iVar2,in_EAX[1],0,0);
    uVar6 = in_EAX[3];
    iVar5 = in_EAX[2];
    goto LAB_000591a3;
  case 2:
    FUN_0012caa5(iVar2,in_EAX[1],0,0);
    iVar5 = FUN_0012c85e(iVar2,&DAT_0022d2c0,0x200,&local_8,0);
    if (iVar5 == 0) {
      return 1;
    }
    if (local_8 < 4) {
      return 3;
    }
    uVar6 = in_EAX[3];
    if (DAT_0022d2c0 < (uVar6 & 0xffffff)) {
      if (DAT_0022d2c0 == 0) {
        in_EAX[3] = uVar6 & 0xff000004 | 4;
      }
      else {
        in_EAX[3] = (uVar6 ^ DAT_0022d2c0) & 0xffffff ^ uVar6;
      }
    }
    puVar4 = (undefined4 *)FUN_00057f60(in_EAX[3] & 0xffffff);
    in_EAX[2] = (int)puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      return 1;
    }
    uVar6 = in_EAX[3];
    uVar3 = uVar6 & 0xffffff;
    if (uVar3 < 0x1fd) {
      puVar7 = &DAT_0022d2c4;
      for (uVar3 = uVar3 >> 2; uVar3 != 0; uVar3 = uVar3 - 1) {
        *puVar4 = *puVar7;
        puVar7 = puVar7 + 1;
        puVar4 = puVar4 + 1;
      }
      for (uVar6 = uVar6 & 3; uVar6 != 0; uVar6 = uVar6 - 1) {
        *(undefined1 *)puVar4 = *(undefined1 *)puVar7;
        puVar7 = (undefined4 *)((int)puVar7 + 1);
        puVar4 = (undefined4 *)((int)puVar4 + 1);
      }
    }
    else {
      FUN_0012caa5(iVar2,in_EAX[1] + 0x200,0,0);
      puVar4 = &DAT_0022d2c4;
      puVar7 = (undefined4 *)in_EAX[2];
      for (iVar5 = 0x7f; iVar5 != 0; iVar5 = iVar5 + -1) {
        *puVar7 = *puVar4;
        puVar4 = puVar4 + 1;
        puVar7 = puVar7 + 1;
      }
      iVar5 = FUN_0012c85e(iVar2,in_EAX[2] + 0x1fc,(in_EAX[3] & 0xffffffU) - 0x1fc,&local_8,0);
      if (iVar5 == 0) {
        return 1;
      }
      if ((in_EAX[3] & 0xffffffU) - 0x1fc != local_8) {
        return 3;
      }
    }
    break;
  case 3:
    FUN_0012caa5(iVar2,in_EAX[1],0,0);
    uVar3 = FUN_0012d287(iVar2,local_4);
    uVar6 = in_EAX[3];
    if (uVar3 < (uVar6 & 0xffffff)) {
      in_EAX[3] = (uVar6 ^ uVar3) & 0xffffff ^ uVar6;
    }
    iVar5 = FUN_00057f60(in_EAX[3] & 0xffffff);
    uVar6 = in_EAX[3];
    in_EAX[2] = iVar5;
LAB_000591a3:
    iVar5 = FUN_0012c85e(iVar2,iVar5,uVar6 & 0xffffff,&local_8,0);
    if (iVar5 == 0) {
switchD_0005910b_default:
      return 1;
    }
    bVar8 = (in_EAX[3] & 0xffffffU) == local_8;
LAB_000591bf:
    if (!bVar8) {
      return 3;
    }
    break;
  case 4:
  case 5:
    FUN_0012caa5(iVar2,in_EAX[1],0,0);
    iVar5 = FUN_0012c94b(iVar2,in_EAX[2],in_EAX[3] & 0xffffff,&local_8,0);
    if (iVar5 == 0) {
      return 1;
    }
    bVar8 = (in_EAX[3] & 0xffffffU) == local_8;
    goto LAB_000591bf;
  case 6:
    (*(code *)*in_EAX)(in_EAX[1],in_EAX[2]);
    break;
  case 7:
    in_EAX[3] = in_EAX[3] & 0xff000000;
    break;
  default:
    goto switchD_0005910b_default;
  }
  cVar1 = *(char *)((int)in_EAX + 0xf);
  if (((cVar1 == '\x01') || (cVar1 == '\x03')) || (cVar1 == '\x05')) {
    FUN_0012c0be(iVar2);
  }
  return 0;
}


