// func FUN_0005b8a0 @ 0x0005B8A0 (size 0x27)

void FUN_0005b8a0(undefined4 *param_1)

{
  int *in_EAX;
  
  FUN_0005ba50();
  *(undefined4 *)(*in_EAX + (uint)*(ushort *)((int)in_EAX + 6) * 4) = *param_1;
  *(short *)((int)in_EAX + 6) = *(short *)((int)in_EAX + 6) + 1;
  return;
}


