// func FUN_00021b20 @ 0x00021B20 (size 0x46)

/* WARNING: Removing unreachable block (ram,0x00021b53) */

uint FUN_00021b20(void)

{
  uint uVar1;
  
  uVar1 = DAT_00222f34 * 0xf25 + 0x7385;
  DAT_00222f34 = uVar1 % 0x222c0;
  return uVar1 / 0x222c0;
}


