// func FUN_00046cf0 @ 0x00046CF0 (size 0x151)

void FUN_00046cf0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,byte param_4)

{
  int iVar1;
  int iVar2;
  byte *pbVar3;
  undefined4 uVar4;
  undefined4 local_b0;
  undefined4 local_ac;
  undefined4 local_a8;
  undefined4 local_a0;
  undefined4 local_9c;
  undefined4 local_98;
  undefined4 local_90;
  undefined4 local_8c;
  undefined4 local_88;
  undefined1 local_80 [64];
  undefined1 local_40 [64];
  
  iVar1 = *(int *)(DAT_0022a6c4 + 0x14);
  iVar2 = *(int *)(*(int *)(*(int *)(iVar1 + 0x14) + 4) + 4);
  pbVar3 = *(byte **)(*(int *)(iVar1 + 0x14) + 0x10);
  if ((param_4 < *pbVar3) && ((uint)param_4 * 0x40 + *(int *)(pbVar3 + 4) == 0)) {
    iVar2 = *(int *)(iVar1 + 0x10);
    *param_1 = *(undefined4 *)(iVar2 + 0x10);
    param_1[1] = *(undefined4 *)(iVar2 + 0x14);
    param_1[2] = *(undefined4 *)(iVar2 + 0x18);
    iVar2 = *(int *)(iVar1 + 0x10);
    *param_2 = *(undefined4 *)(iVar2 + 0x20);
    param_2[1] = *(undefined4 *)(iVar2 + 0x24);
    param_2[2] = *(undefined4 *)(iVar2 + 0x28);
    iVar1 = *(int *)(iVar1 + 0x10);
    *param_3 = *(undefined4 *)(iVar1 + 0x30);
    param_3[1] = *(undefined4 *)(iVar1 + 0x34);
    param_3[2] = *(undefined4 *)(iVar1 + 0x38);
    return;
  }
  FUN_00047960();
  FUN_000479c0();
  FUN_000286c0(iVar2 + (uint)param_4 * 0xc4 + 0x1d8,local_80);
  uVar4 = *(undefined4 *)(iVar1 + 0x10);
  FUN_000479c0();
  FUN_000286c0(local_40,uVar4);
  *param_1 = local_b0;
  param_1[1] = local_ac;
  param_1[2] = local_a8;
  *param_2 = local_a0;
  param_2[1] = local_9c;
  param_2[2] = local_98;
  *param_3 = local_90;
  param_3[1] = local_8c;
  param_3[2] = local_88;
  return;
}


