// func FUN_0001bac0 @ 0x0001BAC0 (size 0x29)

void FUN_0001bac0(int *param_1,undefined4 param_2)

{
  int iVar1;
  
  if (*param_1 != 0) {
    iVar1 = FUN_00058980(*param_1,param_2);
    if (iVar1 != 0) {
      *param_1 = iVar1;
    }
    FUN_0001aea0(*param_1);
  }
  return;
}


