// func FUN_00028b90 @ 0x00028B90 (size 0x7A)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00028b90(float param_1)

{
  float fVar1;
  int in_EAX;
  float10 fVar2;
  
  if ((uint)ABS(param_1) < 0x358637bd) {
    *(undefined4 *)(in_EAX + 0x1c) = 0;
    *(undefined4 *)(in_EAX + 0x18) = 0;
    *(undefined4 *)(in_EAX + 0x14) = 0;
    return;
  }
  fVar2 = (float10)FUN_00021640(param_1);
  fVar1 = (float)(SQRT((float10)_DAT_0020df98 / fVar2) * (float10)param_1);
  *(float *)(in_EAX + 0x14) = fVar1 * *(float *)(in_EAX + 0x14);
  *(ulonglong *)(in_EAX + 0x18) =
       CONCAT44(fVar1 * (float)((ulonglong)*(undefined8 *)(in_EAX + 0x18) >> 0x20),
                fVar1 * (float)*(undefined8 *)(in_EAX + 0x18));
  return;
}


