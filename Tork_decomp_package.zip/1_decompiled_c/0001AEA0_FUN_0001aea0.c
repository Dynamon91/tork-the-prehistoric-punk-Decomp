// func FUN_0001aea0 @ 0x0001AEA0 (size 0x317)

void FUN_0001aea0(int param_1)

{
  char *pcVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  uint local_c;
  
  iVar4 = param_1;
  if ((*(uint *)(param_1 + -4) >> 0x1e & 1) != 0) goto LAB_0001b1b0;
  *(uint *)(param_1 + -4) = *(uint *)(param_1 + -4) | 0x40000000;
  iVar6 = *(int *)(param_1 + 0xc);
  if (iVar6 == 0) {
    iVar8 = DAT_00241208;
  }
  else {
    iVar5 = FUN_00058910();
    iVar8 = DAT_00241208;
    if (iVar5 != -1) {
      iVar7 = *(int *)(DAT_00241208 + iVar5 * 4);
      if (iVar6 + -8 == iVar7) {
        iVar6 = (*(int *)(DAT_0024120c + iVar5 * 4) - iVar7) + iVar6;
        if (iVar6 != 0) {
          *(int *)(param_1 + 0xc) = iVar6;
        }
      }
    }
  }
  iVar6 = *(int *)(param_1 + 0x10);
  if ((((iVar6 != 0) && (iVar5 = FUN_00058910(), iVar5 != -1)) &&
      (iVar7 = *(int *)(iVar8 + iVar5 * 4), iVar6 + -8 == iVar7)) &&
     (iVar6 = (*(int *)(DAT_0024120c + iVar5 * 4) - iVar7) + iVar6, iVar6 != 0)) {
    *(int *)(param_1 + 0x10) = iVar6;
  }
  pcVar1 = (char *)(param_1 + 2);
  param_1 = 0;
  if (*pcVar1 != '\0') {
    do {
      iVar6 = *(int *)(iVar4 + 0xc);
      iVar5 = param_1 * 4;
      iVar8 = *(int *)(iVar6 + iVar5);
      if (((iVar8 != 0) && (iVar7 = FUN_00058910(), iVar7 != -1)) &&
         ((iVar10 = *(int *)(DAT_00241208 + iVar7 * 4), iVar8 + -8 == iVar10 &&
          (iVar8 = (*(int *)(DAT_0024120c + iVar7 * 4) - iVar10) + iVar8, iVar8 != 0)))) {
        *(int *)(iVar6 + iVar5) = iVar8;
      }
      FUN_0001b1c0(*(undefined4 *)(*(int *)(iVar4 + 0xc) + iVar5));
      param_1 = param_1 + 1;
    } while (param_1 < (int)(uint)*(byte *)(iVar4 + 2));
    iVar8 = DAT_00241208;
  }
  param_1 = 0;
  if (*(char *)(iVar4 + 3) != '\0') {
    do {
      iVar6 = *(int *)(iVar4 + 0x10);
      iVar5 = param_1 * 4;
      iVar8 = *(int *)(iVar6 + iVar5);
      if (((iVar8 != 0) && (iVar7 = FUN_00058910(), iVar7 != -1)) &&
         ((iVar10 = *(int *)(DAT_00241208 + iVar7 * 4), iVar8 + -8 == iVar10 &&
          (iVar8 = (*(int *)(DAT_0024120c + iVar7 * 4) - iVar10) + iVar8, iVar8 != 0)))) {
        *(int *)(iVar6 + iVar5) = iVar8;
      }
      FUN_0001b1c0(*(undefined4 *)(iVar5 + *(int *)(iVar4 + 0x10)));
      param_1 = param_1 + 1;
    } while (param_1 < (int)(uint)*(byte *)(iVar4 + 3));
    iVar8 = DAT_00241208;
  }
  iVar6 = *(int *)(iVar4 + 0x14);
  if (iVar6 == 0) {
LAB_0001b046:
    iVar5 = DAT_0024120c;
  }
  else {
    iVar7 = FUN_00058910();
    iVar5 = DAT_0024120c;
    if ((iVar7 == -1) || (iVar10 = *(int *)(iVar8 + iVar7 * 4), iVar6 + -8 != iVar10))
    goto LAB_0001b046;
    iVar6 = (*(int *)(DAT_0024120c + iVar7 * 4) - iVar10) + iVar6;
    if (iVar6 != 0) {
      *(int *)(iVar4 + 0x14) = iVar6;
    }
  }
  iVar6 = *(int *)(iVar4 + 0x20);
  if ((((iVar6 != 0) && (iVar7 = FUN_00058910(), iVar7 != -1)) &&
      (iVar10 = *(int *)(iVar8 + iVar7 * 4), iVar6 + -8 == iVar10)) &&
     (iVar6 = (*(int *)(iVar5 + iVar7 * 4) - iVar10) + iVar6, iVar6 != 0)) {
    *(int *)(iVar4 + 0x20) = iVar6;
  }
  iVar6 = *(int *)(iVar4 + 0x18);
  if (iVar6 != 0) {
    iVar7 = FUN_00058910();
    if (((iVar7 != -1) && (iVar10 = *(int *)(iVar8 + iVar7 * 4), iVar6 + -8 == iVar10)) &&
       (iVar6 = (*(int *)(iVar5 + iVar7 * 4) - iVar10) + iVar6, iVar6 != 0)) {
      *(int *)(iVar4 + 0x18) = iVar6;
    }
    FUN_0001ca50(*(undefined4 *)(iVar4 + 0x18));
  }
  iVar6 = *(int *)(iVar4 + 0x1c);
  if (iVar6 != 0) {
    iVar7 = FUN_00058910();
    if (((iVar7 != -1) && (iVar8 = *(int *)(iVar8 + iVar7 * 4), iVar6 + -8 == iVar8)) &&
       (iVar6 = (*(int *)(iVar5 + iVar7 * 4) - iVar8) + iVar6, iVar6 != 0)) {
      *(int *)(iVar4 + 0x1c) = iVar6;
    }
    FUN_0001ca50(*(undefined4 *)(iVar4 + 0x1c));
  }
  iVar6 = 0;
  if (0 < *(short *)(iVar4 + 0x26)) {
    iVar8 = iVar4 + 0x28;
    do {
      FUN_0001bac0(iVar8,0);
      iVar6 = iVar6 + 1;
      iVar8 = iVar8 + 4;
    } while (iVar6 < *(short *)(iVar4 + 0x26));
  }
  if (*(uint **)(iVar4 + 0x18) != (uint *)0x0) {
    uVar2 = **(uint **)(iVar4 + 0x18);
    local_c = 0;
    if (uVar2 != 0) {
      do {
        iVar6 = *(int *)(iVar4 + 0x18) + 8 + (local_c & 0xffff) * 0x14;
        if (*(char *)(iVar6 + 0xc) < '\0') {
          uVar9 = *(uint *)(iVar6 + 4) >> 2;
          uVar11 = 0;
          if (uVar9 != 0) {
            do {
              iVar8 = *(int *)(iVar4 + 0x14) + uVar11 * 4;
              iVar5 = *(int *)(iVar6 + 8);
              iVar7 = *(int *)(iVar8 + iVar5);
              if ((((iVar7 != 0) && (iVar10 = FUN_00058910(), iVar10 != -1)) &&
                  (iVar3 = *(int *)(DAT_00241208 + iVar10 * 4), iVar7 + -8 == iVar3)) &&
                 (iVar7 = (*(int *)(DAT_0024120c + iVar10 * 4) - iVar3) + iVar7, iVar7 != 0)) {
                *(int *)(iVar8 + iVar5) = iVar7;
              }
              uVar11 = uVar11 + 1;
            } while (uVar11 < uVar9);
          }
        }
        local_c = local_c + 1;
      } while (local_c < uVar2);
    }
  }
LAB_0001b1b0:
  return;
}


