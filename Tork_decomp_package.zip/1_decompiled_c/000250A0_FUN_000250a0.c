// func FUN_000250a0 @ 0x000250A0 (size 0x5D)

void FUN_000250a0(void)

{
  uint *puVar1;
  float fVar2;
  float *in_EAX;
  int in_ECX;
  float *pfVar3;
  
  if ((char)*(uint *)(in_ECX + 4) < '\0') {
    puVar1 = *(uint **)(in_ECX + 0x1c);
    pfVar3 = (float *)puVar1[1];
    *pfVar3 = *pfVar3 + *in_EAX;
    pfVar3[1] = in_EAX[1] + pfVar3[1];
    pfVar3[2] = in_EAX[2] + pfVar3[2];
    FUN_000e47c0(*puVar1 | 0x200);
    return;
  }
  pfVar3 = *(float **)(in_ECX + 0x10);
  if ((*(uint *)(in_ECX + 4) & 2) == 0) {
    fVar2 = *pfVar3 + *in_EAX;
  }
  else {
    pfVar3 = pfVar3 + 0xc;
    fVar2 = *in_EAX + *pfVar3;
  }
  *pfVar3 = fVar2;
  pfVar3[1] = in_EAX[1] + pfVar3[1];
  pfVar3[2] = in_EAX[2] + pfVar3[2];
  return;
}


