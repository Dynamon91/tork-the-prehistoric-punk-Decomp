// func FUN_0002f7c0 @ 0x0002F7C0 (size 0xED)

undefined4
FUN_0002f7c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined1 local_e;
  char local_d;
  int local_c;
  int local_8;
  undefined4 local_4;
  
  iVar3 = DAT_0022a6f8;
  iVar1 = *(int *)(DAT_0022a6c4 + 0x14);
  local_d = DAT_002411ee + 1;
  iVar2 = *(int *)(*(int *)(iVar1 + 0x24) + 0x10);
  if (DAT_002411ee < *(byte *)(iVar2 + 3) >> 3) {
    local_4 = *(undefined4 *)(*(int *)(iVar2 + 8) + (uint)DAT_002411ee * 4);
  }
  else {
    local_4 = 0;
  }
  iVar2 = *(int *)(*(int *)(DAT_0022a6f8 + 0x24) + 0x10);
  local_8 = DAT_0022a6f8;
  if (DAT_002411ef < *(byte *)(iVar2 + 3) >> 3) {
    local_c = *(int *)(*(int *)(iVar2 + 8) + (uint)DAT_002411ef * 4);
  }
  else {
    local_c = 0;
  }
  local_e = FUN_000e9e90();
  if (local_c == 0) {
    iVar3 = FUN_0002c660(0x800);
    local_8 = iVar3;
  }
  if (iVar3 == 0) {
    return 0;
  }
  uVar4 = FUN_0002d0f0(param_1,param_2,param_3,param_4,param_5,param_6,iVar1,&local_4,&local_d,
                       &local_8,&local_c,&local_e);
  return uVar4;
}


