// func FUN_00024e50 @ 0x00024E50 (size 0x31)

void FUN_00024e50(void)

{
  undefined4 *puVar1;
  undefined4 *in_EAX;
  int in_ECX;
  
  if ((*(uint *)(in_ECX + 4) >> 9 & 1) != 0) {
    puVar1 = *(undefined4 **)(in_ECX + 0x28);
    *puVar1 = *in_EAX;
    puVar1[1] = in_EAX[1];
    puVar1[2] = in_EAX[2];
    puVar1[3] = in_EAX[3];
    puVar1[4] = in_EAX[4];
    puVar1[5] = in_EAX[5];
  }
  return;
}


