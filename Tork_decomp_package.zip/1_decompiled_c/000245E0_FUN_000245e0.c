// func FUN_000245e0 @ 0x000245E0 (size 0x4C)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_000245e0(float param_1)

{
  float10 fVar1;
  
  if (_DAT_0020df5c < param_1) {
    fVar1 = (float10)thunk_FUN_00140fea();
    return fVar1;
  }
  if (param_1 < _DAT_0020df5c) {
    fVar1 = (float10)thunk_FUN_00140fea();
    return -fVar1;
  }
  return (float10)_DAT_0020df5c;
}


