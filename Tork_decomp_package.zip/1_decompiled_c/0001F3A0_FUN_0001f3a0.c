// func FUN_0001f3a0 @ 0x0001F3A0 (size 0xBF)

void FUN_0001f3a0(void)

{
  byte *pbVar1;
  char cVar2;
  int iVar3;
  int in_ECX;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  
  pbVar1 = *(byte **)(in_ECX + 0x3c);
  *(byte **)(in_ECX + 0x3c) = pbVar1 + 4;
  uVar4 = *pbVar1 & 7;
  if ((*pbVar1 & 7) != 0) {
    uVar7 = uVar4;
    do {
      (**(code **)(&DAT_00241540 + (*(byte *)(*(int *)(in_ECX + 0x3c) + 1) & 0x3f) * 0x10))();
      uVar7 = uVar7 - 1;
    } while (uVar7 != 0);
  }
  iVar3 = FUN_0001c170();
  iVar5 = uVar4 - 1;
  while (-1 < iVar5) {
    puVar6 = (undefined4 *)(*(int *)(in_ECX + 8) + -4);
    iVar5 = iVar5 + -1;
    *(undefined4 **)(in_ECX + 8) = puVar6;
    *(undefined4 *)(iVar3 + 4 + iVar5 * 4) = *puVar6;
  }
  cVar2 = (**(code **)(&DAT_00002098 + (uint)*(ushort *)(pbVar1 + 2) * 4 + in_ECX))(1,iVar3);
  if (cVar2 == '\0') {
    iVar5 = *(int *)(in_ECX + 0xc) + 0x6a + (uint)*(byte *)(in_ECX + 0x18) * 8;
    *(undefined2 *)(iVar5 + 4) = *(undefined2 *)(pbVar1 + 2);
    *(short *)(iVar5 + 6) = (short)(*(int *)(in_ECX + 0x3c) - *(int *)(in_ECX + 0x24) >> 2);
    (&DAT_0000229c)[in_ECX] = 1;
    return;
  }
  *(undefined1 *)(*(int *)(in_ECX + 0xc) + 0x6d + (uint)*(byte *)(in_ECX + 0x18) * 8) = 0xff;
  return;
}


