// func FUN_00057860 @ 0x00057860 (size 0xBC)

void FUN_00057860(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_54;
  int local_50 [4];
  int local_40;
  undefined4 local_3c;
  int local_34;
  undefined1 local_28 [40];
  
  piVar1 = (int *)FUN_00057560(local_28);
  piVar3 = local_50;
  for (iVar2 = 10; iVar2 != 0; iVar2 = iVar2 + -1) {
    *piVar3 = *piVar1;
    piVar1 = piVar1 + 1;
    piVar3 = piVar3 + 1;
  }
  FUN_00057ee0();
  FID_conflict__fwprintf((__FILE *)&DAT_00220d68,(wchar_t *)s_free_bytes____10lu_0020844c,local_5c);
  FID_conflict__fwprintf
            ((__FILE *)&DAT_00220d68,(wchar_t *)s_reserved_bytes____10lu_00208430,local_58);
  FID_conflict__fwprintf
            ((__FILE *)&DAT_00220d68,(wchar_t *)s_committed_bytes____10lu_00208414,local_54);
  FID_conflict__fwprintf
            ((__FILE *)&DAT_00220d68,(wchar_t *)s_max_system_bytes____10lu_002083f8,local_3c);
  FID_conflict__fwprintf
            ((__FILE *)&DAT_00220d68,(wchar_t *)s_system_bytes____10lu_002083dc,
             local_40 + local_50[0]);
  FID_conflict__fwprintf
            ((__FILE *)&DAT_00220d68,(wchar_t *)s_in_use_bytes____10lu_002083c0,local_34 + local_40)
  ;
  return;
}


