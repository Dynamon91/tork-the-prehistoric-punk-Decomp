// func FUN_0001dd90 @ 0x0001DD90 (size 0x449)

void FUN_0001dd90(void)

{
  float fVar1;
  char cVar2;
  char cVar3;
  char cVar4;
  undefined2 uVar5;
  char *pcVar6;
  uint uVar7;
  undefined4 uVar8;
  int iVar9;
  uint *puVar10;
  undefined4 *puVar11;
  uint *in_ECX;
  int iVar12;
  undefined4 *puVar13;
  int *piVar14;
  float *pfVar15;
  undefined4 *puVar16;
  undefined2 *puVar17;
  undefined4 uStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  undefined4 auStack_40 [16];
  
  pcVar6 = (char *)in_ECX[0xf];
  cVar2 = pcVar6[2];
  cVar3 = pcVar6[3];
  cVar4 = *pcVar6;
  in_ECX[0xf] = (uint)(pcVar6 + 4);
  (**(code **)(&DAT_00241540 + ((byte)pcVar6[5] & 0x3f) * 0x10))();
  (**(code **)(&DAT_00241540 + (*(byte *)(in_ECX[0xf] + 1) & 0x3f) * 0x10))();
  switch(cVar2) {
  case '\x01':
  case '\x02':
  case '\x03':
  case '\x04':
  case '\x05':
  case '\x06':
  case '\a':
    uVar7 = in_ECX[2];
    piVar14 = (int *)(uVar7 - 4);
    in_ECX[2] = (uint)piVar14;
    iVar12 = *piVar14;
    in_ECX[2] = uVar7 - 8;
    iVar9 = FUN_0001d940();
    switch(cVar4) {
    case '\x01':
      FUN_0001d990();
      return;
    case '\x02':
      FUN_0001d990();
      return;
    case '\x03':
      FUN_0001d990();
      return;
    case '\x04':
      FUN_0001d990();
      return;
    case '\x05':
      FUN_0001d990();
      return;
    case '\x06':
      FUN_0001d990();
      return;
    case '\a':
      FUN_0001d990();
      return;
    case '\b':
      FUN_0001d990();
      return;
    case '\t':
      FUN_0001d990();
      return;
    case '\n':
      FUN_0001d990();
      return;
    case '\v':
      if (iVar9 == 0) goto LAB_0001df14;
      break;
    case '\f':
      if (iVar9 != 0) goto switchD_0001de2d_default;
      break;
    default:
      goto switchD_0001de2d_default;
    }
    if (iVar12 == 0) {
LAB_0001df14:
      FUN_0001d990();
      return;
    }
switchD_0001de2d_default:
    FUN_0001d990();
    return;
  case '\b':
    uVar7 = in_ECX[2];
    pfVar15 = (float *)(uVar7 - 4);
    in_ECX[2] = (uint)pfVar15;
    fVar1 = *pfVar15;
    puVar11 = (undefined4 *)(uVar7 - 8);
    in_ECX[2] = (uint)puVar11;
    pfVar15 = (float *)*puVar11;
    switch(cVar4) {
    case '\x02':
      *pfVar15 = fVar1 + *pfVar15;
      return;
    case '\x03':
      *pfVar15 = *pfVar15 - fVar1;
      break;
    case '\x04':
      fVar1 = fVar1 * *pfVar15;
    case '\x01':
      *pfVar15 = fVar1;
      return;
    case '\x05':
      *pfVar15 = *pfVar15 / fVar1;
      return;
    }
    break;
  case '\t':
    uVar7 = in_ECX[2];
    if (cVar3 == '\t') {
      in_ECX[2] = uVar7 - 0xc;
      fStack_4c = *(float *)(uVar7 - 0xc);
      fStack_48 = *(float *)(uVar7 - 8);
      fStack_44 = *(float *)(uVar7 - 4);
    }
    else {
      in_ECX[2] = uVar7 - 4;
      uStack_50 = *(undefined4 *)(uVar7 - 4);
    }
    uVar7 = in_ECX[2];
    in_ECX[2] = uVar7 - 4;
    pfVar15 = *(float **)(uVar7 - 4);
    switch(cVar4) {
    case '\x01':
      *pfVar15 = fStack_4c;
      pfVar15[1] = fStack_48;
      pfVar15[2] = fStack_44;
      return;
    case '\x02':
      *pfVar15 = fStack_4c + *pfVar15;
      pfVar15[1] = fStack_48 + pfVar15[1];
      pfVar15[2] = fStack_44 + pfVar15[2];
      return;
    case '\x03':
      *pfVar15 = *pfVar15 - fStack_4c;
      pfVar15[1] = pfVar15[1] - fStack_48;
      pfVar15[2] = pfVar15[2] - fStack_44;
      return;
    case '\x04':
      FUN_0001fbf0(pfVar15,uStack_50);
      return;
    case '\x05':
      FUN_0001fbb0(pfVar15,uStack_50);
      return;
    }
    break;
  case '\n':
    uVar7 = in_ECX[2];
    puVar13 = (undefined4 *)(uVar7 - 0x40);
    in_ECX[2] = (uint)puVar13;
    puVar11 = (undefined4 *)(uVar7 - 0x44);
    puVar16 = auStack_40;
    for (iVar12 = 0x10; iVar12 != 0; iVar12 = iVar12 + -1) {
      *puVar16 = *puVar13;
      puVar13 = puVar13 + 1;
      puVar16 = puVar16 + 1;
    }
    in_ECX[2] = (uint)puVar11;
    if (cVar4 == '\x01') {
      puVar13 = auStack_40;
      puVar11 = (undefined4 *)*puVar11;
      for (iVar12 = 0x10; iVar12 != 0; iVar12 = iVar12 + -1) {
        *puVar11 = *puVar13;
        puVar13 = puVar13 + 1;
        puVar11 = puVar11 + 1;
      }
      return;
    }
    break;
  case '\v':
    uVar7 = in_ECX[2];
    puVar11 = (undefined4 *)(uVar7 - 4);
    in_ECX[2] = (uint)puVar11;
    uVar8 = *puVar11;
    puVar10 = (uint *)(uVar7 - 8);
    in_ECX[2] = (uint)puVar10;
    uVar7 = *puVar10;
    if ((uVar7 < *in_ECX) || (uStack_50 = 1, in_ECX[1] <= uVar7)) {
      uStack_50 = 0;
    }
    if (cVar4 == '\x01') {
      FUN_00018c80(uVar7,uStack_50);
      return;
    }
    if (cVar4 == '\x02') {
      FUN_00018f70(DAT_002411d8,uVar7,uVar8,uStack_50);
      return;
    }
    break;
  default:
    uVar7 = in_ECX[2];
    puVar11 = (undefined4 *)(uVar7 - 4);
    in_ECX[2] = (uint)puVar11;
    uVar8 = *puVar11;
    puVar11 = (undefined4 *)(uVar7 - 8);
    in_ECX[2] = (uint)puVar11;
    *(undefined4 *)*puVar11 = uVar8;
    return;
  case ' ':
    uVar7 = in_ECX[2];
    puVar17 = (undefined2 *)(uVar7 - 4);
    in_ECX[2] = (uint)puVar17;
    uVar5 = *puVar17;
    puVar11 = (undefined4 *)(uVar7 - 8);
    in_ECX[2] = (uint)puVar11;
    if (cVar4 == '\x01') {
      *(undefined2 *)*puVar11 = uVar5;
      return;
    }
    break;
  case '\"':
    uVar7 = in_ECX[2];
    puVar11 = (undefined4 *)(uVar7 - 4);
    in_ECX[2] = (uint)puVar11;
    uVar8 = *puVar11;
    puVar10 = (uint *)(uVar7 - 8);
    in_ECX[2] = (uint)puVar10;
    uVar7 = *puVar10;
    if ((uVar7 < *in_ECX) || (uStack_50 = 1, in_ECX[1] <= uVar7)) {
      uStack_50 = 0;
    }
    if (cVar4 == '\x01') {
      FUN_00018e10(uVar7,uVar8,uStack_50);
      return;
    }
    if (cVar4 == '\x02') {
      FUN_00019180(uVar8,uStack_50);
      return;
    }
  }
  return;
}


