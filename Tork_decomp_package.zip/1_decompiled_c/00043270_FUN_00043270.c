// func FUN_00043270 @ 0x00043270 (size 0x27)

uint FUN_00043270(void)

{
  int iVar1;
  int in_EAX;
  uint uVar2;
  byte local_4 [4];
  
  uVar2 = 0;
  if ((*(int **)(in_EAX + 0x18) != (int *)0x0) &&
     (iVar1 = **(int **)(in_EAX + 0x18), uVar2 = 0, iVar1 != 0)) {
    uVar2 = FUN_00166b82(iVar1,local_4);
    if (uVar2 == 0) {
      return local_4[0] & 0xffffff01;
    }
  }
  return uVar2 & 0xffffff00;
}


