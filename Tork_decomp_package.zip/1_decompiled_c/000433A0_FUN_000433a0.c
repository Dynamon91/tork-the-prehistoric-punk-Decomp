// func FUN_000433a0 @ 0x000433A0 (size 0x1E)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_000433a0(void)

{
  float fVar1;
  uint in_EAX;
  
  if (*(char *)(in_EAX + 0x50) == '\x01') {
    fVar1 = *(float *)(in_EAX + 0x2c);
    in_EAX = CONCAT22((short)(in_EAX >> 0x10),
                      (ushort)(fVar1 < _DAT_0020df5c) << 8 |
                      (ushort)(NAN(fVar1) || NAN(_DAT_0020df5c)) << 10 |
                      (ushort)(fVar1 == _DAT_0020df5c) << 0xe);
    if (fVar1 == _DAT_0020df5c) {
      return CONCAT31((int3)(in_EAX >> 8),1);
    }
  }
  return in_EAX & 0xffffff00;
}


