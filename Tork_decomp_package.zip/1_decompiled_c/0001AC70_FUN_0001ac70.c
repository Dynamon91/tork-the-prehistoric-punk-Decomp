// func FUN_0001ac70 @ 0x0001AC70 (size 0x22B)

void FUN_0001ac70(void)

{
  short *psVar1;
  ushort uVar2;
  uint *puVar3;
  byte bVar4;
  ushort *in_ECX;
  ushort *puVar5;
  int iVar6;
  uint *puVar7;
  uint local_4;
  
  *in_ECX = *in_ECX - 1;
  if (*in_ECX == in_ECX[0x12]) {
    if (*in_ECX == 0) goto LAB_0001acff;
    if (0 < (short)in_ECX[0x13]) {
      in_ECX[0x12] = in_ECX[0x12] | 0x2000;
      DAT_0022a6cc = '\0';
      FUN_0001b230();
      while (DAT_0022a6cc != '\0') {
        FUN_0001b2a0();
        DAT_0022a6cc = '\0';
        FUN_0001b230();
      }
      FUN_0001b2e0();
      uVar2 = *in_ECX;
      bVar4 = FUN_0001b330();
      FUN_0001b390(-(uint)((uVar2 == 0 & bVar4) != 0) & (uint)in_ECX);
    }
  }
  if (*in_ECX != 0) {
    return;
  }
LAB_0001acff:
  iVar6 = 0;
  if ((char)in_ECX[1] != '\0') {
    do {
      if (*(int *)(*(int *)(in_ECX + 6) + iVar6 * 4) != 0) {
        FUN_0001b8e0(0);
        FUN_0001aab0(DAT_0022d4c0);
        FUN_00058010();
      }
      iVar6 = iVar6 + 1;
    } while (iVar6 < (int)(uint)(byte)in_ECX[1]);
  }
  iVar6 = 0;
  if (*(char *)((int)in_ECX + 3) != '\0') {
    do {
      if (*(int *)(*(int *)(in_ECX + 8) + iVar6 * 4) != 0) {
        FUN_0001b8e0(0);
        FUN_0001aab0(DAT_0022d4c0);
        FUN_00058010();
      }
      iVar6 = iVar6 + 1;
    } while (iVar6 < (int)(uint)*(byte *)((int)in_ECX + 3));
  }
  iVar6 = 0;
  if (0 < (short)in_ECX[0x13]) {
    puVar5 = in_ECX + 0x14;
    do {
      if (*(int *)puVar5 != 0) {
        psVar1 = (short *)(*(int *)puVar5 + 0x24);
        *psVar1 = *psVar1 + -1;
        FUN_0001ac70();
      }
      iVar6 = iVar6 + 1;
      puVar5 = puVar5 + 2;
    } while (iVar6 < (short)in_ECX[0x13]);
  }
  if (*(int *)(in_ECX + 6) != 0) {
    FUN_00058010();
  }
  if (*(int *)(in_ECX + 8) != 0) {
    FUN_00058010();
  }
  if (*(int *)(in_ECX + 2) != 0) {
    FUN_00058010();
  }
  if (*(int *)(in_ECX + 0xc) != 0) {
    FUN_0001aab0(DAT_0022d4c0);
    puVar3 = *(uint **)(in_ECX + 0xc);
    local_4 = 0;
    if (*puVar3 != 0) {
      puVar7 = puVar3 + 3;
      do {
        if (((puVar7[2] & 1) != 0) && (4 < *puVar7)) {
          FUN_00058010();
        }
        local_4 = local_4 + 1;
        puVar7 = puVar7 + 5;
      } while (local_4 < *puVar3);
    }
    FUN_00058010();
  }
  if (*(int *)(in_ECX + 0xe) != 0) {
    FUN_0001aab0(DAT_0022d4c0);
    puVar3 = *(uint **)(in_ECX + 0xe);
    local_4 = 0;
    if (*puVar3 != 0) {
      puVar7 = puVar3 + 3;
      do {
        if (((puVar7[2] & 1) != 0) && (4 < *puVar7)) {
          FUN_00058010();
        }
        local_4 = local_4 + 1;
        puVar7 = puVar7 + 5;
      } while (local_4 < *puVar3);
    }
    FUN_00058010();
  }
  FUN_0001aab0(DAT_0022d4c0);
  FUN_00058010();
  return;
}


