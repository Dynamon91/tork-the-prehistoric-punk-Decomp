// func FUN_00023b40 @ 0x00023B40 (size 0x27)

void FUN_00023b40(float param_1)

{
  float *in_EAX;
  float *in_ECX;
  
  *in_EAX = *in_EAX - param_1 * *in_ECX;
  in_EAX[1] = in_EAX[1] - param_1 * in_ECX[1];
  in_EAX[2] = in_EAX[2] - param_1 * in_ECX[2];
  return;
}


