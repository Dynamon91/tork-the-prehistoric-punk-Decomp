// func FUN_0001d9d0 @ 0x0001D9D0 (size 0x96)

void FUN_0001d9d0(void)

{
  byte bVar1;
  uint in_EAX;
  ushort *in_ECX;
  uint uVar2;
  int in_EDX;
  byte *pbVar3;
  
  switch(in_EAX & 0xff) {
  case 1:
    **(uint **)(in_EDX + 8) = (uint)((byte)*in_ECX != 0);
    *(int *)(in_EDX + 8) = *(int *)(in_EDX + 8) + 4;
    return;
  case 2:
    **(int **)(in_EDX + 8) = (int)(char)(byte)*in_ECX;
    *(int *)(in_EDX + 8) = *(int *)(in_EDX + 8) + 4;
    return;
  case 3:
    **(uint **)(in_EDX + 8) = (uint)(byte)*in_ECX;
    *(int *)(in_EDX + 8) = *(int *)(in_EDX + 8) + 4;
    return;
  case 4:
    **(int **)(in_EDX + 8) = (int)(short)*in_ECX;
    *(int *)(in_EDX + 8) = *(int *)(in_EDX + 8) + 4;
    return;
  case 5:
  case 0x20:
    **(uint **)(in_EDX + 8) = (uint)*in_ECX;
    *(int *)(in_EDX + 8) = *(int *)(in_EDX + 8) + 4;
    return;
  default:
    bVar1 = (&DAT_002080e8)[in_EAX & 0xff];
    pbVar3 = *(byte **)(in_EDX + 8);
  }
  for (uVar2 = (uint)(bVar1 >> 2); uVar2 != 0; uVar2 = uVar2 - 1) {
    *(undefined4 *)pbVar3 = *(undefined4 *)in_ECX;
    in_ECX = in_ECX + 2;
    pbVar3 = pbVar3 + 4;
  }
  for (uVar2 = bVar1 & 3; uVar2 != 0; uVar2 = uVar2 - 1) {
    *pbVar3 = (byte)*in_ECX;
    in_ECX = (ushort *)((int)in_ECX + 1);
    pbVar3 = pbVar3 + 1;
  }
  *(uint *)(in_EDX + 8) = *(int *)(in_EDX + 8) + (uint)(bVar1 >> 2) * 4;
  return;
}


