// func FUN_00018770 @ 0x00018770 (size 0x3D)

void FUN_00018770(void)

{
  uint *in_EAX;
  short unaff_BX;
  uint uVar1;
  
  uVar1 = *in_EAX;
  *(undefined1 *)(in_EAX + 0x1047) = 0;
  if (uVar1 != in_EAX[1]) {
    do {
      if (((short)in_EAX[uVar1 * 4 + 4] != -1) &&
         (*(short *)((int)in_EAX + uVar1 * 0x10 + 0x12) == unaff_BX)) {
        in_EAX = (uint *)FUN_00018850();
      }
      uVar1 = uVar1 + 1 & 0x1ff;
    } while (uVar1 != in_EAX[1]);
  }
  return;
}


