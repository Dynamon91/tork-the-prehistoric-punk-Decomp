// func FUN_00021e30 @ 0x00021E30 (size 0xC7)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00021e30(int param_1,float param_2)

{
  int iVar1;
  short sVar2;
  undefined4 *in_EAX;
  ushort in_CX;
  int in_EDX;
  
  if (0xff < in_CX) {
    *in_EAX = DAT_00241764;
    in_EAX[1] = DAT_00241768;
    in_EAX[2] = DAT_0024176c;
    return;
  }
  if (_DAT_0020df5c <= param_2) {
    if (_DAT_0020df98 < param_2) {
      param_2 = 1.0;
    }
  }
  else {
    param_2 = 0.0;
  }
  iVar1 = *(int *)(param_1 + 4 + (uint)in_CX * 4);
  if (iVar1 == 0) {
    *in_EAX = DAT_00241764;
    in_EAX[1] = DAT_00241768;
    in_EAX[2] = DAT_0024176c;
    return;
  }
  if (*(char *)(iVar1 + 0x2b) == '\0') {
    sVar2 = *(short *)(iVar1 + 6);
  }
  else {
    sVar2 = *(short *)(iVar1 + 0xe);
  }
  if ((int)(uint)(ushort)(sVar2 - 2) < in_EDX) {
    param_2 = 1.0;
  }
  FUN_00065d90(param_2);
  return;
}


