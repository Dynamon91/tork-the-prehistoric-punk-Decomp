// func FUN_00049d80 @ 0x00049D80 (size 0x5E)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00049d80(int param_1,float param_2)

{
  undefined1 uVar1;
  
  if (param_2 < _DAT_0020df98) {
    uVar1 = FUN_00140e74();
    *(undefined1 *)(param_1 + 0x75) = uVar1;
    return;
  }
  uVar1 = FUN_00140e74();
  *(undefined1 *)(param_1 + 0x75) = uVar1;
  return;
}


