// func FUN_00043410 @ 0x00043410 (size 0x23)

void FUN_00043410(void)

{
  int in_EDX;
  undefined4 local_44 [17];
  
  local_44[0] = 0xc;
  FUN_00043310(*(undefined4 *)(in_EDX + 0x248),local_44);
  return;
}


