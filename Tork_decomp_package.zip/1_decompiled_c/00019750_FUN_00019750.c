// func FUN_00019750 @ 0x00019750 (size 0x4D)

void FUN_00019750(void)

{
  byte bVar1;
  int in_EAX;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined8 uVar6;
  
  uVar6 = FUN_000551e0();
  iVar4 = (int)((ulonglong)uVar6 >> 0x20);
  iVar2 = (int)uVar6 + in_EAX;
  if (in_EAX < iVar2) {
    puVar5 = (undefined4 *)(&DAT_00002064 + in_EAX * 4 + iVar4);
    do {
      iVar3 = in_EAX >> 5;
      bVar1 = (byte)in_EAX;
      *puVar5 = 0;
      puVar5 = puVar5 + 1;
      in_EAX = in_EAX + 1;
      *(uint *)(&DAT_00002044 + iVar3 * 4 + iVar4) =
           *(uint *)(&DAT_00002044 + iVar3 * 4 + iVar4) & ~(1 << (bVar1 & 0x1f));
    } while (in_EAX < iVar2);
  }
  return;
}


