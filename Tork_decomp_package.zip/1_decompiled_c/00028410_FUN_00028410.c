// func FUN_00028410 @ 0x00028410 (size 0x34)

float10 FUN_00028410(void)

{
  float *in_EAX;
  float10 fVar1;
  
  fVar1 = (float10)in_EAX[1];
  if (fVar1 < (float10)*in_EAX) {
    fVar1 = (float10)*in_EAX;
  }
  if (fVar1 <= (float10)in_EAX[2]) {
    fVar1 = (float10)in_EAX[2];
  }
  return fVar1;
}


