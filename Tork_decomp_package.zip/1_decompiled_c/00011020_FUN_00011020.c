// func FUN_00011020 @ 0x00011020 (size 0x16)

undefined8 FUN_00011020(undefined4 *param_1)

{
  undefined8 uVar1;
  undefined4 in_EAX;
  undefined4 in_EDX;
  
  uVar1 = rdtsc();
  *param_1 = (int)uVar1;
  param_1[1] = (int)((ulonglong)uVar1 >> 0x20);
  return CONCAT44(in_EDX,in_EAX);
}


