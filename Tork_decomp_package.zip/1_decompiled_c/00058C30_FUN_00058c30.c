// func FUN_00058c30 @ 0x00058C30 (size 0x1D)

void FUN_00058c30(void)

{
  undefined4 *in_ECX;
  
  *in_ECX = 0;
  in_ECX[4] = in_ECX[4] & 0xff000000;
  in_ECX[1] = 0;
  in_ECX[2] = 0;
  in_ECX[3] = 0;
  *(undefined1 *)((int)in_ECX + 0x13) = 0;
  in_ECX[5] = 0;
  return;
}


