// func FUN_00028790 @ 0x00028790 (size 0x8E)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00028790(void)

{
  float10 fVar1;
  
  fVar1 = (float10)FUN_00021640();
  if ((uint)ABS((float)(fVar1 - (float10)_DAT_0020df98)) < 0x358637be) {
    fVar1 = (float10)FUN_00021640();
    if ((uint)ABS((float)(fVar1 - (float10)_DAT_0020df98)) < 0x358637be) {
      fVar1 = (float10)FUN_00021640();
      if ((uint)ABS((float)(fVar1 - (float10)_DAT_0020df98)) < 0x358637be) {
        return 0;
      }
    }
  }
  return 1;
}


