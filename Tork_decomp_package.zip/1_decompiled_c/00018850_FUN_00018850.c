// func FUN_00018850 @ 0x00018850 (size 0x5E)

void FUN_00018850(void)

{
  short sVar1;
  uint *in_EAX;
  uint uVar2;
  uint unaff_ESI;
  
  *(undefined2 *)(in_EAX + unaff_ESI * 4 + 4) = 0xffff;
  *(short *)(in_EAX[unaff_ESI * 4 + 2] + 6) = *(short *)(in_EAX[unaff_ESI * 4 + 2] + 6) + -1;
  sVar1 = *(short *)((int)in_EAX + unaff_ESI * 0x10 + 0x16);
  if ((short)in_EAX[unaff_ESI * 4 + 5] != sVar1) {
    in_EAX = (uint *)FUN_00018650((short)in_EAX[unaff_ESI * 4 + 5],sVar1 - 1U & 0x7ff);
  }
  if (unaff_ESI == *in_EAX) {
    do {
      uVar2 = *in_EAX + 1 & 0x1ff;
      *in_EAX = uVar2;
      if ((short)in_EAX[(uVar2 + 1) * 4] != -1) {
        return;
      }
    } while (uVar2 != in_EAX[1]);
  }
  return;
}


