// func FUN_00018420 @ 0x00018420 (size 0x82)

void FUN_00018420(uint param_1,undefined2 param_2,undefined2 param_3)

{
  uint *puVar1;
  uint *in_EDX;
  uint *extraout_EDX;
  uint unaff_ESI;
  
  if ((in_EDX[1] + 1 & 0x1ff) == *in_EDX) {
    FUN_000188b0();
    in_EDX = extraout_EDX;
  }
  puVar1 = in_EDX + in_EDX[1] * 4 + 2;
  puVar1[1] = param_1;
  *(undefined2 *)(puVar1 + 2) = param_2;
  *(undefined2 *)((int)puVar1 + 10) = param_3;
  *puVar1 = unaff_ESI;
  if ((char)in_EDX[0x1044] == '\0') {
    *(undefined2 *)(puVar1 + 3) = 0;
    *(undefined2 *)((int)puVar1 + 0xe) = 0;
  }
  else {
    *(short *)(puVar1 + 3) = (short)in_EDX[0x1045];
    *(short *)((int)puVar1 + 0xe) = (short)in_EDX[0x1046];
  }
  in_EDX[1] = in_EDX[1] + 1 & 0x1ff;
  *(undefined1 *)(in_EDX + 0x1044) = 0;
  *(short *)(unaff_ESI + 6) = *(short *)(unaff_ESI + 6) + 1;
  return;
}


