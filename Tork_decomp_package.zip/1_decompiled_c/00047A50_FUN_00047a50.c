// func FUN_00047a50 @ 0x00047A50 (size 0x23)

void FUN_00047a50(undefined4 param_1)

{
  undefined1 local_40 [64];
  
  FUN_000479c0();
  FUN_000286c0(param_1,local_40);
  return;
}


