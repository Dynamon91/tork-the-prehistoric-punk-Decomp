// func FUN_0001c200 @ 0x0001C200 (size 0xCA)

uint FUN_0001c200(short *param_1)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  int unaff_EBX;
  undefined4 *puVar7;
  
  bVar1 = *(byte *)(unaff_EBX + 1);
  uVar3 = 0;
  if (bVar1 != 0) {
    puVar7 = (undefined4 *)(unaff_EBX + 8);
    do {
      if ((short *)*puVar7 == param_1) {
        return uVar3;
      }
      uVar3 = uVar3 + 1;
      puVar7 = puVar7 + 1;
    } while ((int)uVar3 < (int)(uint)*(byte *)(unaff_EBX + 1));
  }
  if (bVar1 == 6) {
    return 0xff;
  }
  *(short **)(unaff_EBX + 8 + (uint)bVar1 * 4) = param_1;
  iVar2 = *(int *)(param_1 + 4);
  *(undefined4 *)(unaff_EBX + 0x20 + (uint)*(byte *)(unaff_EBX + 1) * 4) = 0;
  puVar7 = (undefined4 *)(unaff_EBX + 0x20 + (uint)*(byte *)(unaff_EBX + 1) * 4);
  if (*(int *)(unaff_EBX + 0x20 + (uint)*(byte *)(unaff_EBX + 1) * 4) == 0) {
    if (iVar2 < 1) goto LAB_0001c294;
    uVar5 = FUN_00057f60(iVar2);
  }
  else {
    if (iVar2 < 1) {
      FUN_00058010();
      *puVar7 = 0;
      goto LAB_0001c294;
    }
    iVar4 = FUN_000560f0();
    if (iVar2 == iVar4) goto LAB_0001c294;
    uVar5 = FUN_00058070();
  }
  *puVar7 = uVar5;
LAB_0001c294:
  uVar3 = *(uint *)(*(int *)(unaff_EBX + 8 + (uint)*(byte *)(unaff_EBX + 1) * 4) + 8);
  puVar7 = *(undefined4 **)(unaff_EBX + 0x20 + (uint)*(byte *)(unaff_EBX + 1) * 4);
  for (uVar6 = uVar3 >> 2; uVar6 != 0; uVar6 = uVar6 - 1) {
    *puVar7 = 0;
    puVar7 = puVar7 + 1;
  }
  for (uVar3 = uVar3 & 3; uVar3 != 0; uVar3 = uVar3 - 1) {
    *(undefined1 *)puVar7 = 0;
    puVar7 = (undefined4 *)((int)puVar7 + 1);
  }
  *param_1 = *param_1 + 1;
  bVar1 = *(byte *)(unaff_EBX + 1);
  *(byte *)(unaff_EBX + 1) = bVar1 + 1;
  return (uint)bVar1;
}


