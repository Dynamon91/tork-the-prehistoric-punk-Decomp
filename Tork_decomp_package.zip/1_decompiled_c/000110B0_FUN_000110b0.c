// func FUN_000110b0 @ 0x000110B0 (size 0x40)

int FUN_000110b0(void)

{
  ushort uVar1;
  int iVar2;
  ushort uVar3;
  int in_EAX;
  
  uVar1 = *(ushort *)(*(int *)(in_EAX + 4) + 10);
  uVar3 = 0;
  if (uVar1 != 0) {
    iVar2 = *(int *)(*(int *)(in_EAX + 4) + 4);
    while ((**(byte **)(iVar2 + (uint)uVar3 * 4) & 1) == 0) {
      uVar3 = uVar3 + 1;
      if (uVar1 <= uVar3) {
        return -1;
      }
    }
    iVar2 = *(int *)(iVar2 + (uint)uVar3 * 4);
    if (iVar2 != 0) {
      return (uint)*(ushort *)(iVar2 + 2) << 0x17;
    }
  }
  return -1;
}


