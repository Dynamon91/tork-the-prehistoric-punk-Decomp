// func FUN_0001dc90 @ 0x0001DC90 (size 0x80)

void FUN_0001dc90(void)

{
  int iVar1;
  uint uVar2;
  int in_ECX;
  int iVar3;
  
  iVar1 = *(int *)(in_ECX + 0x3c);
  *(uint **)(in_ECX + 0x3c) = (uint *)(iVar1 + 4);
  uVar2 = (uint)*(ushort *)(iVar1 + 2);
  if (uVar2 == 0x7fff) {
    uVar2 = *(uint *)(iVar1 + 4);
    *(int *)(in_ECX + 0x3c) = iVar1 + 8;
  }
  iVar3 = *(int *)(*(int *)(in_ECX + 0x30) + 0x20 + (uint)*(byte *)(in_ECX + 0x38) * 4) + uVar2;
  if ((&DAT_00002298)[in_ECX] != '\0') {
    if ((&DAT_00002299)[in_ECX] != 0) {
      iVar3 = iVar3 + (uint)*(ushort *)(&DAT_0000229a + in_ECX) *
                      (uint)(byte)(&DAT_00002299)[in_ECX];
    }
    (&DAT_00002298)[in_ECX] = 0;
  }
  if (*(char *)(iVar1 + 1) == '\x03') {
    FUN_0001d9d0();
    *(undefined4 *)(in_ECX + 0x30) = *(undefined4 *)(in_ECX + 0xc);
    return;
  }
  **(int **)(in_ECX + 8) = iVar3;
  *(int *)(in_ECX + 8) = *(int *)(in_ECX + 8) + 4;
  *(undefined4 *)(in_ECX + 0x30) = *(undefined4 *)(in_ECX + 0xc);
  return;
}


