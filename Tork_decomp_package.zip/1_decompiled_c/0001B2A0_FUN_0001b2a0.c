// func FUN_0001b2a0 @ 0x0001B2A0 (size 0x3C)

void FUN_0001b2a0(void)

{
  int in_ECX;
  int iVar1;
  int *piVar2;
  
  *(byte *)(in_ECX + 0x25) = *(byte *)(in_ECX + 0x25) & 0xbf;
  iVar1 = 0;
  if (0 < *(short *)(in_ECX + 0x26)) {
    piVar2 = (int *)(in_ECX + 0x28);
    do {
      if ((*piVar2 != 0) && ((*(ushort *)(*piVar2 + 0x24) >> 0xe & 1) != 0)) {
        FUN_0001b2a0();
      }
      iVar1 = iVar1 + 1;
      piVar2 = piVar2 + 1;
    } while (iVar1 < *(short *)(in_ECX + 0x26));
  }
  return;
}


