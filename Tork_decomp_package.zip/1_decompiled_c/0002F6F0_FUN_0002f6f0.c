// func FUN_0002f6f0 @ 0x0002F6F0 (size 0xCC)

undefined4
FUN_0002f6f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  byte bVar5;
  undefined1 local_e;
  byte local_d;
  int local_c [3];
  
  iVar1 = *(int *)(DAT_0022a6c4 + 0x14);
  FUN_0002c2e0();
  local_c[2] = FUN_0002c660(0x800);
  if (((*(uint *)(iVar1 + 4) >> 0xb & 1) == 0) || (local_c[2] == 0)) {
    return 0;
  }
  iVar2 = *(int *)(*(int *)(iVar1 + 0x24) + 0x10);
  bVar5 = *(byte *)(iVar2 + 3) >> 3;
  uVar3 = 0;
  if (bVar5 != 0) {
    do {
      local_c[0] = *(int *)(*(int *)(iVar2 + 8) + uVar3 * 4);
      local_d = (char)uVar3 + 1;
      uVar3 = (uint)local_d;
      if (local_c[0] != 0) goto LAB_0002f75e;
    } while (local_d < bVar5);
  }
  local_c[0] = 0;
  local_d = 0xff;
LAB_0002f75e:
  local_c[1] = 0;
  local_e = 0;
  uVar4 = FUN_0002d0f0(param_1,param_2,param_3,param_4,param_5,param_6,iVar1,local_c,&local_d,
                       local_c + 2,local_c + 1,&local_e);
  return uVar4;
}


