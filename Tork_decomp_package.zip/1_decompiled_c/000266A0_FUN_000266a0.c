// func FUN_000266a0 @ 0x000266A0 (size 0x12E)

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_000266a0(float param_1,float param_2,undefined4 param_3,undefined4 param_4)

{
  float fVar1;
  undefined8 uVar2;
  int iVar3;
  int in_EAX;
  byte *pbVar4;
  float *pfVar5;
  uint uVar6;
  float *local_30;
  
  uVar6 = *(uint *)(in_EAX + 4);
  if ((uVar6 >> 0xd & 1) == 0) {
    if ((uVar6 & 0x10000008) != 0) {
      FUN_000e0d80(param_1,param_2,param_4);
      return;
    }
  }
  else {
    if ((uVar6 & 2) == 0) {
      local_30 = *(float **)(in_EAX + 0x10);
    }
    else {
      local_30 = (float *)(*(int *)(in_EAX + 0x10) + 0x30);
    }
    fVar1 = *local_30;
    uVar2 = *(undefined8 *)(local_30 + 1);
    pbVar4 = *(byte **)(*(int *)(in_EAX + 0x24) + 0x2c);
    uVar6 = 0;
    if (*pbVar4 != 0) {
      do {
        iVar3 = *(int *)(*(int *)(pbVar4 + 4) + (uVar6 & 0xff) * 4);
        pfVar5 = *(float **)(iVar3 + 0x10);
        if ((*(byte *)(iVar3 + 4) & 2) != 0) {
          pfVar5 = pfVar5 + 0xc;
        }
        if ((*(uint *)(in_EAX + 4) & 0x10000008) != 0) {
          FUN_000e0d80((param_1 - fVar1) + *pfVar5,
                       (param_2 - (float)((ulonglong)uVar2 >> 0x20)) + pfVar5[2],param_4);
        }
        pbVar4 = *(byte **)(*(int *)(in_EAX + 0x24) + 0x2c);
        uVar6 = uVar6 + 1;
      } while ((int)uVar6 < (int)(uint)*pbVar4);
    }
  }
  return;
}


