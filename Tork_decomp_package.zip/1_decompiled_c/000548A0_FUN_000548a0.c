// func FUN_000548a0 @ 0x000548A0 (size 0x1D)

ushort * FUN_000548a0(void)

{
  ushort uVar1;
  ushort *in_ECX;
  
  if (*in_ECX == 0) {
    return (ushort *)0xffffffff;
  }
  uVar1 = *in_ECX - 1;
  *in_ECX = uVar1;
  return in_ECX + (uint)uVar1 * 6 + 3;
}


