// func FUN_000465c0 @ 0x000465C0 (size 0x68)

void FUN_000465c0(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int *unaff_EDI;
  
  uVar2 = unaff_EDI[1];
  if (unaff_EDI[3] == uVar2) {
    if (uVar2 == 0) {
      uVar3 = 0x100;
    }
    else {
      uVar3 = FUN_00140e74();
    }
    if (uVar2 < uVar3) {
      iVar4 = FUN_00058070();
      *unaff_EDI = iVar4;
      unaff_EDI[1] = uVar3;
    }
  }
  puVar1 = (undefined4 *)(*unaff_EDI + unaff_EDI[3] * 8);
  unaff_EDI[3] = unaff_EDI[3] + 1;
  *puVar1 = param_1;
  puVar1[1] = param_2;
  return;
}


