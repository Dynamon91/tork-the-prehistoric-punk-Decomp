// func FUN_0005ac10 @ 0x0005AC10 (size 0x5D)

int FUN_0005ac10(void)

{
  ushort uVar1;
  int iVar2;
  int in_EAX;
  ushort uVar3;
  int unaff_EBX;
  ushort uVar4;
  
  uVar4 = 0;
  if (*(ushort *)(in_EAX + 10) != 0) {
    do {
      iVar2 = *(int *)(*(int *)(in_EAX + 4) + (uint)uVar4 * 4);
      uVar1 = *(ushort *)(iVar2 + 10);
      uVar3 = 0;
      if (uVar1 != 0) {
        iVar2 = *(int *)(iVar2 + 4);
        do {
          if (*(int *)(iVar2 + 4 + (uint)uVar3 * 0xc) == unaff_EBX) {
            iVar2 = *(int *)(iVar2 + (uint)uVar3 * 0xc);
            if (iVar2 != -1) {
              return iVar2;
            }
            break;
          }
          uVar3 = uVar3 + 1;
        } while (uVar3 < uVar1);
      }
      uVar4 = uVar4 + 1;
    } while (uVar4 < *(ushort *)(in_EAX + 10));
  }
  return -1;
}


