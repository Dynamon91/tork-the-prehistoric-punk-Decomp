// func FUN_000284f0 @ 0x000284F0 (size 0x45)

void FUN_000284f0(void)

{
  undefined4 *in_EAX;
  undefined4 *in_ECX;
  
  *in_ECX = *in_EAX;
  in_ECX[1] = in_EAX[1];
  in_ECX[2] = in_EAX[2];
  in_ECX[4] = in_EAX[4];
  in_ECX[5] = in_EAX[5];
  in_ECX[6] = in_EAX[6];
  in_ECX[8] = in_EAX[8];
  in_ECX[9] = in_EAX[9];
  in_ECX[10] = in_EAX[10];
  return;
}


