// func FUN_000549c0 @ 0x000549C0 (size 0x1A)

ushort * FUN_000549c0(void)

{
  ushort uVar1;
  ushort *in_ECX;
  
  if (*in_ECX == 0) {
    return (ushort *)0xffffffff;
  }
  uVar1 = *in_ECX - 1;
  *in_ECX = uVar1;
  return in_ECX + (uint)uVar1 * 2 + 3;
}


