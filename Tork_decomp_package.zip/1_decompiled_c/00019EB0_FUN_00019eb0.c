// func FUN_00019eb0 @ 0x00019EB0 (size 0x125)

void FUN_00019eb0(undefined4 *param_1,undefined4 *param_2)

{
  int in_EAX;
  undefined4 *in_ECX;
  undefined4 *in_EDX;
  
  if (param_2 != (undefined4 *)0x0) {
    *(undefined1 *)(in_EAX + 0x203) = 4;
    *(undefined4 *)(in_EAX + 0x24c) = *in_ECX;
    *(undefined4 *)(in_EAX + 0x250) = in_ECX[1];
    *(undefined4 *)(in_EAX + 0x254) = in_ECX[2];
    *(undefined4 *)(in_EAX + 600) = *in_EDX;
    *(undefined4 *)(in_EAX + 0x25c) = in_EDX[1];
    *(undefined4 *)(in_EAX + 0x260) = in_EDX[2];
    *(undefined4 *)(in_EAX + 0x264) = *param_1;
    *(undefined4 *)(in_EAX + 0x268) = param_1[1];
    *(undefined4 *)(in_EAX + 0x26c) = param_1[2];
    *(undefined4 *)(in_EAX + 0x270) = *param_2;
    *(undefined4 *)(in_EAX + 0x274) = param_2[1];
    *(undefined4 *)(in_EAX + 0x278) = param_2[2];
    return;
  }
  if (param_1 != (undefined4 *)0x0) {
    *(undefined1 *)(in_EAX + 0x203) = 3;
    *(undefined4 *)(in_EAX + 0x24c) = *in_ECX;
    *(undefined4 *)(in_EAX + 0x250) = in_ECX[1];
    *(undefined4 *)(in_EAX + 0x254) = in_ECX[2];
    *(undefined4 *)(in_EAX + 600) = *in_EDX;
    *(undefined4 *)(in_EAX + 0x25c) = in_EDX[1];
    *(undefined4 *)(in_EAX + 0x260) = in_EDX[2];
    *(undefined4 *)(in_EAX + 0x264) = *param_1;
    *(undefined4 *)(in_EAX + 0x268) = param_1[1];
    *(undefined4 *)(in_EAX + 0x26c) = param_1[2];
    return;
  }
  if (in_EDX == (undefined4 *)0x0) {
    *(undefined1 *)(in_EAX + 0x203) = 1;
    *(undefined4 *)(in_EAX + 0x24c) = *in_ECX;
    *(undefined4 *)(in_EAX + 0x250) = in_ECX[1];
    *(undefined4 *)(in_EAX + 0x254) = in_ECX[2];
    return;
  }
  *(undefined1 *)(in_EAX + 0x203) = 2;
  *(undefined4 *)(in_EAX + 0x24c) = *in_ECX;
  *(undefined4 *)(in_EAX + 0x250) = in_ECX[1];
  *(undefined4 *)(in_EAX + 0x254) = in_ECX[2];
  *(undefined4 *)(in_EAX + 600) = *in_EDX;
  *(undefined4 *)(in_EAX + 0x25c) = in_EDX[1];
  *(undefined4 *)(in_EAX + 0x260) = in_EDX[2];
  return;
}


