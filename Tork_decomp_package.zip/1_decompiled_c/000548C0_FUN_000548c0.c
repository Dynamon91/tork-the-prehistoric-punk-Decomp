// func FUN_000548c0 @ 0x000548C0 (size 0x30)

undefined4 FUN_000548c0(void)

{
  ushort *puVar1;
  ushort *in_EAX;
  undefined4 *in_EDX;
  
  if ((int)(uint)*in_EAX < (int)(in_EAX[1] - 1)) {
    puVar1 = in_EAX + (uint)*in_EAX * 6 + 3;
    *(undefined4 *)puVar1 = *in_EDX;
    *(undefined4 *)(puVar1 + 2) = in_EDX[1];
    *(undefined4 *)(puVar1 + 4) = in_EDX[2];
    *in_EAX = *in_EAX + 1;
    return 0;
  }
  return 0xffffffff;
}


