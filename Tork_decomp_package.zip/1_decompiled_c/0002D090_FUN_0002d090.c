// func FUN_0002d090 @ 0x0002D090 (size 0x56)

void FUN_0002d090(void)

{
  int in_EAX;
  float *in_ECX;
  float *in_EDX;
  
  *in_EDX = (float)*(byte *)(in_EAX + 9);
  in_EDX[1] = (float)*(byte *)(in_EAX + 10);
  in_EDX[2] = (float)*(byte *)(in_EAX + 0xb);
  *in_ECX = (float)*(byte *)(in_EAX + 0xc);
  in_ECX[1] = (float)*(byte *)(in_EAX + 0xd);
  in_ECX[2] = (float)*(byte *)(in_EAX + 0xe);
  return;
}


