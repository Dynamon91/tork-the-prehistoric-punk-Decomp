// func FUN_0004adb0 @ 0x0004ADB0 (size 0xC1)

char * FUN_0004adb0(char *param_1,uint param_2)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  int iVar4;
  char *__format;
  uint uVar5;
  bool bVar6;
  
  iVar2 = DAT_002411d8;
  pcVar3 = param_1;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  uVar5 = (int)pcVar3 - (int)(param_1 + 1);
  if ((int)pcVar3 - (int)(param_1 + 1) <= (int)param_2) {
    uVar5 = param_2;
  }
  iVar4 = FUN_000550f0((int)(uVar5 + 0x20 + ((int)(uVar5 + 0x20) >> 0x1f & 0x1fU)) >> 5);
  *(undefined4 *)(&DAT_00002064 + iVar4 * 4 + iVar2) = 0;
  pcVar3 = (char *)(iVar4 * 0x20 + 0x44 + iVar2);
  __format = &DAT_0020824c;
  if ((int)param_2 < 0) {
    __format = &DAT_00208248;
  }
  _sprintf(pcVar3,__format,(param_2 ^ (int)param_2 >> 0x1f) - ((int)param_2 >> 0x1f),param_1);
  if (((char *)(DAT_002411d8 + 0x44) <= param_1) && (param_1 < &DAT_00002044 + DAT_002411d8)) {
    param_1 = param_1 + (-0x44 - DAT_002411d8);
    uVar5 = (uint)param_1 & 0x8000001f;
    bVar6 = uVar5 == 0;
    if ((int)uVar5 < 0) {
      bVar6 = (uVar5 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar6) && ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5 != -1)) &&
       (*(int *)(&DAT_00002064 +
                ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5) * 4 + DAT_002411d8) == 0)) {
      FUN_00019750();
    }
  }
  return pcVar3;
}


