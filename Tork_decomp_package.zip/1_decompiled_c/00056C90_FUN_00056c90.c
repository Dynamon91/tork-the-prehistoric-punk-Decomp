// func FUN_00056c90 @ 0x00056C90 (size 0x154)

void FUN_00056c90(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 *in_EAX;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  
  if (in_EAX != (undefined4 *)0x0) {
    piVar5 = in_EAX + -2;
    uVar6 = in_EAX[-1] & 0x7ffffffc;
    if (uVar6 <= DAT_0022a740) {
      DAT_0022a740 = DAT_0022a740 | 3;
      *in_EAX = (&DAT_0022a73c)[uVar6 >> 3];
      (&DAT_0022a73c)[uVar6 >> 3] = piVar5;
      return;
    }
    if ((in_EAX[-1] & 2) == 0) {
      DAT_0022a740 = DAT_0022a740 | 1;
      piVar1 = (int *)(uVar6 + (int)piVar5);
      uVar7 = *(uint *)(uVar6 + 4 + (int)piVar5) & 0x7ffffffc;
      if ((*(byte *)(in_EAX + -1) & 1) == 0) {
        uVar6 = uVar6 + *piVar5;
        piVar5 = (int *)((int)piVar5 - *piVar5);
        iVar2 = piVar5[2];
        iVar3 = piVar5[3];
        *(int *)(iVar2 + 0xc) = iVar3;
        *(int *)(iVar3 + 8) = iVar2;
      }
      if (piVar1 == DAT_0022a76c) {
        uVar6 = uVar6 + uVar7;
        piVar5[1] = uVar6 | 1;
        DAT_0022a76c = piVar5;
      }
      else {
        uVar4 = *(uint *)(uVar7 + 4 + (int)piVar1);
        piVar1[1] = uVar7;
        if ((uVar4 & 1) == 0) {
          iVar2 = piVar1[2];
          iVar3 = piVar1[3];
          *(int *)(iVar2 + 0xc) = iVar3;
          *(int *)(iVar3 + 8) = iVar2;
          uVar6 = uVar6 + uVar7;
        }
        piVar5[2] = (int)DAT_0022a77c;
        piVar5[3] = (int)&DAT_0022a774;
        piVar1 = DAT_0022a77c + 3;
        DAT_0022a77c = piVar5;
        *piVar1 = (int)piVar5;
        piVar5[1] = uVar6 | 1;
        *(uint *)(uVar6 + (int)piVar5) = uVar6;
      }
      if (0xffff < uVar6) {
        if ((DAT_0022a740 & 2) != 0) {
          FUN_00056df0(&DAT_0022a740);
        }
        if (DAT_0022aa84 <= (DAT_0022a76c[1] & 0x7ffffffcU)) {
          FUN_00056830(DAT_0022aa88);
          return;
        }
      }
    }
    else {
      DAT_0022aaa4 = DAT_0022aaa4 - (uVar6 + *piVar5);
      DAT_0022aa90 = DAT_0022aa90 + -1;
      FUN_00057e90((int)piVar5 - *piVar5);
    }
  }
  return;
}


