// func FUN_00054910 @ 0x00054910 (size 0x19)

ushort * FUN_00054910(void)

{
  ushort uVar1;
  ushort *in_EDX;
  
  uVar1 = *in_EDX - 1;
  if (uVar1 < *in_EDX) {
    return in_EDX + (uint)uVar1 * 2 + 3;
  }
  return (ushort *)0xffffffff;
}


