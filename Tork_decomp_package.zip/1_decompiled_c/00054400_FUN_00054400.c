// func FUN_00054400 @ 0x00054400 (size 0x19)

int FUN_00054400(void)

{
  ushort uVar1;
  ushort *in_EDX;
  
  uVar1 = *in_EDX - 1;
  if (uVar1 < *in_EDX) {
    return uVar1 + 6 + (int)in_EDX;
  }
  return -1;
}


