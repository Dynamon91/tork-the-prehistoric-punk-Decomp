// func FUN_00045660 @ 0x00045660 (size 0x2C)

int FUN_00045660(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *in_EDX;
  int unaff_ESI;
  
  piVar1 = (int *)*in_EDX;
  piVar3 = piVar1;
  do {
    if (piVar1 + in_EDX[3] <= piVar3) {
      return -1;
    }
    iVar2 = *piVar3;
    piVar3 = piVar3 + 1;
  } while (iVar2 != unaff_ESI);
  return (int)piVar3 + (-4 - (int)piVar1) >> 2;
}


