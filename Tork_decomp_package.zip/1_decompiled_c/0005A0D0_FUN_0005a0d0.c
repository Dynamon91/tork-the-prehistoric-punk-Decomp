// func FUN_0005a0d0 @ 0x0005A0D0 (size 0x36)

void FUN_0005a0d0(undefined4 *param_1)

{
  int in_ECX;
  undefined4 local_20;
  undefined4 local_1c;
  undefined1 local_18 [8];
  undefined1 local_10 [8];
  undefined1 local_8 [8];
  
  FUN_0012c3c3(*(undefined4 *)(in_ECX + 0x20),local_8,local_10,&local_20,local_18);
  *param_1 = local_20;
  param_1[1] = local_1c;
  return;
}


