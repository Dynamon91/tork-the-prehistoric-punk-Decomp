// func FUN_0001d790 @ 0x0001D790 (size 0x20)

void FUN_0001d790(void)

{
  int in_EAX;
  undefined4 *in_ECX;
  
  **(undefined4 **)(in_EAX + 8) = *in_ECX;
  *(undefined4 *)(*(int *)(in_EAX + 8) + 4) = in_ECX[1];
  *(undefined4 *)(*(int *)(in_EAX + 8) + 8) = in_ECX[2];
  *(int *)(in_EAX + 8) = *(int *)(in_EAX + 8) + 0xc;
  return;
}


