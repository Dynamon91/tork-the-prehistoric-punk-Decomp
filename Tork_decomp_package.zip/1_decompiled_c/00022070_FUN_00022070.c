// func FUN_00022070 @ 0x00022070 (size 0x20)

bool FUN_00022070(uint param_1,uint param_2)

{
  return (param_1 & 0x7fffffff) < param_2;
}


