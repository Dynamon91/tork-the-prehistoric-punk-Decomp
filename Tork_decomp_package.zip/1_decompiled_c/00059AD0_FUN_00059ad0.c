// func FUN_00059ad0 @ 0x00059AD0 (size 0x29)

void FUN_00059ad0(void)

{
  undefined4 *in_EAX;
  
  if (((undefined4 *)((int)&DAT_0022aabc + 3) < in_EAX) && (in_EAX < &DAT_0022d2c0)) {
    *in_EAX = DAT_0022aabc;
    DAT_0022aabc = in_EAX;
    return;
  }
  FUN_00058010();
  return;
}


