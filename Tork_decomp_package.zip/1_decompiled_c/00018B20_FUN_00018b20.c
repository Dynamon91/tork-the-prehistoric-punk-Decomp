// func FUN_00018b20 @ 0x00018B20 (size 0x57)

void FUN_00018b20(void)

{
  uint uVar1;
  int in_EDX;
  int extraout_EDX;
  uint *puVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  if ((&DAT_00002464)[in_EDX] != '\0') {
    iVar5 = 0;
    puVar2 = (uint *)(&DAT_00002044 + in_EDX);
    do {
      uVar1 = *puVar2;
      if (uVar1 != 0) {
        uVar3 = 1;
        iVar4 = 0;
        do {
          if ((uVar1 & uVar3) != 0) {
            FUN_00019750();
            uVar1 = *puVar2;
            in_EDX = extraout_EDX;
            if (uVar1 == 0) break;
          }
          iVar4 = iVar4 + 1;
          uVar3 = uVar3 << 1;
        } while (iVar4 < 0x20);
      }
      iVar5 = iVar5 + 0x20;
      puVar2 = puVar2 + 1;
    } while (iVar5 < 0x100);
    (&DAT_00002464)[in_EDX] = 0;
  }
  return;
}


