// func FUN_000249e0 @ 0x000249E0 (size 0x3A)

float10 FUN_000249e0(void)

{
  float *in_ECX;
  float fVar1;
  float fVar2;
  
  fVar1 = (float)*(undefined8 *)(in_ECX + 1);
  fVar2 = (float)((ulonglong)*(undefined8 *)(in_ECX + 1) >> 0x20);
  return (float10)SQRT(*in_ECX * *in_ECX + fVar1 * fVar1 + fVar2 * fVar2);
}


