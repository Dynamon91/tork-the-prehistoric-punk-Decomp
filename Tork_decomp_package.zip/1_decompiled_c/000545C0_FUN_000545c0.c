// func FUN_000545c0 @ 0x000545C0 (size 0x26)

undefined4 FUN_000545c0(ushort *param_1)

{
  ushort *in_EAX;
  
  if ((int)(uint)*in_EAX < (int)(in_EAX[1] - 1)) {
    in_EAX[*in_EAX + 3] = *param_1;
    *in_EAX = *in_EAX + 1;
    return 0;
  }
  return 0xffffffff;
}


