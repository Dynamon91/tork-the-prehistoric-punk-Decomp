// func FUN_000475e0 @ 0x000475E0 (size 0xE7)

void FUN_000475e0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  short *psVar5;
  ushort uVar6;
  ushort uVar7;
  byte bVar8;
  uint uVar9;
  byte local_9;
  
  iVar2 = *(int *)(*(int *)(DAT_0022a6c4 + 0x14) + 0x14);
  uVar7 = 0;
  while( true ) {
    uVar6 = *(ushort *)(*(int *)(iVar2 + 4) + 0xe);
    if (uVar6 == 0) {
      uVar6 = 1;
    }
    if (uVar6 <= uVar7) break;
    local_9 = 0;
    uVar9 = 0;
    while ((iVar3 = *(int *)(iVar2 + 4), iVar3 != 0 && ((byte)uVar9 < *(byte *)(iVar3 + 2)))) {
      uVar6 = uVar7;
      if (*(ushort *)(iVar3 + 0xe) <= uVar7) {
        uVar6 = 0;
      }
      iVar3 = *(int *)(iVar3 + 0x10 + ((uint)*(byte *)(iVar3 + 2) * (uint)uVar6 + uVar9) * 4);
      if (*(char *)(iVar3 + 2) != '\0') {
        uVar9 = 0;
        do {
          if (*(int *)(iVar3 + (uVar9 * 3 + 9) * 8) == param_1) {
            iVar4 = *(int *)(iVar3 + 0x4c + uVar9 * 0x18);
            iVar1 = iVar3 + 0x38 + uVar9 * 0x18;
            if (*(int *)(iVar1 + 0x10) != iVar4) {
              if (iVar4 != 0) {
                FUN_000bd0f0();
              }
              psVar5 = *(short **)(iVar1 + 0x10);
              *(short **)(iVar1 + 0x14) = psVar5;
              if (psVar5 != (short *)0x0) {
                *psVar5 = *psVar5 + 1;
              }
            }
          }
          bVar8 = (char)uVar9 + 1;
          uVar9 = (uint)bVar8;
        } while (bVar8 < *(byte *)(iVar3 + 2));
      }
      local_9 = local_9 + 1;
      uVar9 = (uint)local_9;
    }
    uVar7 = uVar7 + 1;
  }
  return;
}


