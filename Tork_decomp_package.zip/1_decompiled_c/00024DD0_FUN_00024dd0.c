// func FUN_00024dd0 @ 0x00024DD0 (size 0x1A)

void FUN_00024dd0(void)

{
  FUN_000dfc60();
  return;
}


