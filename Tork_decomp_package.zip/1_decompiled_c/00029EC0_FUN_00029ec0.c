// func FUN_00029ec0 @ 0x00029EC0 (size 0x19)

void FUN_00029ec0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_000e0f10(param_2,param_3,param_4);
  return;
}


