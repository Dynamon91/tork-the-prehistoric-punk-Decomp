// func FUN_00018110 @ 0x00018110 (size 0x5F)

char FUN_00018110(void)

{
  int iVar1;
  short sVar2;
  char cVar3;
  undefined4 uVar4;
  int unaff_ESI;
  
  sVar2 = *(short *)(*(int *)(unaff_ESI + 0xc) + 0x6e + (uint)*(byte *)(unaff_ESI + 0x18) * 8);
  iVar1 = *(int *)(unaff_ESI + 0xc) + 0x6a + (uint)*(byte *)(unaff_ESI + 0x18) * 8;
  if (sVar2 == -1) {
    return '\x01';
  }
  uVar4 = FUN_0001c170();
  cVar3 = (**(code **)(&DAT_00002098 + sVar2 * 4 + unaff_ESI))(0,uVar4);
  if (cVar3 != '\0') {
    *(undefined2 *)(iVar1 + 4) = 0xffff;
    *(uint *)(unaff_ESI + 0x3c) = *(int *)(unaff_ESI + 0x24) + (uint)*(ushort *)(iVar1 + 6) * 4;
    *(undefined1 *)(*(int *)(unaff_ESI + 0xc) + 0x6d + (uint)*(byte *)(unaff_ESI + 0x18) * 8) = 0xff
    ;
  }
  return cVar3;
}


