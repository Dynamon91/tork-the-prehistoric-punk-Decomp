// func FUN_000184b0 @ 0x000184B0 (size 0x75)

void FUN_000184b0(void)

{
  int in_EAX;
  uint uVar1;
  undefined4 *in_EDX;
  int iVar2;
  
  if ((&DAT_00004110)[in_EAX] == '\0') {
    *(undefined4 *)(&DAT_00004118 + in_EAX) = *(undefined4 *)(&DAT_0000200c + in_EAX);
    *(undefined4 *)(&DAT_00004114 + in_EAX) = *(undefined4 *)(&DAT_0000200c + in_EAX);
    (&DAT_00004110)[in_EAX] = 1;
  }
  *(undefined4 *)(&DAT_00002010 + *(int *)(&DAT_00004118 + in_EAX) * 4 + in_EAX) = *in_EDX;
  iVar2 = *(int *)(&DAT_00004118 + in_EAX) >> 5;
  *(uint *)(&DAT_00004010 + iVar2 * 4 + in_EAX) =
       *(uint *)(&DAT_00004010 + iVar2 * 4 + in_EAX) |
       1 << ((byte)*(int *)(&DAT_00004118 + in_EAX) & 0x1f);
  uVar1 = *(int *)(&DAT_00004118 + in_EAX) + 1U & 0x7ff;
  *(uint *)(&DAT_0000200c + in_EAX) = uVar1;
  *(uint *)(&DAT_00004118 + in_EAX) = uVar1;
  return;
}


