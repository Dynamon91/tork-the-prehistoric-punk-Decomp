// func FUN_00024540 @ 0x00024540 (size 0x37)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00024540(float param_1)

{
  if (_DAT_0020df5c < param_1) {
    return (float10)_DAT_0020df98;
  }
  if (param_1 < _DAT_0020df5c) {
    return (float10)_DAT_0020e010;
  }
  return (float10)_DAT_0020df5c;
}


