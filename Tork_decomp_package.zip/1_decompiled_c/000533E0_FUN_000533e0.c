// func FUN_000533e0 @ 0x000533E0 (size 0x18E)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_000533e0(ushort *param_1,ushort param_2,code *param_3)

{
  float *pfVar1;
  float *pfVar2;
  float *pfVar3;
  ushort uVar4;
  ushort uVar5;
  int iVar6;
  ushort *puVar7;
  ushort uVar8;
  ushort *puVar9;
  int unaff_EDI;
  uint local_20;
  uint local_1c;
  
  if (param_2 != 0) {
    local_1c = (uint)param_2;
    uVar5 = 1;
    puVar7 = param_1;
    do {
      if (uVar5 < param_2) {
        local_20 = (uint)(ushort)(param_2 - uVar5);
        puVar9 = param_1 + uVar5;
        do {
          iVar6 = (*param_3)(unaff_EDI + (uint)*puVar7 * 0xc,unaff_EDI + (uint)*puVar9 * 0xc);
          if (iVar6 != 0) {
            uVar8 = *puVar7;
            *puVar7 = *puVar9;
            *puVar9 = uVar8;
          }
          puVar9 = puVar9 + 1;
          local_20 = local_20 - 1;
        } while (local_20 != 0);
      }
      uVar5 = uVar5 + 1;
      puVar7 = puVar7 + 1;
      local_1c = local_1c - 1;
    } while (local_1c != 0);
  }
  uVar8 = 2;
  uVar5 = 1;
  if (2 < param_2) {
    puVar7 = param_1 + 2;
    do {
      if (uVar5 != 0) {
        pfVar1 = (float *)(unaff_EDI + (uint)*puVar7 * 0xc);
        do {
          pfVar2 = (float *)(unaff_EDI + (uint)param_1[uVar5] * 0xc);
          pfVar3 = (float *)(unaff_EDI + (uint)(param_1 + uVar5)[-1] * 0xc);
          if (_DAT_0020df5c <
              (pfVar3[1] - pfVar2[1]) * (*pfVar1 - *pfVar2) -
              (pfVar1[1] - pfVar2[1]) * (*pfVar3 - *pfVar2)) break;
          uVar5 = uVar5 - 1;
        } while (uVar5 != 0);
      }
      uVar5 = uVar5 + 1;
      if (uVar5 != uVar8) {
        uVar4 = *puVar7;
        *puVar7 = param_1[uVar5];
        param_1[uVar5] = uVar4;
      }
      uVar8 = uVar8 + 1;
      puVar7 = puVar7 + 1;
    } while (uVar8 < param_2);
  }
  return;
}


