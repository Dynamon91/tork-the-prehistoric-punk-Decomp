// func FUN_00024580 @ 0x00024580 (size 0x19)

float10 FUN_00024580(float param_1,float param_2)

{
  if (param_2 < param_1) {
    return (float10)param_1;
  }
  return (float10)param_2;
}


