// func FUN_00059ab0 @ 0x00059AB0 (size 0x1D)

void FUN_00059ab0(void)

{
  if (DAT_0022aabc == (undefined4 *)0x0) {
    FUN_00057f60(0x14);
    return;
  }
  DAT_0022aabc = (undefined4 *)*DAT_0022aabc;
  return;
}


