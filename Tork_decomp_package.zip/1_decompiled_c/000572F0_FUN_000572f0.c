// func FUN_000572f0 @ 0x000572F0 (size 0x1B9)

undefined4 * FUN_000572f0(int param_1,int *param_2,byte param_3)

{
  undefined4 uVar1;
  undefined4 *in_EAX;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  uint local_c;
  uint local_8;
  undefined4 *local_4;
  
  if (DAT_0022a740 == 0) {
    FUN_00056df0(&DAT_0022a740);
  }
  uVar1 = DAT_0022aa94;
  if (in_EAX == (undefined4 *)0x0) {
    if (param_1 == 0) {
      puVar2 = (undefined4 *)FUN_000568c0(0);
      return puVar2;
    }
    local_c = param_1 * 4 + 0xb;
    local_4 = (undefined4 *)0x0;
    if (local_c < 0x10) {
      local_c = 0x10;
    }
    else {
      local_c = local_c & 0xfffffff8;
    }
  }
  else {
    if (param_1 == 0) {
      return in_EAX;
    }
    local_c = 0;
    local_4 = in_EAX;
  }
  if ((param_3 & 1) == 0) {
    uVar6 = 0;
    local_8 = 0;
    iVar4 = 0;
    do {
      if (param_2[iVar4] + 0xbU < 0x10) {
        uVar7 = 0x10;
      }
      else {
        uVar7 = param_2[iVar4] + 0xbU & 0xfffffff8;
      }
      uVar6 = uVar6 + uVar7;
      iVar4 = iVar4 + 1;
    } while (iVar4 != param_1);
  }
  else if (*param_2 + 0xbU < 0x10) {
    local_8 = 0x10;
    uVar6 = param_1 * 0x10;
  }
  else {
    local_8 = *param_2 + 0xbU & 0xfffffff8;
    uVar6 = local_8 * param_1;
  }
  DAT_0022aa94 = 0;
  puVar2 = (undefined4 *)FUN_000568c0((local_c - 7) + uVar6);
  DAT_0022aa94 = uVar1;
  if (puVar2 == (undefined4 *)0x0) {
    return (undefined4 *)0x0;
  }
  puVar5 = puVar2 + -2;
  uVar7 = puVar2[-1] & 0x7ffffffc;
  if ((param_3 & 2) != 0) {
    puVar8 = puVar2;
    for (uVar3 = (uVar7 - local_c) - 4 >> 2; uVar3 != 0; uVar3 = uVar3 - 1) {
      *puVar8 = 0;
      puVar8 = puVar8 + 1;
    }
    for (iVar4 = 0; iVar4 != 0; iVar4 = iVar4 + -1) {
      *(undefined1 *)puVar8 = 0;
      puVar8 = (undefined4 *)((int)puVar8 + 1);
    }
  }
  if (local_4 == (undefined4 *)0x0) {
    local_4 = (undefined4 *)((int)puVar2 + uVar6);
    *(uint *)((int)puVar2 + (uVar6 - 4)) = uVar7 - uVar6 | 1;
    uVar7 = uVar6;
  }
  *local_4 = puVar2;
  param_1 = param_1 + -1;
  if (param_1 != 0) {
    iVar4 = (int)local_4 - (int)param_2;
    do {
      uVar6 = local_8;
      if (local_8 == 0) {
        if (*param_2 + 0xbU < 0x10) {
          uVar6 = 0x10;
        }
        else {
          uVar6 = *param_2 + 0xbU & 0xfffffff8;
        }
      }
      puVar5[1] = uVar6 | 1;
      puVar5 = (undefined4 *)((int)puVar5 + uVar6);
      uVar7 = uVar7 - uVar6;
      param_2 = param_2 + 1;
      param_1 = param_1 + -1;
      *(undefined4 **)(iVar4 + (int)param_2) = puVar5 + 2;
    } while (param_1 != 0);
  }
  puVar5[1] = uVar7 | 1;
  return local_4;
}


