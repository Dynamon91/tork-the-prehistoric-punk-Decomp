// func FUN_00019d40 @ 0x00019D40 (size 0x163)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00019d40(undefined4 param_1,float param_2,float param_3,float param_4,float param_5,
                 float param_6)

{
  bool bVar1;
  int in_ECX;
  
  if (param_6 != _DAT_0020df5c) {
    *(undefined4 *)(in_ECX + 0x21c) = param_1;
    *(float *)(in_ECX + 0x220) = param_2;
    *(float *)(in_ECX + 0x224) = param_3;
    *(float *)(in_ECX + 0x228) = param_4;
    *(undefined1 *)(in_ECX + 0x201) = 6;
    *(float *)(in_ECX + 0x22c) = param_5;
    *(float *)(in_ECX + 0x230) = param_6;
    return;
  }
  if (param_5 != _DAT_0020df5c) {
    *(undefined4 *)(in_ECX + 0x21c) = param_1;
    *(float *)(in_ECX + 0x220) = param_2;
    *(float *)(in_ECX + 0x224) = param_3;
    *(undefined1 *)(in_ECX + 0x201) = 5;
    *(float *)(in_ECX + 0x228) = param_4;
    *(float *)(in_ECX + 0x22c) = param_5;
    return;
  }
  if (param_4 != _DAT_0020df5c) {
    *(undefined4 *)(in_ECX + 0x21c) = param_1;
    *(float *)(in_ECX + 0x220) = param_2;
    *(undefined1 *)(in_ECX + 0x201) = 4;
    *(float *)(in_ECX + 0x224) = param_3;
    *(float *)(in_ECX + 0x228) = param_4;
    return;
  }
  if (param_3 != _DAT_0020df5c) {
    *(undefined4 *)(in_ECX + 0x21c) = param_1;
    *(undefined1 *)(in_ECX + 0x201) = 3;
    *(float *)(in_ECX + 0x220) = param_2;
    *(float *)(in_ECX + 0x224) = param_3;
    return;
  }
  bVar1 = param_2 == _DAT_0020df5c;
  *(undefined4 *)(in_ECX + 0x21c) = param_1;
  if (bVar1) {
    *(undefined1 *)(in_ECX + 0x201) = 1;
    return;
  }
  *(undefined1 *)(in_ECX + 0x201) = 2;
  *(float *)(in_ECX + 0x220) = param_2;
  return;
}


