// func FUN_00049e80 @ 0x00049E80 (size 0x2F)

void FUN_00049e80(void)

{
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  FUN_00049c90();
  FUN_00049df0(local_10,local_c,local_8);
  return;
}


