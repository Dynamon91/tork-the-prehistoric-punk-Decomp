// func FUN_0001fa70 @ 0x0001FA70 (size 0x8A)

byte * FUN_0001fa70(void)

{
  byte *pbVar1;
  byte bVar2;
  byte *pbVar3;
  int in_ECX;
  uint uVar4;
  uint uVar5;
  bool bVar6;
  
  pbVar1 = *(byte **)(in_ECX + 0x3c);
  pbVar3 = pbVar1 + 4;
  *(byte **)(in_ECX + 0x3c) = pbVar3;
  bVar2 = *pbVar1;
  uVar5 = (uint)*(byte *)(*(int *)(in_ECX + 0x30) + 0x69) + DAT_002411e0;
  if ((char)bVar2 < '\0') {
    bVar6 = (bVar2 & (byte)uVar5 & 0x3f) != 0;
  }
  else {
    if ((bVar2 & 0x40) == 0) {
      (**(code **)(&DAT_00241540 + (pbVar1[5] & 0x3f) * 0x10))();
      pbVar3 = (byte *)(*(int *)(in_ECX + 8) + -4);
      *(byte **)(in_ECX + 8) = pbVar3;
      bVar2 = *pbVar3;
      if (bVar2 == 0) {
        bVar2 = 1;
      }
      uVar4 = (uint)bVar2;
    }
    else {
      uVar4 = bVar2 & 0x3f;
    }
    pbVar3 = (byte *)(uVar5 / uVar4);
    bVar6 = uVar5 % uVar4 != 0;
  }
  if (bVar6) {
    pbVar3 = pbVar1 + *(short *)(pbVar1 + 2) * 4;
    *(byte **)(in_ECX + 0x3c) = pbVar3;
  }
  return pbVar3;
}


