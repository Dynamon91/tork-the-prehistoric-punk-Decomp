// func FUN_00054b70 @ 0x00054B70 (size 0x30)

int FUN_00054b70(short *param_1)

{
  short *psVar1;
  short *psVar2;
  int in_ECX;
  short *in_EDX;
  
  if ((in_EDX != (short *)0x0) && (psVar1 = in_EDX + in_ECX, in_EDX < psVar1)) {
    psVar2 = in_EDX;
    do {
      if (*psVar2 == *param_1) {
        if (psVar2 < psVar1) {
          return (int)psVar2 - (int)in_EDX >> 1;
        }
        return -1;
      }
      psVar2 = psVar2 + 1;
    } while (psVar2 < psVar1);
  }
  return -1;
}


