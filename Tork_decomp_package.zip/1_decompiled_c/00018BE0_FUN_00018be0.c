// func FUN_00018be0 @ 0x00018BE0 (size 0x48)

void FUN_00018be0(void)

{
  undefined *in_EAX;
  undefined *puVar1;
  int in_ECX;
  uint uVar2;
  bool bVar3;
  
  if (((undefined *)(in_ECX + 0x44) <= in_EAX) && (in_EAX < &DAT_00002044 + in_ECX)) {
    puVar1 = in_EAX + (-0x44 - in_ECX);
    uVar2 = (uint)puVar1 & 0x8000001f;
    bVar3 = uVar2 == 0;
    if ((int)uVar2 < 0) {
      bVar3 = (uVar2 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar3) && ((int)(puVar1 + ((int)puVar1 >> 0x1f & 0x1f)) >> 5 != -1)) &&
       (*(int *)(&DAT_00002064 + ((int)(puVar1 + ((int)puVar1 >> 0x1f & 0x1f)) >> 5) * 4 + in_ECX)
        == 0)) {
      FUN_00019750();
      return;
    }
  }
  return;
}


