// func FUN_00011480 @ 0x00011480 (size 0x125)

void FUN_00011480(void)

{
  char cVar1;
  undefined4 in_EAX;
  undefined4 *in_ECX;
  
  *in_ECX = in_EAX;
  *(undefined1 *)(in_ECX + 0x23) = 0;
  *(undefined1 *)((int)in_ECX + 0x8d) = 0;
  *(undefined1 *)((int)in_ECX + 0x8e) = 0;
  *(undefined1 *)((int)in_ECX + 0x8f) = 0;
  *(undefined1 *)(in_ECX + 0x24) = 0;
  *(undefined1 *)((int)in_ECX + 0x91) = 0;
  *(undefined1 *)((int)in_ECX + 0x92) = 0;
  *(undefined1 *)((int)in_ECX + 0x93) = 0;
  *(undefined1 *)((int)in_ECX + 0x95) = 0;
  *(undefined1 *)((int)in_ECX + 0x96) = 0;
  *(undefined1 *)((int)in_ECX + 0x97) = 0;
  *(undefined1 *)(in_ECX + 0x26) = 0;
  *(undefined1 *)(in_ECX + 3) = 0;
  DAT_00241214 = 0x119c0;
  res_bgl_d_tork_bgl();
  FUN_000115b0();
  FUN_0012a37c();
  cVar1 = *(char *)((int)in_ECX + 0x8e);
  while (cVar1 == '\0') {
    if (*(char *)((int)in_ECX + 0x99) == '\x01') {
      DAT_00241820 = DAT_00241820 | 0x1000000;
      FUN_0012ebe2(*(undefined4 *)(DAT_00241470 + 0x30),0xffffffff);
      FUN_0008ec40(DAT_0022ddcc,0);
      FUN_00080980();
      FUN_0012e945(*(undefined4 *)(DAT_00241470 + 0x30));
    }
    else {
      FUN_000d8e60(*(undefined1 *)(in_ECX + 0x23),0);
      if (*(int *)(DAT_002414b0 + 0xc) != -1) {
        FUN_000d7f10(*(int *)(DAT_002414b0 + 0xc),*(undefined1 *)(DAT_002414b0 + 0x10));
        *(undefined4 *)(DAT_002414b0 + 0xc) = 0xffffffff;
        *(undefined1 *)(DAT_002414b0 + 0x10) = 0;
      }
    }
    cVar1 = *(char *)((int)in_ECX + 0x8e);
  }
  FUN_00011910(in_ECX);
  return;
}


