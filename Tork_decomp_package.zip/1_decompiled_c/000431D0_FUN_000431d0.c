// func FUN_000431d0 @ 0x000431D0 (size 0x61)

void FUN_000431d0(void)

{
  byte bVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int *piVar4;
  int *in_ECX;
  
  bVar1 = *(byte *)(in_ECX + 3);
  if ((bVar1 & 4) == 0) {
    *(byte *)(in_ECX + 3) = bVar1 & 0xfd;
    piVar4 = (int *)in_ECX[6];
    if (piVar4 != (int *)0x0) {
      *(undefined1 *)(piVar4 + 4) = 0;
      if (*piVar4 != 0) {
        FUN_00166ae6(*piVar4);
        return;
      }
    }
  }
  else {
    puVar2 = (undefined4 *)in_ECX[6];
    *(byte *)(in_ECX + 3) = bVar1 & 0xfb;
    if (puVar2 != (undefined4 *)0x0) {
      uVar3 = *(undefined4 *)(*in_ECX + 0x20);
      *(undefined1 *)(puVar2 + 4) = 0;
      FUN_00166b62(*puVar2,0,uVar3);
      FUN_00166bbe(*puVar2,puVar2[3]);
      FUN_00166a9e(*puVar2,0,0,0);
    }
  }
  return;
}


