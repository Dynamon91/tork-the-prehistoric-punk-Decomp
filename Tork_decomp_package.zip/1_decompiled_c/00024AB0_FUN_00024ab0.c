// func FUN_00024ab0 @ 0x00024AB0 (size 0x2B)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00024ab0(void)

{
  float *in_EAX;
  float *in_ECX;
  float *in_EDX;
  
  *in_EDX = (*in_ECX + *in_EAX) * _DAT_0020df84;
  in_EDX[1] = (in_ECX[1] + in_EAX[1]) * _DAT_0020df84;
  in_EDX[2] = (in_ECX[2] + in_EAX[2]) * _DAT_0020df84;
  return;
}


