// func FUN_00026560 @ 0x00026560 (size 0x91)

undefined4
FUN_00026560(undefined *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  uint uVar1;
  bool bVar2;
  undefined4 local_4;
  
  local_4 = 0;
  FUN_000e8eb0(&local_4,param_1,param_2,param_3,param_4,param_5,param_6,0,0,0,0);
  if (((undefined *)(DAT_002411d8 + 0x44) <= param_1) && (param_1 < &DAT_00002044 + DAT_002411d8)) {
    param_1 = param_1 + (-0x44 - DAT_002411d8);
    uVar1 = (uint)param_1 & 0x8000001f;
    bVar2 = uVar1 == 0;
    if ((int)uVar1 < 0) {
      bVar2 = (uVar1 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar2) && ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5 != -1)) &&
       (*(int *)(&DAT_00002064 +
                ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5) * 4 + DAT_002411d8) == 0)) {
      FUN_00019750();
    }
  }
  return local_4;
}


