// func FUN_00021970 @ 0x00021970 (size 0x110)

void FUN_00021970(int param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  short *psVar2;
  short *psVar3;
  int iVar4;
  
  psVar2 = (short *)FUN_00057f60(0x18);
  psVar2[2] = 0;
  psVar2[3] = 0;
  *psVar2 = 0;
  psVar2[4] = 0xfdb;
  psVar2[5] = 0x3fc9;
  psVar2[6] = 0;
  psVar2[7] = 0x3f80;
  psVar2[8] = 0;
  psVar2[9] = 0x447a;
  psVar2[10] = 0;
  psVar2[0xb] = 0x4348;
  psVar3 = (short *)FUN_00057f60(0x18);
  *psVar3 = 0;
  psVar3[2] = 0;
  psVar3[3] = 0;
  psVar3[4] = 0xfdb;
  psVar3[5] = 0x3fc9;
  psVar3[6] = 0;
  psVar3[7] = 0x3f80;
  psVar3[8] = 0;
  psVar3[9] = 0x447a;
  psVar3[10] = 0;
  psVar3[0xb] = 0x4348;
  *psVar2 = *psVar2 + 1;
  *psVar3 = *psVar3 + 1;
  if (param_1 < *(int *)(DAT_002414bc + 0x10c)) {
    iVar4 = *(int *)(DAT_002414bc + 0x110 + param_1 * 4);
  }
  else {
    iVar4 = 0;
  }
  iVar1 = *(int *)(iVar4 + 8);
  *(undefined4 *)(psVar2 + 4) = *(undefined4 *)(iVar1 + 8);
  *(undefined4 *)(psVar2 + 6) = *(undefined4 *)(iVar1 + 0xc);
  *(undefined4 *)(psVar2 + 8) = *(undefined4 *)(iVar1 + 0x10);
  *(undefined4 *)(psVar2 + 10) = *(undefined4 *)(iVar1 + 0x14);
  *(undefined4 *)(psVar2 + 2) = *(undefined4 *)(iVar1 + 4);
  iVar1 = *(int *)(iVar4 + 8);
  *(undefined4 *)(psVar3 + 4) = *(undefined4 *)(iVar1 + 8);
  *(undefined4 *)(psVar3 + 6) = *(undefined4 *)(iVar1 + 0xc);
  *(undefined4 *)(psVar3 + 8) = *(undefined4 *)(iVar1 + 0x10);
  *(undefined4 *)(psVar3 + 10) = *(undefined4 *)(iVar1 + 0x14);
  *(undefined4 *)(psVar3 + 2) = *(undefined4 *)(iVar1 + 4);
  *(undefined4 *)(psVar2 + 2) = *(undefined4 *)(param_2 + 0x10);
  *(undefined4 *)(psVar3 + 2) = *(undefined4 *)(param_3 + 0x10);
  FUN_000e3140(iVar4,psVar3,param_4);
  *psVar2 = *psVar2 + -1;
  if (*psVar2 == 0) {
    FUN_00058010();
  }
  *psVar3 = *psVar3 + -1;
  if (*psVar3 == 0) {
    FUN_00058010();
  }
  return;
}


