// func FUN_00035cb0 @ 0x00035CB0 (size 0x388)

uint FUN_00035cb0(uint param_1,ushort param_2)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  float *pfVar5;
  uint uVar6;
  int iVar7;
  float *pfVar8;
  uint local_d8;
  uint local_b8;
  float local_a8 [32];
  float local_28;
  float local_24;
  float local_20;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  iVar2 = *(int *)(DAT_0022a6c4 + 0x14);
  local_a8[10] = 1.0;
  local_a8[5] = 1.0;
  local_a8[0] = 1.0;
  local_a8[0xf] = 1.0;
  local_a8[0xe] = 0.0;
  local_a8[0xd] = 0.0;
  local_a8[0xc] = 0.0;
  local_a8[9] = 0.0;
  local_a8[8] = 0.0;
  local_a8[6] = 0.0;
  local_a8[4] = 0.0;
  local_a8[2] = 0.0;
  local_a8[1] = 0.0;
  local_a8[0xb] = 0.0;
  local_a8[7] = 0.0;
  local_a8[3] = 0.0;
  local_a8[0x10] = 0.0;
  local_d8 = 0;
  local_b8 = param_1;
  local_a8[0x11] = 0.0;
  local_a8[0x12] = 0.0;
  if ((*(byte *)(iVar2 + 8) & 1) != 0) {
    if ((param_1 & 0x10000000) != 0) {
      return param_1;
    }
    local_d8 = (~(param_1 >> 0x1a) & 1) + (param_1 & 0xff);
    uVar6 = (uint)*(ushort *)(*(int *)(iVar2 + 0x24) + 0x1e);
    if ((*(uint *)(iVar2 + 4) >> 0x1e & 1) == 0) {
      if (local_d8 < uVar6) {
        do {
          iVar3 = *(int *)(*(int *)(*(int *)(iVar2 + 0x24) + 0x18) + (local_d8 & 0xff) * 4);
          if ((*(ushort *)(iVar3 + 2) & param_2) != 0) {
            if ((*(uint *)(iVar3 + 4) >> 0x1e & 1) == 0) goto LAB_0003601c;
            iVar7 = *(int *)(iVar3 + 0x28);
            FUN_000479c0();
            local_14 = *(undefined4 *)(iVar7 + 0x74);
            local_18 = *(undefined4 *)(iVar7 + 0x70);
            local_10 = *(undefined4 *)(iVar7 + 0x78);
            if ((*(byte *)(iVar3 + 4) & 1) != 0) {
              pfVar5 = *(float **)(iVar3 + 0x10);
              if ((*(byte *)(iVar3 + 4) & 2) != 0) {
                pfVar5 = pfVar5 + 0xc;
              }
              local_28 = local_28 + *pfVar5;
              local_24 = local_24 + pfVar5[1];
              local_20 = local_20 + pfVar5[2];
            }
            cVar4 = FUN_00070600();
            if (cVar4 != '\0') goto LAB_0003601c;
          }
          local_d8 = local_d8 + 1;
        } while (local_d8 < uVar6);
      }
    }
    else if (local_d8 < uVar6) {
      do {
        iVar3 = *(int *)(*(int *)(*(int *)(iVar2 + 0x24) + 0x18) + (local_d8 & 0xff) * 4);
        if ((*(ushort *)(iVar3 + 2) & param_2) != 0) {
          bVar1 = *(byte *)(iVar2 + 4);
          pfVar5 = (float *)(*(int *)(iVar2 + 0x28) + 0x30);
          pfVar8 = local_a8;
          for (iVar7 = 0x13; iVar7 != 0; iVar7 = iVar7 + -1) {
            *pfVar8 = *pfVar5;
            pfVar5 = pfVar5 + 1;
            pfVar8 = pfVar8 + 1;
          }
          if ((bVar1 & 1) != 0) {
            pfVar5 = *(float **)(iVar2 + 0x10);
            if ((bVar1 & 2) != 0) {
              pfVar5 = pfVar5 + 0xc;
            }
            local_a8[0xc] = local_a8[0xc] + *pfVar5;
            local_a8[0xd] = local_a8[0xd] + pfVar5[1];
            local_a8[0xe] = local_a8[0xe] + pfVar5[2];
          }
          if ((*(uint *)(iVar3 + 4) >> 0x1e & 1) == 0) {
            cVar4 = FUN_00070600();
          }
          else {
            iVar7 = *(int *)(iVar3 + 0x28);
            FUN_000479c0();
            local_10 = *(undefined4 *)(iVar7 + 0x78);
            local_18 = *(undefined4 *)(iVar7 + 0x70);
            local_14 = *(undefined4 *)(iVar7 + 0x74);
            if ((*(byte *)(iVar3 + 4) & 1) != 0) {
              pfVar5 = *(float **)(iVar3 + 0x10);
              if ((*(byte *)(iVar3 + 4) & 2) != 0) {
                pfVar5 = pfVar5 + 0xc;
              }
              local_28 = local_28 + *pfVar5;
              local_24 = local_24 + pfVar5[1];
              local_20 = local_20 + pfVar5[2];
            }
            cVar4 = FUN_00070480();
          }
          if (cVar4 != '\0') goto LAB_0003601c;
        }
        local_d8 = local_d8 + 1;
      } while (local_d8 < uVar6);
    }
  }
  local_b8 = param_1 | 0x10000000;
LAB_0003601c:
  return local_b8 & 0xfbffff00 | local_d8 & 0xff;
}


