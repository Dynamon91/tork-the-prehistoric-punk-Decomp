// func FUN_00054800 @ 0x00054800 (size 0x14)

ushort * FUN_00054800(void)

{
  ushort in_AX;
  ushort *in_ECX;
  
  if (in_AX < *in_ECX) {
    return in_ECX + (uint)in_AX * 6 + 3;
  }
  return (ushort *)0xffffffff;
}


