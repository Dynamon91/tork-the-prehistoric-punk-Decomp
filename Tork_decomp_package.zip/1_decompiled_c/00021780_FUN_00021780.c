// func FUN_00021780 @ 0x00021780 (size 0x42)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00021780(void)

{
  float *unaff_ESI;
  float10 fVar1;
  
  fVar1 = (float10)FUN_00021640();
  fVar1 = SQRT((float10)_DAT_0020df98 / fVar1);
  *unaff_ESI = (float)(fVar1 * (float10)*unaff_ESI);
  unaff_ESI[1] = (float)(fVar1 * (float10)unaff_ESI[1]);
  unaff_ESI[2] = (float)(fVar1 * (float10)unaff_ESI[2]);
  return;
}


