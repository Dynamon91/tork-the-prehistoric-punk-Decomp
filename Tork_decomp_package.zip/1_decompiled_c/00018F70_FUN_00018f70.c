// func FUN_00018f70 @ 0x00018F70 (size 0x207)

void FUN_00018f70(int param_1,undefined4 *param_2,char *param_3,undefined4 param_4)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  int iVar4;
  char *pcVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  bool bVar9;
  
  pcVar5 = (char *)*param_2;
  if ((pcVar5 < (char *)(param_1 + 0x44)) || (&DAT_00002044 + param_1 <= pcVar5)) {
LAB_00018fc3:
    iVar8 = -1;
  }
  else {
    pcVar2 = pcVar5 + (-0x44 - param_1);
    uVar7 = (uint)pcVar2 & 0x8000001f;
    if ((int)uVar7 < 0) {
      uVar7 = (uVar7 - 1 | 0xffffffe0) + 1;
    }
    if ((uVar7 != 0) ||
       ((iVar8 = (int)(pcVar2 + ((int)pcVar2 >> 0x1f & 0x1f)) >> 5, iVar8 != -1 &&
        (*(undefined4 **)(&DAT_00002064 + iVar8 * 4 + param_1) != param_2)))) goto LAB_00018fc3;
  }
  if ((param_3 < (char *)(param_1 + 0x44)) || (&DAT_00002044 + param_1 <= param_3)) {
LAB_00019024:
    bVar9 = false;
  }
  else {
    pcVar2 = param_3 + (-0x44 - param_1);
    uVar7 = (uint)pcVar2 & 0x8000001f;
    bVar9 = uVar7 == 0;
    if ((int)uVar7 < 0) {
      bVar9 = (uVar7 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((!bVar9) || ((int)(pcVar2 + ((int)pcVar2 >> 0x1f & 0x1f)) >> 5 == -1)) ||
       (bVar9 = true,
       *(int *)(&DAT_00002064 + ((int)(pcVar2 + ((int)pcVar2 >> 0x1f & 0x1f)) >> 5) * 4 + param_1)
       != 0)) goto LAB_00019024;
  }
  pcVar2 = pcVar5;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  pcVar3 = param_3;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  if (iVar8 == -1) {
    iVar8 = FUN_000196d0(param_4);
    param_1 = iVar8 * 0x20 + 0x44 + param_1;
    iVar8 = param_1 - (int)pcVar5;
    do {
      cVar1 = *pcVar5;
      pcVar5[iVar8] = cVar1;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    pcVar5 = param_3;
    do {
      cVar1 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    uVar7 = (int)pcVar5 - (int)param_3;
    pcVar5 = (char *)(param_1 + -1);
    do {
      pcVar2 = pcVar5 + 1;
      pcVar5 = pcVar5 + 1;
    } while (*pcVar2 != '\0');
  }
  else {
    iVar4 = FUN_000550b0();
    if (iVar4 < (int)(pcVar2 + (int)(pcVar3 + (-(int)(param_3 + 1) - (int)(pcVar5 + 1)) + 0x20) +
                     ((int)(pcVar2 + (int)(pcVar3 + (-(int)(param_3 + 1) - (int)(pcVar5 + 1)) + 0x20
                                          )) >> 0x1f & 0x1f)) >> 5) {
      iVar8 = FUN_000196d0(param_4);
      param_1 = iVar8 * 0x20 + 0x44 + param_1;
      iVar8 = param_1 - (int)pcVar5;
      do {
        cVar1 = *pcVar5;
        pcVar5[iVar8] = cVar1;
        pcVar5 = pcVar5 + 1;
      } while (cVar1 != '\0');
      pcVar5 = param_3;
      do {
        cVar1 = *pcVar5;
        pcVar5 = pcVar5 + 1;
      } while (cVar1 != '\0');
      pcVar2 = (char *)(param_1 + -1);
      do {
        pcVar3 = pcVar2 + 1;
        pcVar2 = pcVar2 + 1;
      } while (*pcVar3 != '\0');
      pcVar3 = param_3;
      for (uVar7 = (uint)((int)pcVar5 - (int)param_3) >> 2; uVar7 != 0; uVar7 = uVar7 - 1) {
        *(undefined4 *)pcVar2 = *(undefined4 *)pcVar3;
        pcVar3 = pcVar3 + 4;
        pcVar2 = pcVar2 + 4;
      }
      for (uVar7 = (int)pcVar5 - (int)param_3 & 3; uVar7 != 0; uVar7 = uVar7 - 1) {
        *pcVar2 = *pcVar3;
        pcVar3 = pcVar3 + 1;
        pcVar2 = pcVar2 + 1;
      }
      FUN_00019750();
      goto LAB_00019158;
    }
    pcVar5 = param_3;
    do {
      cVar1 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    uVar7 = (int)pcVar5 - (int)param_3;
    pcVar5 = (char *)(iVar8 * 0x20 + param_1 + 0x43);
    do {
      pcVar2 = pcVar5 + 1;
      pcVar5 = pcVar5 + 1;
    } while (*pcVar2 != '\0');
  }
  for (uVar6 = uVar7 >> 2; uVar6 != 0; uVar6 = uVar6 - 1) {
    *(undefined4 *)pcVar5 = *(undefined4 *)param_3;
    param_3 = param_3 + 4;
    pcVar5 = pcVar5 + 4;
  }
  for (uVar7 = uVar7 & 3; uVar7 != 0; uVar7 = uVar7 - 1) {
    *pcVar5 = *param_3;
    param_3 = param_3 + 1;
    pcVar5 = pcVar5 + 1;
  }
LAB_00019158:
  if (bVar9) {
    FUN_00019750();
  }
  return;
}


