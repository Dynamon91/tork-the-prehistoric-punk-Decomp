// func FUN_00058d60 @ 0x00058D60 (size 0x19B)

undefined4 * FUN_00058d60(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 *unaff_FS_OFFSET;
  undefined4 local_c;
  undefined1 *puStack_8;
  undefined4 local_4;
  
  local_c = *unaff_FS_OFFSET;
  local_4 = 0xffffffff;
  puStack_8 = &LAB_00144213;
  *unaff_FS_OFFSET = &local_c;
  *param_1 = &PTR_LAB_002085c0;
  uVar1 = FUN_0012e891(0,0,0);
  param_1[6] = uVar1;
  uVar1 = FUN_0012e699(0,1,0,0);
  param_1[7] = uVar1;
  local_4 = 0;
  *param_1 = &PTR_LAB_00208610;
  uVar1 = FUN_0012e699(0,1,0,0);
  param_1[0x12] = uVar1;
  local_4 = CONCAT31(local_4._1_3_,1);
  ___L_YGXPAXIHP6EX0_Z1_Z(param_1 + 0x2b,0x18,0x200,FUN_00058c30,&DAT_00058c50);
  param_1[0xd] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x11] = 0x3c23d70a;
  param_1[0x10] = 0;
  param_1[0x17] = 0x20;
  param_1[0x16] = 0;
  param_1[0x15] = 0;
  param_1[0x14] = 0;
  uVar1 = FUN_00057f60(0x40);
  param_1[0x13] = uVar1;
  param_1[0x1c] = 0x100;
  param_1[0x1b] = 0;
  param_1[0x1a] = 0;
  param_1[0x19] = 0;
  uVar1 = FUN_00057f60(0x200);
  param_1[0x18] = uVar1;
  param_1[0x21] = 0x8000;
  param_1[0x20] = 0;
  param_1[0x1f] = 0;
  param_1[0x1e] = 0;
  uVar1 = FUN_00057f60(0x10000);
  param_1[0x1d] = uVar1;
  param_1[0x26] = 0x10;
  param_1[0x25] = 0;
  param_1[0x24] = 0;
  param_1[0x23] = 0;
  uVar1 = FUN_00057f60(0x20);
  param_1[0x22] = uVar1;
  param_1[0x27] = 0;
  *(undefined2 *)(param_1 + 0x28) = 0;
  *(undefined2 *)((int)param_1 + 0xa2) = 0;
  param_1[0x29] = 0;
  *(undefined2 *)(param_1 + 0x2a) = 0;
  *(undefined2 *)((int)param_1 + 0xaa) = 0;
  *(undefined1 *)(param_1 + 0xc2b) = 0;
  *(undefined1 *)((int)param_1 + 0x30ad) = 0;
  DAT_00241218 = 0;
  param_1[5] = 0x20;
  param_1[4] = 0;
  param_1[3] = 0;
  param_1[2] = 0;
  uVar1 = FUN_00057f60(0x80);
  param_1[1] = uVar1;
  uVar1 = FUN_0012c5d9(0,0x4000,&LAB_0005a450,param_1,0,0);
  param_1[8] = uVar1;
  *unaff_FS_OFFSET = local_c;
  return param_1;
}


