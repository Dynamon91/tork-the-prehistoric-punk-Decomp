// func FUN_00023240 @ 0x00023240 (size 0x6C)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00023240(float *param_1,float *param_2,float param_3)

{
  float10 fVar1;
  float10 fVar2;
  
  fVar1 = (float10)fcos((float10)param_3);
  fVar2 = (float10)fsin((float10)param_3);
  *param_1 = (float)((float10)param_2[1] * (float10)_DAT_0020df5c +
                    fVar1 * (float10)*param_2 + fVar2 * (float10)param_2[2]);
  param_1[1] = (param_2[2] + *param_2) * _DAT_0020df5c + param_2[1];
  param_1[2] = (float)((float10)param_2[1] * (float10)_DAT_0020df5c +
                      (float10)-(float)fVar2 * (float10)*param_2 + fVar1 * (float10)param_2[2]);
  return;
}


