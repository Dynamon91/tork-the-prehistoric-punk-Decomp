// func FUN_00054450 @ 0x00054450 (size 0x3E)

void FUN_00054450(void)

{
  ushort uVar1;
  ushort in_AX;
  uint uVar2;
  ushort *in_ECX;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  if (in_AX < *in_ECX) {
    uVar1 = *in_ECX - 1;
    uVar2 = (uint)in_AX;
    puVar5 = (undefined4 *)(uVar2 + 6 + (int)in_ECX);
    *in_ECX = uVar1;
    puVar4 = (undefined4 *)(uVar2 + 7 + (int)in_ECX);
    if ((puVar5 != (undefined4 *)0x0) && (puVar4 != (undefined4 *)0x0)) {
      uVar2 = uVar1 - uVar2;
      for (uVar3 = uVar2 >> 2; uVar3 != 0; uVar3 = uVar3 - 1) {
        *puVar5 = *puVar4;
        puVar4 = puVar4 + 1;
        puVar5 = puVar5 + 1;
      }
      for (uVar2 = uVar2 & 3; uVar2 != 0; uVar2 = uVar2 - 1) {
        *(undefined1 *)puVar5 = *(undefined1 *)puVar4;
        puVar4 = (undefined4 *)((int)puVar4 + 1);
        puVar5 = (undefined4 *)((int)puVar5 + 1);
      }
    }
  }
  return;
}


