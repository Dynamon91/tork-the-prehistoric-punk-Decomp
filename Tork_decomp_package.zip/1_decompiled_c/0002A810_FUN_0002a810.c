// func FUN_0002a810 @ 0x0002A810 (size 0x43)

uint FUN_0002a810(char param_1)

{
  uint in_EAX;
  byte bVar1;
  int in_EDX;
  
  bVar1 = 0;
  if (*(byte *)(in_EDX + 0x36) != 0) {
    do {
      in_EAX = (uint)bVar1 * 3;
      if (*(char *)(in_EDX + 0x49 + (uint)bVar1 * 0x18) == param_1) {
        return CONCAT31((int3)(in_EAX >> 8),(*(byte *)(in_EDX + 0x48) & 3) == 2);
      }
      bVar1 = bVar1 + 1;
    } while (bVar1 < *(byte *)(in_EDX + 0x36));
  }
  return in_EAX & 0xffffff00;
}


