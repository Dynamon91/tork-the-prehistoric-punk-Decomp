// func FUN_0004b320 @ 0x0004B320 (size 0x9E)

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_0004b320(undefined *param_1)

{
  int iVar1;
  undefined1 *puVar2;
  undefined *puVar3;
  uint uVar4;
  bool bVar5;
  undefined1 local_38 [52];
  undefined4 local_4;
  
  local_4 = DAT_002264b0;
  iVar1 = FUN_00134fe8(param_1);
  puVar2 = local_38;
  if (iVar1 != 0) {
    puVar3 = param_1;
    do {
      *puVar2 = *puVar3;
      puVar2 = puVar2 + 1;
      puVar3 = puVar3 + 2;
      iVar1 = iVar1 + -1;
    } while (iVar1 != 0);
  }
  *puVar2 = 0;
  FUN_00135873(local_38);
  if (((undefined *)(DAT_002411d8 + 0x44) <= param_1) && (param_1 < &DAT_00002044 + DAT_002411d8)) {
    param_1 = param_1 + (-0x44 - DAT_002411d8);
    uVar4 = (uint)param_1 & 0x8000001f;
    bVar5 = uVar4 == 0;
    if ((int)uVar4 < 0) {
      bVar5 = (uVar4 - 1 | 0xffffffe0) == 0xffffffff;
    }
    if (((bVar5) && ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5 != -1)) &&
       (*(int *)(&DAT_00002064 +
                ((int)(param_1 + ((int)param_1 >> 0x1f & 0x1f)) >> 5) * 4 + DAT_002411d8) == 0)) {
      FUN_00019750();
    }
  }
  return;
}


