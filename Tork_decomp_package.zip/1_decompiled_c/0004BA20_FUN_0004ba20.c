// func FUN_0004ba20 @ 0x0004BA20 (size 0x3E)

uint FUN_0004ba20(int param_1,uint param_2)

{
  undefined2 uVar1;
  uint uVar2;
  undefined2 extraout_var;
  
  uVar2 = FUN_00134fe8(param_1);
  if (uVar2 < param_2) {
    uVar2 = FUN_00018c30();
    return uVar2 & 0xffff0000;
  }
  uVar1 = *(undefined2 *)(param_1 + param_2 * 2);
  FUN_00018c30();
  return CONCAT22(extraout_var,uVar1);
}


