// func FUN_000117a0 @ 0x000117A0 (size 0x165)

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_000117a0(void)

{
  undefined4 uVar1;
  float fVar2;
  int iVar3;
  undefined4 unaff_EBX;
  int unaff_ESI;
  undefined4 unaff_EDI;
  undefined8 uVar4;
  char local_104 [256];
  undefined4 local_4;
  
  local_4 = DAT_002264b0;
  iVar3 = FUN_0012a37c();
  fVar2 = (float)iVar3;
  if (iVar3 < 0) {
    fVar2 = fVar2 + _DAT_0020dfb4;
  }
  _sprintf(local_104,s___3f___End_of_initialization___2_00208044,(double)(fVar2 * _DAT_0020e0ac));
  iVar3 = FUN_000110b0();
  if (iVar3 == -1) {
    FUN_0012ebe2(*(undefined4 *)(DAT_00241470 + 0x30),0xffffffff);
    FUN_0008ec40(DAT_0022ddcc,0);
    FUN_00080980();
    FUN_0012e945();
    return;
  }
  uVar4 = CONCAT44(unaff_EBX,unaff_EDI);
  FUN_000112c0(iVar3,0,&DAT_002414b0);
  FUN_00011170();
  iVar3 = FUN_0012a37c(uVar4);
  fVar2 = (float)iVar3;
  if (iVar3 < 0) {
    fVar2 = fVar2 + _DAT_0020dfb4;
  }
  _sprintf(local_104,s___3f___End_of_map_loading_00208028,(double)(fVar2 * _DAT_0020e0ac));
  *(undefined4 *)(DAT_002414bc + *(int *)(DAT_002414bc + 0x86) * 2 + 0x88) =
       *(undefined4 *)(unaff_ESI + 8);
  *(int *)(DAT_002414bc + 0x86) = *(int *)(DAT_002414bc + 0x86) + 1;
  FUN_000dcdf0();
  *DAT_002414bc = *DAT_002414bc + 1;
  *(undefined1 *)(DAT_002414bc + 1) = 1;
  iVar3 = DAT_0022d4e0;
  uVar1 = *(undefined4 *)(*(int *)(*(int *)(unaff_ESI + 8) + 8) + 4);
  *(undefined4 *)(DAT_0022d4e0 + 0x104) = uVar1;
  *(undefined4 *)(iVar3 + 0x9c) = uVar1;
  return;
}


