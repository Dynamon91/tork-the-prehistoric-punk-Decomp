// func FUN_00043f60 @ 0x00043F60 (size 0x2E)

void FUN_00043f60(void)

{
  int iVar1;
  ushort uVar2;
  int unaff_EBX;
  int unaff_EDI;
  
  uVar2 = *(ushort *)(unaff_EDI + 2);
  while (uVar2 != 0xffff) {
    iVar1 = (uint)uVar2 * 0x68 + unaff_EDI;
    if (*(int *)(iVar1 + 0x6c) == unaff_EBX) {
      FUN_00043ef0();
    }
    uVar2 = *(ushort *)(iVar1 + 0x6a);
  }
  return;
}


