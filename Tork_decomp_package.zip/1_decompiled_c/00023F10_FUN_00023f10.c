// func FUN_00023f10 @ 0x00023F10 (size 0x5C)

float10 FUN_00023f10(void)

{
  float *in_EAX;
  float fVar1;
  float10 fVar2;
  
  fVar1 = ABS(in_EAX[1]);
  if (fVar1 < ABS(*in_EAX)) {
    fVar1 = ABS(*in_EAX);
  }
  fVar2 = (float10)fVar1;
  if (fVar2 <= (float10)ABS(in_EAX[2])) {
    fVar2 = (float10)ABS(in_EAX[2]);
  }
  return fVar2;
}


