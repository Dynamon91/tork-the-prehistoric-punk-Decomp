// func FUN_0002ba40 @ 0x0002BA40 (size 0x1C7)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0002ba40(int param_1)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  int in_EAX;
  float *unaff_EDI;
  float local_64;
  float local_60;
  float local_40;
  float local_3c;
  float local_38;
  float local_30;
  float local_2c;
  float local_28;
  float local_20;
  float local_1c;
  float local_18;
  float local_10;
  float local_c;
  float local_8;
  
  fVar4 = (*(float *)(in_EAX + 8) + *(float *)(in_EAX + 0x14)) * _DAT_0020df84;
  fVar5 = (*(float *)(in_EAX + 0x18) + *(float *)(in_EAX + 0xc)) * _DAT_0020df84;
  fVar6 = (*(float *)(in_EAX + 0x1c) + *(float *)(in_EAX + 0x10)) * _DAT_0020df84;
  fVar2 = *(float *)(in_EAX + 0x14) - fVar4;
  fVar3 = *(float *)(in_EAX + 0x18) - fVar5;
  fVar7 = *(float *)(in_EAX + 0x1c) - fVar6;
  local_64 = fVar4;
  local_60 = fVar5;
  if ((*(byte *)(in_EAX + 2) >> 3 & 1) != 0) {
    FUN_000941f0();
    local_64 = local_40 * fVar4 + local_30 * fVar5 + local_20 * fVar6 + local_10;
    local_60 = local_3c * fVar4 + local_2c * fVar5 + local_1c * fVar6 + local_c;
    fVar6 = local_38 * fVar4 + local_28 * fVar5 + local_18 * fVar6 + local_8;
  }
  pfVar1 = *(float **)(param_1 + 0x10);
  fVar8 = local_64 * *pfVar1 + local_60 * pfVar1[4] + fVar6 * pfVar1[8] + pfVar1[0xc];
  fVar5 = local_60 * pfVar1[5] + local_64 * pfVar1[1] + fVar6 * pfVar1[9] + pfVar1[0xd];
  fVar4 = local_64 * pfVar1[2] + local_60 * pfVar1[6] + fVar6 * pfVar1[10] + pfVar1[0xe];
  unaff_EDI[3] = fVar2 + fVar8;
  unaff_EDI[4] = fVar3 + fVar5;
  unaff_EDI[5] = fVar7 + fVar4;
  *unaff_EDI = fVar8 - fVar2;
  unaff_EDI[1] = fVar5 - fVar3;
  unaff_EDI[2] = fVar4 - fVar7;
  return;
}


