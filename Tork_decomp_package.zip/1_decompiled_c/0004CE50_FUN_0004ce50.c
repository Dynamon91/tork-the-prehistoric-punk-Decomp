// func FUN_0004ce50 @ 0x0004CE50 (size 0x62)

void FUN_0004ce50(undefined1 param_1,undefined4 *param_2,undefined4 param_3,undefined1 param_4,
                 undefined1 param_5)

{
  undefined1 local_68;
  undefined1 local_67;
  undefined1 local_66;
  undefined1 local_65;
  undefined1 *local_64;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_48;
  
  local_67 = param_1;
  local_66 = param_4;
  local_65 = param_5;
  local_60 = *param_2;
  local_5c = param_2[1];
  local_58 = param_2[2];
  local_68 = 0x11;
  local_64 = &LAB_00112f90;
  local_48 = param_3;
  FUN_0004c800(*(undefined4 *)(*(int *)(DAT_0022a6c4 + 0x14) + 0x20),*(int *)(DAT_0022a6c4 + 0x14),
               &local_68);
  return;
}


