// func FUN_00018930 @ 0x00018930 (size 0x17)

void FUN_00018930(void)

{
  int iVar1;
  int *unaff_ESI;
  
  if (*unaff_ESI != 0) {
    iVar1 = FUN_00058980(*unaff_ESI);
    if (iVar1 != 0) {
      *unaff_ESI = iVar1;
    }
  }
  return;
}


