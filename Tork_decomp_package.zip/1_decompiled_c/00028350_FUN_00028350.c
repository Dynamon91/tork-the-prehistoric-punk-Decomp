// func FUN_00028350 @ 0x00028350 (size 0x6F)

void FUN_00028350(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *in_EAX;
  undefined4 *in_ECX;
  
  uVar1 = in_EAX[8];
  uVar2 = in_EAX[4];
  *in_ECX = *in_EAX;
  in_ECX[1] = uVar2;
  in_ECX[2] = uVar1;
  uVar1 = in_EAX[9];
  uVar2 = in_EAX[5];
  in_ECX[4] = in_EAX[1];
  in_ECX[5] = uVar2;
  in_ECX[6] = uVar1;
  uVar1 = in_EAX[10];
  uVar2 = in_EAX[6];
  in_ECX[8] = in_EAX[2];
  in_ECX[9] = uVar2;
  in_ECX[10] = uVar1;
  return;
}


