// func FUN_000581b0 @ 0x000581B0 (size 0x2B6)

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_000581b0(void)

{
  uint *puVar1;
  undefined *puVar2;
  undefined1 uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined *puVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  int local_11c;
  int local_118;
  int local_110;
  char local_104 [256];
  undefined4 local_4;
  
  uVar7 = 0;
  local_4 = DAT_002264b0;
  uVar6 = 0;
  puVar9 = &DAT_0022a774;
  do {
    for (puVar2 = *(undefined **)(puVar9 + 0xc); puVar2 != puVar9;
        puVar2 = *(undefined **)(puVar2 + 0xc)) {
      if (uVar6 < (*(uint *)(puVar2 + 4) & 0x7ffffffc)) {
        uVar6 = *(uint *)(puVar2 + 4) & 0x7ffffffc;
      }
    }
    puVar9 = puVar9 + 8;
  } while ((int)puVar9 < 0x22aa6c);
  if (uVar6 < 0x10000) {
    return 0;
  }
  iVar5 = uVar6 - 0x200;
  uVar4 = FUN_00057f60(iVar5);
  uVar6 = 0xffffffff;
  local_11c = 0;
  local_118 = 0;
  local_110 = DAT_0022a73c;
  if (DAT_0022a73c != 0) {
    do {
      uVar12 = *(uint *)(local_110 + 8);
      uVar11 = uVar12 - *(int *)(local_110 + 0xc);
      if ((uVar12 <= uVar4 + iVar5) && (uVar4 <= uVar11)) {
        FUN_0013f8c6(uVar11,0,0x8000);
        local_11c = local_11c + 1;
        local_118 = local_118 + (uVar12 - uVar11);
        if (uVar11 < uVar6) {
          uVar6 = uVar11;
        }
        if (uVar7 < uVar12) {
          uVar7 = uVar12;
        }
      }
      local_110 = *(int *)(local_110 + 0x10);
    } while (local_110 != 0);
  }
  if (local_11c < 1) {
    uVar3 = FUN_000581b0();
    FUN_00058010();
    return uVar3;
  }
  piVar10 = (int *)(uVar6 - 8);
  uVar12 = (int)piVar10 - (int)(uVar4 - 8);
  uVar8 = (uVar7 - uVar6) + 8;
  uVar11 = (*(uint *)(uVar4 - 4) & 0x7ffffffc) - uVar12;
  if ((*(uint *)(uVar4 - 4) & 2) == 0) {
    *(uint *)(uVar6 - 4) = uVar11 | 1;
    puVar1 = (uint *)(uVar11 + 4 + (int)piVar10);
    *puVar1 = *puVar1 | 1;
    *(uint *)(uVar4 - 4) = *(uint *)(uVar4 - 4) & 1 | uVar12;
    FUN_00056c90();
    if (((*(uint *)(uVar6 - 4) & 2) == 0) &&
       (uVar4 = *(uint *)(uVar6 - 4) & 0x7ffffffc, (uVar7 - uVar6) + 0x18 < uVar4)) {
      uVar4 = uVar4 - uVar8;
      *(uint *)((uVar6 - 4) + uVar8) = uVar4 | 1;
      *(uint *)(uVar6 - 4) = *(uint *)(uVar6 - 4) & 1 | uVar8;
      FUN_00056c90();
      uVar12 = uVar4 + uVar12;
    }
  }
  else {
    *piVar10 = *(int *)(uVar4 - 8) + uVar12;
    *(uint *)(uVar6 - 4) = uVar11 | 2;
    uVar12 = 0;
  }
  DAT_002411f8 = DAT_002411f8 + local_11c;
  DAT_002411fc = DAT_002411fc + local_118;
  DAT_00241204 = DAT_00241204 + uVar12;
  DAT_00241200 = DAT_00241200 + ((iVar5 - uVar12) - local_118);
  iVar5 = (iVar5 - uVar12) - local_118;
  _sprintf(local_104,s_Give__d_KB_back_to_the_system____00208368,
           (int)(local_118 + (local_118 >> 0x1f & 0x3ffU)) >> 10,local_11c,
           (int)(iVar5 + (iVar5 >> 0x1f & 0x3ffU)) >> 10,
           (int)(uVar12 + ((int)uVar12 >> 0x1f & 0x3ffU)) >> 10);
  _sprintf(local_104,s_Total____d_KB_given_back_to_the_s_00208308,
           (int)(DAT_002411fc + (DAT_002411fc >> 0x1f & 0x3ffU)) >> 10,DAT_002411f8,
           (int)(DAT_00241200 + (DAT_00241200 >> 0x1f & 0x3ffU)) >> 10,
           (int)(DAT_00241204 + (DAT_00241204 >> 0x1f & 0x3ffU)) >> 10);
  return 1;
}


