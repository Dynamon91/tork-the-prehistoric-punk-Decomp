// func FUN_0005b4b0 @ 0x0005B4B0 (size 0x46)

void FUN_0005b4b0(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int in_EAX;
  uint local_4;
  
  local_4 = local_4 & 0xffffff00;
  FUN_0005b940();
  puVar1 = (undefined4 *)(*(int *)(in_EAX + 4) + (uint)*(ushort *)(in_EAX + 10) * 0xc);
  *puVar1 = param_1;
  puVar1[1] = param_2;
  puVar1[2] = local_4;
  *(short *)(in_EAX + 10) = *(short *)(in_EAX + 10) + 1;
  return;
}


