// func FUN_00043310 @ 0x00043310 (size 0x4E)

void FUN_00043310(int param_1,undefined4 *param_2)

{
  char cVar1;
  int iVar2;
  byte bVar3;
  undefined4 *puVar4;
  
  bVar3 = *(byte *)(param_1 + 1);
  while (99 < bVar3) {
    FUN_0012ec0e(0);
    bVar3 = *(byte *)(param_1 + 1);
  }
  puVar4 = (undefined4 *)((uint)*(byte *)(param_1 + 2) * 0x44 + 4 + param_1);
  for (iVar2 = 0x11; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar4 = *param_2;
    param_2 = param_2 + 1;
    puVar4 = puVar4 + 1;
  }
  cVar1 = *(char *)(param_1 + 2);
  bVar3 = cVar1 + 1;
  *(byte *)(param_1 + 2) = bVar3;
  if (99 < bVar3) {
    *(char *)(param_1 + 2) = cVar1 + -99;
  }
  *(char *)(param_1 + 1) = *(char *)(param_1 + 1) + '\x01';
  return;
}


