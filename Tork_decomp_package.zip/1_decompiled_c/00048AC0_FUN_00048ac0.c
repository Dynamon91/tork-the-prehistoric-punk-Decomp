// func FUN_00048ac0 @ 0x00048AC0 (size 0x60D)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00048ac0(undefined4 param_1,int param_2,float param_3,float param_4)

{
  ushort uVar1;
  float fVar2;
  bool bVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  byte bVar7;
  int iVar8;
  uint uVar9;
  undefined1 *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  bool bVar13;
  float10 fVar14;
  undefined4 uVar15;
  int *piVar16;
  bool local_2a;
  int local_28;
  int local_24;
  float local_20;
  uint local_1c;
  float local_18;
  int *local_14;
  int local_10;
  float local_c;
  undefined4 local_8;
  undefined4 local_4;
  
  (&DAT_000059f4)[DAT_0022d4c0] = 0;
  puVar11 = (undefined4 *)(DAT_0022ddc8 + 0x2cc);
  puVar12 = (undefined4 *)(DAT_0022ddc8 + 0x74c);
  for (iVar8 = 0x120; iVar8 != 0; iVar8 = iVar8 + -1) {
    *puVar12 = *puVar11;
    puVar11 = puVar11 + 1;
    puVar12 = puVar12 + 1;
  }
  FUN_0008b5f0();
  *(undefined1 *)(DAT_0022ddcc + 0x795) = *(undefined1 *)(DAT_0022ddcc + 0x794);
  *(undefined1 *)(DAT_0022ddcc + 0x794) = 0x28;
  FUN_00118c50(*(undefined4 *)(DAT_002414b0 + 0x52c),*(undefined4 *)(DAT_002414b0 + 0x530),
               *(undefined4 *)(DAT_002414b0 + 0x534));
  FUN_0010cc70();
  if (DAT_002414d4 != 0) {
    FUN_001009c0();
  }
  FUN_000b47f0();
  *(undefined2 *)(DAT_0022ddcc + 0x69a) = 0;
  *(undefined2 *)(DAT_0022ddcc + 0x6ea) = 0;
  FUN_00081460();
  FUN_0012ec0e(100);
  iVar8 = DAT_0022d4c0;
  FUN_0012ebe2(*(undefined4 *)(&DAT_00002960 + DAT_0022d4c0),0xffffffff);
  (&DAT_000059f5)[iVar8] = 1;
  FUN_0012ec0e(100);
  puVar11 = (undefined4 *)(&DAT_00002988 + DAT_0022d4c0);
  if ((*(int *)(&DAT_00002988 + DAT_0022d4c0) != 0) ||
     (*(int *)(&DAT_00002814 + DAT_0022d4c0) + *(int *)(&DAT_00002838 + DAT_0022d4c0) * 2 != 0)) {
    FUN_0012e965(0xfffffffe,1,1);
    *puVar11 = 0;
  }
  FUN_00058670();
  FUN_000600c0(DAT_0022d4c0,&LAB_00048a80,0x5c9,0);
  puVar11 = (undefined4 *)(&DAT_00002960 + DAT_0022d4c0);
  (&DAT_000059f5)[DAT_0022d4c0] = 0;
  FUN_0012e945(*puVar11);
  piVar16 = &local_28;
  local_28 = 0;
  uVar15 = 0;
  uVar5 = FUN_0005aba0(0,piVar16);
  FUN_000112c0(uVar5,uVar15,piVar16);
  FUN_00011170(0);
  if (local_28 == 0) {
    *(undefined4 *)(&DAT_0022a6fc + DAT_002411f0 * 4) = 1;
  }
  else {
    if (*(int *)(DAT_002414bc + 0x10c) < 1) {
      uVar5 = 0;
    }
    else {
      uVar5 = *(undefined4 *)(DAT_002414bc + 0x110);
    }
    *(undefined4 *)(local_28 + 0x4c) = uVar5;
    local_14 = DAT_0022d4e4;
    *(undefined4 *)(local_28 + 0x50) = 0;
    *(undefined4 *)(local_28 + 0x54) = 0;
    *(undefined4 *)(local_28 + 0x28) = *(undefined4 *)(local_28 + 0x30);
    local_10 = local_28;
    *(undefined4 *)(local_28 + 0x34) = *(undefined4 *)(local_28 + 0x3c);
    local_4 = 0x3d088880;
    local_c = 0.0;
    local_8 = 0;
    FUN_000e95b0(DAT_002414c0);
    iVar8 = DAT_0022ddcc;
    *(float *)(DAT_0022ddcc + 0x780) = _DAT_00225f6c + _DAT_0020dfcc;
    *(undefined1 *)(iVar8 + 0x776) = 1;
    *(undefined4 *)(iVar8 + 0x778) = 0;
    *(undefined4 *)(iVar8 + 0x77c) = 0x3dcccccd;
    *(undefined4 *)(iVar8 + 0x78c) = 0x3f800000;
    *(undefined4 *)(iVar8 + 0x790) = 0;
    *(undefined4 *)(iVar8 + 0x784) = 0;
    *(undefined4 *)(iVar8 + 0x788) = 0;
    local_2a = (bool)FUN_00110410(&local_14);
    local_18 = *(float *)(*local_14 + 8);
    fVar14 = (float10)FUN_00062e30();
    local_8 = *(undefined4 *)(local_10 + 0x54);
    bVar7 = 0;
    bVar3 = false;
    iVar8 = 0;
    local_c = (float)(fVar14 / (float10)local_18);
    do {
      if ((&DAT_00241224)[iVar8] != '\0') {
        bVar7 = bVar7 + 1;
      }
      iVar8 = iVar8 + 1;
    } while (iVar8 < 4);
    local_1c = (uint)bVar7;
    local_18 = (float)((DAT_00241238 >> 0x18) + (DAT_00241238 >> 0x10 & 0xff) +
                       (DAT_00241238 >> 8 & 0xff) + (DAT_00241238 & 0xff));
    iVar8 = 0;
    if (local_2a != false) {
      while (cVar4 = FUN_00110410(&local_14), cVar4 != '\0') {
        if (((param_2 != -1) && (!bVar3)) &&
           (fVar14 = (float10)FUN_00048410(), (float10)_DAT_0020df98 == fVar14)) {
          FUN_00048920(param_2);
          bVar3 = true;
        }
        iVar6 = local_28;
        local_24 = iVar8 + 1;
        if (local_24 == 0x96) {
          puVar10 = (undefined1 *)
                    ((int)*(undefined4 **)(local_28 + 0x30) +
                    (*(int *)(local_28 + 0x2c) - (int)*(undefined4 **)(local_28 + 0x28)));
          local_24 = 0;
          if (puVar10 != (undefined1 *)0x0) {
            puVar11 = *(undefined4 **)(local_28 + 0x28);
            puVar12 = *(undefined4 **)(local_28 + 0x30);
            for (uVar9 = (uint)puVar10 >> 2; uVar9 != 0; uVar9 = uVar9 - 1) {
              *puVar12 = *puVar11;
              puVar11 = puVar11 + 1;
              puVar12 = puVar12 + 1;
            }
            for (uVar9 = (uint)puVar10 & 3; uVar9 != 0; uVar9 = uVar9 - 1) {
              *(undefined1 *)puVar12 = *(undefined1 *)puVar11;
              puVar11 = (undefined4 *)((int)puVar11 + 1);
              puVar12 = (undefined4 *)((int)puVar12 + 1);
            }
            *(undefined4 *)(local_28 + 0x28) = *(undefined4 *)(local_28 + 0x30);
            FUN_00058070();
            *(undefined1 **)(iVar6 + 0x2c) = puVar10;
          }
        }
        FUN_000808d0(0);
        local_20 = (float)DAT_0022d4e4[3];
        if (_DAT_0020e018 <= local_20) {
          local_20 = 0.05;
        }
        FUN_00062210(local_20);
        iVar8 = local_28;
        if (param_3 <= *(float *)(local_28 + 0x54)) {
          if (_DAT_0020df5c <= param_3) {
            bVar7 = 0;
            iVar6 = 0;
            do {
              if ((&DAT_00241224)[iVar6] != '\0') {
                bVar7 = bVar7 + 1;
              }
              iVar6 = iVar6 + 1;
            } while (iVar6 < 4);
            uVar9 = (uint)bVar7;
            bVar13 = local_1c != uVar9;
            if (bVar13) {
              local_1c = uVar9;
            }
            local_2a = !bVar13;
            iVar6 = (DAT_00241238 >> 0x18) + (DAT_00241238 >> 0x10 & 0xff) +
                    (DAT_00241238 >> 8 & 0xff) + (DAT_00241238 & 0xff);
            if (local_18 != (float)iVar6) {
              local_2a = false;
              local_18 = (float)iVar6;
            }
            iVar6 = 0;
            if (uVar9 != 0) {
              do {
                cVar4 = FUN_00061610();
                local_2a = (bool)(local_2a & 1U - (cVar4 != '\0'));
                iVar6 = iVar6 + 1;
              } while (iVar6 < (int)uVar9);
            }
          }
          if (param_4 <= *(float *)(iVar8 + 0x54)) {
            local_2a = false;
          }
        }
        FUN_0005ccf0();
        puVar11 = (undefined4 *)(&DAT_00002988 + DAT_0022d4c0);
        if ((*(int *)(&DAT_00002988 + DAT_0022d4c0) != 0) ||
           (*(int *)(&DAT_00002814 + DAT_0022d4c0) + *(int *)(&DAT_00002838 + DAT_0022d4c0) * 2 != 0
           )) {
          FUN_0012e965(0xfffffffe,1,1);
          *puVar11 = 0;
        }
        if (local_2a == false) break;
        iVar8 = local_24;
      }
    }
    FUN_0010d4c0(local_28);
    FUN_00058010();
    cVar4 = DAT_002411f4;
    iVar8 = DAT_0022ddcc;
    fVar2 = _DAT_00225f6c + _DAT_0020e2d0;
    *(undefined1 *)(DAT_0022ddcc + 0x776) = 0;
    *(float *)(iVar8 + 0x780) = fVar2;
    *(undefined4 *)(iVar8 + 0x778) = 0;
    *(undefined4 *)(iVar8 + 0x77c) = 0x3d800000;
    *(undefined4 *)(iVar8 + 0x78c) = 0x3f800000;
    *(undefined4 *)(iVar8 + 0x790) = 0;
    *(undefined4 *)(iVar8 + 0x784) = 0;
    *(undefined4 *)(iVar8 + 0x788) = 0;
    uVar5 = 0;
    if (cVar4 != '\0') {
      uVar5 = 8;
      DAT_002411f4 = '\0';
    }
    if (DAT_00241460 != 0) {
      if (DAT_00241460 == 2) {
        uVar5 = 4;
      }
      else if (DAT_00241460 == 1) {
        uVar5 = 2;
      }
      DAT_00241460 = 0;
    }
    *(undefined4 *)(&DAT_0022a6fc + DAT_002411f0 * 4) = uVar5;
  }
  *(undefined4 *)(&DAT_0022a71c + DAT_002411f0 * 4) = param_1;
  DAT_002411f0 = DAT_002411f0 + 1 & 7;
  FUN_0010cc70();
  FUN_00118d00();
  iVar8 = DAT_002414d4;
  if (DAT_002414d4 != 0) {
    for (uVar1 = *(ushort *)(DAT_002414d4 + 6); uVar1 != 0xffff;
        uVar1 = *(ushort *)(iVar8 + 0xe + (uint)uVar1 * 8)) {
      iVar6 = *(int *)(iVar8 + 0x10 + (uint)uVar1 * 8);
      bVar7 = *(byte *)(iVar6 + 4);
      if (((bVar7 & 8) != 0) && ((bVar7 & 2) != 0)) {
        *(byte *)(iVar6 + 4) = (bVar7 >> 2 ^ bVar7 & 0xfd) & 1 ^ bVar7 & 0xfd;
      }
    }
  }
  if (DAT_002414bc != 0) {
    FUN_000dd190();
  }
  puVar11 = (undefined4 *)(DAT_0022ddc8 + 0x74c);
  puVar12 = (undefined4 *)(DAT_0022ddc8 + 0x2cc);
  for (iVar8 = 0x120; iVar8 != 0; iVar8 = iVar8 + -1) {
    *puVar12 = *puVar11;
    puVar11 = puVar11 + 1;
    puVar12 = puVar12 + 1;
  }
  *(undefined1 *)(DAT_0022ddcc + 0x794) = *(undefined1 *)(DAT_0022ddcc + 0x795);
  return;
}


