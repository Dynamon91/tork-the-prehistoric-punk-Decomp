// func FUN_00024df0 @ 0x00024DF0 (size 0x54)

void FUN_00024df0(byte param_1)

{
  byte *pbVar1;
  byte in_AL;
  int in_ECX;
  
  param_1 = ~in_AL & *(byte *)(in_ECX + 0xb) | param_1;
  *(byte *)(in_ECX + 0xb) = param_1;
  if ((*(uint *)(in_ECX + 4) >> 3 & 1) != 0) {
    if ((param_1 & 1) == 0) {
      pbVar1 = (byte *)(*(int *)(in_ECX + 0x14) + 0x28);
      *pbVar1 = *pbVar1 & 0xbf;
    }
    else {
      pbVar1 = (byte *)(*(int *)(in_ECX + 0x14) + 0x28);
      *pbVar1 = *pbVar1 | 0x40;
    }
  }
  if ((*(uint *)(in_ECX + 4) >> 0x1c & 1) != 0) {
    if ((*(byte *)(in_ECX + 0xb) & 1) != 0) {
      *(undefined1 *)(*(int *)(*(int *)(in_ECX + 0x24) + 0xc) + 0xb) = 0;
      return;
    }
    *(undefined1 *)(*(int *)(*(int *)(in_ECX + 0x24) + 0xc) + 0xb) = 0;
  }
  return;
}


