// func FUN_000561a0 @ 0x000561A0 (size 0x6C)

void FUN_000561a0(void)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *unaff_EBX;
  undefined4 *puVar3;
  undefined4 local_50 [10];
  undefined1 local_28 [40];
  
  iVar1 = 0;
  LOCK();
  if (DAT_0022aab8 == 0) {
    DAT_0022aab8 = 1;
  }
  else {
    iVar1 = DAT_0022aab8;
  }
  UNLOCK();
  while (iVar1 != 0) {
    FUN_0012ec0e(0);
    iVar1 = 0;
    LOCK();
    if (DAT_0022aab8 == 0) {
      DAT_0022aab8 = 1;
    }
    else {
      iVar1 = DAT_0022aab8;
    }
    UNLOCK();
  }
  puVar2 = (undefined4 *)FUN_00057560(local_28);
  puVar3 = local_50;
  for (iVar1 = 10; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar3 = *puVar2;
    puVar2 = puVar2 + 1;
    puVar3 = puVar3 + 1;
  }
  LOCK();
  DAT_0022aab8 = 0;
  UNLOCK();
  puVar2 = local_50;
  for (iVar1 = 10; iVar1 != 0; iVar1 = iVar1 + -1) {
    *unaff_EBX = *puVar2;
    puVar2 = puVar2 + 1;
    unaff_EBX = unaff_EBX + 1;
  }
  return;
}


