// func FUN_00022970 @ 0x00022970 (size 0x4C)

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00022970(float *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float10 fVar3;
  
  fVar3 = (float10)FUN_00021640();
  fVar3 = SQRT((float10)_DAT_0020df98 / fVar3);
  fVar1 = param_2[1];
  fVar2 = param_2[2];
  *param_1 = (float)(fVar3 * (float10)*param_2);
  param_1[1] = (float)(fVar3 * (float10)fVar1);
  param_1[2] = (float)(fVar3 * (float10)fVar2);
  return;
}


