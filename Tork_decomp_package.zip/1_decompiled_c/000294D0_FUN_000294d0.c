// func FUN_000294d0 @ 0x000294D0 (size 0x2C)

float10 FUN_000294d0(void)

{
  return (float10)*(float *)(*(int *)(*(int *)(DAT_0022a6c4 + 0x14) + 0x1c) + 0x28);
}


