// func FUN_00045f10 @ 0x00045F10 (size 0x32)

void FUN_00045f10(void)

{
  undefined4 *puVar1;
  int *in_EAX;
  undefined4 *unaff_ESI;
  
  FUN_00045f50();
  puVar1 = (undefined4 *)(*in_EAX + (uint)*(ushort *)((int)in_EAX + 6) * 0xc);
  *puVar1 = *unaff_ESI;
  puVar1[1] = unaff_ESI[1];
  puVar1[2] = unaff_ESI[2];
  *(short *)((int)in_EAX + 6) = *(short *)((int)in_EAX + 6) + 1;
  return;
}


