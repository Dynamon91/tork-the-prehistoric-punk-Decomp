// func FUN_00056830 @ 0x00056830 (size 0x87)

undefined4 FUN_00056830(int param_1)

{
  uint uVar1;
  int iVar2;
  int unaff_EBX;
  uint uVar3;
  int iVar4;
  
  uVar1 = *(uint *)(unaff_EBX + 0x35c);
  uVar3 = *(uint *)(*(int *)(unaff_EBX + 0x2c) + 4) & 0x7ffffffc;
  iVar4 = (((uVar3 - param_1) + -0x11 + uVar1) / uVar1 - 1) * uVar1;
  if (0 < iVar4) {
    iVar2 = FUN_00057a80(0);
    if (iVar2 == *(int *)(unaff_EBX + 0x2c) + uVar3) {
      FUN_00057a80(-iVar4);
      iVar4 = FUN_00057a80(0);
      if ((iVar4 != -1) && (iVar2 = iVar2 - iVar4, iVar2 != 0)) {
        *(int *)(unaff_EBX + 0x368) = *(int *)(unaff_EBX + 0x368) - iVar2;
        *(uint *)(*(int *)(unaff_EBX + 0x2c) + 4) = uVar3 - iVar2 | 1;
        return 1;
      }
    }
  }
  return 0;
}


