// func FUN_00045820 @ 0x00045820 (size 0x35)

void FUN_00045820(void)

{
  undefined4 *puVar1;
  int in_EAX;
  undefined4 *unaff_ESI;
  
  FUN_00045f50();
  puVar1 = (undefined4 *)(*(int *)(in_EAX + 0x10) + (uint)*(ushort *)(in_EAX + 0x16) * 0xc);
  *puVar1 = *unaff_ESI;
  puVar1[1] = unaff_ESI[1];
  puVar1[2] = unaff_ESI[2];
  *(short *)(in_EAX + 0x16) = *(short *)(in_EAX + 0x16) + 1;
  return;
}


